package com.corykui.wifispeed.records;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Foreground owner of background location collection. It intentionally requests
 * one best provider instead of GPS/network/passive simultaneously; mixing several
 * providers caused alternating fixes, inflated distance and false zig-zags.
 */
public class TrackingForegroundService extends Service {
    private static final String CHANNEL_ID = "ride_tracking";
    private static final int NOTIFICATION_ID = 1401;
    private static final long WIFI_INTERVAL_MS = 30_000L;
    private static final long WATCHDOG_INTERVAL_MS = 15_000L;
    private static final long RESTART_ALARM_MS = 2L * 60L * 1000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private LocationManager locationManager;
    private WifiManager wifiManager;
    private NotificationManager notificationManager;
    private boolean wifiReceiverRegistered;
    private boolean providerReceiverRegistered;
    private PowerManager.WakeLock wakeLock;
    private String requestedProvider = "none";
    private long lastLocationElapsedMs = 0L;

    private final LocationListener locationListener = new LocationListener() {
        @Override public void onLocationChanged(Location location) {
            if (!TrackingStateStore.isActive(TrackingForegroundService.this)) return;
            lastLocationElapsedMs = SystemClock.elapsedRealtime();
            TrackingStateStore.setServiceHeartbeat(TrackingForegroundService.this);
            long seq = TrackingStateStore.appendLocation(TrackingForegroundService.this, location);
            Intent update = new Intent(MainActivity.ACTION_BACKGROUND_LOCATION);
            update.setPackage(getPackageName());
            update.putExtra("location", location);
            update.putExtra("journalSeq", seq);
            sendBroadcast(update);
            updateNotification(location);
        }
        @Override public void onProviderEnabled(String provider) { startLocationUpdates(); }
        @Override public void onProviderDisabled(String provider) { startLocationUpdates(); }
        @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
    };

    private final BroadcastReceiver wifiReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            Intent update = new Intent(MainActivity.ACTION_BACKGROUND_WIFI);
            update.setPackage(getPackageName());
            sendBroadcast(update);
        }
    };

    private final BroadcastReceiver providerReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            handler.postDelayed(() -> startLocationUpdates(), 500L);
        }
    };

    private final Runnable wifiRunnable = new Runnable() {
        @Override public void run() {
            if (!TrackingStateStore.isActive(TrackingForegroundService.this)) return;
            try {
                if (wifiManager != null && wifiManager.isWifiEnabled() && hasWifiPermissions()) {
                    wifiManager.startScan();
                }
            } catch (Exception ignored) { }
            handler.postDelayed(this, WIFI_INTERVAL_MS);
        }
    };

    private final Runnable watchdogRunnable = new Runnable() {
        @Override public void run() {
            if (!TrackingStateStore.isActive(TrackingForegroundService.this)) {
                stopSelf();
                return;
            }
            TrackingStateStore.setServiceHeartbeat(TrackingForegroundService.this);
            ensureWakeLock();
            long age = lastLocationElapsedMs == 0L ? Long.MAX_VALUE
                    : SystemClock.elapsedRealtime() - lastLocationElapsedMs;
            if (age > 25_000L) startLocationUpdates();
            if (!isLocationEnabled()) updateWaitingNotification();
            scheduleRestartAlarm();
            handler.postDelayed(this, WATCHDOG_INTERVAL_MS);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, createNotification("正在启动持续定位…"));
        if (!TrackingStateStore.isActive(this)) {
            stopSelf();
            return;
        }
        ensureWakeLock();
        registerWifiReceiver();
        registerProviderReceiver();
        startLocationUpdates();
        handler.post(wifiRunnable);
        handler.post(watchdogRunnable);
        scheduleRestartAlarm();
        TrackingStateStore.setServiceHeartbeat(this);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (!TrackingStateStore.isActive(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        ensureWakeLock();
        startLocationUpdates();
        scheduleRestartAlarm();
        return START_REDELIVER_INTENT;
    }

    private Notification createNotification(String detail) {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return builder
                .setContentTitle("小魁WiFi骑行正在记录")
                .setContentText(detail)
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build();
    }

    private void updateNotification(Location location) {
        if (notificationManager == null || location == null) return;
        String detail = "后台持续记录";
        if (location.hasAccuracy()) detail += String.format(Locale.CHINA, " · 精度约 %.0f m", location.getAccuracy());
        if (location.hasSpeed()) detail += String.format(Locale.CHINA, " · %.1f km/h", location.getSpeed() * 3.6f);
        notificationManager.notify(NOTIFICATION_ID, createNotification(detail));
    }

    private void updateWaitingNotification() {
        if (notificationManager != null)
            notificationManager.notify(NOTIFICATION_ID, createNotification("系统位置服务已关闭，开启后会自动继续记录"));
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "轨迹记录", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("锁屏和后台轨迹记录通知");
        channel.setShowBadge(false);
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.createNotificationChannel(channel);
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasWifiPermissions() {
        return hasLocationPermission() && (Build.VERSION.SDK_INT < 33 ||
                checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED);
    }

    private boolean isLocationEnabled() {
        if (locationManager == null) return false;
        try {
            if (Build.VERSION.SDK_INT >= 28) return locationManager.isLocationEnabled();
            return !locationManager.getProviders(true).isEmpty();
        } catch (Exception ignored) { return false; }
    }

    private void startLocationUpdates() {
        if (locationManager == null || !hasLocationPermission() || !TrackingStateStore.isActive(this)) return;
        try { locationManager.removeUpdates(locationListener); } catch (Exception ignored) { }
        requestedProvider = chooseSingleBestProvider();
        if (requestedProvider == null) {
            requestedProvider = "none";
            updateWaitingNotification();
            return;
        }
        try {
            locationManager.requestLocationUpdates(requestedProvider, 1000L, 0f,
                    locationListener, Looper.getMainLooper());
        } catch (Exception ignored) {
            requestedProvider = "none";
            updateWaitingNotification();
        }
    }

    private String chooseSingleBestProvider() {
        if (locationManager == null || !isLocationEnabled()) return null;
        List<String> enabled;
        try { enabled = new ArrayList<>(locationManager.getProviders(true)); }
        catch (Exception e) { enabled = new ArrayList<>(); }
        if (enabled.isEmpty()) return null;
        // Samsung exposes a fused provider. Prefer it because it already merges GNSS/network
        // and avoids alternating coordinates from several independently registered listeners.
        for (String provider : enabled) {
            if (provider != null && provider.toLowerCase(Locale.US).contains("fused")) return provider;
        }
        try {
            Criteria criteria = new Criteria();
            criteria.setAccuracy(Criteria.ACCURACY_FINE);
            criteria.setPowerRequirement(Criteria.POWER_HIGH);
            String best = locationManager.getBestProvider(criteria, true);
            if (best != null) return best;
        } catch (Exception ignored) { }
        if (enabled.contains(LocationManager.GPS_PROVIDER)) return LocationManager.GPS_PROVIDER;
        if (enabled.contains(LocationManager.NETWORK_PROVIDER)) return LocationManager.NETWORK_PROVIDER;
        for (String provider : enabled) {
            if (!LocationManager.PASSIVE_PROVIDER.equals(provider)) return provider;
        }
        return null;
    }

    private void registerWifiReceiver() {
        if (wifiReceiverRegistered) return;
        IntentFilter filter = new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(wifiReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(wifiReceiver, filter);
        wifiReceiverRegistered = true;
    }

    private void registerProviderReceiver() {
        if (providerReceiverRegistered) return;
        IntentFilter filter = new IntentFilter();
        filter.addAction(LocationManager.PROVIDERS_CHANGED_ACTION);
        if (Build.VERSION.SDK_INT >= 19) filter.addAction(LocationManager.MODE_CHANGED_ACTION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(providerReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(providerReceiver, filter);
        providerReceiverRegistered = true;
    }

    private void ensureWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) return;
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager == null) return;
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                getPackageName() + ":ride-location");
        wakeLock.setReferenceCounted(false);
        try { wakeLock.acquire(); } catch (Exception ignored) { }
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        if (TrackingStateStore.isActive(this)) scheduleRestartAlarm();
        super.onTaskRemoved(rootIntent);
    }

    private void scheduleRestartAlarm() {
        if (!TrackingStateStore.isActive(this)) return;
        try {
            Intent restart = new Intent(this, TrackingRestartReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(this, 1402, restart,
                    PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
            AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
            if (am != null) am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    SystemClock.elapsedRealtime() + RESTART_ALARM_MS, pi);
        } catch (Exception ignored) { }
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(wifiRunnable);
        handler.removeCallbacks(watchdogRunnable);
        if (locationManager != null) {
            try { locationManager.removeUpdates(locationListener); } catch (Exception ignored) { }
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) { }
        }
        if (wifiReceiverRegistered) {
            try { unregisterReceiver(wifiReceiver); } catch (Exception ignored) { }
        }
        if (providerReceiverRegistered) {
            try { unregisterReceiver(providerReceiver); } catch (Exception ignored) { }
        }
        if (TrackingStateStore.isActive(this)) scheduleRestartAlarm();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
