package com.corykui.wifispeed.records;

import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;
import android.os.SystemClock;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Persists whether a ride is actively recording and journals foreground-service
 * locations so a killed Activity/process can reconstruct the missing segment.
 */
public final class TrackingStateStore {
    private static final String PREFS = "tracking_runtime_state";
    private static final String KEY_ACTIVE = "active";
    private static final String KEY_NEXT_SEQ = "next_location_seq";
    private static final String KEY_CONSUMED_SEQ = "consumed_location_seq";
    private static final String KEY_SERVICE_HEARTBEAT = "service_heartbeat_wall_ms";
    private static final String KEY_SESSION_STARTED = "session_started_wall_ms";
    private static final String KEY_LAST_LOCATION_WALL = "last_location_wall_ms";
    private static final String KEY_LAST_PROVIDER = "last_provider";
    private static final String JOURNAL = "tracking_locations.jsonl";
    private static final String ACTIVE_MARKER = "tracking_active.flag";
    private static final long COMPACT_AT_BYTES = 32L * 1024L * 1024L;
    private static final int MAX_RETAINED_LINES = 100000;

    private TrackingStateStore() { }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean isActive(Context context) {
        return prefs(context).getBoolean(KEY_ACTIVE, false) ||
                new File(context.getFilesDir(), ACTIVE_MARKER).exists();
    }

    public static void beginSession(Context context) {
        synchronized (TrackingStateStore.class) {
            prefs(context).edit()
                    .putBoolean(KEY_ACTIVE, true)
                    .putLong(KEY_SESSION_STARTED, System.currentTimeMillis())
                    .putLong(KEY_CONSUMED_SEQ, 0L)
                    .putLong(KEY_NEXT_SEQ, 0L)
                    .commit();
            try { new File(context.getFilesDir(), ACTIVE_MARKER).createNewFile(); } catch (Exception ignored) { }
            File file = journalFile(context);
            if (file.exists()) file.delete();
        }
    }

    public static void setActive(Context context, boolean active) {
        prefs(context).edit().putBoolean(KEY_ACTIVE, active).commit();
        File marker = new File(context.getFilesDir(), ACTIVE_MARKER);
        if (active) {
            try { marker.createNewFile(); } catch (Exception ignored) { }
        } else if (marker.exists()) marker.delete();
    }

    public static long getSessionStartedWallMs(Context context) {
        return prefs(context).getLong(KEY_SESSION_STARTED, 0L);
    }

    public static void setServiceHeartbeat(Context context) {
        prefs(context).edit().putLong(KEY_SERVICE_HEARTBEAT, System.currentTimeMillis()).apply();
    }

    public static long getServiceHeartbeatWallMs(Context context) {
        return prefs(context).getLong(KEY_SERVICE_HEARTBEAT, 0L);
    }

    public static long getLastConsumedSeq(Context context) {
        return prefs(context).getLong(KEY_CONSUMED_SEQ, 0L);
    }

    public static long getLastJournalLocationWallMs(Context context) {
        return prefs(context).getLong(KEY_LAST_LOCATION_WALL, 0L);
    }

    public static String getLastJournalProvider(Context context) {
        return prefs(context).getString(KEY_LAST_PROVIDER, "none");
    }

    public static void markConsumed(Context context, long seq) {
        if (seq <= 0L) return;
        SharedPreferences p = prefs(context);
        long old = p.getLong(KEY_CONSUMED_SEQ, 0L);
        if (seq > old) p.edit().putLong(KEY_CONSUMED_SEQ, seq).apply();
    }

    private static File journalFile(Context context) {
        return new File(context.getFilesDir(), JOURNAL);
    }

    public static long getJournalBytes(Context context) {
        File file = journalFile(context);
        return file.exists() ? file.length() : 0L;
    }

    public static long appendLocation(Context context, Location location) {
        if (location == null) return 0L;
        synchronized (TrackingStateStore.class) {
            SharedPreferences p = prefs(context);
            long last = p.getLong(KEY_NEXT_SEQ, 0L);
            long wallBased = System.currentTimeMillis() * 1000L + (SystemClock.elapsedRealtime() % 1000L);
            long seq = Math.max(last + 1L, wallBased);
            try {
                JSONObject item = new JSONObject();
                item.put("seq", seq);
                item.put("provider", location.getProvider() == null ? "unknown" : location.getProvider());
                item.put("latitude", location.getLatitude());
                item.put("longitude", location.getLongitude());
                item.put("timeMs", location.getTime());
                item.put("elapsedRealtimeNanos", location.getElapsedRealtimeNanos());
                if (location.hasAccuracy()) item.put("accuracyMeters", location.getAccuracy());
                if (location.hasSpeed()) item.put("speedMps", location.getSpeed());
                if (android.os.Build.VERSION.SDK_INT >= 26 && location.hasSpeedAccuracy())
                    item.put("speedAccuracyMps", location.getSpeedAccuracyMetersPerSecond());
                if (location.hasBearing()) item.put("bearingDegrees", location.getBearing());
                if (location.hasAltitude()) item.put("altitudeMeters", location.getAltitude());
                File file = journalFile(context);
                try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                        new FileOutputStream(file, true), StandardCharsets.UTF_8))) {
                    writer.write(item.toString());
                    writer.newLine();
                }
                p.edit().putLong(KEY_NEXT_SEQ, seq)
                        .putLong(KEY_LAST_LOCATION_WALL, System.currentTimeMillis())
                        .putString(KEY_LAST_PROVIDER, location.getProvider() == null ? "unknown" : location.getProvider())
                        .apply();
                if (file.length() >= COMPACT_AT_BYTES) compactLocked(context);
                return seq;
            } catch (Exception ignored) {
                return 0L;
            }
        }
    }

    public static List<JournalLocation> readPending(Context context) {
        synchronized (TrackingStateStore.class) {
            ArrayList<JournalLocation> result = new ArrayList<>();
            File file = journalFile(context);
            if (!file.exists()) return result;
            long consumed = getLastConsumedSeq(context);
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                    new FileInputStream(file), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.trim().isEmpty()) continue;
                    JSONObject item = new JSONObject(line);
                    long seq = item.optLong("seq", 0L);
                    if (seq <= consumed) continue;
                    Location location = new Location(item.optString("provider", "journal"));
                    location.setLatitude(item.getDouble("latitude"));
                    location.setLongitude(item.getDouble("longitude"));
                    location.setTime(item.optLong("timeMs", System.currentTimeMillis()));
                    long elapsed = item.optLong("elapsedRealtimeNanos", 0L);
                    if (elapsed > 0L) location.setElapsedRealtimeNanos(elapsed);
                    if (item.has("accuracyMeters")) location.setAccuracy((float)item.optDouble("accuracyMeters", 0.0));
                    if (item.has("speedMps")) location.setSpeed((float)item.optDouble("speedMps", 0.0));
                    if (android.os.Build.VERSION.SDK_INT >= 26 && item.has("speedAccuracyMps"))
                        location.setSpeedAccuracyMetersPerSecond((float)item.optDouble("speedAccuracyMps", 0.0));
                    if (item.has("bearingDegrees")) location.setBearing((float)item.optDouble("bearingDegrees", 0.0));
                    if (item.has("altitudeMeters")) location.setAltitude(item.optDouble("altitudeMeters", 0.0));
                    result.add(new JournalLocation(seq, location));
                }
            } catch (Exception ignored) { }
            return result;
        }
    }

    public static void compact(Context context) {
        synchronized (TrackingStateStore.class) {
            compactLocked(context);
        }
    }

    private static void compactLocked(Context context) {
        File source = journalFile(context);
        if (!source.exists()) return;
        long consumed = getLastConsumedSeq(context);
        ArrayList<String> retained = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                new FileInputStream(source), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                try {
                    long seq = new JSONObject(line).optLong("seq", 0L);
                    if (seq > consumed) retained.add(line);
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { return; }
        if (retained.size() > MAX_RETAINED_LINES) {
            retained = new ArrayList<>(retained.subList(retained.size() - MAX_RETAINED_LINES, retained.size()));
        }
        File temp = new File(context.getFilesDir(), JOURNAL + ".tmp");
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(temp, false), StandardCharsets.UTF_8))) {
            for (String line : retained) {
                writer.write(line);
                writer.newLine();
            }
        } catch (Exception ignored) {
            temp.delete();
            return;
        }
        if (source.exists()) source.delete();
        temp.renameTo(source);
    }

    public static final class JournalLocation {
        public final long seq;
        public final Location location;
        JournalLocation(long seq, Location location) {
            this.seq = seq;
            this.location = location;
        }
    }
}
