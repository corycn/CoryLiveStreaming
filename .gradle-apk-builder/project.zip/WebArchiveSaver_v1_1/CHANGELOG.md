# Changelog

## 1.1.0

- Fixed empty CSS in single-file HTML exports.
- Added self-contained `index.html` to ZIP exports.
- Added optional pre-expansion of collapsible content.
- Added script-free checkbox/label toggles for `.queryListUL` panels, including MHTML.
- Disabled original page scripts by default.
- Added regression checks based on the supplied China Telecom tariff archive.

## 1.0.0

- Initial release.
