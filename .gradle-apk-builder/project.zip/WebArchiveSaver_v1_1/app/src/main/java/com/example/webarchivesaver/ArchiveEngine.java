package com.example.webarchivesaver;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Comment;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.DataNode;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public final class ArchiveEngine {
    public interface ProgressListener {
        void onProgress(String message, int completed, int totalHint);
    }

    public interface CookieProvider {
        String cookiesFor(String url);
    }

    private static final Pattern CSS_URL = Pattern.compile("url\\(\\s*(['\\\"]?)(.*?)\\1\\s*\\)", Pattern.CASE_INSENSITIVE);
    private static final Pattern CSS_IMPORT = Pattern.compile("@import\\s+(?:url\\(\\s*)?(['\\\"]?)([^'\\\")\\s;]+)\\1\\s*\\)?([^;]*);", Pattern.CASE_INSENSITIVE);
    private static final Pattern CHARSET = Pattern.compile("charset=([^;\\s]+)", Pattern.CASE_INSENSITIVE);

    private final String userAgent;
    private final CookieProvider cookieProvider;
    private final ProgressListener listener;

    public ArchiveEngine(String userAgent, CookieProvider cookieProvider, ProgressListener listener) {
        this.userAgent = userAgent == null ? "Mozilla/5.0 Android WebArchiveSaver/1.0" : userAgent;
        this.cookieProvider = cookieProvider;
        this.listener = listener;
    }

    public ArchiveResult archive(String pageUrl, String capturedHtml, File workRoot, ArchiveOptions options) throws IOException {
        if (capturedHtml == null || capturedHtml.isBlank()) {
            throw new IOException("页面 DOM 为空，可能是网页阻止了脚本执行或页面尚未加载完成。");
        }
        if (!workRoot.exists() && !workRoot.mkdirs()) {
            throw new IOException("无法创建临时目录：" + workRoot);
        }

        File session = new File(workRoot, "archive_" + System.currentTimeMillis());
        if (!session.mkdirs()) throw new IOException("无法创建归档目录");

        Context ctx = new Context(pageUrl, session, options);
        Document doc = Jsoup.parse(capturedHtml, pageUrl);
        doc.outputSettings().prettyPrint(false).charset(StandardCharsets.UTF_8);
        ensureMetaCharset(doc);
        normalizeNavigationUrls(doc, pageUrl);

        progress("正在分析页面资源…", 0, 0);
        if (options.mode == ArchiveOptions.Mode.SINGLE_HTML) {
            buildSingleHtml(doc, ctx);
            appendReportComment(doc, ctx);
            String name = safePageName(pageUrl) + "_offline.html";
            File out = new File(session, name);
            writeUtf8(out, doc.outerHtml());
            deleteRecursivelyQuietly(ctx.downloadsDir);
            return new ArchiveResult(out, name, "text/html", ctx.savedCount, ctx.failures.size(), ctx.totalBytes);
        }

        File packageDir = new File(session, "package");
        File assetsDir = new File(packageDir, "assets");
        if (!assetsDir.mkdirs()) throw new IOException("无法创建资源目录");
        ctx.assetsDir = assetsDir;

        // ZIP 内同时提供两个入口：
        // 1) index.html：资源完全内嵌，直接从 content:// 或 file:// 打开也能保持 UI；
        // 2) index-assets.html：传统 HTML + assets 目录，方便检查和二次编辑。
        Document selfContained = doc.clone();
        buildSingleHtml(selfContained, ctx);

        Document assetBased = doc.clone();
        buildZipPackage(assetBased, ctx);

        appendReportComment(selfContained, ctx);
        writeUtf8(new File(packageDir, "index.html"), selfContained.outerHtml());
        writeUtf8(new File(packageDir, "index-assets.html"), assetBased.outerHtml());
        writeUtf8(new File(packageDir, "archive-report.txt"), ctx.reportText());
        String name = safePageName(pageUrl) + "_offline.zip";
        File zip = new File(session, name);
        zipDirectory(packageDir, zip);
        deleteRecursivelyQuietly(packageDir);
        deleteRecursivelyQuietly(ctx.downloadsDir);
        return new ArchiveResult(zip, name, "application/zip", ctx.savedCount, ctx.failures.size(), ctx.totalBytes);
    }

    private void buildSingleHtml(Document doc, Context ctx) {
        inlineStylesheets(doc, ctx);
        rewriteInlineCss(doc, ctx, true);
        embedElementResources(doc, ctx, true);
        processScripts(doc, ctx, true);
        doc.select("base").remove();
    }

    private void buildZipPackage(Document doc, Context ctx) {
        localizeStylesheets(doc, ctx);
        rewriteInlineCss(doc, ctx, false);
        embedElementResources(doc, ctx, false);
        processScripts(doc, ctx, false);
        doc.select("base").remove();
    }

    private void inlineStylesheets(Document doc, Context ctx) {
        for (Element link : new ArrayList<>(doc.select("link[href]"))) {
            String rel = link.attr("rel").toLowerCase(Locale.ROOT);
            String as = link.attr("as").toLowerCase(Locale.ROOT);
            String abs = absolute(ctx.pageUrl, link.attr("href"));
            if (abs == null) continue;
            if (rel.contains("stylesheet") || (rel.contains("preload") && "style".equals(as))) {
                try {
                    String css = ctx.inlineCss(abs, new HashSet<>());
                    Element style = new Element("style");
                    style.attr("data-archived-from", abs);
                    if (link.hasAttr("media")) style.attr("media", link.attr("media"));
                    style.appendChild(new DataNode(css));
                    link.replaceWith(style);
                } catch (Exception e) {
                    ctx.fail(abs, e);
                }
            } else if (isIconRel(rel) || rel.contains("manifest") || rel.contains("preload")) {
                replaceAttrWithEmbedded(link, "href", abs, ctx);
            }
        }
    }

    private void localizeStylesheets(Document doc, Context ctx) {
        for (Element link : doc.select("link[href]")) {
            String rel = link.attr("rel").toLowerCase(Locale.ROOT);
            String as = link.attr("as").toLowerCase(Locale.ROOT);
            String abs = absolute(ctx.pageUrl, link.attr("href"));
            if (abs == null) continue;
            try {
                if (rel.contains("stylesheet") || (rel.contains("preload") && "style".equals(as))) {
                    link.attr("href", "assets/" + ctx.localizeCss(abs, new HashSet<>()));
                } else if (isIconRel(rel) || rel.contains("manifest") || rel.contains("preload")) {
                    link.attr("href", "assets/" + ctx.localizeBinary(abs));
                }
            } catch (Exception e) {
                ctx.fail(abs, e);
            }
        }
    }

    private static boolean isIconRel(String rel) {
        return rel.contains("icon") || rel.contains("apple-touch-icon") || rel.contains("mask-icon");
    }

    private void rewriteInlineCss(Document doc, Context ctx, boolean inline) {
        for (Element style : doc.select("style")) {
            String base = style.hasAttr("data-archived-from") ? style.attr("data-archived-from") : ctx.pageUrl;
            try {
                // 必须先读取 CSS，再清空节点。Java 会先求值 style.empty()，旧写法因此把所有 <style> 变成空标签。
                String rawCss = style.data();
                String processedCss = ctx.processCss(rawCss, base, inline, inline ? "" : "assets/", new HashSet<>());
                style.empty();
                style.appendChild(new DataNode(processedCss));
            } catch (Exception e) {
                ctx.fail(base + "#inline-style", e);
            }
        }
        for (Element el : doc.select("[style]")) {
            try {
                el.attr("style", ctx.processCss(el.attr("style"), ctx.pageUrl, inline,
                        inline ? "" : "assets/", new HashSet<>()));
            } catch (Exception e) {
                ctx.fail(ctx.pageUrl + "#style-attribute", e);
            }
        }
    }

    private void embedElementResources(Document doc, Context ctx, boolean inline) {
        Map<String, String> selectors = new LinkedHashMap<>();
        selectors.put("img[src]", "src");
        selectors.put("input[type=image][src]", "src");
        selectors.put("video[poster]", "poster");
        selectors.put("object[data]", "data");
        selectors.put("embed[src]", "src");
        selectors.put("track[src]", "src");
        selectors.put("audio[src]", "src");
        selectors.put("video[src]", "src");
        selectors.put("source[src]", "src");

        for (Map.Entry<String, String> entry : selectors.entrySet()) {
            for (Element el : doc.select(entry.getKey())) {
                if (!ctx.options.includeMedia && isAudioVideoResource(el)) continue;
                String attr = entry.getValue();
                String abs = absolute(ctx.pageUrl, el.attr(attr));
                if (abs == null) continue;
                try {
                    String replacement = inline ? ctx.inlineBinary(abs) : "assets/" + ctx.localizeBinary(abs);
                    el.attr(attr, replacement);
                } catch (Exception e) {
                    ctx.fail(abs, e);
                }
            }
        }

        for (Element el : doc.select("img[srcset], source[srcset]")) {
            if (!ctx.options.includeMedia && isAudioVideoResource(el)) continue;
            el.attr("srcset", rewriteSrcset(el.attr("srcset"), ctx, inline));
        }

        // Cross-origin iframe DOM is not available to the parent WebView. Keep it online and report it.
        for (Element iframe : doc.select("iframe[src]")) {
            String abs = absolute(ctx.pageUrl, iframe.attr("src"));
            if (abs != null) ctx.note("iframe 未递归归档：" + abs);
        }
    }

    private String rewriteSrcset(String srcset, Context ctx, boolean inline) {
        if (srcset == null || srcset.isBlank() || srcset.trim().startsWith("data:")) return srcset;
        String[] parts = srcset.split(",");
        List<String> out = new ArrayList<>();
        for (String part : parts) {
            String p = part.trim();
            if (p.isEmpty()) continue;
            int space = firstWhitespace(p);
            String raw = space < 0 ? p : p.substring(0, space);
            String descriptor = space < 0 ? "" : p.substring(space).trim();
            String abs = absolute(ctx.pageUrl, raw);
            if (abs == null) {
                out.add(p);
                continue;
            }
            try {
                String repl = inline ? ctx.inlineBinary(abs) : "assets/" + ctx.localizeBinary(abs);
                out.add(repl + (descriptor.isEmpty() ? "" : " " + descriptor));
            } catch (Exception e) {
                ctx.fail(abs, e);
                out.add(p);
            }
        }
        return String.join(", ", out);
    }

    private static int firstWhitespace(String value) {
        for (int i = 0; i < value.length(); i++) if (Character.isWhitespace(value.charAt(i))) return i;
        return -1;
    }

    private static boolean isAudioVideoResource(Element el) {
        String tag = el.tagName();
        if (tag.equals("audio") || tag.equals("video") || tag.equals("track")) return true;
        if (tag.equals("source")) {
            Element parent = el.parent();
            return parent != null && (parent.tagName().equals("audio") || parent.tagName().equals("video"));
        }
        return false;
    }

    private void processScripts(Document doc, Context ctx, boolean inline) {
        for (Element script : doc.select("script[src]")) {
            String abs = absolute(ctx.pageUrl, script.attr("src"));
            if (abs == null) continue;
            if (!ctx.options.includeScripts) {
                script.remove();
                continue;
            }
            try {
                if (inline) {
                    Resource r = ctx.fetch(abs);
                    if (!isTextLike(r.contentType, abs)) throw new IOException("脚本不是文本资源");
                    script.removeAttr("src");
                    script.removeAttr("integrity");
                    script.removeAttr("crossorigin");
                    script.attr("data-archived-from", abs);
                    script.empty().appendChild(new DataNode(decodeText(r)));
                } else {
                    script.attr("src", "assets/" + ctx.localizeBinary(abs));
                    script.removeAttr("integrity");
                    script.removeAttr("crossorigin");
                }
            } catch (Exception e) {
                ctx.fail(abs, e);
            }
        }
    }

    private void replaceAttrWithEmbedded(Element el, String attr, String abs, Context ctx) {
        try {
            el.attr(attr, ctx.inlineBinary(abs));
        } catch (Exception e) {
            ctx.fail(abs, e);
        }
    }

    private static void normalizeNavigationUrls(Document doc, String pageUrl) {
        String[][] attrs = {
                {"a[href]", "href"}, {"form[action]", "action"}, {"area[href]", "href"},
                {"blockquote[cite]", "cite"}, {"q[cite]", "cite"}, {"del[cite]", "cite"},
                {"ins[cite]", "cite"}
        };
        for (String[] pair : attrs) {
            for (Element el : doc.select(pair[0])) {
                String abs = absolute(pageUrl, el.attr(pair[1]));
                if (abs != null) el.attr(pair[1], abs);
            }
        }
    }

    private static void ensureMetaCharset(Document doc) {
        if (doc.head() == null) doc.prependElement("head");
        doc.select("meta[charset]").remove();
        doc.head().prependElement("meta").attr("charset", "utf-8");
        doc.head().prependElement("meta").attr("name", "generator").attr("content", "WebArchiveSaver Android");
    }

    private static void appendReportComment(Document doc, Context ctx) {
        String report = "\nWebArchiveSaver report\n" + ctx.reportText().replace("--", "—") + "\n";
        doc.appendChild(new Comment(report));
    }

    private void progress(String message, int completed, int totalHint) {
        if (listener != null) listener.onProgress(message, completed, totalHint);
    }

    private final class Context {
        final String pageUrl;
        final File session;
        final ArchiveOptions options;
        final File downloadsDir;
        File assetsDir;
        long totalBytes;
        int savedCount;
        final Map<String, Resource> fetched = new HashMap<>();
        final Map<String, String> localized = new HashMap<>();
        final Map<String, String> localizedCss = new HashMap<>();
        final Map<String, String> inlinedCss = new HashMap<>();
        final List<String> failures = new ArrayList<>();
        final List<String> notes = new ArrayList<>();

        Context(String pageUrl, File session, ArchiveOptions options) throws IOException {
            this.pageUrl = pageUrl;
            this.session = session;
            this.options = options;
            this.downloadsDir = new File(session, "downloads");
            if (!downloadsDir.mkdirs()) throw new IOException("无法创建下载缓存目录");
        }

        Resource fetch(String url) throws IOException {
            String key = stripFragment(url);
            Resource cached = fetched.get(key);
            if (cached != null) return cached;
            if (fetched.size() >= options.maxResources) throw new IOException("资源数量超过上限 " + options.maxResources);
            Resource r = download(key, this);
            fetched.put(key, r);
            totalBytes += r.size;
            savedCount++;
            progress("已抓取 " + savedCount + " 个资源", savedCount, options.maxResources);
            return r;
        }

        String inlineBinary(String url) throws IOException {
            if (url.startsWith("data:")) return url;
            Resource r = fetch(url);
            return "data:" + safeMime(r.contentType, r.finalUrl) + ";base64," + Base64.getEncoder().encodeToString(readBytes(r));
        }

        String localizeBinary(String url) throws IOException {
            String key = stripFragment(url);
            String existing = localized.get(key);
            if (existing != null) return existing;
            Resource r = fetch(key);
            String name = uniqueFileName(r.finalUrl, r.contentType, false);
            copyFile(r.file, new File(assetsDir, name));
            localized.put(key, name);
            return name;
        }

        String inlineCss(String url, Set<String> stack) throws IOException {
            String key = stripFragment(url);
            String existing = inlinedCss.get(key);
            if (existing != null) return existing;
            if (!stack.add(key)) return "/* circular @import skipped: " + key + " */";
            Resource r = fetch(key);
            String css = decodeText(r);
            String processed = processCss(css, r.finalUrl, true, "", stack);
            stack.remove(key);
            inlinedCss.put(key, processed);
            return processed;
        }

        String localizeCss(String url, Set<String> stack) throws IOException {
            String key = stripFragment(url);
            String existing = localizedCss.get(key);
            if (existing != null) return existing;
            if (!stack.add(key)) throw new IOException("检测到循环 CSS @import");
            Resource r = fetch(key);
            String processed = processCss(decodeText(r), r.finalUrl, false, "", stack);
            String name = uniqueFileName(r.finalUrl, "text/css", true);
            writeUtf8(new File(assetsDir, name), processed);
            localizedCss.put(key, name);
            stack.remove(key);
            return name;
        }

        String processCss(String css, String cssBaseUrl, boolean inline, String localPrefix, Set<String> stack) {
            if (css == null || css.isEmpty()) return css;
            String imported = replaceImports(css, cssBaseUrl, inline, localPrefix, stack);
            Matcher m = CSS_URL.matcher(imported);
            StringBuffer sb = new StringBuffer();
            while (m.find()) {
                String raw = m.group(2).trim();
                if (raw.startsWith("data:") || raw.startsWith("blob:") || raw.startsWith("#")) {
                    m.appendReplacement(sb, Matcher.quoteReplacement(m.group(0)));
                    continue;
                }
                String abs = absolute(cssBaseUrl, raw);
                if (abs == null) {
                    m.appendReplacement(sb, Matcher.quoteReplacement(m.group(0)));
                    continue;
                }
                try {
                    String replacement = inline ? inlineBinary(abs) : localPrefix + localizeBinary(abs);
                    m.appendReplacement(sb, Matcher.quoteReplacement("url(\"" + replacement + "\")"));
                } catch (Exception e) {
                    fail(abs, e);
                    m.appendReplacement(sb, Matcher.quoteReplacement(m.group(0)));
                }
            }
            m.appendTail(sb);
            return sb.toString();
        }

        private String replaceImports(String css, String cssBaseUrl, boolean inline, String localPrefix, Set<String> stack) {
            Matcher m = CSS_IMPORT.matcher(css);
            StringBuffer sb = new StringBuffer();
            while (m.find()) {
                String raw = m.group(2).trim();
                String media = m.group(3) == null ? "" : m.group(3).trim();
                String abs = absolute(cssBaseUrl, raw);
                if (abs == null) {
                    m.appendReplacement(sb, Matcher.quoteReplacement(m.group(0)));
                    continue;
                }
                try {
                    String replacement;
                    if (inline) {
                        String child = inlineCss(abs, stack);
                        replacement = media.isEmpty() ? child : "@media " + media + " {\n" + child + "\n}";
                    } else {
                        replacement = "@import url(\"" + localPrefix + localizeCss(abs, stack) + "\")" +
                                (media.isEmpty() ? "" : " " + media) + ";";
                    }
                    m.appendReplacement(sb, Matcher.quoteReplacement(replacement));
                } catch (Exception e) {
                    fail(abs, e);
                    m.appendReplacement(sb, Matcher.quoteReplacement(m.group(0)));
                }
            }
            m.appendTail(sb);
            return sb.toString();
        }

        void fail(String url, Exception e) {
            String msg = url + " — " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
            if (!failures.contains(msg)) failures.add(msg);
        }

        void note(String text) {
            if (!notes.contains(text)) notes.add(text);
        }

        String reportText() {
            StringBuilder b = new StringBuilder();
            b.append("Source: ").append(pageUrl).append('\n');
            b.append("Created: ").append(utcNow()).append('\n');
            b.append("Saved resources: ").append(savedCount).append('\n');
            b.append("Downloaded bytes: ").append(totalBytes).append('\n');
            b.append("Failed resources: ").append(failures.size()).append('\n');
            b.append("\nKnown limitations:\n");
            b.append("- No tool can guarantee 100% capture of DRM, closed shadow DOM, cross-origin iframe DOM, service-worker state, encrypted media, CAPTCHA, or server-side authenticated APIs.\n");
            b.append("- Failed or oversized resources retain their original online URL when possible.\n");
            b.append("- The recommended index.html is a self-contained rendered snapshot; original scripts are disabled unless explicitly selected.\n");
            b.append("- Opening saved scripts can execute page code, reconnect to the website, or remount the app; use only with sites you trust.\n");
            for (String n : notes) b.append("- ").append(n).append('\n');
            if (!failures.isEmpty()) {
                b.append("\nFailures:\n");
                for (String f : failures) b.append("- ").append(f).append('\n');
            }
            return b.toString();
        }
    }

    private Resource download(String url, Context ctx) throws IOException {
        URL current = new URL(url);
        if (!current.getProtocol().equalsIgnoreCase("http") && !current.getProtocol().equalsIgnoreCase("https")) {
            throw new IOException("不支持的协议：" + current.getProtocol());
        }
        HttpURLConnection conn = (HttpURLConnection) current.openConnection();
        conn.setInstanceFollowRedirects(true);
        conn.setConnectTimeout(20_000);
        conn.setReadTimeout(45_000);
        conn.setRequestProperty("User-Agent", userAgent);
        conn.setRequestProperty("Accept", "*/*");
        conn.setRequestProperty("Referer", ctx.pageUrl);
        if (cookieProvider != null) {
            String cookie = cookieProvider.cookiesFor(url);
            if (cookie != null && !cookie.isBlank()) conn.setRequestProperty("Cookie", cookie);
        }
        int code = conn.getResponseCode();
        if (code < 200 || code >= 300) {
            conn.disconnect();
            throw new IOException("HTTP " + code);
        }
        long declared = conn.getContentLengthLong();
        if (declared > ctx.options.maxSingleResourceBytes) {
            conn.disconnect();
            throw new IOException("单个资源超过限制：" + declared + " bytes");
        }
        if (declared > 0 && ctx.totalBytes + declared > ctx.options.maxTotalBytes) {
            conn.disconnect();
            throw new IOException("归档总大小超过限制");
        }
        String type = conn.getContentType();
        URL finalUrl = conn.getURL();
        File temp = new File(ctx.downloadsDir, "dl_" + sha256(url) + ".bin");
        try (InputStream in = new BufferedInputStream(conn.getInputStream());
             OutputStream out = new BufferedOutputStream(new FileOutputStream(temp))) {
            byte[] buf = new byte[16_384];
            int n;
            long count = 0;
            while ((n = in.read(buf)) != -1) {
                count += n;
                if (count > ctx.options.maxSingleResourceBytes) throw new IOException("单个资源超过限制");
                if (ctx.totalBytes + count > ctx.options.maxTotalBytes) throw new IOException("归档总大小超过限制");
                out.write(buf, 0, n);
            }
            return new Resource(finalUrl.toString(), type, temp, count);
        } catch (Exception e) {
            if (temp.exists()) temp.delete();
            throw e;
        } finally {
            conn.disconnect();
        }
    }

    private static final class Resource {
        final String finalUrl;
        final String contentType;
        final File file;
        final long size;

        Resource(String finalUrl, String contentType, File file, long size) {
            this.finalUrl = finalUrl;
            this.contentType = contentType == null ? "application/octet-stream" : contentType;
            this.file = file;
            this.size = size;
        }
    }

    private static byte[] readBytes(Resource resource) throws IOException {
        if (resource.size > Integer.MAX_VALUE) throw new IOException("资源过大，无法载入内存");
        try (InputStream in = new BufferedInputStream(new FileInputStream(resource.file));
             ByteArrayOutputStream out = new ByteArrayOutputStream((int) resource.size)) {
            byte[] buffer = new byte[16_384];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            return out.toByteArray();
        }
    }

    private static String decodeText(Resource resource) throws IOException {
        Charset charset = StandardCharsets.UTF_8;
        Matcher m = CHARSET.matcher(resource.contentType);
        if (m.find()) {
            try { charset = Charset.forName(m.group(1).replace("\"", "").trim()); } catch (Exception ignored) { }
        }
        return new String(readBytes(resource), charset);
    }

    private static boolean isTextLike(String type, String url) {
        String t = type == null ? "" : type.toLowerCase(Locale.ROOT);
        String u = url.toLowerCase(Locale.ROOT);
        return t.startsWith("text/") || t.contains("javascript") || t.contains("json") || t.contains("xml") ||
                u.endsWith(".js") || u.endsWith(".mjs") || u.endsWith(".css") || u.endsWith(".json");
    }

    private static String safeMime(String type, String url) {
        if (type != null && !type.isBlank()) {
            int semicolon = type.indexOf(';');
            String clean = (semicolon >= 0 ? type.substring(0, semicolon) : type).trim();
            if (!clean.isBlank()) return clean;
        }
        String ext = extensionFromUrl(url);
        return switch (ext) {
            case ".png" -> "image/png";
            case ".jpg", ".jpeg" -> "image/jpeg";
            case ".gif" -> "image/gif";
            case ".webp" -> "image/webp";
            case ".svg" -> "image/svg+xml";
            case ".css" -> "text/css";
            case ".js", ".mjs" -> "text/javascript";
            case ".woff" -> "font/woff";
            case ".woff2" -> "font/woff2";
            case ".ttf" -> "font/ttf";
            case ".mp4" -> "video/mp4";
            case ".webm" -> "video/webm";
            case ".mp3" -> "audio/mpeg";
            default -> "application/octet-stream";
        };
    }

    private static String uniqueFileName(String url, String type, boolean forceCss) {
        String ext = forceCss ? ".css" : extensionFromUrl(url);
        if (ext.isEmpty()) ext = extensionFromMime(type);
        if (ext.isEmpty()) ext = ".bin";
        String base = "res_" + sha256(url).substring(0, 20);
        return base + ext;
    }

    private static String extensionFromUrl(String url) {
        try {
            String path = URI.create(url).getPath();
            if (path == null) return "";
            int slash = path.lastIndexOf('/');
            String name = slash >= 0 ? path.substring(slash + 1) : path;
            int dot = name.lastIndexOf('.');
            if (dot >= 0 && name.length() - dot <= 8) {
                String ext = name.substring(dot).toLowerCase(Locale.ROOT);
                if (ext.matches("\\.[a-z0-9]{1,7}")) return ext;
            }
        } catch (Exception ignored) { }
        return "";
    }

    private static String extensionFromMime(String type) {
        String mime = safeMime(type, "");
        return switch (mime) {
            case "text/css" -> ".css";
            case "text/javascript", "application/javascript" -> ".js";
            case "image/png" -> ".png";
            case "image/jpeg" -> ".jpg";
            case "image/gif" -> ".gif";
            case "image/webp" -> ".webp";
            case "image/svg+xml" -> ".svg";
            case "font/woff" -> ".woff";
            case "font/woff2" -> ".woff2";
            case "font/ttf" -> ".ttf";
            case "video/mp4" -> ".mp4";
            case "video/webm" -> ".webm";
            case "audio/mpeg" -> ".mp3";
            case "application/json" -> ".json";
            default -> "";
        };
    }

    private static String absolute(String base, String raw) {
        if (raw == null) return null;
        String v = raw.trim();
        if (v.isEmpty() || v.startsWith("data:") || v.startsWith("blob:") || v.startsWith("javascript:") ||
                v.startsWith("mailto:") || v.startsWith("tel:") || v.startsWith("about:") || v.startsWith("#")) return null;
        try {
            URI result = URI.create(base).resolve(v);
            String scheme = result.getScheme();
            if (scheme == null || !(scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https"))) return null;
            return result.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private static String stripFragment(String url) {
        int hash = url.indexOf('#');
        return hash >= 0 ? url.substring(0, hash) : url;
    }

    private static String safePageName(String url) {
        try {
            String host = URI.create(url).getHost();
            if (host == null || host.isBlank()) host = "webpage";
            return host.replaceAll("[^a-zA-Z0-9._-]", "_");
        } catch (Exception e) {
            return "webpage";
        }
    }

    private static String sha256(String text) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(text.getBytes(StandardCharsets.UTF_8));
            StringBuilder b = new StringBuilder();
            for (byte value : bytes) b.append(String.format(Locale.ROOT, "%02x", value));
            return b.toString();
        } catch (Exception e) {
            return Integer.toHexString(text.hashCode()) + "00000000000000000000";
        }
    }

    private static String utcNow() {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.ROOT);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date());
    }


    private static void copyFile(File source, File destination) throws IOException {
        File parent = destination.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("无法创建目录：" + parent);
        try (InputStream in = new BufferedInputStream(new FileInputStream(source));
             OutputStream out = new BufferedOutputStream(new FileOutputStream(destination))) {
            byte[] buffer = new byte[16_384];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        }
    }

    private static void deleteRecursivelyQuietly(File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteRecursivelyQuietly(child);
        }
        // Best effort cache cleanup. Exported files are not passed here.
        file.delete();
    }

    private static void writeUtf8(File file, String text) throws IOException {
        writeBytes(file, text.getBytes(StandardCharsets.UTF_8));
    }

    private static void writeBytes(File file, byte[] bytes) throws IOException {
        File parent = file.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("无法创建目录：" + parent);
        try (OutputStream out = new BufferedOutputStream(new FileOutputStream(file))) {
            out.write(bytes);
        }
    }

    private static void zipDirectory(File dir, File output) throws IOException {
        try (ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(output)))) {
            zipRecursively(dir, dir, zip);
        }
    }

    private static void zipRecursively(File root, File current, ZipOutputStream zip) throws IOException {
        File[] children = current.listFiles();
        if (children == null) return;
        byte[] buffer = new byte[16_384];
        for (File child : children) {
            if (child.isDirectory()) {
                zipRecursively(root, child, zip);
            } else {
                String name = root.toPath().relativize(child.toPath()).toString().replace(File.separatorChar, '/');
                zip.putNextEntry(new ZipEntry(name));
                try (InputStream in = new BufferedInputStream(new FileInputStream(child))) {
                    int n;
                    while ((n = in.read(buffer)) != -1) zip.write(buffer, 0, n);
                }
                zip.closeEntry();
            }
        }
    }
}
