package com.example.webarchivesaver;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int REQUEST_CREATE_FILE = 2001;
    private static final long MAX_CAPTURE_CHARS = 100L * 1024 * 1024;

    private WebView webView;
    private EditText urlInput;
    private Button loadButton;
    private Button saveHtmlButton;
    private Button saveZipButton;
    private Button saveMhtmlButton;
    private CheckBox includeScripts;
    private CheckBox includeMedia;
    private CheckBox expandBeforeSave;
    private ProgressBar progressBar;
    private TextView statusText;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private CaptureBridge captureBridge;
    private File pendingExport;
    private String pendingMime;
    private String pendingName;
    private boolean busy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
        configureWebView();
        bindActions();
        if (savedInstanceState != null) webView.restoreState(savedInstanceState);
    }

    private void bindViews() {
        webView = findViewById(R.id.webView);
        urlInput = findViewById(R.id.urlInput);
        loadButton = findViewById(R.id.loadButton);
        saveHtmlButton = findViewById(R.id.saveHtmlButton);
        saveZipButton = findViewById(R.id.saveZipButton);
        saveMhtmlButton = findViewById(R.id.saveMhtmlButton);
        includeScripts = findViewById(R.id.includeScripts);
        includeMedia = findViewById(R.id.includeMedia);
        expandBeforeSave = findViewById(R.id.expandBeforeSave);
        progressBar = findViewById(R.id.progressBar);
        statusText = findViewById(R.id.statusText);
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        captureBridge = new CaptureBridge();
        webView.addJavascriptInterface(captureBridge, "OfflineArchiveBridge");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (!busy) statusText.setText("网页加载 " + newProgress + "%");
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                setArchiveButtons(false);
                if (!busy) showBusy("正在打开网页…");
                urlInput.setText(url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (!busy) {
                    hideBusy("页面已加载，可滚动或登录后再归档");
                    setArchiveButtons(true);
                }
                urlInput.setText(url);
            }
        });
    }

    private void bindActions() {
        loadButton.setOnClickListener(v -> loadTypedUrl());
        urlInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO) {
                loadTypedUrl();
                return true;
            }
            return false;
        });
        saveHtmlButton.setOnClickListener(v -> startDomArchive(ArchiveOptions.Mode.SINGLE_HTML));
        saveZipButton.setOnClickListener(v -> startDomArchive(ArchiveOptions.Mode.ZIP_PACKAGE));
        saveMhtmlButton.setOnClickListener(v -> saveMhtml());
    }

    private void loadTypedUrl() {
        if (busy) return;
        String value = urlInput.getText().toString().trim();
        if (value.isEmpty()) {
            toast("请输入网址");
            return;
        }
        if (!value.matches("(?i)^https?://.*")) value = "https://" + value;
        webView.loadUrl(value);
    }

    private void startDomArchive(ArchiveOptions.Mode mode) {
        if (busy || webView.getUrl() == null) return;
        busy = true;
        setArchiveButtons(false);
        showBusy("正在提取渲染后的页面 DOM…");
        final String token = UUID.randomUUID().toString();
        captureBridge.start(token, new CaptureBridge.Callback() {
            @Override
            public void onCaptured(String html) {
                runArchive(mode, html);
            }

            @Override
            public void onError(String message) {
                failUi(message);
            }
        });
        webView.evaluateJavascript(buildCaptureScript(token, expandBeforeSave.isChecked()), null);
    }

    private void runArchive(ArchiveOptions.Mode mode, String html) {
        final String pageUrl = webView.getUrl();
        final String userAgent = webView.getSettings().getUserAgentString();
        final ArchiveOptions options = new ArchiveOptions(mode, includeScripts.isChecked(), includeMedia.isChecked());
        executor.execute(() -> {
            try {
                ArchiveEngine engine = new ArchiveEngine(userAgent,
                        url -> CookieManager.getInstance().getCookie(url),
                        (message, completed, totalHint) -> mainHandler.post(() -> statusText.setText(message)));
                File root = new File(getCacheDir(), "exports");
                ArchiveResult result = engine.archive(pageUrl, html, root, options);
                mainHandler.post(() -> requestExport(result));
            } catch (Exception e) {
                mainHandler.post(() -> failUi("归档失败：" + safeMessage(e)));
            }
        });
    }

    private void saveMhtml() {
        if (busy || webView.getUrl() == null) return;
        busy = true;
        setArchiveButtons(false);
        showBusy("正在准备可展开的 MHTML 快照…");
        File dir = new File(getCacheDir(), "mhtml");
        if (!dir.exists() && !dir.mkdirs()) {
            failUi("无法创建临时目录");
            return;
        }
        String host = Uri.parse(webView.getUrl()).getHost();
        if (host == null || host.isBlank()) host = "webpage";
        String name = host.replaceAll("[^a-zA-Z0-9._-]", "_") + "_archive.mht";
        File file = new File(dir, name);

        // MHTML 查看器经常禁用页面 JavaScript。保存前把常见折叠区域改造成
        // “隐藏 checkbox + label + CSS”结构，即使脚本被禁用也可以点击展开/收起。
        webView.evaluateJavascript(buildPrepareMhtmlScript(expandBeforeSave.isChecked()), ignored ->
                mainHandler.postDelayed(() -> {
                    statusText.setText("正在生成 MHTML…");
                    webView.saveWebArchive(file.getAbsolutePath(), false, savedPath -> {
                        if (savedPath == null) {
                            failUi("WebView 无法生成 MHTML");
                        } else {
                            requestExport(new ArchiveResult(new File(savedPath), name, "multipart/related", 0, 0, file.length()));
                        }
                    });
                }, expandBeforeSave.isChecked() ? 2200L : 250L));
    }

    private void requestExport(ArchiveResult result) {
        pendingExport = result.file;
        pendingMime = result.mimeType;
        pendingName = result.suggestedName;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(result.mimeType);
        intent.putExtra(Intent.EXTRA_TITLE, result.suggestedName);
        try {
            startActivityForResult(intent, REQUEST_CREATE_FILE);
            statusText.setText(String.format(Locale.ROOT, "资源 %d 个，失败 %d 个；请选择保存位置", result.savedResources, result.failedResources));
        } catch (Exception e) {
            failUi("无法打开系统文件保存器：" + safeMessage(e));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CREATE_FILE) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            finishBusy("已取消保存");
            return;
        }
        Uri destination = data.getData();
        File source = pendingExport;
        executor.execute(() -> {
            try {
                copyToUri(source, destination);
                mainHandler.post(() -> finishBusy("保存成功：" + pendingName));
            } catch (Exception e) {
                mainHandler.post(() -> failUi("写入文件失败：" + safeMessage(e)));
            }
        });
    }

    private void copyToUri(File source, Uri destination) throws IOException {
        if (source == null || !source.isFile()) throw new IOException("临时文件不存在");
        try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(source));
             OutputStream raw = getContentResolver().openOutputStream(destination, "w")) {
            if (raw == null) throw new IOException("无法打开目标文件");
            try (BufferedOutputStream out = new BufferedOutputStream(raw)) {
                byte[] buffer = new byte[32_768];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            }
        }
    }

    private String buildCaptureScript(String token, boolean expandFirst) {
        String quoted = jsQuote(token);
        return """
                (async function(){
                  try {
                    const token = %s;
                    const expandFirst = %s;
                    const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

                    function isVisible(el) {
                      if (!el) return false;
                      const st = getComputedStyle(el);
                      return !el.hidden && st.display !== 'none' && st.visibility !== 'hidden';
                    }

                    async function expandKnownPanels(root) {
                      const targets = [];
                      root.querySelectorAll('.queryListUL').forEach(box => {
                        const trigger = box.querySelector(':scope > .top');
                        const content = box.querySelector(':scope > .content');
                        if (trigger && content && !isVisible(content)) targets.push(trigger);
                      });
                      root.querySelectorAll('details:not([open]) > summary').forEach(el => targets.push(el));
                      root.querySelectorAll('[aria-expanded="false"][aria-controls], .accordion-button.collapsed, [data-bs-toggle="collapse"].collapsed').forEach(el => targets.push(el));
                      const unique = Array.from(new Set(targets)).slice(0, 1500);
                      for (let i = 0; i < unique.length; i += 40) {
                        unique.slice(i, i + 40).forEach(el => { try { el.click(); } catch (_) {} });
                        await sleep(40);
                      }
                      if (unique.length) await sleep(1600);
                    }

                    function markPanelState(root) {
                      root.querySelectorAll('.queryListUL').forEach(box => {
                        const content = box.querySelector(':scope > .content');
                        if (content && isVisible(content)) box.setAttribute('data-was-open', '1');
                        else box.removeAttribute('data-was-open');
                      });
                    }

                    function copyElementAsLabel(oldNode, id) {
                      const label = document.createElement('label');
                      for (const attr of Array.from(oldNode.attributes || [])) {
                        if (attr.name.toLowerCase() !== 'for') label.setAttribute(attr.name, attr.value);
                      }
                      label.setAttribute('for', id);
                      label.classList.add('was-offline-toggle-label');
                      while (oldNode.firstChild) label.appendChild(oldNode.firstChild);
                      oldNode.replaceWith(label);
                      return label;
                    }

                    function offlineizePanels(root) {
                      let head = root.querySelector('head');
                      if (!head) {
                        head = document.createElement('head');
                        root.insertBefore(head, root.firstChild);
                      }
                      const style = document.createElement('style');
                      style.setAttribute('data-webarchivesaver', 'offline-toggles');
                      style.textContent = `
                        .was-offline-toggle-control{position:absolute!important;width:1px!important;height:1px!important;opacity:0!important;pointer-events:none!important;overflow:hidden!important}
                        .was-offline-toggle-label{cursor:pointer!important;-webkit-tap-highlight-color:transparent}
                        .was-offline-toggle-control~.was-offline-toggle-content{display:none!important}
                        .was-offline-toggle-control:checked~.was-offline-toggle-content{display:block!important}
                        .was-offline-toggle-control:checked+.was-offline-toggle-label .more{transform:rotate(180deg)!important}
                        .was-offline-toggle-control:focus-visible+.was-offline-toggle-label{outline:2px solid #397ff6!important;outline-offset:2px!important}
                      `;
                      head.appendChild(style);

                      let serial = 0;
                      root.querySelectorAll('.queryListUL').forEach(box => {
                        if (box.querySelector(':scope > .was-offline-toggle-control')) return;
                        const trigger = box.querySelector(':scope > .top');
                        const content = box.querySelector(':scope > .content');
                        if (!trigger || !content) return;
                        const id = 'was_toggle_' + (++serial);
                        const control = document.createElement('input');
                        control.type = 'checkbox';
                        control.id = id;
                        control.className = 'was-offline-toggle-control';
                        control.checked = box.getAttribute('data-was-open') === '1' || box.classList.contains('on');
                        box.classList.remove('on');
                        content.classList.add('was-offline-toggle-content');
                        box.insertBefore(control, trigger);
                        copyElementAsLabel(trigger, id);
                      });
                    }

                    if (expandFirst) await expandKnownPanels(document);
                    markPanelState(document);

                    const src = document.documentElement;
                    const dst = src.cloneNode(true);
                    const s = src.querySelectorAll('*');
                    const d = dst.querySelectorAll('*');
                    for (let i = 0; i < s.length && i < d.length; i++) {
                      const a = s[i], b = d[i];
                      if (a.tagName === 'INPUT') {
                        if (a.type === 'checkbox' || a.type === 'radio') {
                          if (a.checked) b.setAttribute('checked', 'checked'); else b.removeAttribute('checked');
                        } else b.setAttribute('value', a.value || '');
                      } else if (a.tagName === 'TEXTAREA') b.textContent = a.value || '';
                      else if (a.tagName === 'OPTION') {
                        if (a.selected) b.setAttribute('selected', 'selected'); else b.removeAttribute('selected');
                      } else if (a.tagName === 'DETAILS') {
                        if (a.open) b.setAttribute('open', 'open'); else b.removeAttribute('open');
                      }
                      if (a.tagName === 'IMG') {
                        const current = a.currentSrc || a.getAttribute('src') || a.getAttribute('data-src') || a.getAttribute('data-original') || a.getAttribute('data-lazy-src');
                        if (current) b.setAttribute('src', current);
                        const srcset = a.getAttribute('srcset') || a.getAttribute('data-srcset');
                        if (srcset) b.setAttribute('srcset', srcset);
                      }
                      if (a.tagName === 'SOURCE') {
                        const current = a.getAttribute('src') || a.getAttribute('data-src');
                        const srcset = a.getAttribute('srcset') || a.getAttribute('data-srcset');
                        if (current) b.setAttribute('src', current);
                        if (srcset) b.setAttribute('srcset', srcset);
                      }
                      if (a.shadowRoot) {
                        try {
                          const t = document.createElement('template');
                          t.setAttribute('shadowrootmode', 'open');
                          t.innerHTML = a.shadowRoot.innerHTML;
                          b.insertBefore(t, b.firstChild);
                        } catch (_) {}
                      }
                    }
                    const sc = src.querySelectorAll('canvas'), dc = dst.querySelectorAll('canvas');
                    for (let j = 0; j < sc.length && j < dc.length; j++) {
                      try {
                        const im = document.createElement('img');
                        im.src = sc[j].toDataURL('image/png');
                        im.width = sc[j].width;
                        im.height = sc[j].height;
                        dc[j].replaceWith(im);
                      } catch (_) {}
                    }
                    offlineizePanels(dst);
                    const html = '<!DOCTYPE html>\\n' + dst.outerHTML;
                    const size = 180000, total = Math.ceil(html.length / size);
                    if (html.length > %d) {
                      OfflineArchiveBridge.fail(token, '页面 DOM 超过 100 MB 限制');
                      return;
                    }
                    for (let k = 0; k < total; k++) {
                      OfflineArchiveBridge.push(token, k, total, html.substring(k * size, (k + 1) * size));
                    }
                  } catch (e) {
                    OfflineArchiveBridge.fail(%s, String(e && e.message || e));
                  }
                })();
                """.formatted(quoted, expandFirst ? "true" : "false", MAX_CAPTURE_CHARS, quoted);
    }

    private String buildPrepareMhtmlScript(boolean expandFirst) {
        return """
                (async function(){
                  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
                  function visible(el){if(!el)return false;const s=getComputedStyle(el);return !el.hidden&&s.display!=='none'&&s.visibility!=='hidden'}
                  if (%s) {
                    const targets=[];
                    document.querySelectorAll('.queryListUL').forEach(box=>{const t=box.querySelector(':scope > .top'),c=box.querySelector(':scope > .content');if(t&&c&&!visible(c))targets.push(t)});
                    for(let i=0;i<targets.length;i+=40){targets.slice(i,i+40).forEach(el=>{try{el.click()}catch(_){}});await sleep(40)}
                    if(targets.length)await sleep(1600);
                  }
                  if(!document.getElementById('was-mhtml-toggle-style')){
                    const st=document.createElement('style');st.id='was-mhtml-toggle-style';st.textContent='.was-offline-toggle-control{position:absolute!important;width:1px!important;height:1px!important;opacity:0!important;pointer-events:none!important}.was-offline-toggle-label{cursor:pointer!important}.was-offline-toggle-control~.was-offline-toggle-content{display:none!important}.was-offline-toggle-control:checked~.was-offline-toggle-content{display:block!important}.was-offline-toggle-control:checked+.was-offline-toggle-label .more{transform:rotate(180deg)!important}';document.head.appendChild(st)
                  }
                  let n=0;
                  document.querySelectorAll('.queryListUL').forEach(box=>{
                    if(box.querySelector(':scope > .was-offline-toggle-control'))return;
                    const top=box.querySelector(':scope > .top'),content=box.querySelector(':scope > .content');if(!top||!content)return;
                    const open=visible(content)||box.classList.contains('on');
                    const id='was_mhtml_toggle_'+(++n),cb=document.createElement('input');cb.type='checkbox';cb.id=id;cb.className='was-offline-toggle-control';cb.checked=open;
                    const label=document.createElement('label');Array.from(top.attributes).forEach(a=>{if(a.name.toLowerCase()!=='for')label.setAttribute(a.name,a.value)});label.setAttribute('for',id);label.classList.add('was-offline-toggle-label');while(top.firstChild)label.appendChild(top.firstChild);
                    content.classList.add('was-offline-toggle-content');box.classList.remove('on');box.insertBefore(cb,top);top.replaceWith(label)
                  });
                  return 'ok';
                })();
                """.formatted(expandFirst ? "true" : "false");
    }

    private static String jsQuote(String value) {
        return "'" + value.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "") + "'";
    }

    private void setArchiveButtons(boolean enabled) {
        saveHtmlButton.setEnabled(enabled && !busy);
        saveZipButton.setEnabled(enabled && !busy);
        saveMhtmlButton.setEnabled(enabled && !busy);
        loadButton.setEnabled(!busy);
    }

    private void showBusy(String message) {
        progressBar.setVisibility(View.VISIBLE);
        statusText.setText(message);
    }

    private void hideBusy(String message) {
        progressBar.setVisibility(View.GONE);
        statusText.setText(message);
    }

    private void finishBusy(String message) {
        busy = false;
        deletePendingExport();
        hideBusy(message);
        setArchiveButtons(webView.getUrl() != null);
        toast(message);
    }

    private void failUi(String message) {
        busy = false;
        deletePendingExport();
        hideBusy(message);
        setArchiveButtons(webView.getUrl() != null);
        toast(message);
    }

    private void deletePendingExport() {
        File file = pendingExport;
        pendingExport = null;
        if (file != null && file.exists()) {
            file.delete();
            File parent = file.getParentFile();
            if (parent != null) parent.delete();
        }
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private static String safeMessage(Throwable e) {
        return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        captureBridge.cancel();
        deletePendingExport();
        webView.removeJavascriptInterface("OfflineArchiveBridge");
        webView.destroy();
        executor.shutdownNow();
        super.onDestroy();
    }

    private final class CaptureBridge {
        interface Callback {
            void onCaptured(String html);
            void onError(String message);
        }

        private String token;
        private String[] chunks;
        private int received;
        private long chars;
        private Callback callback;

        synchronized void start(String token, Callback callback) {
            this.token = token;
            this.callback = callback;
            this.chunks = null;
            this.received = 0;
            this.chars = 0;
        }

        synchronized void cancel() {
            token = null;
            chunks = null;
            callback = null;
            received = 0;
            chars = 0;
        }

        @JavascriptInterface
        public synchronized void push(String incomingToken, int index, int total, String chunk) {
            if (token == null || !token.equals(incomingToken) || total <= 0 || total > 10000 || index < 0 || index >= total) return;
            if (chunks == null) chunks = new String[total];
            if (chunks.length != total || chunks[index] != null) return;
            chars += chunk == null ? 0 : chunk.length();
            if (chars > MAX_CAPTURE_CHARS) {
                Callback cb = callback;
                cancel();
                if (cb != null) mainHandler.post(() -> cb.onError("页面 DOM 超过 100 MB 限制"));
                return;
            }
            chunks[index] = chunk == null ? "" : chunk;
            received++;
            if (received == total) {
                StringBuilder b = new StringBuilder((int) Math.min(chars, Integer.MAX_VALUE));
                for (String part : chunks) b.append(part);
                Callback cb = callback;
                cancel();
                if (cb != null) mainHandler.post(() -> cb.onCaptured(b.toString()));
            }
        }

        @JavascriptInterface
        public synchronized void fail(String incomingToken, String message) {
            if (token == null || !token.equals(incomingToken)) return;
            Callback cb = callback;
            cancel();
            if (cb != null) mainHandler.post(() -> cb.onError("提取 DOM 失败：" + message));
        }
    }
}
