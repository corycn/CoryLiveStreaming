# Validation notes

Checks completed for version 1.1.0:

- All Android XML resources parsed as well-formed XML.
- `MainActivity.java` passed Java 17 syntax/type checking against lightweight Android API stubs.
- `ArchiveEngine.java`, `ArchiveOptions.java`, and `ArchiveResult.java` passed Java 17 syntax/type checking against lightweight Jsoup API stubs.
- The supplied China Telecom HTML was inspected: the rendered DOM contained 182 `.queryListUL` panels and their hidden `.content` sections, while the single-file export contained empty archived `<style>` elements.
- A repaired self-contained sample was generated with 4 non-empty style blocks, 182 CSS-only toggle controls, 182 matching labels, no executable original scripts, and no remaining relative CSS resource URLs.
- A repaired MHTML sample was generated while preserving all 7 MIME body parts and adding 182 script-free toggle controls to the HTML part.
- The project ZIP was opened after creation and its checksum manifest was verified.

Not completed in this environment:

- A real Android `assembleDebug` build, because Android SDK Platform 37 and Maven/Gradle binary dependency resolution were not available in the runtime. Android Studio or a normal Android CI environment remains the definitive build/lint check.
- Automated visual screenshot comparison. The supplied page was instead checked structurally for non-empty CSS, embedded resources and matching fold controls.
