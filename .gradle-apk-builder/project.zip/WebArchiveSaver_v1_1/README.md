# WebArchiveSaver 1.1（网页离线归档 Android App）

一个可直接导入 Android Studio 的 Gradle 工程。用户手动输入网址，在内置 WebView 中完成加载或登录后，可将当前渲染状态导出为离线网页。

## 1.1 修复内容

- 修复“单文件 HTML 只剩文字”的根因：旧代码在读取 `<style>` 内容前先清空了节点，导致所有 CSS 变成空标签。
- ZIP 中新增推荐入口 `index.html`：CSS、背景图片、普通图片和字体均内嵌，因此从 Android 的 `content://` 或 `file://` 打开时不依赖同目录资源权限。
- ZIP 同时保留 `index-assets.html` 与 `assets/`，便于检查、编辑和二次开发。
- 新增“归档前展开折叠内容”，会尝试展开资费列表、`details` 和常见 accordion/collapse 项，再抓取 DOM。
- 将 `.queryListUL > .top + .content` 形式的折叠列表转换为纯 HTML/CSS 控件。即使 MHTML 查看器禁用 JavaScript，也可点击标题展开或收起。
- “保留原脚本”默认关闭。现代 Vue/React 页面离线运行原脚本时，常因模块路径、接口、CORS 或登录状态失效而重新挂载空页面；静态 DOM 快照通常更可靠。

## 三种导出模式

1. **单文件 HTML**：把可下载的 CSS、背景图片、普通图片、字体及媒体转换为 data URI，输出一个 `.html` 文件。
2. **HTML + 资源 ZIP**：包含：
   - `index.html`：完全自包含，推荐直接打开；
   - `index-assets.html`：引用 `assets/` 的传统目录版；
   - `assets/`：下载的原始资源；
   - `archive-report.txt`：失败项与限制说明。
3. **原生 MHTML**：调用 Android WebView 的 `saveWebArchive()` 生成 `.mht`，并在保存前给常见折叠列表加入无需 JavaScript 的展开控件。

## 构建环境

- Android Gradle Plugin 9.3.0
- Gradle 9.5.0
- Java / JDK 17
- NIO core-library desugaring 2.1.5
- compileSdk / targetSdk 37
- minSdk 26

在 Android Studio 中打开项目，等待 Gradle 同步，然后运行 `app`。命令行可使用：

```bash
./gradlew assembleDebug
```

生成 APK：`app/build/outputs/apk/debug/app-debug.apk`

## 使用方法

1. 输入 `https://...` 或域名，点击“打开网页”。
2. 等页面加载完成；登录、滚动触发懒加载等操作应先在 WebView 中完成。
3. 建议保持“归档前展开折叠内容”勾选。
4. 建议不要勾选“保留原脚本（可能失效）”，除非确实需要原网页代码。
5. 选择导出格式并指定保存位置。
6. ZIP 必须先解压。优先打开解压后的 `index.html`；不要直接在压缩包预览器里打开 `index-assets.html`。

## 技术实现

- WebView 执行 JavaScript，分块回传当前 DOM，避免大型页面一次性回调限制。
- 同步表单值、选中状态、`details` 状态、当前图片、canvas 快照和开放式 Shadow DOM。
- 抓取前按保守规则尝试展开折叠项，等待异步内容加载后再克隆 DOM。
- 为中国电信资费页使用的 `.queryListUL/.top/.content` 结构生成 checkbox + label + CSS 的离线交互。
- Jsoup 解析 DOM，递归处理 CSS `@import` 与 `url(...)`。
- 使用当前 WebView User-Agent 和 Cookie 请求资源。
- 每次 ZIP 归档包含失败清单和已知限制报告。

## 仍然无法保证的内容

任何客户端工具都无法对所有网站保证 100% 复刻。以下内容可能无法完整保存：

- DRM、加密音视频、流媒体分片与受保护内容；
- CAPTCHA、反爬、设备校验、证书绑定或临时签名 URL；
- 跨域 iframe 内部 DOM、closed Shadow DOM；
- Service Worker、IndexedDB、WebSocket 的完整运行状态；
- 点击后才向服务器请求且抓取前未加载的数据；
- 完全自定义、无法从 DOM 结构判断目标的 JavaScript 交互；
- 超过应用资源数量或大小保护上限的文件。

失败资源会尽量保留原始在线 URL，并记录在报告中。请仅归档您有权保存的网页。应用不会绕过登录、DRM、验证码或访问控制。

## 主要源码

- `MainActivity.java`：WebView、自动展开、离线折叠控件、DOM 分块捕获、MHTML 与系统文件保存器。
- `ArchiveEngine.java`：资源下载、CSS 递归处理、单文件内联、双入口 ZIP 和报告。
- `ArchiveOptions.java`：脚本、媒体及资源大小限制。

## 许可

项目示例代码采用 MIT License。第三方依赖 Jsoup 使用其自身许可。
