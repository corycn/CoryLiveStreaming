
## v1.10.1 更新

### v1.10.1 本地构建修复

- 修复 `OperationProgressDialog` 取消回调中局部变量重名，避免 `compileDebugJavaWithJavac` 编译失败。
- 为 Android/Termux JDK 显式设置 `user.home` 与 `android.user.home`，并统一到工程私有可写目录。
- 创建并修复 `.home/.android` 权限，避免 AGP 指向 `/data/data/com.termux/files/home/.android/analytics.settings`。


- 从资源包提取完整签名材料或 keystore 后，可“立即导入并编辑”；编辑界面支持验证保存、重新生成并启用、保存并导出到 Download。
- 手机本地构建和 GitHub Actions 云端构建新增独立进度小窗与取消按钮；工具链导出、全量系统备份继续使用可取消进度小窗。
- 构建状态区改为固定高度可滚动面板，保留最近 20 条记录、最新记录在最上方，并提供透明的首条/末条跳转按钮。
- 关于页面新增制作人、QQ 和邮箱；QQ 优先跳转手机 QQ 临时会话，失败时打开网页，邮箱使用 mailto 调起邮件应用。
# 小魁安卓编译 / CoryKui APKbuild 1.9.9

Android Studio 工程源码。

## 本版新增

- 应用名称改为“小魁安卓编译”，英文名为 `CoryKui APKbuild`。
- 内置紫色圆角启动图标，原始图片：`CoryKui-APKbuild-icon.png`。
- APK 签名证书管理新增随机生成证书，可编辑别名、密码、证书名称、组织、地区、国家代码和有效期。
- 已生成/导入的签名证书可继续导出为便携证书包。
- 新增“应用图标管理”：
  - 从手机选择 PNG/JPEG/WebP 作为编译图标；
  - 从 APK、AAB、APKS、XAPK、ZIP、AAR、JAR 等资源包提取图标；
  - 保存提取图标到 `Download/GradleApkBuilder`；
  - 本地或云端构建前，在临时工程中替换 launcher 图标，不修改原始工程 ZIP。

## 固定签名

覆盖安装旧版本时，仍必须使用旧版本对应的同一份 keystore。工程支持根目录 `signing.properties` 固定签名配置。

## 构建

使用 Android Studio 打开本目录，配置 Android SDK 35 和 JDK 17，然后执行：

```bash
./gradlew assembleDebug
```

如需 release APK，请先配置固定签名证书，再执行：

```bash
./gradlew assembleRelease
```


## v1.9.6 Gradle 离线缓存修复

- 官方 Gradle 发行包改为保存在共享工具链目录 `sdk-components/gradle-distributions/`。
- `gradle-8.9-bin.zip` 与解压后的 Gradle 目录会同时纳入“导出全部工具链”和“全量系统备份”。
- 导入或恢复后，本地构建会优先使用已解压的 Gradle；只有 ZIP 时会本地解压，不联网。
- 工具链与全量备份清单会记录并校验已缓存的 Gradle 版本。
- “仅导出系统设置”不包含 Gradle、JDK、SDK 等大文件，属于预期行为。


## v1.9.8 Gradle/Maven 离线依赖备份

- `GRADLE_USER_HOME` 改为共享工具链目录 `sdk-components/gradle-user-home/`。
- 在线构建成功后下载的 Android Gradle Plugin、Kotlin 插件、AndroidX、Google Maven、Maven Central 依赖与转换缓存会保留在共享目录。
- “导出全部工具链”和“全量系统备份”会包含共享依赖缓存；导入恢复后会检查缓存是否存在。
- 自动迁移旧版 `local-build-*/project/.gradle-user-home` 中已经下载的依赖。
- 网络或 DNS 不可用时，如果已恢复依赖缓存，会自动使用 Gradle `--offline` 再尝试一次。
- 导出时跳过 Gradle daemon、临时目录与锁文件；这些运行时文件不影响离线构建。
- 首次构建某个从未缓存过的新工程/新依赖版本仍需要联网完成一次下载。


## v1.9.8 随机签名证书修复

- 随机生成的 JKS 不再使用 Android 系统 KeyStore Provider 验证。
- 改用当前 JDK 的 keytool 验证明文证书库、别名和私钥密码。
- 修复部分 Android 设备把有效 JKS 错误报告为“不是 PKCS12 key store”的问题。


## v1.9.9 离线依赖状态刷新修复

- 本地构建成功后立即重新扫描共享 `gradle-user-home` 并刷新环境状态。
- 成功状态中直接显示当前离线依赖缓存大小，避免缓存已生成但主界面仍显示“未缓存”。
- App 返回前台时自动重新读取工具链状态。
- 工具链导出继续递归包含 `sdk-components/gradle-user-home/`；全量系统备份继续包含整个 App 私有文件目录。
- 工具链包清单会记录 `gradleDependencyCachePresent` 和 `gradleDependencyCacheBytes`，导入后若声明存在缓存但实际缺失，会判定恢复失败。
