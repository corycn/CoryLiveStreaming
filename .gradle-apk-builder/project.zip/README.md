# 安卓工程编译器 v1.9.3

## v1.9.3 修复与核验

- 本地构建会分析 Android Gradle Plugin 与 Java toolchain；AGP 8.x 默认优先使用已安装的 JDK 17，只有工程明确要求 Java 21 时才使用 JDK 21。
- Gradle 本地构建启用单 Worker、关闭并行/构建缓存，并让 Kotlin 编译器在进程内运行，减少 Android/Termux 子进程兼容问题。
- 构建失败弹窗优先显示 `What went wrong`、`Execution failed`、`Caused by`、AAPT 与编译错误，不再只显示无意义的堆栈末尾。
- 工具链导出清单现在记录全部 Android Platform、Build Tools 与活动 JDK；导入后逐项核验，再执行 `aapt2 dump resources android.jar` 兼容性自检。
- 全量备份同样记录组件清单；恢复后核验 Platform 与 Build Tools。Platform 35 和 ARM64 Build Tools 35.0.2 位于 `files/linux-runtime/sdk-components/android-sdk`，会随工具链导出和全量备份一起保存、覆盖恢复。
- 版本：`versionCode 10902`，`versionName 1.9.3`。


## v1.9.1 修复与新增

- 根据最新 Bug 日志修复本地 `:app:processDebugResources`：旧 ARM64 `aapt2 34.0.4` 无法解析 API 35 的新资源表类型。
- 自动获取并安装 ARM64 Build Tools 35.0.2；Release 元数据先读取 GitHub 最新 `digest` 字段，若旧资产未返回 digest，则仅允许固定仓库、固定标签和固定文件名，并在安装前后记录 SHA-256、实测解析 `android.jar`，失败立即回滚。
- 构建状态区最多显示 20 行，当前进度和最新消息置顶，旧消息自动移除。
- 新增“仅导出系统设置”和“仅导入系统设置”。设置包只包含 GitHub 配置、加密 Token、Gradle 任务和活动 JDK 选择；重复设置覆盖，工具链、工程、签名证书及其他全量文件不受影响。
- 全量恢复改为直接流式解密到单个临时恢复目录，不再生成“加密文件副本 + 完整明文 ZIP”两份大型中间文件。
- 全量恢复支持取消，进度刷新限频；正式写入时按顶层目录逐项原子覆盖，避免直接替换整个 App 文件目录导致卡死或闪退。
- 版本：`versionCode 10901`，`versionName 1.9.1`。固定签名配置保持不变。

# 安卓工程编译器 v1.8.5


## v1.8.5 修复

- 修复工具链导入或系统恢复后，ZIP 丢失 Unix 执行权限导致 PRoot 报 `execve("/bin/busybox"): Permission denied`。
- 导入后会显式修复 BusyBox、`/bin`、`/sbin`、musl 动态加载器、PRoot 与 PRoot loader 权限。
- PRoot 临时目录改为 Termux PREFIX 内的 `tmp`，同时设置 `PROOT_TMP_DIR` 与 `TMPDIR`。
- 本地 PRoot 构建与环境自检使用相同的临时目录和权限修复逻辑。

- 修复 AGP 8 默认不生成 `BuildConfig` 导致 `SystemBackupManager` 与 `RuntimeBundleManager` 编译失败。
- 显式启用 `android.buildFeatures.buildConfig`。
- GitHub Actions 的 Artifact 上传升级为 `actions/upload-artifact@v6`，使用 Node.js 24。
- 保持固定签名配置不变；覆盖安装仍需使用同一份 keystore。

# 安卓工程编译器 v1.8.3

- 修复 Alpine rootfs 中 `/bin/sh` 是绝对符号链接时被 Android `File.isFile()` 误判为缺失。
- rootfs 校验改用 `lstat()`，并把 `/bin/sh -> /bin/busybox` 规范化为相对链接；不支持链接时自动复制 BusyBox 作为兜底。
- 解压进度改为显示实际已处理 TAR 字节，不再把“条目数”错误显示为几百字节。
- PRoot 状态、工具链 ZIP 导入校验均支持符号链接形式的 `/bin/sh`。
- Bug 日志中的 App 版本改为运行时读取，不再固定显示 1.7.4。
- 保留 v1.7.8 的固定签名配置；升级构建必须继续使用同一份 keystore。

# 安卓工程编译器 v1.7.6

修复：Termux PRoot 多镜像与 Packages/Packages.xz 自动回退；云端构建锁屏/后台 WakeLock+Wi-Fi Lock 与网络重试；每次写入唯一 trigger.json，无需删除仓库旧文件即可重复触发。

# 安卓工程编译器 1.3.0

本版修复“连接 AndroidIDE 清单后仍提示无法安装”的问题：

- 自动解析 AndroidIDEOfficial/androidide-tools 的 manifest.json
- 按设备 ABI 选择最新版 Build Tools 与 Platform Tools
- 自动下载 android-sdk、cmdline-tools、build-tools、platform-tools、JDK 11（清单存在时）
- 使用 Apache Commons Compress + XZ 解压 `.tar.xz`
- 安全路径检查、重定向处理、分阶段安装与失败回滚
- SDK 组件和完整 PRoot 运行时分开显示状态

重要限制：AndroidIDE 清单不提供完整 PRoot/rootfs。SDK 组件可以全自动安装，但本地 Gradle 按钮只有在完整 PRoot 运行时 ZIP 已导入时才启用。云端 GitHub Actions 构建不受影响。


## v1.4.0
- SDK 组件安装完成后直接启用 Android 原生本地构建，不再强制要求 PRoot/rootfs。
- 新增 Java、Android SDK、aapt2 环境自检。
- 修复 tar.xz 符号链接恢复和可执行权限。

## v1.5.0 可迁移工具链程序包

SDK 工具链操作新增：安装/更新环境组件、导入工具链程序包、导出全部组件程序包。

导出的 `.gaptoolchain.zip` 包含：

- `toolchain-package.properties`：格式、版本、ABI、创建时间与组件范围
- `checksums.sha256`：逐文件 SHA-256 完整性清单
- `components/`：已安装的 JDK、Android SDK、Build Tools、Platform Tools、Command-line Tools 等
- `runtime/`：可选 PRoot、rootfs、Gradle 与 Linux 运行环境

导入流程会先安全解压和校验所有文件，再原子替换本地环境、恢复可执行权限并运行 Java/SDK/aapt2 自检；失败时自动恢复导入前环境。旧版完整 PRoot ZIP 继续兼容。


## v1.5.3 GitHub Actions 修复

- 对用户动态导入的工程关闭 `setup-gradle` Wrapper 校验，避免未知但可用的 Wrapper JAR 在编译前被拦截。
- 工作流继续使用只读 `contents: read` 权限。
- 更新到 Node.js 24 对应的 `checkout@v5`、`setup-java@v5` 与 `setup-gradle@v6`。
- 构建日志会输出导入工程 Wrapper JAR 的 SHA-256，便于审计。


## v1.5.4 修复说明

- 旁加载本地编译版 targetSdk 调整为 28，以兼容 Android 10+ 对应用私有目录下载工具的 exec 限制。此版本不适合 Google Play 发布。
- 云端构建不再执行导入项目中的 gradle-wrapper.jar，而是读取 gradle-wrapper.properties 并从 Gradle 官方域名重新下载发行包。
- 云端失败时 App 自动下载并显示 Actions 日志末尾。


## v1.6.0 PRoot Linux compatibility environment
- Adds a dedicated automatic PRoot/Linux installation action.
- Discovers Android-native PRoot and dependencies from the official Termux package repository.
- Discovers and verifies the latest official Alpine ARM64 mini root filesystem.
- Exports and imports PRoot, rootfs, SDK, JDK, Gradle/cache and metadata in one portable toolchain package.
- Runs PRoot self-test after installation/import.

## v1.7.0：云端配置持久化与全量系统备份

- 点击“上传并云端编译 APK”后，自动保存 GitHub 用户名、仓库、分支、Gradle 任务。
- GitHub Token 使用 Android Keystore AES-GCM 加密保存，下次启动自动恢复。
- 菜单新增“系统备份与恢复”。
- `.gapbackup` 全量备份包含：全部 app 私有工作目录、JDK、Android SDK、Build Tools、Platform Tools、Gradle 缓存、PRoot/rootfs、构建输出、当前工程 ZIP、云端配置和 Token。
- 全量备份必须设置至少 6 位密码，包含 Token 的设置再次使用 PBKDF2 + AES-GCM 加密。
- 恢复时检查包格式与设备 ABI，恢复可执行权限，并自动运行工具链环境自检。
- 建议恢复完成后关闭并重新打开 App。


## v1.7.6 导入进度
- 工程 ZIP 导入改为后台线程，实时显示复制字节与百分比。
- 工具链包导入显示复制、解压、校验、安装和自检进度。
- 全量系统恢复显示解密、解压、恢复和自检阶段进度。
- 大文件导入期间 UI 保持响应，工程导入支持取消。


## v1.7.6 对话框布局修复

- SDK / Linux 环境管理改为自适应滚动内容区。
- “安装构建组件”“更多操作”“关闭”改为纵向全宽按钮。
- 对话框按屏幕高度自动调整，内容过长时仅内容区滚动，所有按钮始终完整可见。


## v1.7.6
- Fixed Gradle JVM options being interpreted as the main class on Android shell.
- Fixed PRoot cleanup with symbolic links.
- Added Bug log export.


## v1.7.6
- Deferred Termux TAR symbolic/hard link creation until regular files are extracted.
- Avoids ENOENT when packages contain documentation symlinks such as libtalloc/copyright.
- Ignores broken documentation-only links while preserving failures for runtime links.


## v1.7.6 PRoot cross-package documentation-link fix

- Skips Termux `usr/share/doc`, `usr/share/man`, and `usr/share/info` payloads during PRoot installation.
- Prevents a documentation symlink created by one DEB from breaking extraction of a later DEB with `ENOENT`.
- Runtime binaries, libraries, configuration files, and shell resources are still installed normally.

## v1.7.7

- Fixed PRoot PREFIX normalization failing while deleting Termux `usr/lib` trees.
- The raw package tree is atomically renamed before the normalized runtime is installed.
- Cleanup of obsolete package metadata is best-effort and no longer invalidates a working runtime.
- Deletion now uses `lstat()` so dangling symbolic links are detected without following them.
- Signing configuration is intentionally unchanged from v1.7.6. Android Studio builds on the same computer/user continue using the same debug keystore.

## v1.7.8：固定签名与升级安装

Android 更新要求 applicationId 相同、versionCode 不降低，并且新 APK 必须使用与已安装版本相同的签名私钥。

本版不再允许 GitHub Actions 使用 Runner 临时生成的 debug.keystore。云端构建必须配置以下 Repository Secrets：

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Windows PowerShell 生成 Base64：

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("D:\\path\\gradle-apk-builder.jks")) | Set-Content keystore-base64.txt
```

如果当前已安装版本由旧 GitHub Actions 的临时 debug key 签名，而当时没有保存 keystore，则该私钥无法恢复。请先在旧 App 中创建全量系统备份，卸载旧版，安装一次使用固定 keystore 构建的 v1.7.8，再导入恢复备份。之后所有版本必须继续使用同一个 keystore。


## v1.8.1

- 修复 Android 15/16 上 PRoot 启动 Alpine shell 时的 `execve Permission denied`。
- 自动定位并设置 Termux `libexec/proot/loader`，不再引用原 Termux 包名路径。
- PRoot 默认设置 `PROOT_NO_SECCOMP=1`，并清除继承的 `LD_PRELOAD`。
- 自检与 PRoot 构建直接调用 `/bin/busybox sh`，避免 `/bin/sh` 链接兼容问题。
- 解压 rootfs 时恢复 TAR 权限，并额外修复 BusyBox、musl loader 与命令目录权限。
- 固定签名配置保持不变；覆盖安装仍需使用与旧版本相同的 keystore。


## v1.8.1：工具链与系统备份符号链接修复

- 工具链导出不再把 rootfs 中的符号链接当作普通文件读取。
- 修复 `rootfs/usr/bin/yes -> /bin/busybox` 等绝对链接在 Android 宿主侧显示为断链并导致 `ENOENT`。
- 新版 `.gaptoolchain.zip` 使用 schema 3，并通过 `symlinks.properties` 单独保存链接路径与目标。
- 导入工具链时先校验普通文件，再安全恢复全部符号链接并执行环境自检。
- 全量 `.gapbackup` 同步保存和恢复 JDK、SDK、PRoot、rootfs 中的符号链接。
- 导入仍兼容旧 schema 2 工具链包与 schema 1 系统备份。
- 固定签名配置未变；升级安装必须继续使用此前相同的 keystore。
## v1.8.2：Android SDK 编译兼容修复

- 修复 `SystemBackupManager` 与 `RuntimeBundleManager` 中调用 `Os.unlink()` 导致的 `cannot find symbol`。
- 删除符号链接时改用 `File.delete()`；在 Android/Linux 上该操作只删除链接目录项，不会删除链接目标。
- 工具链 schema 3 与符号链接导入导出行为保持不变。


## v1.8.3：JDK 17 / JDK 21 自动安装与迁移

- “SDK / Linux 环境管理”新增独立的“自动安装 JDK 17”和“自动安装 JDK 21”按钮。
- 从 Termux 官方主仓库及备用镜像自动解析 ARM64 软件包、依赖项和 SHA-256。
- JDK 17 与 JDK 21 可以同时安装；最后安装的版本自动设为当前构建 JDK。
- 状态页显示已安装版本与当前启用版本。
- 刷新 Android SDK 组件时保留已经安装的 JDK 17/21 和活动版本设置。
- 工具链 `.gaptoolchain.zip` 自动包含 JDK 11/17/21、依赖库和活动版本选择。
- 全量 `.gapbackup` 备份同样包含所有 JDK；导入恢复后自动恢复原活动版本并自检。
- 运行 JDK 时自动设置对应的 `JAVA_HOME`、`TMPDIR` 和 `LD_LIBRARY_PATH`。

JDK 21 对旧版 Gradle 的兼容性有限，通常建议 Gradle 8.4 或更高版本。一般 Android Gradle Plugin 8.x 工程优先选择 JDK 17。


## v1.8.7 修复

- 本地构建强制将 `java.io.tmpdir` 指向每次工程构建的私有可写目录，并同步写入 Gradle 用户级配置。
- 禁用 Gradle 文件系统监视，提升 Android 宿主文件系统兼容性。
- 全量系统备份改为边压缩、边 AES-GCM 加密、边写出，不再创建大型明文中间 ZIP。
- APK、工具链、签名证书、Bug 日志与系统备份导出均显示实时进度并支持取消。


## v1.8.8 修复

- JDK 17/21 已安装提示改成自适应自定义对话框，始终显示“仅启用”“重新下载安装”“取消”三个全宽按钮。
- 修复 Android/Termux JDK 21 启动 Gradle 单次守护进程时 `Failed to exec spawn helper`。
- Java 主进程、Gradle 单次守护进程和继承的 Java 子进程统一使用 `-Djdk.lang.Process.launchMechanism=VFORK`。
- 构建日志会显示当前进程启动模式，便于 Bug 日志排查。


## v1.9.1
- 修复 API 35 与旧版 ARM64 aapt2 不兼容导致的资源链接失败。
- GitHub Release Asset 使用最新 digest 元数据，并在 digest 缺失时执行固定来源与 Android Platform 内容自检。
- 构建状态最多显示 20 行，最新状态置顶。
- 新增仅导入/导出系统设置，不影响已安装工具链与工程文件。
- 全量恢复改为流式解密、可取消和按顶层目录原子覆盖，减少大备份恢复时卡死或退出。


## v1.9.1
- 自动从 Google 官方 SDK 仓库安装并校验工程需要的 Android Platform（包括 API 35）。
- 修复只升级 ARM64 aapt2、但缺少 Platform 35/android.jar 的问题。
- 修复 Bug 日志中同名 README.txt 导致 duplicate entry。
- ZIP 解压进度按实际解压字节计算并节流，避免重复显示大量 100%。


## v1.9.3
- 本地构建始终保存完整 Gradle 日志。
- 失败弹窗优先显示 What went wrong / Caused by 根因块，不再只显示堆栈尾部。
- Gradle 使用 plain console 输出，便于手机端解析。
