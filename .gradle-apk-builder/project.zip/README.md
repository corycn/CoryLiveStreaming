# 安卓工程编译器 v1.7.4

修复：Termux PRoot 多镜像与 Packages/Packages.xz 自动回退；云端构建锁屏/后台 WakeLock+Wi-Fi Lock 与网络重试；每次写入唯一 trigger.json，无需删除仓库旧文件即可重复触发。

# 安卓工程编译器 1.3.0

本版修复“连接 AndroidIDE 清单后仍提示无法安装”的问题：

- 自动解析 AndroidIDEOfficial/androidide-tools 的 manifest.json
- 按设备 ABI 选择最新版 Build Tools 与 Platform Tools
- 自动下载 android-sdk、cmdline-tools、build-tools、platform-tools、JDK 11（清单存在时）
- 使用 Apache Commons Compress + XZ 解压 `.tar.xz`
- 安全路径检查、重定向处理、分阶段安装与失败回滚
- SDK 组件和完整 PRoot 运行时分开显示状态

重要限制：AndroidIDE 清单不提供完整 PRoot/rootfs。SDK 组件可以全自动安装，但本地 Gradle 按钮只有在完整 PRoot 运行时 ZIP 已导入时才启用。云端 GitHub Actions 构建不受影响。


## v1.4.0
- SDK 组件安装完成后直接启用 Android 原生本地构建，不再强制要求 PRoot/rootfs。
- 新增 Java、Android SDK、aapt2 环境自检。
- 修复 tar.xz 符号链接恢复和可执行权限。

## v1.5.0 可迁移工具链程序包

SDK 工具链操作新增：安装/更新环境组件、导入工具链程序包、导出全部组件程序包。

导出的 `.gaptoolchain.zip` 包含：

- `toolchain-package.properties`：格式、版本、ABI、创建时间与组件范围
- `checksums.sha256`：逐文件 SHA-256 完整性清单
- `components/`：已安装的 JDK、Android SDK、Build Tools、Platform Tools、Command-line Tools 等
- `runtime/`：可选 PRoot、rootfs、Gradle 与 Linux 运行环境

导入流程会先安全解压和校验所有文件，再原子替换本地环境、恢复可执行权限并运行 Java/SDK/aapt2 自检；失败时自动恢复导入前环境。旧版完整 PRoot ZIP 继续兼容。


## v1.5.3 GitHub Actions 修复

- 对用户动态导入的工程关闭 `setup-gradle` Wrapper 校验，避免未知但可用的 Wrapper JAR 在编译前被拦截。
- 工作流继续使用只读 `contents: read` 权限。
- 更新到 Node.js 24 对应的 `checkout@v5`、`setup-java@v5` 与 `setup-gradle@v6`。
- 构建日志会输出导入工程 Wrapper JAR 的 SHA-256，便于审计。


## v1.5.4 修复说明

- 旁加载本地编译版 targetSdk 调整为 28，以兼容 Android 10+ 对应用私有目录下载工具的 exec 限制。此版本不适合 Google Play 发布。
- 云端构建不再执行导入项目中的 gradle-wrapper.jar，而是读取 gradle-wrapper.properties 并从 Gradle 官方域名重新下载发行包。
- 云端失败时 App 自动下载并显示 Actions 日志末尾。


## v1.6.0 PRoot Linux compatibility environment
- Adds a dedicated automatic PRoot/Linux installation action.
- Discovers Android-native PRoot and dependencies from the official Termux package repository.
- Discovers and verifies the latest official Alpine ARM64 mini root filesystem.
- Exports and imports PRoot, rootfs, SDK, JDK, Gradle/cache and metadata in one portable toolchain package.
- Runs PRoot self-test after installation/import.

## v1.7.0：云端配置持久化与全量系统备份

- 点击“上传并云端编译 APK”后，自动保存 GitHub 用户名、仓库、分支、Gradle 任务。
- GitHub Token 使用 Android Keystore AES-GCM 加密保存，下次启动自动恢复。
- 菜单新增“系统备份与恢复”。
- `.gapbackup` 全量备份包含：全部 app 私有工作目录、JDK、Android SDK、Build Tools、Platform Tools、Gradle 缓存、PRoot/rootfs、构建输出、当前工程 ZIP、云端配置和 Token。
- 全量备份必须设置至少 6 位密码，包含 Token 的设置再次使用 PBKDF2 + AES-GCM 加密。
- 恢复时检查包格式与设备 ABI，恢复可执行权限，并自动运行工具链环境自检。
- 建议恢复完成后关闭并重新打开 App。


## v1.7.4 导入进度
- 工程 ZIP 导入改为后台线程，实时显示复制字节与百分比。
- 工具链包导入显示复制、解压、校验、安装和自检进度。
- 全量系统恢复显示解密、解压、恢复和自检阶段进度。
- 大文件导入期间 UI 保持响应，工程导入支持取消。


## v1.7.4 对话框布局修复

- SDK / Linux 环境管理改为自适应滚动内容区。
- “安装构建组件”“更多操作”“关闭”改为纵向全宽按钮。
- 对话框按屏幕高度自动调整，内容过长时仅内容区滚动，所有按钮始终完整可见。


## v1.7.4
- Fixed Gradle JVM options being interpreted as the main class on Android shell.
- Fixed PRoot cleanup with symbolic links.
- Added Bug log export.
