package com.example.gradleapkbuilder;

import android.app.*;
import android.content.Context;
import android.view.*;
import android.widget.*;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

final class OperationProgressDialog {
    private final AlertDialog dialog;
    private final TextView stage, detail, percent;
    private final ProgressBar bar;
    private final AtomicBoolean cancelled = new AtomicBoolean(false);

    OperationProgressDialog(Context context, String title, boolean cancellable) {
        LinearLayout box = new LinearLayout(context);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Math.round(20 * context.getResources().getDisplayMetrics().density);
        box.setPadding(p, p / 2, p, 0);
        stage = new TextView(context); stage.setTextSize(17); box.addView(stage);
        bar = new ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(1000); bar.setProgress(0); box.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        percent = new TextView(context); percent.setGravity(Gravity.END); percent.setText("0%"); box.addView(percent);
        detail = new TextView(context); detail.setTextSize(13); detail.setMaxLines(4); detail.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE); box.addView(detail);
        AlertDialog.Builder b = new AlertDialog.Builder(context).setTitle(title).setView(box).setCancelable(false);
        if (cancellable) b.setNegativeButton("取消", (d, w) -> cancelled.set(true));
        dialog = b.create();
    }

    void show() { dialog.show(); }
    void dismiss() { if (dialog.isShowing()) dialog.dismiss(); }
    boolean isCancelled() { return cancelled.get(); }

    void update(String message, long done, long total) {
        stage.setText(message == null ? "正在处理…" : message);
        if (total > 0) {
            int value = (int)Math.min(1000, Math.max(0, done * 1000L / total));
            bar.setIndeterminate(false); bar.setProgress(value);
            percent.setText(String.format(Locale.US, "%d%%", value / 10));
            detail.setText(human(done) + " / " + human(total));
        } else {
            bar.setIndeterminate(true); percent.setText("处理中"); detail.setText(done > 0 ? human(done) : "请稍候…");
        }
    }

    void updatePercent(String message, int value, String current) {
        int p = Math.max(0, Math.min(100, value));
        stage.setText(message); bar.setIndeterminate(false); bar.setProgress(p * 10); percent.setText(p + "%"); detail.setText(current == null ? "" : current);
    }

    private static String human(long n) {
        if (n < 1024) return n + " B";
        if (n < 1048576) return String.format(Locale.US, "%.1f KB", n / 1024.0);
        if (n < 1073741824) return String.format(Locale.US, "%.1f MB", n / 1048576.0);
        return String.format(Locale.US, "%.2f GB", n / 1073741824.0);
    }
}
