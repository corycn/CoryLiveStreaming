package com.example.gradleapkbuilder;

import java.io.*;
import java.util.*;
import java.util.zip.*;

final class ProjectInspector {
    static final class Result {
        boolean valid;
        boolean hasWrapper;
        boolean hasSettings;
        boolean hasAppModule;
        String rootPrefix = "";
        final List<String> modules = new ArrayList<>();
        final List<String> warnings = new ArrayList<>();

        String summary() {
            StringBuilder b = new StringBuilder();
            b.append(valid ? "✓ 已识别为 Gradle/Android 工程\n" : "⚠ 未确认是标准 Android Gradle 工程\n");
            b.append("Gradle Wrapper：").append(hasWrapper ? "有" : "无").append('\n');
            b.append("settings.gradle：").append(hasSettings ? "有" : "无").append('\n');
            b.append("app 模块：").append(hasAppModule ? "有" : "未发现").append('\n');
            if (!rootPrefix.isEmpty()) b.append("ZIP 根目录：").append(rootPrefix).append('\n');
            if (!modules.isEmpty()) b.append("候选模块：").append(join(modules)).append('\n');
            for (String warning : warnings) b.append("• ").append(warning).append('\n');
            return b.toString().trim();
        }

        private static String join(List<String> values) {
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < values.size(); i++) {
                if (i > 0) b.append(", ");
                b.append(values.get(i));
            }
            return b.toString();
        }
    }

    static Result inspect(File zipFile) throws IOException {
        Result r = new Result();
        Set<String> entries = new HashSet<>();
        try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(new FileInputStream(zipFile)))) {
            ZipEntry e;
            int count = 0;
            while ((e = zin.getNextEntry()) != null && count++ < 30000) {
                String name = safeName(e.getName());
                if (!name.isEmpty()) entries.add(name);
            }
        }
        r.rootPrefix = detectRoot(entries);
        String p = r.rootPrefix;
        r.hasSettings = entries.contains(p + "settings.gradle") || entries.contains(p + "settings.gradle.kts");
        r.hasWrapper = entries.contains(p + "gradlew") && entries.contains(p + "gradle/wrapper/gradle-wrapper.jar");
        r.hasAppModule = entries.contains(p + "app/build.gradle") || entries.contains(p + "app/build.gradle.kts");
        for (String name : entries) {
            if (!name.startsWith(p) || !(name.endsWith("/build.gradle") || name.endsWith("/build.gradle.kts"))) continue;
            String rel = name.substring(p.length());
            int slash = rel.indexOf('/');
            if (slash > 0) {
                String module = rel.substring(0, slash);
                if (!r.modules.contains(module) && r.modules.size() < 20) r.modules.add(module);
            }
        }
        Collections.sort(r.modules);
        r.valid = r.hasSettings && (r.hasAppModule || !r.modules.isEmpty());
        if (!r.hasWrapper) r.warnings.add("工程没有完整 Gradle Wrapper，云端会尝试使用预装 Gradle，但兼容性较低。 ");
        if (!entries.contains(p + "gradle.properties")) r.warnings.add("未发现 gradle.properties；这通常不是错误。 ");
        if (zipFile.length() > 90L * 1024L * 1024L) r.warnings.add("ZIP 接近 GitHub Contents API 的大小限制，建议删掉 build、.gradle 和 .git 目录。 ");
        return r;
    }

    private static String detectRoot(Set<String> entries) {
        for (String n : entries) if (n.equals("settings.gradle") || n.equals("settings.gradle.kts")) return "";
        for (String n : entries) {
            if (n.endsWith("/settings.gradle") || n.endsWith("/settings.gradle.kts")) {
                return n.substring(0, n.lastIndexOf('/') + 1);
            }
        }
        return "";
    }

    private static String safeName(String raw) throws IOException {
        if (raw == null) return "";
        String n = raw.replace('\\', '/');
        if (n.startsWith("/") || n.contains("../") || n.equals("..")) throw new IOException("ZIP 中包含不安全路径");
        while (n.startsWith("./")) n = n.substring(2);
        return n;
    }
}
