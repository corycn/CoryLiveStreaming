package com.example.gradleapkbuilder;

import android.os.Build;
import android.system.Os;
import android.system.OsConstants;

import org.apache.commons.compress.archivers.ar.ArArchiveEntry;
import org.apache.commons.compress.archivers.ar.ArArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.*;

/** Installs Android/ARM64 OpenJDK packages from the official Termux repositories. */
final class TermuxJdkInstaller {
    interface Progress { void onProgress(String message, long done, long total); }

    private static final String[] REPOSITORIES = {
            "https://packages.termux.dev/apt/termux-main/",
            "https://packages-cf.termux.dev/apt/termux-main/",
            "https://mirror.iscas.ac.cn/termux/apt/termux-main/",
            "https://mirrors.ustc.edu.cn/termux/apt/termux-main/"
    };

    static final class Result {
        final File prefix;
        final File javaHome;
        final File javaExecutable;
        final String packageVersion;
        final String selfTestOutput;

        Result(File prefix, File javaHome, File javaExecutable,
               String packageVersion, String selfTestOutput) {
            this.prefix = prefix;
            this.javaHome = javaHome;
            this.javaExecutable = javaExecutable;
            this.packageVersion = packageVersion;
            this.selfTestOutput = selfTestOutput;
        }
    }

    static Result install(File componentsDir, File downloadsDir, int major,
                          Progress progress) throws Exception {
        if (major != 17 && major != 21) {
            throw new IllegalArgumentException("仅支持 JDK 17 或 JDK 21");
        }
        if (!Arrays.asList(Build.SUPPORTED_ABIS).contains("arm64-v8a")) {
            throw new IOException("JDK 自动安装目前仅支持 arm64-v8a 设备");
        }

        mkdirs(componentsDir);
        mkdirs(downloadsDir);
        RepoIndex index = fetchIndex(progress);
        Map<String, Pkg> all = parsePackages(index.packages);
        String rootPackage = "openjdk-" + major;
        if (!all.containsKey(rootPackage)) {
            throw new IOException("Termux 软件源中未找到 " + rootPackage);
        }

        LinkedHashSet<String> wanted = new LinkedHashSet<>();
        resolve(rootPackage, all, wanted, new HashSet<String>());
        // HTTPS downloads performed by Gradle need a CA store. These packages are optional
        // in repository metadata, so include them when available.
        addOptional("ca-certificates", all, wanted);

        File staging = new File(componentsDir.getParentFile(),
                "jdk-" + major + "-staging-" + System.currentTimeMillis());
        deleteTreeLenient(staging);
        mkdirs(staging);
        File raw = new File(staging, "raw");
        mkdirs(raw);
        ArrayList<LinkRecord> links = new ArrayList<>();

        try {
            int position = 0;
            for (String name : wanted) {
                Pkg pkg = all.get(name);
                if (pkg == null) continue;
                position++;
                File archive = new File(downloadsDir,
                        "jdk" + major + "-" + name + "-" + safeFilePart(pkg.version) + ".deb.part");
                download(index.base + pkg.filename, archive, progress,
                        "[" + position + "/" + wanted.size() + "] 下载 " + name + "…");
                verifySha256(archive, pkg.sha256);
                extractDeb(archive, raw, links, progress, name);
                if (!archive.delete()) archive.deleteOnExit();
            }

            createDeferredLinks(raw, links, progress);
            File prefix = locateTermuxPrefix(raw, major);
            if (prefix == null) {
                throw new IOException("JDK 软件包已解压，但未找到 Termux PREFIX");
            }
            File javaHome = new File(prefix, "lib/jvm/java-" + major + "-openjdk");
            File java = new File(javaHome, "bin/java");
            if (!java.isFile()) {
                java = findJava(prefix, major);
                if (java == null) throw new IOException("JDK " + major + " 中未找到 bin/java");
                javaHome = java.getParentFile().getParentFile();
            }

            File jdkStore = new File(componentsDir, "jdks");
            mkdirs(jdkStore);
            File destination = new File(jdkStore, "jdk-" + major + "-prefix");
            File backup = new File(jdkStore, "jdk-" + major + "-backup");
            deleteTreeLenient(backup);
            if (destination.exists() && !destination.renameTo(backup)) {
                throw new IOException("无法备份现有 JDK " + major + "：" + destination);
            }
            try {
                if (!prefix.renameTo(destination)) {
                    copyTreeNoFollow(prefix, destination);
                }
                File installedHome = new File(destination, "lib/jvm/java-" + major + "-openjdk");
                File installedJava = new File(installedHome, "bin/java");
                if (!installedJava.isFile()) {
                    installedJava = findJava(destination, major);
                    if (installedJava == null) throw new IOException("安装后未找到 JDK " + major + " 的 java");
                    installedHome = installedJava.getParentFile().getParentFile();
                }
                markExecutables(installedHome);
                markExecutables(new File(destination, "bin"));
                String output = selfTest(destination, installedHome, installedJava, major);
                writeSelection(componentsDir, major, all.get(rootPackage).version);
                deleteTreeLenient(backup);
                return new Result(destination, installedHome, installedJava,
                        all.get(rootPackage).version, output);
            } catch (Exception failure) {
                deleteTreeLenient(destination);
                if (backup.exists() && !backup.renameTo(destination)) {
                    copyTreeNoFollow(backup, destination);
                }
                throw failure;
            }
        } finally {
            deleteTreeLenient(staging);
        }
    }

    private static void addOptional(String name, Map<String, Pkg> all,
                                    LinkedHashSet<String> wanted) throws IOException {
        if (all.containsKey(name)) resolve(name, all, wanted, new HashSet<String>());
    }

    private static String selfTest(File prefix, File javaHome, File java,
                                   int expectedMajor) throws Exception {
        chmod(java);
        Map<String, String> env = new HashMap<>();
        env.put("JAVA_HOME", javaHome.getAbsolutePath());
        env.put("TMPDIR", new File(prefix, "tmp").getAbsolutePath());
        env.put("LD_LIBRARY_PATH", libraryPath(prefix, javaHome));
        mkdirs(new File(prefix, "tmp"));
        ProcessBuilder pb = new ProcessBuilder(java.getAbsolutePath(), "-version");
        pb.redirectErrorStream(true);
        pb.environment().putAll(env);
        Process p = pb.start();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (InputStream in = p.getInputStream()) {
            byte[] buffer = new byte[4096];
            int count;
            while ((count = in.read(buffer)) >= 0) out.write(buffer, 0, count);
        }
        int code = p.waitFor();
        String text = out.toString("UTF-8").trim();
        if (code != 0) throw new IOException("JDK " + expectedMajor + " 自检失败：\n" + text);
        int actual = parseJavaMajor(text);
        if (actual != expectedMajor) {
            throw new IOException("下载的是 JDK " + expectedMajor + "，但自检识别为 Java " + actual + "：\n" + text);
        }
        return text;
    }

    static String libraryPath(File prefix, File javaHome) {
        ArrayList<String> paths = new ArrayList<>();
        addDir(paths, new File(prefix, "lib"));
        addDir(paths, new File(javaHome, "lib"));
        addDir(paths, new File(javaHome, "lib/server"));
        addDir(paths, new File(javaHome, "lib/jli"));
        return join(paths, ":");
    }

    private static void addDir(List<String> paths, File dir) {
        if (dir != null && dir.isDirectory()) paths.add(dir.getAbsolutePath());
    }

    private static int parseJavaMajor(String text) {
        if (text == null) return -1;
        java.util.regex.Matcher matcher = java.util.regex.Pattern
                .compile("(?:openjdk|java) version \\\"(?:1\\.)?([0-9]+)")
                .matcher(text.toLowerCase(Locale.US));
        if (!matcher.find()) return -1;
        try { return Integer.parseInt(matcher.group(1)); }
        catch (Exception ignored) { return -1; }
    }

    private static final class RepoIndex {
        final String base;
        final String packages;
        RepoIndex(String base, String packages) { this.base = base; this.packages = packages; }
    }

    private static RepoIndex fetchIndex(Progress progress) throws Exception {
        ArrayList<String> errors = new ArrayList<>();
        for (String base : REPOSITORIES) {
            String[] names = {
                    "dists/stable/main/binary-aarch64/Packages",
                    "dists/stable/main/binary-aarch64/Packages.xz"
            };
            for (String name : names) {
                String url = base + name;
                try {
                    if (progress != null) progress.onProgress(
                            "正在查询 JDK 镜像：" + new URL(base).getHost(), 0, -1);
                    byte[] bytes = getBytes(url, 50_000_000);
                    String text = name.endsWith(".xz")
                            ? decompressXz(bytes) : new String(bytes, "UTF-8");
                    if (text.contains("Package: openjdk-17")
                            && text.contains("Package: openjdk-21")) {
                        return new RepoIndex(base, text);
                    }
                    errors.add(url + "：未包含 JDK 17/21");
                } catch (Exception error) {
                    errors.add(url + "：" + error.getMessage());
                }
            }
        }
        StringBuilder message = new StringBuilder("所有 Termux 官方/备用 JDK 镜像均不可用。\n");
        for (String error : errors) message.append("• ").append(error).append('\n');
        throw new IOException(message.toString());
    }

    private static final class Pkg {
        String name;
        String version;
        String filename;
        String sha256;
        String depends;
        String preDepends;
    }

    private static Map<String, Pkg> parsePackages(String text) {
        LinkedHashMap<String, Pkg> result = new LinkedHashMap<>();
        String normalized = text.replace("\r\n", "\n");
        for (String block : normalized.split("\n\n+")) {
            Pkg pkg = new Pkg();
            String currentKey = null;
            StringBuilder currentValue = new StringBuilder();
            ArrayList<String[]> fields = new ArrayList<>();
            for (String line : block.split("\n")) {
                if ((line.startsWith(" ") || line.startsWith("\t")) && currentKey != null) {
                    currentValue.append(' ').append(line.trim());
                    continue;
                }
                if (currentKey != null) fields.add(new String[]{currentKey, currentValue.toString()});
                int colon = line.indexOf(':');
                if (colon <= 0) { currentKey = null; currentValue.setLength(0); continue; }
                currentKey = line.substring(0, colon);
                currentValue.setLength(0);
                currentValue.append(line.substring(colon + 1).trim());
            }
            if (currentKey != null) fields.add(new String[]{currentKey, currentValue.toString()});
            for (String[] field : fields) {
                if ("Package".equals(field[0])) pkg.name = field[1];
                else if ("Version".equals(field[0])) pkg.version = field[1];
                else if ("Filename".equals(field[0])) pkg.filename = field[1];
                else if ("SHA256".equals(field[0])) pkg.sha256 = field[1];
                else if ("Depends".equals(field[0])) pkg.depends = field[1];
                else if ("Pre-Depends".equals(field[0])) pkg.preDepends = field[1];
            }
            if (pkg.name != null && pkg.filename != null && pkg.sha256 != null) {
                result.put(pkg.name, pkg);
            }
        }
        return result;
    }

    private static void resolve(String requested, Map<String, Pkg> all,
                                LinkedHashSet<String> output,
                                Set<String> visiting) throws IOException {
        String name = normalizeDependency(requested, all);
        if (name.isEmpty() || output.contains(name)) return;
        if ("libc".equals(name) || "android-api-level".equals(name)) return;
        if (!visiting.add(name)) return;
        Pkg pkg = all.get(name);
        if (pkg == null) {
            throw new IOException("Termux 软件源缺少 JDK 依赖：" + name);
        }
        resolveList(pkg.preDepends, all, output, visiting);
        resolveList(pkg.depends, all, output, visiting);
        output.add(name);
        visiting.remove(name);
    }

    private static void resolveList(String list, Map<String, Pkg> all,
                                    LinkedHashSet<String> output,
                                    Set<String> visiting) throws IOException {
        if (list == null || list.trim().isEmpty()) return;
        for (String dependency : list.split(",")) {
            resolve(dependency, all, output, visiting);
        }
    }

    private static String normalizeDependency(String raw, Map<String, Pkg> all) {
        String[] alternatives = raw.split("\\|");
        for (String alternative : alternatives) {
            String name = alternative.trim().replaceAll("\\s*\\(.*?\\)", "");
            int colon = name.indexOf(':');
            if (colon > 0) name = name.substring(0, colon);
            if (all.containsKey(name)) return name;
        }
        String name = alternatives[0].trim().replaceAll("\\s*\\(.*?\\)", "");
        int colon = name.indexOf(':');
        return colon > 0 ? name.substring(0, colon) : name;
    }

    private static final class LinkRecord {
        final String name;
        final String target;
        final boolean hard;
        LinkRecord(String name, String target, boolean hard) {
            this.name = name; this.target = target; this.hard = hard;
        }
    }

    private static void extractDeb(File deb, File root, List<LinkRecord> links,
                                   Progress progress, String packageName) throws Exception {
        try (ArArchiveInputStream ar = new ArArchiveInputStream(
                new BufferedInputStream(new FileInputStream(deb)))) {
            ArArchiveEntry entry;
            while ((entry = ar.getNextArEntry()) != null) {
                String memberName = entry.getName();
                if (!memberName.startsWith("data.tar")) continue;
                InputStream decompressed;
                if (memberName.endsWith(".xz")) decompressed = new XZCompressorInputStream(ar);
                else if (memberName.endsWith(".gz")) decompressed = new GzipCompressorInputStream(ar);
                else if (memberName.equals("data.tar")) decompressed = ar;
                else throw new IOException("暂不支持的 deb 数据压缩格式：" + memberName);
                extractTarPayload(decompressed, root, links, progress, packageName);
                return;
            }
        }
        throw new IOException(packageName + " 软件包缺少 data.tar");
    }

    private static void extractTarPayload(InputStream decompressed, File root,
                                          List<LinkRecord> links, Progress progress,
                                          String packageName) throws Exception {
        try (TarArchiveInputStream tar = new TarArchiveInputStream(
                new BufferedInputStream(decompressed))) {
            TarArchiveEntry entry;
            byte[] buffer = new byte[65536];
            while ((entry = tar.getNextTarEntry()) != null) {
                String name = safeName(entry.getName());
                if (name.isEmpty() || isDocumentation(name)) continue;
                File destination = new File(root, name);
                ensureInside(root, destination);
                if (entry.isSymbolicLink()) {
                    links.add(new LinkRecord(name, entry.getLinkName(), false));
                } else if (entry.isLink()) {
                    links.add(new LinkRecord(name, safeName(entry.getLinkName()), true));
                } else if (entry.isDirectory()) {
                    mkdirs(destination);
                    applyMode(destination, entry.getMode());
                } else if (entry.isFile()) {
                    mkdirs(destination.getParentFile());
                    try (OutputStream output = new BufferedOutputStream(
                            new FileOutputStream(destination))) {
                        int count;
                        while ((count = tar.read(buffer)) >= 0) output.write(buffer, 0, count);
                    }
                    applyMode(destination, entry.getMode());
                    if (entry.getModTime() != null) destination.setLastModified(entry.getModTime().getTime());
                }
                if (progress != null) progress.onProgress(
                        "正在安装 " + packageName + "：" + name, 0, -1);
            }
        }
    }

    private static boolean isDocumentation(String name) {
        String normalized = name.startsWith("./") ? name.substring(2) : name;
        return normalized.contains("/usr/share/doc/")
                || normalized.contains("/usr/share/man/")
                || normalized.contains("/usr/share/info/");
    }

    private static void createDeferredLinks(File root, List<LinkRecord> records,
                                            Progress progress) throws IOException {
        Collections.sort(records, new Comparator<LinkRecord>() {
            @Override public int compare(LinkRecord a, LinkRecord b) {
                return Integer.compare(pathDepth(a.name), pathDepth(b.name));
            }
        });
        for (LinkRecord record : records) {
            File destination = new File(root, safeName(record.name));
            ensureInside(root, destination);
            mkdirs(destination.getParentFile());
            if (destination.exists() || existsNoFollow(destination)) destination.delete();
            if (record.hard) {
                File target = new File(root, safeName(record.target));
                ensureInside(root, target);
                if (target.isFile()) copyFile(target, destination);
                continue;
            }
            String target = rewriteSymlinkTarget(root, destination.getParentFile(), record.target);
            try {
                Os.symlink(target, destination.getAbsolutePath());
            } catch (Exception error) {
                File resolved = resolveLinkForCopy(root, destination.getParentFile(), target);
                if (resolved != null && resolved.isFile()) copyFile(resolved, destination);
                else if (!isDocumentation(record.name)) {
                    throw new IOException("无法创建 JDK 符号链接：" + record.name + " -> " + target, error);
                }
            }
            if (progress != null) progress.onProgress(
                    "正在恢复 JDK 链接：" + record.name, 0, -1);
        }
    }

    private static String rewriteSymlinkTarget(File root, File linkParent,
                                               String target) throws IOException {
        if (target == null) return "";
        String termux = "/data/data/com.termux/files/";
        if (target.startsWith(termux)) {
            File actual = new File(root, "data/data/com.termux/files/" + target.substring(termux.length()));
            return relativePath(linkParent, actual);
        }
        return target;
    }

    private static File resolveLinkForCopy(File root, File parent, String target) {
        try {
            File file = target.startsWith("/") ? new File(root, target.substring(1)) : new File(parent, target);
            return file.getCanonicalFile();
        } catch (Exception ignored) { return null; }
    }

    private static String relativePath(File from, File to) throws IOException {
        String[] a = from.getCanonicalPath().split("/");
        String[] b = to.getCanonicalPath().split("/");
        int common = 0;
        while (common < a.length && common < b.length && a[common].equals(b[common])) common++;
        StringBuilder result = new StringBuilder();
        for (int i = common; i < a.length; i++) {
            if (!a[i].isEmpty()) result.append("../");
        }
        for (int i = common; i < b.length; i++) {
            if (b[i].isEmpty()) continue;
            if (result.length() > 0 && result.charAt(result.length() - 1) != '/') result.append('/');
            result.append(b[i]);
        }
        return result.length() == 0 ? "." : result.toString();
    }

    private static File locateTermuxPrefix(File raw, int major) {
        File direct = new File(raw, "data/data/com.termux/files/usr");
        if (new File(direct, "lib/jvm/java-" + major + "-openjdk/bin/java").isFile()) return direct;
        File java = findJava(raw, major);
        if (java == null) return null;
        File home = java.getParentFile().getParentFile();
        File jvm = home.getParentFile();
        File lib = jvm == null ? null : jvm.getParentFile();
        return lib == null ? null : lib.getParentFile();
    }

    private static File findJava(File root, int major) {
        if (root == null || !root.exists()) return null;
        if (root.isFile()) {
            if ("java".equals(root.getName()) && root.getParentFile() != null
                    && "bin".equals(root.getParentFile().getName())) {
                String path = root.getAbsolutePath();
                if (path.contains("java-" + major + "-openjdk")) return root;
            }
            return null;
        }
        File[] children = root.listFiles();
        if (children != null) {
            for (File child : children) {
                File found = findJava(child, major);
                if (found != null) return found;
            }
        }
        return null;
    }

    private static void writeSelection(File componentsDir, int major,
                                       String packageVersion) throws IOException {
        Properties selection = new Properties();
        selection.setProperty("activeMajor", String.valueOf(major));
        selection.setProperty("activePrefix", "jdks/jdk-" + major + "-prefix");
        selection.setProperty("packageVersion", packageVersion == null ? "unknown" : packageVersion);
        try (OutputStream output = new FileOutputStream(
                new File(componentsDir, "jdk-selection.properties"))) {
            selection.store(output, "GradleApkBuilder active JDK");
        }
        File components = new File(componentsDir, "components.properties");
        Properties metadata = new Properties();
        if (components.isFile()) {
            try (InputStream input = new FileInputStream(components)) { metadata.load(input); }
        }
        metadata.setProperty("jdk", "Termux OpenJDK " + major + " (active)");
        metadata.setProperty("activeJdk", String.valueOf(major));
        metadata.setProperty("jdk" + major + "Version", packageVersion == null ? "unknown" : packageVersion);
        try (OutputStream output = new FileOutputStream(components)) {
            metadata.store(output, "GradleApkBuilder SDK components");
        }
    }

    private static void download(String address, File output, Progress progress,
                                 String message) throws Exception {
        URL current = new URL(address);
        for (int redirect = 0; redirect < 8; redirect++) {
            HttpURLConnection connection = (HttpURLConnection) current.openConnection();
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(25_000);
            connection.setReadTimeout(180_000);
            connection.setRequestProperty("User-Agent", "GradleApkBuilder-Android/1.8.3");
            int status = connection.getResponseCode();
            if (status >= 300 && status < 400) {
                String location = connection.getHeaderField("Location");
                connection.disconnect();
                if (location == null) throw new IOException("下载重定向缺少 Location：" + current);
                current = new URL(current, location);
                continue;
            }
            if (status != 200) {
                String error = readSmall(connection.getErrorStream());
                connection.disconnect();
                throw new IOException("HTTP " + status + "：" + current + (error.isEmpty() ? "" : "\n" + error));
            }
            long total = connection.getContentLengthLong();
            mkdirs(output.getParentFile());
            try (InputStream input = new BufferedInputStream(connection.getInputStream());
                 OutputStream out = new BufferedOutputStream(new FileOutputStream(output))) {
                byte[] buffer = new byte[65536];
                long done = 0;
                int count;
                while ((count = input.read(buffer)) >= 0) {
                    out.write(buffer, 0, count);
                    done += count;
                    if (progress != null) progress.onProgress(message, done, total);
                }
            } finally { connection.disconnect(); }
            return;
        }
        throw new IOException("下载重定向次数过多：" + address);
    }

    private static byte[] getBytes(String address, int limit) throws Exception {
        URL current = new URL(address);
        for (int redirect = 0; redirect < 8; redirect++) {
            HttpURLConnection connection = (HttpURLConnection) current.openConnection();
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(20_000);
            connection.setReadTimeout(90_000);
            connection.setRequestProperty("User-Agent", "GradleApkBuilder-Android/1.8.3");
            int status = connection.getResponseCode();
            if (status >= 300 && status < 400) {
                String location = connection.getHeaderField("Location");
                connection.disconnect();
                if (location == null) throw new IOException("索引重定向缺少 Location");
                current = new URL(current, location);
                continue;
            }
            if (status != 200) {
                connection.disconnect();
                throw new IOException("HTTP " + status);
            }
            try (InputStream input = connection.getInputStream();
                 ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[32768];
                int count;
                while ((count = input.read(buffer)) >= 0) {
                    if (output.size() + count > limit) throw new IOException("软件源索引过大");
                    output.write(buffer, 0, count);
                }
                return output.toByteArray();
            } finally { connection.disconnect(); }
        }
        throw new IOException("索引重定向次数过多");
    }

    private static String decompressXz(byte[] data) throws Exception {
        try (InputStream input = new XZCompressorInputStream(new ByteArrayInputStream(data));
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[32768];
            int count;
            while ((count = input.read(buffer)) >= 0) output.write(buffer, 0, count);
            return output.toString("UTF-8");
        }
    }

    private static void verifySha256(File file, String expected) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream input = new BufferedInputStream(new FileInputStream(file))) {
            byte[] buffer = new byte[65536];
            int count;
            while ((count = input.read(buffer)) >= 0) digest.update(buffer, 0, count);
        }
        StringBuilder actual = new StringBuilder();
        for (byte b : digest.digest()) actual.append(String.format(Locale.US, "%02x", b & 0xff));
        if (!actual.toString().equalsIgnoreCase(expected)) {
            throw new SecurityException("JDK 软件包 SHA-256 校验失败\n期望：" + expected + "\n实际：" + actual);
        }
    }

    private static void markExecutables(File root) {
        if (root == null || !root.exists()) return;
        if (root.isDirectory()) {
            File[] children = root.listFiles();
            if (children != null) for (File child : children) markExecutables(child);
            return;
        }
        File parent = root.getParentFile();
        String parentName = parent == null ? "" : parent.getName();
        if ("bin".equals(parentName) || "java".equals(root.getName())
                || "javac".equals(root.getName()) || "jlink".equals(root.getName())) {
            try { chmod(root); } catch (Exception ignored) { root.setExecutable(true, false); }
        }
    }

    private static void chmod(File file) throws Exception {
        try { Os.chmod(file.getAbsolutePath(), 0755); }
        catch (Throwable error) {
            if (!file.setExecutable(true, false)) throw new IOException("无法设置执行权限：" + file, error);
        }
    }

    private static void applyMode(File file, int mode) {
        try { Os.chmod(file.getAbsolutePath(), mode & 0777); }
        catch (Throwable ignored) {
            if ((mode & 0111) != 0) file.setExecutable(true, false);
        }
    }

    private static boolean existsNoFollow(File file) {
        try { Os.lstat(file.getAbsolutePath()); return true; }
        catch (Exception ignored) { return false; }
    }

    private static boolean isSymlink(File file) {
        try { return OsConstants.S_ISLNK(Os.lstat(file.getAbsolutePath()).st_mode); }
        catch (Exception ignored) { return false; }
    }

    private static void copyTreeNoFollow(File source, File destination) throws IOException {
        if (isSymlink(source)) {
            mkdirs(destination.getParentFile());
            try { Os.symlink(Os.readlink(source.getAbsolutePath()), destination.getAbsolutePath()); }
            catch (Exception error) { throw new IOException("无法复制符号链接：" + source, error); }
            return;
        }
        if (source.isDirectory()) {
            mkdirs(destination);
            File[] children = source.listFiles();
            if (children != null) for (File child : children) {
                copyTreeNoFollow(child, new File(destination, child.getName()));
            }
            return;
        }
        if (source.isFile()) copyFile(source, destination);
    }

    private static void copyFile(File source, File destination) throws IOException {
        mkdirs(destination.getParentFile());
        try (InputStream input = new BufferedInputStream(new FileInputStream(source));
             OutputStream output = new BufferedOutputStream(new FileOutputStream(destination))) {
            byte[] buffer = new byte[65536];
            int count;
            while ((count = input.read(buffer)) >= 0) output.write(buffer, 0, count);
        }
        destination.setLastModified(source.lastModified());
        if (source.canExecute()) destination.setExecutable(true, false);
    }

    private static void deleteTreeLenient(File file) {
        if (file == null || !existsNoFollow(file)) return;
        if (isSymlink(file) || file.isFile()) {
            if (!file.delete()) file.deleteOnExit();
            return;
        }
        File[] children = file.listFiles();
        if (children != null) for (File child : children) deleteTreeLenient(child);
        if (!file.delete()) file.deleteOnExit();
    }

    private static void mkdirs(File directory) throws IOException {
        if (directory == null || directory.isDirectory()) return;
        if (!directory.mkdirs() && !directory.isDirectory()) {
            throw new IOException("无法创建目录：" + directory);
        }
    }

    private static void ensureInside(File root, File child) throws IOException {
        String base = root.getCanonicalPath() + File.separator;
        String path = child.getCanonicalPath();
        if (!path.equals(root.getCanonicalPath()) && !path.startsWith(base)) {
            throw new SecurityException("软件包路径越界：" + child);
        }
    }

    private static String safeName(String name) throws IOException {
        if (name == null) return "";
        String value = name.replace('\\', '/');
        while (value.startsWith("./")) value = value.substring(2);
        while (value.startsWith("/")) value = value.substring(1);
        if (value.equals("..") || value.startsWith("../") || value.contains("/../")) {
            throw new SecurityException("软件包包含不安全路径：" + name);
        }
        return value;
    }

    private static int pathDepth(String name) {
        int depth = 0;
        for (int i = 0; i < name.length(); i++) if (name.charAt(i) == '/') depth++;
        return depth;
    }

    private static String safeFilePart(String value) {
        return value == null ? "unknown" : value.replaceAll("[^A-Za-z0-9._-]", "_");
    }

    private static String readSmall(InputStream input) {
        if (input == null) return "";
        try (InputStream in = input; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[1024];
            int count;
            while ((count = in.read(buffer)) >= 0 && output.size() < 8192) output.write(buffer, 0, count);
            return output.toString("UTF-8");
        } catch (Exception ignored) { return ""; }
    }

    private static String join(List<String> values, String separator) {
        StringBuilder output = new StringBuilder();
        for (String value : values) {
            if (output.length() > 0) output.append(separator);
            output.append(value);
        }
        return output.toString();
    }
}
