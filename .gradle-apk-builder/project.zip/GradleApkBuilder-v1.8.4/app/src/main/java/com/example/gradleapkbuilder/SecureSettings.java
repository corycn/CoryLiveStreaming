package com.example.gradleapkbuilder;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

final class SecureSettings {
    private static final String PREFS = "cloud_settings";
    private static final String KEY_ALIAS = "gradle_apk_builder_cloud_token";
    private final Context context;

    SecureSettings(Context context) { this.context = context.getApplicationContext(); }

    void saveCloud(String owner, String repo, String branch, String task, String token) throws Exception {
        SharedPreferences.Editor e = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        e.putString("owner", owner == null ? "" : owner);
        e.putString("repo", repo == null ? "" : repo);
        e.putString("branch", branch == null || branch.trim().isEmpty() ? "main" : branch);
        e.putString("task", task == null || task.trim().isEmpty() ? "assembleDebug" : task);
        if (token != null && !token.isEmpty()) e.putString("token", encrypt(token));
        e.apply();
    }

    Cloud loadCloud() {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String token = "";
        try { token = decrypt(p.getString("token", "")); } catch (Exception ignored) {}
        return new Cloud(p.getString("owner", ""), p.getString("repo", ""), p.getString("branch", "main"), p.getString("task", "assembleDebug"), token);
    }

    void restoreCloud(Cloud c) throws Exception { saveCloud(c.owner, c.repo, c.branch, c.task, c.token); }

    private String encrypt(String text) throws Exception {
        if (text == null || text.isEmpty()) return "";
        SecretKey key = getOrCreateKey();
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] encrypted = cipher.doFinal(text.getBytes(StandardCharsets.UTF_8));
        return Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP) + "." + Base64.encodeToString(encrypted, Base64.NO_WRAP);
    }

    private String decrypt(String value) throws Exception {
        if (value == null || value.isEmpty()) return "";
        String[] parts = value.split("\\.", 2);
        if (parts.length != 2) return "";
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, Base64.decode(parts[0], Base64.NO_WRAP)));
        return new String(cipher.doFinal(Base64.decode(parts[1], Base64.NO_WRAP)), StandardCharsets.UTF_8);
    }

    private SecretKey getOrCreateKey() throws Exception {
        if (Build.VERSION.SDK_INT < 23) throw new IllegalStateException("安全保存 Token 需要 Android 6.0 或更高版本");
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) return ((KeyStore.SecretKeyEntry) ks.getEntry(KEY_ALIAS, null)).getSecretKey();
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build());
        return kg.generateKey();
    }

    static final class Cloud {
        final String owner, repo, branch, task, token;
        Cloud(String owner, String repo, String branch, String task, String token) {
            this.owner = owner == null ? "" : owner;
            this.repo = repo == null ? "" : repo;
            this.branch = branch == null || branch.isEmpty() ? "main" : branch;
            this.task = task == null || task.isEmpty() ? "assembleDebug" : task;
            this.token = token == null ? "" : token;
        }
    }
}
