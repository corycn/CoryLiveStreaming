把固定签名证书放在此目录，但不要提交到公开仓库。

推荐文件名：gradle-apk-builder.jks
然后复制根目录 signing.properties.example 为 signing.properties，并填写密码、别名。

重要：若要覆盖手机里已经安装的版本，必须使用那个版本的原始私钥。
仅有旧 APK 或证书指纹不能恢复私钥。
