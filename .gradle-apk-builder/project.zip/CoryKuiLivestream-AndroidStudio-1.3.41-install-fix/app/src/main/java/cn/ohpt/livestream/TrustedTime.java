package cn.ohpt.livestream;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Date;

final class TrustedTime {
    private static final String[] SOURCES = {
            "https://www.ntsc.ac.cn/",
            "https://www.ntsc.cas.cn/",
            "https://www.aliyun.com/",
            "https://www.qq.com/"
    };

    private TrustedTime() {}

    static Date fetch() {
        for (String source : SOURCES) {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(source).openConnection();
                c.setConnectTimeout(7000);
                c.setReadTimeout(7000);
                c.setInstanceFollowRedirects(true);
                c.setRequestMethod("HEAD");
                c.setRequestProperty("Cache-Control", "no-cache");
                c.setRequestProperty("User-Agent", "CoryKuiLivestream/TrustedTime");
                c.getResponseCode();
                long millis = c.getDate();
                if (millis > 1700000000000L) return new Date(millis);
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.disconnect();
            }
        }
        return null;
    }
}
