package cn.ohpt.livestream;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.PictureInPictureParams;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ClipData;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.util.Rational;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.io.ByteArrayOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity implements RtmpPublisher.Listener, FileRtmpPublisher.Listener {
    private static final int REQ_PERMISSIONS = 1001;
    private static final int REQ_PICK_FILE = 1002;
    private static final int REQ_PICK_BGM = 1003;
    private static final int REQ_PICK_FILE_PLAYLIST = 1004;
    private static final int REQ_STORAGE_ACCESS = 1005;
    private static final int PLAY_MODE_LIST_LOOP = 0;
    private static final int PLAY_MODE_RANDOM = 1;
    private static final int PLAY_MODE_SINGLE_LOOP = 2;
    private static final int REOPEN_NONE = 0;
    private static final int REOPEN_FILE_PLAYLIST = 1;
    private static final int REOPEN_BGM_PLAYLIST = 2;
    private static final long TRIAL_STREAM_MS = 10L * 60L * 1000L;
    private static final long TRIAL_COOLDOWN_MS = 30L * 60L * 1000L;
    private static final long LOCAL_ACTIVATION_SYNC_RETRY_MS = 10L * 60L * 1000L;
    private static final String UPDATE_VERSION_URL = "http://pt20.cn/verlog/corylivest.txt";
    private static final String UPDATE_APK_URL = "http://pt20.cn/verlog/corylivest.apk";
    private static final String ACTIVATION_URL = "http://pt20.cn/verlog/corylivest.php";
    private static final String SERVER_TIME_URL = "http://pt20.cn/verlog/datetime.php";
    private static RtmpPublisher sharedCameraPublisher;
    private static FileRtmpPublisher sharedFilePublisher;
    private static PowerManager.WakeLock sharedLiveWakeLock;
    private static WifiManager.WifiLock sharedLiveWifiLock;

    private FrameLayout root;
    private FrameLayout previewBox;
    private TextureView preview;
    private ImageView streamMirror;
    private ImageView fileImagePreview;
    private VideoView filePlayer;
    private LinearLayout normalControls;
    private LinearLayout fullControls;
    private LinearLayout zoomControls;
    private TextView title;
    private TextView zoomLabel;
    private TextView status;
    private LinearLayout progressPanel;
    private ProgressViews fileProgressViews;
    private ProgressViews bgmProgressViews;
    private Button appMenuButton;
    private Button settingsButton;
    private Button orientationButton;
    private Button fullscreenButton;
    private Button startButton;
    private Button cameraButton;
    private Button recordButton;
    private Button moreButton;
    private Button exitFullscreenButton;
    private Button muteButton;
    private Button stopLiveButton;
    private Button closeCameraButton;
    private RtmpPublisher publisher;
    private FileRtmpPublisher filePublisher;
    private PowerManager.WakeLock liveWakeLock;
    private WifiManager.WifiLock liveWifiLock;
    private MediaPlayer currentFileMediaPlayer;
    private Uri filePreviewUri;
    private boolean filePreviewPrepared;
    private Uri fileUri;
    private int cameraMode = RtmpPublisher.CAMERA_BACK_MAIN;
    private boolean landscape;
    private boolean fullscreen;
    private boolean muted;
    private boolean microphoneEnabled = true;
    private float microphoneVolume = 1.0f;
    private float videoVolume = 1.0f;
    private float backgroundMusicVolume = 1.0f;
    private boolean cameraClosed;
    private boolean fileMode;
    private boolean liveControlsHidden;
    private boolean pipRestartScheduled;
    private boolean pipRestartingStream;
    private boolean pipOrientationRelaxed;
    private Bitmap lastMirrorBitmap;
    private long fileLiveStartMs;
    private final ArrayList<Uri> filePlaylist = new ArrayList<Uri>();
    private final ArrayList<Uri> bgmPlaylist = new ArrayList<Uri>();
    private final Random random = new Random();
    private int filePlaylistIndex;
    private int filePlayMode = PLAY_MODE_LIST_LOOP;
    private int bgmPlayMode = PLAY_MODE_LIST_LOOP;
    private boolean bgmEnabled;
    private boolean bgmPaused;
    private boolean preserveNextBackgroundMusicApply;
    private boolean userStoppingFileStream;
    private int pendingFilePlaylistIndex = -1;
    private int reopenPlaylistAfterPicker = REOPEN_NONE;
    private long pendingFileSeekMs = -1L;
    private Uri progressFileUri;
    private Uri progressBgmUri;
    private boolean localActivationSyncInFlight;
    private final Runnable trialStopRunnable = new Runnable() {
        @Override public void run() {
            if (isActivated() || !isAnyStreaming()) return;
            getSharedPreferences("license", Context.MODE_PRIVATE).edit()
                    .putLong("trialNextAllowedMs", System.currentTimeMillis() + TRIAL_COOLDOWN_MS)
                    .apply();
            stopCurrentLive();
            Toast.makeText(MainActivity.this, "未激活版本本次免费推流已满 10 分钟，请 30 分钟后再试。", Toast.LENGTH_LONG).show();
        }
    };
    private final Runnable progressUpdateRunnable = new Runnable() {
        @Override public void run() {
            updatePlaybackProgressUi();
            if (previewBox != null) {
                previewBox.postDelayed(this, 500);
            }
        }
    };
    private final Runnable pipMirrorFrameRunnable = new Runnable() {
        @Override public void run() {
            if (!shouldShowStreamMirror()) return;
            samplePipMirrorFrame();
            if (previewBox != null) {
                previewBox.postDelayed(this, 250);
            }
        }
    };
    private final Runnable relaxPipOrientationRunnable = new Runnable() {
        @Override public void run() {
            relaxOrientationForPip();
        }
    };

    private static final class ProgressViews {
        LinearLayout root;
        TextView left;
        TextView right;
        TextView bubble;
        TextView current;
        SeekBar bar;
        boolean tracking;
        long durationMs;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        SharedPreferences livePrefs = getSharedPreferences("live", Context.MODE_PRIVATE);
        landscape = livePrefs.getBoolean("landscape", false);
        muted = livePrefs.getBoolean("muted", false);
        microphoneEnabled = livePrefs.getBoolean("microphoneEnabled", true);
        microphoneVolume = livePrefs.getFloat("microphoneVolume", 1.0f);
        videoVolume = livePrefs.getFloat("videoVolume", 1.0f);
        backgroundMusicVolume = livePrefs.getFloat("backgroundMusicVolume", 1.0f);
        applyLiveRequestedOrientation();
        buildUi();
        if (sharedCameraPublisher == null) {
            sharedCameraPublisher = new RtmpPublisher(getApplicationContext(), preview, this);
        } else {
            sharedCameraPublisher.attach(preview, this);
        }
        publisher = sharedCameraPublisher;
        if (sharedFilePublisher == null) {
            sharedFilePublisher = new FileRtmpPublisher(getApplicationContext(), this);
        } else {
            sharedFilePublisher.setListener(this);
        }
        filePublisher = sharedFilePublisher;
        applyMuteState();
        PowerManager pm = (PowerManager) getApplicationContext().getSystemService(Context.POWER_SERVICE);
        if (sharedLiveWakeLock == null && pm != null) {
            sharedLiveWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "CoryKuiLivestream:Live");
            sharedLiveWakeLock.setReferenceCounted(false);
        }
        liveWakeLock = sharedLiveWakeLock;
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (sharedLiveWifiLock == null && wifiManager != null) {
            sharedLiveWifiLock = wifiManager.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "CoryKuiLivestream:Wifi");
            sharedLiveWifiLock.setReferenceCounted(false);
        }
        liveWifiLock = sharedLiveWifiLock;
        loadPlaylists();
        Uri runningFile = filePublisher.getCurrentFileUri();
        if (filePublisher.isStreaming() && runningFile != null) {
            fileUri = runningFile;
            fileMode = true;
            fileLiveStartMs = filePublisher.getStartElapsedMs();
            configureFileMode(true);
            syncStreamingUi();
        } else {
            String savedFile = getSharedPreferences("live", Context.MODE_PRIVATE).getString("fileUri", "");
            if (savedFile.length() > 0) {
            fileUri = Uri.parse(savedFile);
            fileMode = true;
            configureFileMode(true);
            }
        }
        if (!fileMode && publisher.isStreaming()) {
            cameraClosed = false;
            startKeepAliveService();
            syncStreamingUi();
        } else if (!fileMode && hasPermissions()) {
            publisher.openCameraMode(cameraMode);
        } else if (!fileMode) {
            requestLivePermissions();
        }
        syncLocalActivationWithServer(false, false);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (isInPictureInPictureMode()) {
            setPipUi(true);
            scheduleRelaxOrientationForPip();
            updateLivePictureInPictureParams();
            return;
        }
        restoreOrientationAfterPip();
        restoreForegroundLayoutAfterPip();
        setPipUi(false);
        syncStreamingUi();
        if (fileMode && fileUri != null && filePlayer != null) {
            showFilePreview(fileUri);
            syncFilePreviewPosition();
        }
    }

    @Override
    protected void onPause() {
        if (isAnyStreaming()) {
            setPipUi(true);
            enterLivePictureInPicture();
        }
        super.onPause();
    }

    @Override
    protected void onStop() {
        if (isAnyStreaming() || isInPictureInPictureMode()) {
            setPipUi(true);
        }
        super.onStop();
    }

    @Override
    protected void onUserLeaveHint() {
        if (isAnyStreaming()) {
            setPipUi(true);
            enterLivePictureInPicture();
        }
        super.onUserLeaveHint();
    }

    @Override
    protected void onResume() {
        super.onResume();
        recoverLandscapeFromConfiguration();
        applyMuteState();
        syncLocalActivationWithServer(false, false);
        if (isInPictureInPictureMode()) {
            setPipUi(true);
            scheduleRelaxOrientationForPip();
            return;
        }
        restoreOrientationAfterPip();
        setPipUi(false);
        syncStreamingUi();
        if (isAnyStreaming()) {
            if (fileMode && fileUri != null && filePlayer != null) {
                showFilePreview(fileUri);
                if (!isImageUri(fileUri) && fileLiveStartMs > 0) {
                    filePlayer.seekTo((int) Math.max(0, SystemClock.elapsedRealtime() - fileLiveStartMs));
                }
                if (!isImageUri(fileUri) && !filePlayer.isPlaying()) {
                    filePlayer.start();
                }
            } else if (!fileMode && publisher != null && !cameraClosed) {
                preview.setVisibility(View.VISIBLE);
            }
            if (liveControlsHidden) {
                showLiveControlsTemporarily();
            }
            return;
        }
        if (publisher != null && hasPermissions() && !cameraClosed && !fileMode) {
            publisher.openCameraMode(cameraMode);
        } else if (fileMode && fileUri != null && filePlayer != null) {
            showFilePreview(fileUri);
        }
    }

    @Override
    protected void onDestroy() {
        if (previewBox != null) {
            previewBox.removeCallbacks(progressUpdateRunnable);
            previewBox.removeCallbacks(pipMirrorFrameRunnable);
        }
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMISSIONS && hasPermissions()) {
            publisher.openCameraMode(cameraMode);
            log("权限已授权，可以开始直播。");
        } else {
            log("需要相机和麦克风权限才能直播。");
        }
    }

    private void requestLivePermissions() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{
                    Manifest.permission.CAMERA,
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.POST_NOTIFICATIONS
            }, REQ_PERMISSIONS);
        } else {
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, REQ_PERMISSIONS);
        }
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8, 12, 15));

        previewBox = new FrameLayout(this);
        previewBox.setBackgroundColor(Color.BLACK);
        previewBox.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent event) {
                return handlePreviewTouch(event);
            }
        });
        root.addView(previewBox);

        preview = new TextureView(this);
        previewBox.addView(preview, new FrameLayout.LayoutParams(-1, -1));
        preview.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent event) {
                return handlePreviewTouch(event);
            }
        });

        streamMirror = new ImageView(this);
        streamMirror.setBackgroundColor(Color.BLACK);
        streamMirror.setScaleType(ImageView.ScaleType.FIT_XY);
        streamMirror.setVisibility(View.GONE);
        streamMirror.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent event) {
                return handlePreviewTouch(event);
            }
        });
        previewBox.addView(streamMirror, new FrameLayout.LayoutParams(-1, -1));

        filePlayer = new VideoView(this);
        filePlayer.setVisibility(View.GONE);
        filePlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override public void onPrepared(MediaPlayer mp) {
                currentFileMediaPlayer = mp;
                filePreviewPrepared = true;
                updateFilePreviewVolume();
                if (fileMode && filePublisher != null && filePublisher.isStreaming() && fileLiveStartMs > 0 && !isImageUri(fileUri)) {
                    int position = (int) Math.max(0, SystemClock.elapsedRealtime() - fileLiveStartMs);
                    filePlayer.seekTo(position);
                }
                if (fileMode && filePublisher != null && filePublisher.isStreaming() && !isImageUri(fileUri)) {
                    filePlayer.start();
                }
            }
        });
        filePlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override public void onCompletion(MediaPlayer mp) {
                if (fileMode && !isAnyStreaming() && filePlaylist.size() > 0) {
                    filePlaylistIndex = nextPlaylistIndex(filePlaylistIndex, filePlaylist.size(), filePlayMode);
                    fileUri = filePlaylist.get(filePlaylistIndex);
                    getSharedPreferences("live", Context.MODE_PRIVATE).edit().putString("fileUri", fileUri.toString()).apply();
                    savePlaylists();
                    showFilePreview(fileUri);
                }
            }
        });
        filePlayer.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent event) {
                return handlePreviewTouch(event);
            }
        });
        previewBox.addView(filePlayer, new FrameLayout.LayoutParams(-1, -1));

        fileImagePreview = new ImageView(this);
        fileImagePreview.setBackgroundColor(Color.BLACK);
        fileImagePreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        fileImagePreview.setVisibility(View.GONE);
        fileImagePreview.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent event) {
                return handlePreviewTouch(event);
            }
        });
        previewBox.addView(fileImagePreview, new FrameLayout.LayoutParams(-1, -1));

        title = overlayText("小魁直播  CoryKui Livestream", 16);
        FrameLayout.LayoutParams titleLp = new FrameLayout.LayoutParams(-2, -2, Gravity.LEFT | Gravity.TOP);
        titleLp.setMargins(dp(12), dp(10), dp(72), 0);
        previewBox.addView(title, titleLp);

        fullscreenButton = overlayButton("↗");
        FrameLayout.LayoutParams fsLp = new FrameLayout.LayoutParams(dp(48), dp(42), Gravity.RIGHT | Gravity.TOP);
        fsLp.setMargins(0, dp(8), dp(8), 0);
        previewBox.addView(fullscreenButton, fsLp);

        appMenuButton = overlayButton("⋮");
        FrameLayout.LayoutParams menuLp = new FrameLayout.LayoutParams(dp(48), dp(42), Gravity.RIGHT | Gravity.TOP);
        menuLp.setMargins(0, dp(8), dp(58), 0);
        previewBox.addView(appMenuButton, menuLp);

        settingsButton = overlayButton("直播设置");
        orientationButton = overlayButton("横屏");
        cameraButton = overlayButton("切摄像头");
        startButton = overlayButton("开始直播");
        recordButton = overlayButton("录像");
        moreButton = overlayButton("更多");
        recordButton.setEnabled(false);

        normalControls = new LinearLayout(this);
        normalControls.setOrientation(LinearLayout.VERTICAL);
        normalControls.setPadding(dp(10), 0, dp(10), dp(10));
        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.addView(settingsButton, new LinearLayout.LayoutParams(0, dp(42), 1.0f));
        topRow.addView(orientationButton, new LinearLayout.LayoutParams(0, dp(42), 1.0f));
        topRow.addView(cameraButton, new LinearLayout.LayoutParams(0, dp(42), 1.0f));
        LinearLayout bottomRow = new LinearLayout(this);
        bottomRow.setOrientation(LinearLayout.HORIZONTAL);
        bottomRow.addView(startButton, new LinearLayout.LayoutParams(0, dp(42), 1.0f));
        bottomRow.addView(recordButton, new LinearLayout.LayoutParams(0, dp(42), 1.0f));
        bottomRow.addView(moreButton, new LinearLayout.LayoutParams(0, dp(42), 1.0f));
        normalControls.addView(topRow);
        normalControls.addView(bottomRow);
        FrameLayout.LayoutParams controlsLp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        previewBox.addView(normalControls, controlsLp);

        zoomControls = new LinearLayout(this);
        zoomControls.setOrientation(LinearLayout.VERTICAL);
        zoomControls.setPadding(dp(12), 0, dp(12), 0);
        zoomLabel = overlayText("手动光学变焦：1.0x", 14);
        SeekBar zoomBar = new SeekBar(this);
        zoomBar.setMax(100);
        zoomBar.setProgress(0);
        zoomBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float zoom = 1.0f + progress / 100.0f * Math.max(0.0f, publisher.getMaxZoom() - 1.0f);
                zoomLabel.setText(String.format(Locale.US, "手动光学变焦：%.1fx", zoom));
                publisher.setZoom(zoom);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        zoomControls.addView(zoomLabel);
        zoomControls.addView(zoomBar, new LinearLayout.LayoutParams(-1, dp(36)));
        FrameLayout.LayoutParams zoomLp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        zoomLp.setMargins(0, 0, 0, dp(88));
        previewBox.addView(zoomControls, zoomLp);

        status = overlayText("", 12);
        status.setMaxLines(3);
        FrameLayout.LayoutParams statusLp = new FrameLayout.LayoutParams(-1, -2, Gravity.LEFT | Gravity.BOTTOM);
        statusLp.setMargins(dp(12), 0, dp(12), dp(150));
        previewBox.addView(status, statusLp);

        progressPanel = new LinearLayout(this);
        progressPanel.setOrientation(LinearLayout.VERTICAL);
        progressPanel.setPadding(dp(10), dp(6), dp(10), dp(6));
        progressPanel.setBackgroundColor(Color.argb(120, 0, 0, 0));
        fileProgressViews = createProgressBlock("直播文件", true);
        bgmProgressViews = createProgressBlock("背景音乐", false);
        progressPanel.addView(fileProgressViews.root, new LinearLayout.LayoutParams(-1, -2));
        progressPanel.addView(bgmProgressViews.root, new LinearLayout.LayoutParams(-1, -2));
        progressPanel.setVisibility(View.GONE);
        FrameLayout.LayoutParams progressLp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        progressLp.setMargins(dp(10), 0, dp(10), dp(92));
        previewBox.addView(progressPanel, progressLp);

        exitFullscreenButton = overlayButton("↙");
        muteButton = overlayButton("静音");
        stopLiveButton = overlayButton("停止直播");
        closeCameraButton = overlayButton("关闭摄像头");
        fullControls = new LinearLayout(this);
        fullControls.setOrientation(LinearLayout.HORIZONTAL);
        fullControls.setPadding(dp(8), dp(8), dp(8), 0);
        fullControls.addView(muteButton, new LinearLayout.LayoutParams(0, dp(42), 1.0f));
        fullControls.addView(stopLiveButton, new LinearLayout.LayoutParams(0, dp(42), 1.0f));
        fullControls.addView(closeCameraButton, new LinearLayout.LayoutParams(0, dp(42), 1.0f));
        FrameLayout.LayoutParams fullLp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        previewBox.addView(fullControls, fullLp);
        FrameLayout.LayoutParams exitLp = new FrameLayout.LayoutParams(dp(48), dp(42), Gravity.RIGHT | Gravity.TOP);
        exitLp.setMargins(0, dp(8), dp(8), 0);
        previewBox.addView(exitFullscreenButton, exitLp);
        fullControls.setVisibility(View.GONE);
        exitFullscreenButton.setVisibility(View.GONE);

        bindActions();
        syncOrientationUi();
        syncMuteUi();
        setContentView(root);
        setNormalPreviewBounds();
        previewBox.removeCallbacks(progressUpdateRunnable);
        previewBox.post(progressUpdateRunnable);
        log("请先进入设置填写 RTMP 地址。");
    }

    private void bindActions() {
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showSettingsDialog(); }
        });
        appMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showAppMenuDialogV2(); }
        });
        orientationButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleOrientation(); }
        });
        fullscreenButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { setFullscreenMode(true); }
        });
        exitFullscreenButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { setFullscreenMode(false); }
        });
        cameraButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (fileMode) {
                    cancelFileMode();
                    return;
                }
                if (cameraClosed) {
                    cameraClosed = false;
                    publisher.openCameraMode(cameraMode);
                    cameraButton.setText("切摄像头");
                    closeCameraButton.setText("关闭摄像头");
                    return;
                }
                cameraClosed = false;
                showCameraMenu();
            }
        });
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleStreaming(); }
        });
        recordButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleRecording(); }
        });
        moreButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMoreMenu(); }
        });
        muteButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                toggleMute();
            }
        });
        stopLiveButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                stopCurrentLive();
            }
        });
        closeCameraButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                toggleCameraOpen();
            }
        });
    }

    private void showSettingsDialog() {
        final SharedPreferences sp = getSharedPreferences("live", Context.MODE_PRIVATE);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(Color.rgb(12, 15, 18));
        int pad = dp(14);
        panel.setPadding(pad, pad, pad, pad);

        final EditText serverInput = input("RTMP 推流地址，例如 rtmp://live.example.com/live");
        final EditText keyInput = input("推流码 / Stream Key");
        final EditText multiInput = input("rtmp://host/live/key\nrtmp://host2/live/key2");
        keyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        multiInput.setSingleLine(false);
        multiInput.setMinLines(3);
        multiInput.setGravity(Gravity.TOP);
        final boolean activatedForSettings = isActivated();
        serverInput.setText(sp.getString("server", ""));
        keyInput.setText(sp.getString("key", ""));
        if (activatedForSettings) {
            multiInput.setText(sp.getString("multi", ""));
        } else {
            sp.edit().putString("multi", "").apply();
            multiInput.setText("");
            multiInput.setHint("未激活版本不能使用并发推流地址");
            multiInput.setEnabled(false);
            multiInput.setFocusable(false);
        }

        final Spinner qualitySpinner = new Spinner(this);
        final String[] qualities = new String[]{"720p", "480p", "1080p"};
        qualitySpinner.setAdapter(qualityAdapter(qualities));
        String quality = sp.getString("quality", "720p");
        for (int i = 0; i < qualities.length; i++) {
            if (qualities[i].equals(quality)) qualitySpinner.setSelection(i);
        }

        panel.addView(label("推流地址"));
        panel.addView(serverInput);
        panel.addView(label("推流码"));
        panel.addView(keyInput);
        panel.addView(label("并发推流地址（每行一个完整 rtmp:// 地址）"));
        panel.addView(multiInput);
        panel.addView(label("清晰度"));
        panel.addView(qualitySpinner);
        TextView fileLabel = label("本地文件：" + (fileUri == null ? "未选择" : fileUri.toString()));
        panel.addView(fileLabel);
        Button clearFileButton = overlayButton("清除本地文件模式");
        panel.addView(clearFileButton, new LinearLayout.LayoutParams(-1, dp(42)));
        clearFileButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                fileUri = null;
                fileMode = false;
                getSharedPreferences("live", Context.MODE_PRIVATE).edit().remove("fileUri").apply();
                configureFileMode(false);
                log("已切回摄像头直播模式。");
            }
        });

        new AlertDialog.Builder(this)
                .setTitle("直播设置")
                .setView(panel)
                .setNeutralButton("选择文件", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        saveStreamSettings(serverInput, keyInput, multiInput, qualitySpinner);
                        pickLocalFile();
                    }
                })
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        saveStreamSettings(serverInput, keyInput, multiInput, qualitySpinner);
                        log("直播设置已保存。");
                    }
                })
                .show();
    }

    private void saveStreamSettings(EditText serverInput, EditText keyInput, EditText multiInput, Spinner qualitySpinner) {
        String multi = isActivated() ? multiInput.getText().toString().trim() : "";
        getSharedPreferences("live", Context.MODE_PRIVATE).edit()
                .putString("server", serverInput.getText().toString().trim())
                .putString("key", keyInput.getText().toString().trim())
                .putString("multi", multi)
                .putString("quality", (String) qualitySpinner.getSelectedItem())
                .apply();
    }

    private void loadPlaylists() {
        SharedPreferences sp = getSharedPreferences("live", Context.MODE_PRIVATE);
        readUriList(sp.getString("filePlaylist", ""), filePlaylist);
        readUriList(sp.getString("bgmPlaylist", ""), bgmPlaylist);
        filePlayMode = sp.getInt("filePlayMode", PLAY_MODE_LIST_LOOP);
        bgmPlayMode = sp.getInt("bgmPlayMode", PLAY_MODE_LIST_LOOP);
        bgmEnabled = sp.getBoolean("bgmEnabled", bgmPlaylist.size() > 0);
        filePlaylistIndex = Math.min(sp.getInt("filePlaylistIndex", 0), Math.max(0, filePlaylist.size() - 1));
    }

    private void savePlaylists() {
        getSharedPreferences("live", Context.MODE_PRIVATE).edit()
                .putString("filePlaylist", writeUriList(filePlaylist))
                .putString("bgmPlaylist", writeUriList(bgmPlaylist))
                .putInt("filePlayMode", filePlayMode)
                .putInt("bgmPlayMode", bgmPlayMode)
                .putBoolean("bgmEnabled", bgmEnabled)
                .putInt("filePlaylistIndex", filePlaylistIndex)
                .apply();
    }

    private void readUriList(String raw, ArrayList<Uri> out) {
        out.clear();
        if (raw == null || raw.length() == 0) return;
        String[] lines = raw.split("\\n");
        for (String line : lines) {
            String value = line.trim();
            if (value.length() > 0) out.add(Uri.parse(value));
        }
    }

    private String writeUriList(ArrayList<Uri> list) {
        StringBuilder builder = new StringBuilder();
        for (Uri uri : list) {
            if (builder.length() > 0) builder.append('\n');
            builder.append(uri.toString());
        }
        return builder.toString();
    }

    private void showCameraMenu() {
        final PopupWindow popup = new PopupWindow(this);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(Color.argb(190, 0, 0, 0));
        panel.setPadding(dp(8), dp(8), dp(8), dp(8));

        Button backMain = overlayButton("后置主摄 1x");
        Button ultraWide = overlayButton("后置超广角 0.6x");
        Button front = overlayButton("前置摄像头");
        Button openClose = overlayButton(cameraClosed ? "开启摄像头" : "关闭摄像头");
        panel.addView(backMain, new LinearLayout.LayoutParams(dp(190), dp(44)));
        panel.addView(ultraWide, new LinearLayout.LayoutParams(dp(190), dp(44)));
        panel.addView(front, new LinearLayout.LayoutParams(dp(190), dp(44)));
        panel.addView(openClose, new LinearLayout.LayoutParams(dp(190), dp(44)));

        backMain.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                popup.dismiss();
                switchCameraMode(RtmpPublisher.CAMERA_BACK_MAIN);
            }
        });
        ultraWide.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                popup.dismiss();
                switchCameraMode(RtmpPublisher.CAMERA_BACK_ULTRAWIDE);
            }
        });
        front.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                popup.dismiss();
                switchCameraMode(RtmpPublisher.CAMERA_FRONT);
            }
        });
        openClose.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                popup.dismiss();
                toggleCameraOpen();
            }
        });

        popup.setContentView(panel);
        popup.setWidth(dp(206));
        popup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.setOutsideTouchable(true);
        popup.setFocusable(true);
        popup.showAsDropDown(cameraButton, 0, -dp(142));
    }

    private void showMoreMenu() {
        final PopupWindow popup = new PopupWindow(this);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(Color.argb(205, 0, 0, 0));
        panel.setPadding(dp(8), dp(8), dp(8), dp(8));

        Button mute = overlayButton(muted ? "取消静音" : "静音");
        Button bgm = overlayButton("背景音乐播放列表");
        Button bgmMode = overlayButton("背景音乐：" + playModeLabel(bgmPlayMode));
        Button fileList = overlayButton("直播文件播放列表");
        Button fileModeButton = overlayButton("文件循环：" + playModeLabel(filePlayMode));
        panel.addView(mute, new LinearLayout.LayoutParams(dp(220), dp(44)));
        panel.addView(bgm, new LinearLayout.LayoutParams(dp(220), dp(44)));
        panel.addView(bgmMode, new LinearLayout.LayoutParams(dp(220), dp(44)));
        panel.addView(fileList, new LinearLayout.LayoutParams(dp(220), dp(44)));
        panel.addView(fileModeButton, new LinearLayout.LayoutParams(dp(220), dp(44)));
        final Button otherSettings = overlayButton("其他设置");
        panel.addView(otherSettings, new LinearLayout.LayoutParams(dp(220), dp(44)));

        mute.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                popup.dismiss();
                toggleMute();
            }
        });
        bgm.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                popup.dismiss();
                showBackgroundMusicPlaylistDialogV2();
            }
        });
        bgmMode.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                bgmPlayMode = nextPlayMode(bgmPlayMode);
                updateBackgroundMusicMode();
                bgmMode.setText("背景音乐：" + playModeLabel(bgmPlayMode));
            }
        });
        fileList.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                popup.dismiss();
                showFilePlaylistDialogV2();
            }
        });
        fileModeButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                filePlayMode = nextPlayMode(filePlayMode);
                fileModeButton.setText("文件循环：" + playModeLabel(filePlayMode));
                savePlaylists();
            }
        });

        otherSettings.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                popup.dismiss();
                showOtherSettingsDialogV2();
            }
        });

        popup.setContentView(panel);
        popup.setWidth(dp(236));
        popup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.setOutsideTouchable(true);
        popup.setFocusable(true);
        popup.showAsDropDown(moreButton, -dp(130), -dp(282));
    }

    private void showOtherSettingsDialog() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        panel.setPadding(pad, pad, pad, pad);
        Button version = overlayButton("版本号");
        panel.addView(version, new LinearLayout.LayoutParams(-1, dp(46)));
        new AlertDialog.Builder(this)
                .setTitle("其他设置")
                .setView(panel)
                .setNegativeButton("关闭", null)
                .show();
        version.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                showVersionDialog();
            }
        });
    }

    private void showAppMenuDialog() {
        final ArrayList<String> items = new ArrayList<String>();
        items.add("关于我们");
        items.add("检查更新");
        items.add("授权信息");
        items.add("备份与恢复");
        if (!isActivated()) items.add("激活");
        new AlertDialog.Builder(this)
                .setTitle("设置")
                .setItems(items.toArray(new String[items.size()]), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        String item = items.get(which);
                        if ("关于我们".equals(item)) showAboutDialog();
                        else if ("检查更新".equals(item)) checkUpdate(true);
                        else if ("授权信息".equals(item)) showLicenseInfoDialog();
                        else if ("备份与恢复".equals(item)) showBackupRestoreDialog();
                        else if ("激活".equals(item)) showActivationDialog();
                    }
                })
                .show();
    }

    private void showOtherSettingsDialogV2() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        panel.setPadding(pad, pad, pad, pad);
        Button version = overlayButton("版本号");
        Button systemSettings = overlayButton("系统设置");
        final Button microphone = overlayButton(microphoneEnabled ? "关闭麦克风" : "开启麦克风");
        Button volume = overlayButton("调节音量");
        panel.addView(version, new LinearLayout.LayoutParams(-1, dp(46)));
        panel.addView(systemSettings, new LinearLayout.LayoutParams(-1, dp(46)));
        panel.addView(microphone, new LinearLayout.LayoutParams(-1, dp(46)));
        panel.addView(volume, new LinearLayout.LayoutParams(-1, dp(46)));
        new AlertDialog.Builder(this)
                .setTitle("其他设置")
                .setView(panel)
                .setNegativeButton("关闭", null)
                .show();
        version.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                showVersionDialog();
            }
        });
        systemSettings.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                showAppMenuDialogV2();
            }
        });
        microphone.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                toggleMicrophoneEnabled();
                microphone.setText(microphoneEnabled ? "关闭麦克风" : "开启麦克风");
            }
        });
        volume.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                showVolumeDialogV2();
            }
        });
    }

    private void showAppMenuDialogV2() {
        final ArrayList<String> items = new ArrayList<String>();
        items.add("关于我们");
        items.add("检查更新");
        items.add("授权信息");
        items.add("备份与恢复");
        if (!isActivated()) items.add("激活");
        new AlertDialog.Builder(this)
                .setTitle("系统设置")
                .setItems(items.toArray(new String[items.size()]), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        String item = items.get(which);
                        if ("关于我们".equals(item)) showAboutDialog();
                        else if ("检查更新".equals(item)) checkUpdate(true);
                        else if ("授权信息".equals(item)) showLicenseInfoDialog();
                        else if ("备份与恢复".equals(item)) showBackupRestoreDialog();
                        else if ("激活".equals(item)) showActivationDialog();
                    }
                })
                .show();
    }

    private void showAboutDialog() {
        String version = currentVersionName();
        TextView tv = overlayText("小魁直播 CoryKui Livestream\n版本号：" + version
                + "\n本程序由 小魁老师 制作\nE-mail:mail@pt20.cn", 16);
        tv.setTextIsSelectable(true);
        tv.setPadding(dp(20), dp(12), dp(20), dp(12));
        new AlertDialog.Builder(this)
                .setTitle("关于我们")
                .setView(tv)
                .setPositiveButton("关闭", null)
                .show();
    }

    private void showLicenseInfoDialog() {
        SharedPreferences sp = getSharedPreferences("license", Context.MODE_PRIVATE);
        String user = sp.getString("username", "");
        String serial = sp.getString("serial", "");
        String activatedAt = sp.getString("activatedAt", "");
        LicenseUtil.Result result = LicenseUtil.verify(user, serial);
        String message = result.ok
                ? ("授权给：" + result.username + "\n有效期至：" + LicenseUtil.prettyDate(result.expiry))
                : "当前未激活或授权已过期";
        if (activatedAt.length() > 0) message += "\n激活时间：" + activatedAt;
        if (serial.length() > 0) message += "\n\n序列号：\n" + maskSerial(serial);
        TextView tv = overlayText(message, 15);
        tv.setTextIsSelectable(true);
        tv.setPadding(dp(20), dp(12), dp(20), dp(12));
        new AlertDialog.Builder(this)
                .setTitle("授权信息")
                .setView(tv)
                .setPositiveButton("关闭", null)
                .show();
    }

    private void showActivationDialog() {
        final SharedPreferences sp = getSharedPreferences("license", Context.MODE_PRIVATE);
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18), dp(10), dp(18), dp(6));
        final EditText user = input("用户名");
        user.setText(sp.getString("username", ""));
        final EditText serial = input("序列号");
        serial.setSingleLine(false);
        serial.setMinLines(4);
        serial.setGravity(Gravity.TOP);
        serial.setText(sp.getString("serial", ""));
        form.addView(user, new LinearLayout.LayoutParams(-1, dp(54)));
        form.addView(serial, new LinearLayout.LayoutParams(-1, dp(118)));
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("软件激活")
                .setView(form)
                .setNegativeButton("取消", null)
                .setPositiveButton("联网激活", null)
                .create();
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override public void onShow(DialogInterface d) {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        activateOnline(user.getText().toString().trim(), serial.getText().toString().trim(), dialog);
                    }
                });
            }
        });
        dialog.show();
    }

    private void activateOnline(final String user, final String serial, final AlertDialog dialog) {
        if (user.length() == 0 || serial.length() == 0) {
            Toast.makeText(this, "请输入用户名和序列号。", Toast.LENGTH_SHORT).show();
            return;
        }
        final String deviceId = activationDeviceId();
        final String deviceLabel = activationDeviceLabel();
        Toast.makeText(this, "正在联网激活...", Toast.LENGTH_SHORT).show();
        new AsyncTask<Void, Void, String>() {
            Date serverTime;
            LicenseUtil.Result localResult;

            @Override protected String doInBackground(Void... params) {
                if (LicenseUtil.isLocalSerial(serial)) {
                    localResult = LicenseUtil.verify(user, serial, new Date());
                    if (!localResult.ok) return localResult.error.length() == 0 ? "序列号验证失败。" : localResult.error;
                    return "OK";
                }
                serverTime = fetchServerTime();
                if (serverTime == null) return "联网校时失败，激活失败。";
                localResult = LicenseUtil.verify(user, serial, serverTime);
                if (!localResult.ok) return localResult.error.length() == 0 ? "序列号验证失败。" : localResult.error;
                try {
                    String body = "action=activate"
                            + "&username=" + URLEncoder.encode(localResult.username, "UTF-8")
                            + "&serial=" + URLEncoder.encode(serial, "UTF-8")
                            + "&deviceId=" + URLEncoder.encode(deviceId, "UTF-8")
                            + "&deviceLabel=" + URLEncoder.encode(deviceLabel, "UTF-8")
                            + "&version=" + URLEncoder.encode(currentVersionName(), "UTF-8")
                            + "&package=" + URLEncoder.encode(getPackageName(), "UTF-8");
                    String response = httpPost(ACTIVATION_URL, body);
                    if (response == null || response.trim().length() == 0) return "云端激活失败。";
                    String normalized = response.trim().toUpperCase(Locale.US);
                    if (!normalized.startsWith("OK")) return response.trim();
                    return "OK";
                } catch (Exception e) {
                    return "联网激活失败：" + e.getMessage();
                }
            }

            @Override protected void onPostExecute(String result) {
                if (!"OK".equals(result)) {
                    Toast.makeText(MainActivity.this, result, Toast.LENGTH_LONG).show();
                    return;
                }
                getSharedPreferences("license", Context.MODE_PRIVATE).edit()
                        .putBoolean("activated", true)
                        .putString("username", localResult.username)
                        .putString("serial", serial)
                        .putString("expiry", localResult.expiry)
                        .putString("deviceId", deviceId)
                        .putString("deviceLabel", deviceLabel)
                        .putString("activatedAt", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()))
                        .remove("trialNextAllowedMs")
                        .apply();
                if (publisher != null) publisher.setTrialWatermark(false);
                if (localResult.local) syncLocalActivationWithServer(true, true);
                Toast.makeText(MainActivity.this, "激活成功，有效期至 " + LicenseUtil.prettyDate(localResult.expiry), Toast.LENGTH_LONG).show();
                dialog.dismiss();
            }
        }.execute();
    }

    private boolean isActivated() {
        SharedPreferences sp = getSharedPreferences("license", Context.MODE_PRIVATE);
        if (!sp.getBoolean("activated", false)) return false;
        LicenseUtil.Result result = LicenseUtil.verify(sp.getString("username", ""), sp.getString("serial", ""));
        if (!result.ok) return false;
        String storedDeviceId = sp.getString("deviceId", "");
        return storedDeviceId.length() > 0 && storedDeviceId.equals(activationDeviceId());
    }

    private void syncLocalActivationWithServer(final boolean force, final boolean notify) {
        final SharedPreferences sp = getSharedPreferences("license", Context.MODE_PRIVATE);
        if (!sp.getBoolean("activated", false)) return;
        final String user = sp.getString("username", "");
        final String serial = sp.getString("serial", "");
        if (!LicenseUtil.isLocalSerial(serial)) return;

        final String deviceId = activationDeviceId();
        final String storedDeviceId = sp.getString("deviceId", "");
        if (storedDeviceId.length() == 0 || !storedDeviceId.equals(deviceId)) {
            clearActivationAfterCloudRejection("\u6388\u6743\u8bbe\u5907\u7ed1\u5b9a\u4fe1\u606f\u65e0\u6548\uff0c\u8bf7\u91cd\u65b0\u6fc0\u6d3b\u3002");
            return;
        }

        final LicenseUtil.Result localCheck = LicenseUtil.verify(user, serial, new Date());
        if (!localCheck.ok) return;
        long now = System.currentTimeMillis();
        long lastAttempt = sp.getLong("localSyncAttemptMs", 0L);
        if (!force && now - lastAttempt < LOCAL_ACTIVATION_SYNC_RETRY_MS) return;
        if (localActivationSyncInFlight) return;
        localActivationSyncInFlight = true;
        sp.edit().putLong("localSyncAttemptMs", now).apply();

        new AsyncTask<Void, Void, String>() {
            @Override protected String doInBackground(Void... params) {
                try {
                    String body = "action=syncLocal"
                            + "&username=" + URLEncoder.encode(localCheck.username, "UTF-8")
                            + "&serial=" + URLEncoder.encode(serial, "UTF-8")
                            + "&deviceId=" + URLEncoder.encode(deviceId, "UTF-8")
                            + "&deviceLabel=" + URLEncoder.encode(activationDeviceLabel(), "UTF-8")
                            + "&version=" + URLEncoder.encode(currentVersionName(), "UTF-8")
                            + "&package=" + URLEncoder.encode(getPackageName(), "UTF-8");
                    String response = httpPost(ACTIVATION_URL, body);
                    if (response == null || response.trim().length() == 0) return "RETRY:";
                    String trimmed = response.trim();
                    String upper = trimmed.toUpperCase(Locale.US);
                    if (upper.startsWith("HTTP")) return "RETRY:" + trimmed;
                    if (!upper.startsWith("OK")) return "FAIL:" + trimmed;
                    return "OK";
                } catch (Exception e) {
                    return "RETRY:" + e.getMessage();
                }
            }

            @Override protected void onPostExecute(String result) {
                localActivationSyncInFlight = false;
                if ("OK".equals(result)) {
                    getSharedPreferences("license", Context.MODE_PRIVATE).edit()
                            .putString("localSyncStatus", "OK")
                            .putString("localSyncAt", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()))
                            .putString("localSyncDeviceId", deviceId)
                            .remove("localSyncError")
                            .apply();
                    if (notify) Toast.makeText(MainActivity.this, "\u79bb\u7ebf\u6388\u6743\u5df2\u540c\u6b65\u81f3\u4e91\u7aef\u5e76\u5b8c\u6210\u8bbe\u5907\u7ed1\u5b9a\u3002", Toast.LENGTH_LONG).show();
                    return;
                }
                if (result != null && result.startsWith("RETRY:")) {
                    String error = result.substring("RETRY:".length()).trim();
                    getSharedPreferences("license", Context.MODE_PRIVATE).edit()
                            .putString("localSyncStatus", "PENDING")
                            .putString("localSyncError", error)
                            .apply();
                    Log.w("CoryKuiLivestream", "Local activation cloud sync pending: " + error);
                    if (notify) Toast.makeText(MainActivity.this, "\u79bb\u7ebf\u6388\u6743\u5df2\u5728\u672c\u673a\u751f\u6548\uff0c\u6682\u65f6\u65e0\u6cd5\u8fde\u63a5\u4e91\u7aef\uff0c\u8054\u7f51\u540e\u4f1a\u81ea\u52a8\u540c\u6b65\u3002", Toast.LENGTH_LONG).show();
                    return;
                }
                String message = result == null ? "" : result;
                if (message.startsWith("FAIL:")) message = message.substring("FAIL:".length()).trim();
                if (message.length() == 0) message = "\u4e91\u7aef\u6821\u9a8c\u5931\u8d25";
                clearActivationAfterCloudRejection("\u79bb\u7ebf\u6388\u6743\u4e91\u7aef\u6821\u9a8c\u5931\u8d25\uff1a" + message);
            }
        }.execute();
    }

    private void clearActivationAfterCloudRejection(String message) {
        getSharedPreferences("license", Context.MODE_PRIVATE).edit()
                .putBoolean("activated", false)
                .remove("username")
                .remove("serial")
                .remove("expiry")
                .remove("deviceId")
                .remove("deviceLabel")
                .remove("activatedAt")
                .putString("localSyncStatus", "REJECTED")
                .putString("localSyncError", message)
                .apply();
        if (publisher != null) publisher.setTrialWatermark(true);
        if (isAnyStreaming()) stopCurrentLive();
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void checkUpdate(final boolean manual) {
        if (manual) Toast.makeText(this, "正在检查更新...", Toast.LENGTH_SHORT).show();
        new AsyncTask<Void, Void, String>() {
            @Override protected String doInBackground(Void... params) {
                return httpGet(UPDATE_VERSION_URL);
            }

            @Override protected void onPostExecute(String result) {
                String remote = extractVersion(result);
                if (remote.length() == 0 || compareVersion(remote, currentVersionName()) <= 0) {
                    if (manual) {
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("检查更新")
                                .setMessage("您的软件已是最新版本。")
                                .setPositiveButton("确定", null)
                                .show();
                    }
                    return;
                }
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("发现新版本")
                        .setMessage("发现新版本：" + remote + "，是否下载更新？")
                        .setNegativeButton("取消", null)
                        .setPositiveButton("下载", new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface dialog, int which) {
                                downloadUpdate();
                            }
                        })
                        .show();
            }
        }.execute();
    }

    private void downloadUpdate() {
        try {
            if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                Intent settings = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
                startActivity(settings);
                Toast.makeText(this, "请先允许小魁直播安装未知应用，授权后再点击检查更新下载。", Toast.LENGTH_LONG).show();
                return;
            }
            DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            if (manager == null) throw new IllegalStateException("DownloadManager 不可用");
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(UPDATE_APK_URL));
            request.setTitle("小魁直播更新包");
            request.setDescription("正在下载新版本安装包");
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "corylivest.apk");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            long id = manager.enqueue(request);
            getSharedPreferences("updates", MODE_PRIVATE).edit().putLong("download_id", id).apply();
            Toast.makeText(this, "已开始下载更新包。", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "下载更新失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void showBackupRestoreDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(12), dp(18), dp(8));
        TextView tip = overlayText("备份文件：Download/CoryKuiLivestream/cory_livestream_backup.properties", 14);
        box.addView(tip, new LinearLayout.LayoutParams(-1, dp(58)));
        Button backup = overlayButton("备份");
        Button restore = overlayButton("恢复");
        box.addView(backup, new LinearLayout.LayoutParams(-1, dp(48)));
        box.addView(restore, new LinearLayout.LayoutParams(-1, dp(48)));
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("备份与恢复")
                .setView(box)
                .setPositiveButton("关闭", null)
                .create();
        backup.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (ensureStorageAccessForBackup()) backupLiveSettings();
            }
        });
        restore.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (ensureStorageAccessForBackup()) restoreLiveSettings();
            }
        });
        dialog.show();
    }

    private boolean ensureStorageAccessForBackup() {
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQ_STORAGE_ACCESS);
            } catch (Exception e) {
                startActivityForResult(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION), REQ_STORAGE_ACCESS);
            }
            Toast.makeText(this, "请允许小魁直播访问所有文件后再执行备份或恢复。", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

    private File backupFile() {
        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "CoryKuiLivestream");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, "cory_livestream_backup.properties");
    }

    private void backupLiveSettings() {
        try {
            Properties props = new Properties();
            SharedPreferences live = getSharedPreferences("live", MODE_PRIVATE);
            SharedPreferences license = getSharedPreferences("license", MODE_PRIVATE);
            String[] liveKeys = new String[]{"server", "key", "multi", "quality", "fileUri", "filePlaylist", "bgmPlaylist"};
            for (String key : liveKeys) props.setProperty("live." + key, live.getString(key, ""));
            props.setProperty("live.landscape", String.valueOf(live.getBoolean("landscape", false)));
            props.setProperty("live.muted", String.valueOf(live.getBoolean("muted", false)));
            props.setProperty("live.microphoneEnabled", String.valueOf(live.getBoolean("microphoneEnabled", true)));
            props.setProperty("live.microphoneVolume", String.valueOf(live.getFloat("microphoneVolume", 1.0f)));
            props.setProperty("live.videoVolume", String.valueOf(live.getFloat("videoVolume", 1.0f)));
            props.setProperty("live.backgroundMusicVolume", String.valueOf(live.getFloat("backgroundMusicVolume", 1.0f)));
            props.setProperty("live.filePlayMode", String.valueOf(live.getInt("filePlayMode", PLAY_MODE_LIST_LOOP)));
            props.setProperty("live.bgmPlayMode", String.valueOf(live.getInt("bgmPlayMode", PLAY_MODE_LIST_LOOP)));
            props.setProperty("live.bgmEnabled", String.valueOf(live.getBoolean("bgmEnabled", false)));
            props.setProperty("license.activated", String.valueOf(license.getBoolean("activated", false)));
            props.setProperty("license.username", license.getString("username", ""));
            props.setProperty("license.serial", license.getString("serial", ""));
            props.setProperty("license.expiry", license.getString("expiry", ""));
            props.setProperty("license.deviceId", license.getString("deviceId", ""));
            props.setProperty("license.deviceLabel", license.getString("deviceLabel", ""));
            props.setProperty("license.activatedAt", license.getString("activatedAt", ""));
            FileOutputStream out = new FileOutputStream(backupFile());
            props.store(out, "CoryKuiLivestream backup");
            out.close();
            Toast.makeText(this, "已备份。", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "备份失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void restoreLiveSettings() {
        try {
            File file = backupFile();
            if (!file.exists()) {
                Toast.makeText(this, "没有找到备份文件。", Toast.LENGTH_LONG).show();
                return;
            }
            Properties props = new Properties();
            FileInputStream in = new FileInputStream(file);
            props.load(in);
            in.close();
            SharedPreferences.Editor live = getSharedPreferences("live", MODE_PRIVATE).edit();
            String[] liveKeys = new String[]{"server", "key", "multi", "quality", "fileUri", "filePlaylist", "bgmPlaylist"};
            for (String key : liveKeys) live.putString(key, props.getProperty("live." + key, ""));
            live.putBoolean("landscape", Boolean.parseBoolean(props.getProperty("live.landscape", "false")));
            live.putBoolean("muted", Boolean.parseBoolean(props.getProperty("live.muted", "false")));
            live.putBoolean("microphoneEnabled", Boolean.parseBoolean(props.getProperty("live.microphoneEnabled", "true")));
            live.putFloat("microphoneVolume", parseFloat(props.getProperty("live.microphoneVolume"), 1.0f));
            live.putFloat("videoVolume", parseFloat(props.getProperty("live.videoVolume"), 1.0f));
            live.putFloat("backgroundMusicVolume", parseFloat(props.getProperty("live.backgroundMusicVolume"), 1.0f));
            live.putInt("filePlayMode", parseInt(props.getProperty("live.filePlayMode"), PLAY_MODE_LIST_LOOP));
            live.putInt("bgmPlayMode", parseInt(props.getProperty("live.bgmPlayMode"), PLAY_MODE_LIST_LOOP));
            live.putBoolean("bgmEnabled", Boolean.parseBoolean(props.getProperty("live.bgmEnabled", "false")));
            live.apply();
            getSharedPreferences("license", MODE_PRIVATE).edit()
                    .putBoolean("activated", Boolean.parseBoolean(props.getProperty("license.activated", "false")))
                    .putString("username", props.getProperty("license.username", ""))
                    .putString("serial", props.getProperty("license.serial", ""))
                    .putString("expiry", props.getProperty("license.expiry", ""))
                    .putString("deviceId", props.getProperty("license.deviceId", ""))
                    .putString("deviceLabel", props.getProperty("license.deviceLabel", ""))
                    .putString("activatedAt", props.getProperty("license.activatedAt", ""))
                    .apply();
            loadPlaylists();
            Toast.makeText(this, "已恢复，请重启软件让全部设置生效。", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "恢复失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String httpGet(String urlText) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlText);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(8000);
            conn.setRequestMethod("GET");
            if (conn.getResponseCode() != 200) return "";
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            StringBuilder builder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) builder.append(line).append('\n');
            reader.close();
            return builder.toString();
        } catch (Exception e) {
            return "";
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private String httpPost(String urlText, String body) throws Exception {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlText);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(8000);
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            byte[] bytes = body.getBytes("UTF-8");
            conn.setRequestProperty("Content-Length", String.valueOf(bytes.length));
            OutputStream out = conn.getOutputStream();
            out.write(bytes);
            out.close();
            int code = conn.getResponseCode();
            java.io.InputStream stream = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            if (stream == null) return "HTTP " + code;
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
            StringBuilder builder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) builder.append(line).append('\n');
            reader.close();
            String text = builder.toString();
            return code >= 400 ? ("HTTP " + code + " " + text) : text;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private Date fetchServerTime() {
        Date primary = parseServerTime(httpGet(SERVER_TIME_URL));
        return primary != null ? primary : TrustedTime.fetch();
    }

    private String activationDeviceId() {
        String androidId = "";
        try {
            androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        } catch (Exception ignored) {
        }
        if (androidId == null) androidId = "";
        String raw = getPackageName()
                + "|" + androidId
                + "|" + Build.MANUFACTURER
                + "|" + Build.BRAND
                + "|" + Build.MODEL
                + "|" + Build.DEVICE;
        return sha256Hex(raw);
    }

    private String activationDeviceLabel() {
        String label = (Build.MANUFACTURER + " " + Build.MODEL).trim();
        if (label.length() == 0) label = Build.DEVICE == null ? "Android" : Build.DEVICE;
        return label;
    }

    private String sha256Hex(String text) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(text.getBytes("UTF-8"));
            StringBuilder out = new StringBuilder(bytes.length * 2);
            for (byte b : bytes) {
                String hex = Integer.toHexString(b & 0xff);
                if (hex.length() == 1) out.append('0');
                out.append(hex);
            }
            return out.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private Date parseServerTime(String text) {
        if (text == null) return null;
        try {
            Matcher matcher = Pattern.compile("(\\d{4}-\\d{2}-\\d{2}[ T]\\d{2}:\\d{2}:\\d{2})").matcher(text);
            if (matcher.find()) {
                return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
                        .parse(matcher.group(1).replace('T', ' '));
            }
            Matcher timestamp = Pattern.compile("\\b(\\d{10})\\b").matcher(text);
            if (timestamp.find()) return new Date(Long.parseLong(timestamp.group(1)) * 1000L);
        } catch (Exception ignored) {
        }
        return null;
    }

    private String extractVersion(String text) {
        if (text == null) return "";
        Matcher named = Pattern.compile("(?i)(versionName|version|ver)\\s*[:=]\\s*([0-9]+(?:\\.[0-9]+)+)").matcher(text);
        if (named.find()) return named.group(2);
        Matcher plain = Pattern.compile("\\b([0-9]+(?:\\.[0-9]+)+)\\b").matcher(text);
        return plain.find() ? plain.group(1) : "";
    }

    private int compareVersion(String a, String b) {
        String[] aa = a == null ? new String[0] : a.split("\\.");
        String[] bb = b == null ? new String[0] : b.split("\\.");
        int count = Math.max(aa.length, bb.length);
        for (int i = 0; i < count; i++) {
            int av = i < aa.length ? parseInt(aa[i], 0) : 0;
            int bv = i < bb.length ? parseInt(bb[i], 0) : 0;
            if (av != bv) return av > bv ? 1 : -1;
        }
        return 0;
    }

    private int parseInt(String value, int fallback) {
        try {
            return value == null ? fallback : Integer.parseInt(value.trim());
        } catch (Exception e) {
            return fallback;
        }
    }

    private float parseFloat(String value, float fallback) {
        try {
            return value == null ? fallback : Float.parseFloat(value.trim());
        } catch (Exception e) {
            return fallback;
        }
    }

    private String currentVersionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "未知";
        }
    }

    private String maskSerial(String serial) {
        if (serial == null || serial.length() <= 24) return serial == null ? "" : serial;
        return serial.substring(0, 12) + "..." + serial.substring(serial.length() - 12);
    }

    private void showVersionDialog() {
        String versionName = "未知";
        int versionCode = 0;
        try {
            android.content.pm.PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            versionName = info.versionName;
            if (Build.VERSION.SDK_INT >= 28) {
                versionCode = (int) info.getLongVersionCode();
            } else {
                versionCode = info.versionCode;
            }
        } catch (Exception ignored) {
        }
        new AlertDialog.Builder(this)
                .setTitle("版本号")
                .setMessage("当前版本：" + versionName + "\n版本代码：" + versionCode)
                .setPositiveButton("确定", null)
                .show();
    }

    private String playModeLabel(int mode) {
        if (mode == PLAY_MODE_RANDOM) return "随机播放";
        if (mode == PLAY_MODE_SINGLE_LOOP) return "单曲循环";
        return "列表循环";
    }

    private int nextPlayMode(int mode) {
        if (mode == PLAY_MODE_LIST_LOOP) return PLAY_MODE_RANDOM;
        if (mode == PLAY_MODE_RANDOM) return PLAY_MODE_SINGLE_LOOP;
        return PLAY_MODE_LIST_LOOP;
    }

    private void toggleMicrophoneEnabled() {
        microphoneEnabled = !microphoneEnabled;
        getSharedPreferences("live", Context.MODE_PRIVATE).edit()
                .putBoolean("microphoneEnabled", microphoneEnabled)
                .apply();
        applyVolumeState();
        log(microphoneEnabled ? "麦克风已开启。" : "麦克风已关闭。");
    }

    private void showVolumeDialog() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        panel.setPadding(pad, pad, pad, pad);
        panel.addView(buildVolumeRow("麦克风音量", "microphoneVolume", microphoneVolume, new VolumeSetter() {
            @Override public void set(float value) {
                microphoneVolume = value;
            }
        }));
        panel.addView(buildVolumeRow("视频音量", "videoVolume", videoVolume, new VolumeSetter() {
            @Override public void set(float value) {
                videoVolume = value;
            }
        }));
        panel.addView(buildVolumeRow("背景音乐音量", "backgroundMusicVolume", backgroundMusicVolume, new VolumeSetter() {
            @Override public void set(float value) {
                backgroundMusicVolume = value;
            }
        }));
        new AlertDialog.Builder(this)
                .setTitle("调节音量")
                .setView(panel)
                .setPositiveButton("关闭", null)
                .show();
    }

    private View buildVolumeRow(String title, final String prefKey, float current, final VolumeSetter setter) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        final TextView label = new TextView(this);
        label.setTextColor(Color.BLACK);
        label.setTextSize(15);
        label.setText(title + "：" + Math.round(current * 100.0f) + "%");
        row.addView(label, new LinearLayout.LayoutParams(-1, dp(28)));
        SeekBar bar = new SeekBar(this);
        bar.setMax(200);
        bar.setProgress(Math.max(0, Math.min(200, Math.round(current * 100.0f))));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float value = progress / 100.0f;
                setter.set(value);
                label.setText(label.getText().toString().split("：")[0] + "：" + progress + "%");
                getSharedPreferences("live", Context.MODE_PRIVATE).edit().putFloat(prefKey, value).apply();
                applyVolumeState();
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        row.addView(bar, new LinearLayout.LayoutParams(-1, dp(42)));
        return row;
    }

    private interface VolumeSetter {
        void set(float value);
    }

    private void showVolumeDialogV2() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        panel.setPadding(pad, pad, pad, pad);
        final ArrayList<SeekBar> volumeBars = new ArrayList<SeekBar>();
        panel.addView(buildVolumeRowV2("麦克风音量", "microphoneVolume", microphoneVolume, new VolumeSetter() {
            @Override public void set(float value) {
                microphoneVolume = value;
            }
        }, volumeBars));
        panel.addView(buildVolumeRowV2("视频音量", "videoVolume", videoVolume, new VolumeSetter() {
            @Override public void set(float value) {
                videoVolume = value;
            }
        }, volumeBars));
        panel.addView(buildVolumeRowV2("背景音乐音量", "backgroundMusicVolume", backgroundMusicVolume, new VolumeSetter() {
            @Override public void set(float value) {
                backgroundMusicVolume = value;
            }
        }, volumeBars));
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("调节音量")
                .setView(panel)
                .setNeutralButton("重置", null)
                .setPositiveButton("关闭", null)
                .create();
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override public void onShow(DialogInterface d) {
                dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        microphoneVolume = 1.0f;
                        videoVolume = 1.0f;
                        backgroundMusicVolume = 1.0f;
                        getSharedPreferences("live", Context.MODE_PRIVATE).edit()
                                .putFloat("microphoneVolume", microphoneVolume)
                                .putFloat("videoVolume", videoVolume)
                                .putFloat("backgroundMusicVolume", backgroundMusicVolume)
                                .apply();
                        for (SeekBar bar : volumeBars) bar.setProgress(100);
                        applyVolumeState();
                        Toast.makeText(MainActivity.this, "音量已重置为100%。", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
        dialog.show();
    }

    private View buildVolumeRowV2(final String title, final String prefKey, float current, final VolumeSetter setter, ArrayList<SeekBar> resetBars) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        final TextView label = new TextView(this);
        label.setTextColor(Color.BLACK);
        label.setTextSize(15);
        label.setText(title + "：" + Math.round(current * 100.0f) + "%");
        row.addView(label, new LinearLayout.LayoutParams(-1, dp(28)));
        SeekBar bar = new SeekBar(this);
        bar.setMax(200);
        bar.setProgress(Math.max(0, Math.min(200, Math.round(current * 100.0f))));
        resetBars.add(bar);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float value = progress / 100.0f;
                setter.set(value);
                label.setText(title + "：" + progress + "%");
                getSharedPreferences("live", Context.MODE_PRIVATE).edit().putFloat(prefKey, value).apply();
                applyVolumeState();
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        row.addView(bar, new LinearLayout.LayoutParams(-1, dp(42)));
        return row;
    }

    private void toggleMute() {
        muted = !muted;
        getSharedPreferences("live", Context.MODE_PRIVATE).edit()
                .putBoolean("muted", muted)
                .apply();
        applyMuteState();
        muteButton.setText(muted ? "取消静音" : "静音");
        log(muted ? "已静音。" : "已取消静音。");
    }

    private void applyMuteState() {
        if (publisher != null) publisher.setMuted(muted);
        if (filePublisher != null) filePublisher.setMuted(muted);
        applyVolumeState();
        updateFilePreviewVolume();
        syncMuteUi();
    }

    private void applyVolumeState() {
        if (publisher != null) {
            publisher.setMicrophoneEnabled(microphoneEnabled);
            publisher.setMicrophoneVolume(microphoneVolume);
            publisher.setBackgroundMusicVolume(backgroundMusicVolume);
        }
        if (filePublisher != null) {
            filePublisher.setFileAudioVolume(videoVolume);
            filePublisher.setBackgroundMusicVolume(backgroundMusicVolume);
        }
        updateFilePreviewVolume();
    }

    private void syncMuteUi() {
        if (muteButton != null) muteButton.setText(muted ? "取消静音" : "静音");
    }

    private void syncOrientationUi() {
        if (orientationButton != null) orientationButton.setText(landscape ? "竖屏" : "横屏");
    }

    private void persistLandscapeState() {
        getSharedPreferences("live", Context.MODE_PRIVATE).edit()
                .putBoolean("landscape", landscape)
                .apply();
    }

    private int liveRequestedOrientation() {
        return landscape
                ? ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
    }

    private void applyLiveRequestedOrientation() {
        setRequestedOrientation(liveRequestedOrientation());
    }

    private void scheduleRelaxOrientationForPip() {
        if (Build.VERSION.SDK_INT < 26 || previewBox == null) return;
        previewBox.removeCallbacks(relaxPipOrientationRunnable);
        previewBox.postDelayed(relaxPipOrientationRunnable, 250);
    }

    private void relaxOrientationForPip() {
        if (Build.VERSION.SDK_INT < 26 || !isInPictureInPictureMode()) return;
        if (getRequestedOrientation() != ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED) {
            pipOrientationRelaxed = true;
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        }
    }

    private void restoreOrientationAfterPip() {
        if (previewBox != null) {
            previewBox.removeCallbacks(relaxPipOrientationRunnable);
        }
        if (pipOrientationRelaxed || getRequestedOrientation() == ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED) {
            pipOrientationRelaxed = false;
            applyLiveRequestedOrientation();
        }
    }

    private void restoreForegroundLayoutAfterPip() {
        fullscreen = false;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        applyLiveRequestedOrientation();
        setNormalPreviewBounds();
        scheduleForegroundLayoutRecovery(80);
        scheduleForegroundLayoutRecovery(350);
        scheduleForegroundLayoutRecovery(900);
        scheduleForegroundLayoutRecovery(1500);
    }

    private void scheduleForegroundLayoutRecovery(long delayMs) {
        if (previewBox == null) return;
        previewBox.postDelayed(new Runnable() {
            @Override public void run() {
                if (isInPictureInPictureMode()) return;
                setNormalPreviewBounds();
                if (publisher != null && !fileMode && !cameraClosed) {
                    publisher.refreshPreview();
                    publisher.restartStreamCaptureSession();
                    publisher.requestKeyFrame();
                } else if (fileMode && fileUri != null) {
                    showFilePreview(fileUri);
                    syncFilePreviewPosition();
                }
            }
        }, delayMs);
    }

    private void recoverLandscapeFromConfiguration() {
        if (isInPictureInPictureMode()) return;
        if (!isAnyStreaming() || fileMode) return;
        boolean configLandscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        if (configLandscape && !landscape) {
            landscape = true;
            persistLandscapeState();
            syncOrientationUi();
            applyLiveRequestedOrientation();
            if (!fullscreen) setNormalPreviewBounds();
        }
    }

    private void updateFilePreviewVolume() {
        if (currentFileMediaPlayer == null) return;
        float volume = muted ? 0.0f : videoVolume;
        try {
            currentFileMediaPlayer.setVolume(volume, volume);
        } catch (IllegalStateException e) {
            currentFileMediaPlayer = null;
            Log.w("CoryKuiLive", "file preview player is not ready for volume update");
        }
    }

    private void toggleCameraOpen() {
        if (fileMode) {
            cancelFileMode();
            return;
        }
        cameraClosed = !cameraClosed;
        if (cameraClosed) {
            publisher.closeCamera();
        } else {
            publisher.openCameraMode(cameraMode);
        }
        syncStreamingUi();
    }

    private void switchCameraMode(int mode) {
        cameraMode = mode;
        cameraClosed = false;
        closeCameraButton.setText("关闭摄像头");
        cameraButton.setText("切摄像头");
        publisher.openCameraMode(cameraMode);
    }

    private void toggleOrientation() {
        final boolean restartStream = publisher != null && publisher.isStreaming();
        final boolean restartRecord = publisher != null && publisher.isRecording();
        if (restartStream) {
            orientationButton.setEnabled(false);
            publisher.stopStreaming();
        }
        landscape = !landscape;
        persistLandscapeState();
        applyLiveRequestedOrientation();
        orientationButton.setText(landscape ? "竖屏" : "横屏");
        previewBox.postDelayed(new Runnable() {
            @Override public void run() {
                if (!fullscreen) setNormalPreviewBounds();
                if (publisher != null && !cameraClosed) publisher.refreshPreview();
            }
        }, 300);
        if (restartStream) {
            log("正在按新比例重启直播。");
            previewBox.postDelayed(new Runnable() {
                @Override public void run() {
                    orientationButton.setEnabled(true);
                    startStreamingFromSettings(restartRecord);
                }
            }, 900);
        }
    }

    private void setFullscreenMode(boolean active) {
        fullscreen = active;
        if (fullscreen) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            previewBox.setLayoutParams(new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            setNormalPreviewBounds();
        }
        previewBox.postDelayed(new Runnable() {
            @Override public void run() {
                if (publisher != null && !cameraClosed) publisher.refreshPreview();
            }
        }, 250);
        title.setVisibility(active ? View.GONE : View.VISIBLE);
        fullscreenButton.setVisibility(active ? View.GONE : View.VISIBLE);
        appMenuButton.setVisibility(active ? View.GONE : View.VISIBLE);
        normalControls.setVisibility(active ? View.GONE : View.VISIBLE);
        zoomControls.setVisibility(active ? View.GONE : View.VISIBLE);
        status.setVisibility(active ? View.GONE : View.VISIBLE);
        fullControls.setVisibility(active ? View.VISIBLE : View.GONE);
        exitFullscreenButton.setVisibility(active ? View.VISIBLE : View.GONE);
    }

    private void enterLivePictureInPicture() {
        if (Build.VERSION.SDK_INT < 26 || isInPictureInPictureMode()) return;
        try {
            setPipUi(true);
            PictureInPictureParams params = buildLivePictureInPictureParams();
            setPictureInPictureParams(params);
            enterPictureInPictureMode(params);
            previewBox.postDelayed(new Runnable() {
                @Override public void run() {
                    setPipUi(true);
                    scheduleRelaxOrientationForPip();
                }
            }, 250);
        } catch (Exception e) {
            log("进入画中画失败：" + e.getMessage());
        }
    }

    private PictureInPictureParams buildLivePictureInPictureParams() {
        Rational ratio = (landscape || fileMode) ? new Rational(16, 9) : new Rational(9, 16);
        PictureInPictureParams.Builder builder = new PictureInPictureParams.Builder()
                .setAspectRatio(ratio);
        if (Build.VERSION.SDK_INT >= 31) {
            builder.setAutoEnterEnabled(true);
        }
        return builder.build();
    }

    private void updateLivePictureInPictureParams() {
        if (Build.VERSION.SDK_INT < 26) return;
        try {
            setPictureInPictureParams(buildLivePictureInPictureParams());
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode, Configuration newConfig) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig);
        setPipUi(isInPictureInPictureMode);
        if (isInPictureInPictureMode) {
            scheduleRelaxOrientationForPip();
        } else {
            restoreOrientationAfterPip();
            restoreForegroundLayoutAfterPip();
            syncStreamingUi();
        }
    }

    private void setPipUi(boolean active) {
        previewBox.removeCallbacks(hideLiveControlsRunnable);
        applyMuteState();
        if (active) {
            previewBox.setLayoutParams(new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
            startPipMirrorFrames();
            startKeepAliveService();
            if (publisher != null) {
                publisher.setPreviewSurfaceEnabled(true);
                publisher.setForcePreviewFrames(false);
                publisher.restartStreamCaptureSession();
                publisher.requestKeyFrame();
            }
            previewBox.postDelayed(new Runnable() {
                @Override public void run() {
                    if (isInPictureInPictureMode() && publisher != null) {
                        publisher.restartStreamCaptureSession();
                        publisher.requestKeyFrame();
                    }
                }
            }, 900);
            previewBox.removeCallbacks(pipStreamKeepAliveRunnable);
            previewBox.postDelayed(pipStreamKeepAliveRunnable, 1200);
        } else if (!fullscreen) {
            stopPipMirrorFrames();
            previewBox.removeCallbacks(pipStreamKeepAliveRunnable);
            pipRestartScheduled = false;
            if (publisher != null) {
                publisher.setPreviewSurfaceEnabled(true);
                publisher.setForcePreviewFrames(false);
                publisher.restartStreamCaptureSession();
                publisher.requestKeyFrame();
            }
            setNormalPreviewBounds();
        }
        title.setVisibility(active ? View.GONE : View.VISIBLE);
        fullscreenButton.setVisibility(active ? View.GONE : (fullscreen ? View.GONE : View.VISIBLE));
        appMenuButton.setVisibility(active ? View.GONE : (fullscreen ? View.GONE : View.VISIBLE));
        normalControls.setVisibility(active ? View.GONE : (fullscreen ? View.GONE : View.VISIBLE));
        zoomControls.setVisibility(active ? View.GONE : ((fullscreen || fileMode) ? View.GONE : View.VISIBLE));
        status.setVisibility(active ? View.GONE : View.VISIBLE);
        if (progressPanel != null) {
            if (active) progressPanel.setVisibility(View.GONE);
            else updatePlaybackProgressUi();
        }
        fullControls.setVisibility(active ? View.GONE : (fullscreen ? View.VISIBLE : View.GONE));
        exitFullscreenButton.setVisibility(active ? View.GONE : (fullscreen ? View.VISIBLE : View.GONE));
        if (active && !shouldShowStreamMirror()) {
            hideStreamMirror();
        }
    }

    private void setLiveControlsHidden(boolean hidden) {
        liveControlsHidden = hidden;
        if (fullscreen || isInPictureInPictureMode()) return;
        normalControls.setVisibility(hidden ? View.GONE : View.VISIBLE);
        zoomControls.setVisibility(hidden ? View.GONE : View.VISIBLE);
        status.setVisibility(hidden ? View.GONE : View.VISIBLE);
        if (progressPanel != null) {
            if (hidden) progressPanel.setVisibility(View.GONE);
            else updatePlaybackProgressUi();
        }
        fullscreenButton.setVisibility(hidden ? View.GONE : View.VISIBLE);
        appMenuButton.setVisibility(hidden ? View.GONE : View.VISIBLE);
        title.setVisibility(hidden ? View.GONE : View.VISIBLE);
    }

    private void showLiveControlsTemporarily() {
        setLiveControlsHidden(false);
        previewBox.removeCallbacks(hideLiveControlsRunnable);
        previewBox.postDelayed(hideLiveControlsRunnable, 3000);
    }

    private boolean handlePreviewTouch(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN && isAnyStreaming() && !fullscreen && !isInPictureInPictureMode()) {
            showLiveControlsTemporarily();
            return true;
        }
        if (event.getAction() == MotionEvent.ACTION_UP && publisher != null && !cameraClosed) {
            publisher.focusAt(event.getX(), event.getY());
            return true;
        }
        return true;
    }

    private final Runnable hideLiveControlsRunnable = new Runnable() {
        @Override public void run() {
            if (isAnyStreaming() && !landscape && !fullscreen && !isInPictureInPictureMode()) {
                setLiveControlsHidden(true);
            }
        }
    };

    private final Runnable pipStreamKeepAliveRunnable = new Runnable() {
        @Override public void run() {
            if (isInPictureInPictureMode() && publisher != null && publisher.isStreaming()) {
                publisher.resendStreamHeaders();
                previewBox.postDelayed(this, 2000);
            }
        }
    };

    private void schedulePipStreamRestart() {
        if (fileMode || pipRestartScheduled || publisher == null || !publisher.isStreaming()) return;
        pipRestartScheduled = true;
        previewBox.postDelayed(new Runnable() {
            @Override public void run() {
                if (!isInPictureInPictureMode() || publisher == null || !publisher.isStreaming()) return;
                startKeepAliveService();
                pipRestartingStream = true;
                publisher.stopStreaming();
                previewBox.postDelayed(new Runnable() {
                    @Override public void run() {
                        if (isInPictureInPictureMode() && publisher != null && !publisher.isStreaming()) {
                            startStreamingFromSettings(false);
                        }
                        previewBox.postDelayed(new Runnable() {
                            @Override public void run() {
                                pipRestartingStream = false;
                            }
                        }, 2500);
                    }
                }, 900);
            }
        }, 2200);
    }

    private void setNormalPreviewBounds() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int screenW = root != null && root.getWidth() > dp(240) ? root.getWidth() : dm.widthPixels;
        int screenH = root != null && root.getHeight() > dp(240) ? root.getHeight() : dm.heightPixels;
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                android.view.WindowMetrics metrics = getWindowManager().getCurrentWindowMetrics();
                android.graphics.Rect bounds = metrics.getBounds();
                if (bounds.width() > dp(240) && bounds.height() > dp(240)) {
                    screenW = Math.max(screenW, bounds.width());
                    screenH = Math.max(screenH, bounds.height());
                }
            } catch (Exception ignored) {
            }
        }
        int width;
        int height;
        if (landscape) {
            width = Math.min(screenW, screenH * 16 / 9);
            height = width * 9 / 16;
        } else {
            height = Math.min(screenH, screenW * 16 / 9);
            width = height * 9 / 16;
        }
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, height, Gravity.CENTER);
        previewBox.setLayoutParams(lp);
    }

    private ArrayAdapter<String> qualityAdapter(String[] qualities) {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, qualities) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView, parent);
                view.setTextColor(Color.WHITE);
                view.setTextSize(18);
                view.setBackgroundColor(Color.rgb(31, 38, 45));
                view.setPadding(12, 8, 12, 8);
                return view;
            }

            @Override public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getDropDownView(position, convertView, parent);
                view.setTextColor(Color.BLACK);
                view.setTextSize(18);
                view.setPadding(12, 12, 12, 12);
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return adapter;
    }

    private TextView label(String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(Color.WHITE);
        label.setTextSize(14);
        label.setPadding(0, 8, 0, 4);
        return label;
    }

    private ProgressViews createProgressBlock(String title, final boolean fileProgress) {
        final ProgressViews views = new ProgressViews();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(0, dp(2), 0, dp(4));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = overlayText(title, 12);
        views.left = overlayText("00:00", 11);
        views.right = overlayText("00:00", 11);
        views.bubble = overlayText("", 11);
        views.bubble.setGravity(Gravity.CENTER);
        views.bubble.setVisibility(View.INVISIBLE);
        row.addView(name, new LinearLayout.LayoutParams(0, dp(24), 1.0f));
        row.addView(views.left, new LinearLayout.LayoutParams(dp(54), dp(24)));
        row.addView(views.right, new LinearLayout.LayoutParams(dp(68), dp(24)));
        root.addView(row, new LinearLayout.LayoutParams(-1, dp(24)));

        views.bar = new SeekBar(this);
        views.bar.setMax(1000);
        views.bar.setProgress(0);
        views.bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                long targetMs = progressToMs(views, progress);
                views.bubble.setText(formatDuration(targetMs));
                views.bubble.setVisibility(View.VISIBLE);
                views.current.setText(formatDuration(targetMs));
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) {
                views.tracking = true;
                views.bubble.setVisibility(View.VISIBLE);
            }

            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                long targetMs = progressToMs(views, seekBar.getProgress());
                views.tracking = false;
                views.bubble.setVisibility(View.INVISIBLE);
                if (fileProgress) {
                    seekLiveFileTo(targetMs);
                } else {
                    seekBackgroundMusicTo(targetMs);
                }
            }
        });
        root.addView(views.bubble, new LinearLayout.LayoutParams(-1, dp(20)));
        root.addView(views.bar, new LinearLayout.LayoutParams(-1, dp(34)));
        views.current = overlayText("00:00", 12);
        root.addView(views.current, new LinearLayout.LayoutParams(-1, dp(22)));
        views.root = root;
        return views;
    }

    private long progressToMs(ProgressViews views, int progress) {
        if (views == null || views.durationMs <= 0L) return 0L;
        return Math.max(0L, Math.min(views.durationMs, views.durationMs * progress / 1000L));
    }

    private TextView overlayText(String text, int sp) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(Color.WHITE);
        label.setTextSize(sp);
        label.setShadowLayer(4, 0, 1, Color.BLACK);
        return label;
    }

    private EditText input(String hint) {
        EditText edit = new EditText(this);
        edit.setSingleLine(true);
        edit.setHint(hint);
        edit.setTextColor(Color.WHITE);
        edit.setHintTextColor(Color.rgb(145, 155, 165));
        edit.setBackgroundColor(Color.rgb(31, 38, 45));
        edit.setPadding(12, 8, 12, 8);
        return edit;
    }

    private Button overlayButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setPadding(dp(4), 0, dp(4), 0);
        b.setBackgroundColor(Color.argb(92, 0, 0, 0));
        return b;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toggleStreaming() {
        if ((fileMode && filePublisher.isStreaming()) || (!fileMode && publisher.isStreaming())) {
            stopCurrentLive();
            return;
        }
        if (!fileMode && !hasPermissions()) {
            requestLivePermissions();
            return;
        }
        if (!fileMode && cameraClosed) {
            cameraClosed = false;
            publisher.openCameraMode(cameraMode);
            closeCameraButton.setText("关闭摄像头");
        }
        startStreamingFromSettings(false);
    }

    private void stopCurrentLive() {
        if (previewBox != null) previewBox.removeCallbacks(trialStopRunnable);
        if (fileMode && filePublisher != null && filePublisher.isStreaming()) {
            userStoppingFileStream = true;
            filePublisher.stop();
            fileLiveStartMs = 0;
            if (filePlayer != null) filePlayer.pause();
            syncStreamingUi();
        }
        if (publisher != null && publisher.isStreaming()) {
            publisher.setTrialWatermark(false);
            publisher.stopStreaming();
        }
    }

    private boolean canStartTrialStreaming() {
        long nextAllowed = getSharedPreferences("license", Context.MODE_PRIVATE)
                .getLong("trialNextAllowedMs", 0L);
        long now = System.currentTimeMillis();
        if (now < nextAllowed) {
            long minutes = Math.max(1L, (nextAllowed - now + 59999L) / 60000L);
            Toast.makeText(this, "未激活版本需等待约 " + minutes + " 分钟后才能继续免费推流。", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

    private void scheduleTrialLimitIfNeeded() {
        if (previewBox == null) return;
        previewBox.removeCallbacks(trialStopRunnable);
        if (!isActivated()) {
            previewBox.postDelayed(trialStopRunnable, TRIAL_STREAM_MS);
        }
    }

    private void startStreamingFromSettings(final boolean startRecordingAfterConnect) {
        boolean activated = isActivated();
        if (!activated && fileMode) {
            Toast.makeText(this, "未激活版本不能使用本地文件推流。", Toast.LENGTH_LONG).show();
            return;
        }
        if (!activated && !canStartTrialStreaming()) {
            return;
        }
        if (activated) syncLocalActivationWithServer(false, false);
        SharedPreferences sp = getSharedPreferences("live", Context.MODE_PRIVATE);
        String server = readStreamSetting(sp, "server", "").trim();
        String key = readStreamSetting(sp, "key", "").trim();
        String multi = readStreamSetting(sp, "multi", "").trim();
        List<String> urls = new ArrayList<String>();
        if (server.length() > 0) {
            urls.add(key.length() == 0 ? server : server.replaceAll("/+$", "") + "/" + key);
        }
        if (multi.length() > 0 && activated) {
            String[] lines = multi.split("\\r?\\n");
            for (String line : lines) {
                String url = line.trim();
                if (url.length() > 0) urls.add(url);
            }
        } else if (multi.length() > 0) {
            log("未激活版本已忽略并发推流地址。");
        }
        if (urls.size() == 0) {
            Toast.makeText(this, "请先在设置里填写至少一个 RTMP 地址", Toast.LENGTH_SHORT).show();
            showSettingsDialog();
            return;
        }
        log("已合成推流地址：" + safeUrlForLog(urls.get(0)));
        if (fileMode) {
            if (filePublisher != null && filePublisher.isStreaming()) {
                Uri runningFile = filePublisher.getCurrentFileUri();
                if (runningFile != null) fileUri = runningFile;
                fileLiveStartMs = filePublisher.getStartElapsedMs();
                if (fileUri != null) showFilePreview(fileUri);
                syncStreamingUi();
                return;
            }
            if (fileUri == null && filePlaylist.size() > 0) {
                fileUri = filePlaylist.get(Math.min(filePlaylistIndex, filePlaylist.size() - 1));
            }
            if (fileUri == null) {
                Toast.makeText(this, "请先选择本地音视频文件", Toast.LENGTH_SHORT).show();
                return;
            }
            publisher.stopStreaming();
            publisher.closeCamera();
            cameraClosed = true;
            showFilePreview(fileUri);
            long resumeMs = fileResumePositionMs();
            if (!isImageUri(fileUri) && filePlayer != null) filePlayer.seekTo((int) resumeMs);
            fileLiveStartMs = SystemClock.elapsedRealtime() - resumeMs;
            userStoppingFileStream = false;
            filePublisher.setMuted(muted);
            filePublisher.setFileAudioVolume(videoVolume);
            filePublisher.setBackgroundMusicVolume(backgroundMusicVolume);
            filePublisher.setBackgroundMusicPreservingPlayback(activeBackgroundMusicPlaylist(), bgmPlayMode);
            filePublisher.setBackgroundMusicPaused(bgmPaused);
            filePublisher.start(fileUri, urls, resumeMs);
            return;
        }
        StreamConfig config = StreamConfig.fromLabel(readStreamSetting(sp, "quality", "720p")).oriented(landscape);
        applyBackgroundMusic();
        applyVolumeState();
        publisher.setTrialWatermark(!activated);
        publisher.startStreaming(urls, config, cameraMode == RtmpPublisher.CAMERA_FRONT);
        scheduleTrialLimitIfNeeded();
        previewBox.postDelayed(new Runnable() {
            @Override public void run() {
                applyBackgroundMusic();
            }
        }, 800);
        if (startRecordingAfterConnect) {
            previewBox.postDelayed(new Runnable() {
                @Override public void run() {
                    if (publisher.isStreaming() && !publisher.isRecording()) {
                        publisher.startRecording();
                    }
                }
            }, 1200);
        }
    }

    private String readStreamSetting(SharedPreferences sp, String name, String fallback) {
        String value = sp.getString(name, "");
        if (value != null && value.length() > 0) return value;
        value = readSharedPrefsXmlString(name);
        return value == null ? fallback : value;
    }

    private long fileResumePositionMs() {
        if (fileUri == null || isImageUri(fileUri)) return 0L;
        if (pendingFileSeekMs >= 0L) {
            long seekMs = pendingFileSeekMs;
            pendingFileSeekMs = -1L;
            return seekMs;
        }
        long resumeMs = 0L;
        if (fileLiveStartMs > 0L) {
            resumeMs = Math.max(0L, SystemClock.elapsedRealtime() - fileLiveStartMs);
        }
        if (filePlayer != null && filePreviewUri != null && filePreviewUri.equals(fileUri)) {
            try {
                resumeMs = Math.max(resumeMs, filePlayer.getCurrentPosition());
                int duration = filePlayer.getDuration();
                if (duration > 0 && resumeMs >= duration - 1000L) resumeMs = 0L;
            } catch (Exception ignored) {
            }
        }
        return resumeMs < 1000L ? 0L : resumeMs;
    }

    private String readSharedPrefsXmlString(String name) {
        File file = new File(getApplicationInfo().dataDir, "shared_prefs/live.xml");
        if (!file.exists()) return null;
        FileInputStream in = null;
        try {
            in = new FileInputStream(file);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int read;
            while ((read = in.read(buffer)) > 0) {
                out.write(buffer, 0, read);
            }
            String xml = new String(out.toByteArray(), "UTF-8");
            String value = extractXmlString(xml, name, "\"");
            if (value == null) value = extractXmlString(xml, name, "'");
            return value == null ? null : unescapeXml(value);
        } catch (Exception ignored) {
            return null;
        } finally {
            try {
                if (in != null) in.close();
            } catch (Exception ignored) {
            }
        }
    }

    private String extractXmlString(String xml, String name, String quote) {
        String marker = "<string name=" + quote + name + quote + ">";
        int start = xml.indexOf(marker);
        if (start < 0) return null;
        start += marker.length();
        int end = xml.indexOf("</string>", start);
        if (end < 0) return null;
        return xml.substring(start, end);
    }

    private String unescapeXml(String value) {
        return value.replace("&amp;", "&")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", "\"")
                .replace("&apos;", "'");
    }

    private String safeUrlForLog(String url) {
        int q = url.indexOf('?');
        if (q >= 0) {
            return url.substring(0, q) + "?...";
        }
        return url;
    }

    private void toggleRecording() {
        if (fileMode) {
            Toast.makeText(this, "本地文件推流不需要录像", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!publisher.isStreaming()) {
            Toast.makeText(this, "请先开始直播", Toast.LENGTH_SHORT).show();
            return;
        }
        if (publisher.isRecording()) {
            publisher.stopRecording();
        } else {
            publisher.startRecording();
        }
    }

    private boolean hasPermissions() {
        return checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private void pickLocalFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"video/*", "audio/*", "image/*"});
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_PICK_FILE);
    }

    private void pickBackgroundMusic() {
        reopenPlaylistAfterPicker = REOPEN_BGM_PLAYLIST;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("audio/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_PICK_BGM);
    }

    private void pickFilePlaylist() {
        reopenPlaylistAfterPicker = REOPEN_FILE_PLAYLIST;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"video/*", "audio/*", "image/*"});
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_PICK_FILE_PLAYLIST);
    }

    private void showFilePlaylistDialogV2() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("直播文件播放列表")
                .setView(buildPlaylistViewV2(filePlaylist, filePlaylistIndex, true))
                .setPositiveButton("添加文件", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        pickFilePlaylist();
                    }
                })
                .setNegativeButton("关闭", null);
        if (filePlaylist.size() > 0) {
            builder.setNeutralButton("清空列表", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    boolean runningFileStream = filePublisher != null && filePublisher.isStreaming();
                    filePlaylist.clear();
                    filePlaylistIndex = 0;
                    pendingFilePlaylistIndex = -1;
                    if (!runningFileStream) fileUri = null;
                    savePlaylists();
                    if (fileMode && !runningFileStream) configureFileMode(false);
                    log("已清空直播文件播放列表。");
                }
            });
        }
        builder.show();
    }

    private void showBackgroundMusicPlaylistDialogV2() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("背景音乐播放列表")
                .setView(buildBackgroundMusicPanel())
                .setPositiveButton("添加音乐", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        pickBackgroundMusic();
                    }
                })
                .setNegativeButton("关闭", null);
        if (bgmPlaylist.size() > 0) {
            builder.setNeutralButton("清空列表", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    bgmPlaylist.clear();
                    bgmEnabled = false;
                    bgmPaused = false;
                    savePlaylists();
                    applyBackgroundMusic();
                    log("已清空背景音乐播放列表。");
                }
            });
        }
        builder.show();
    }

    private View buildBackgroundMusicPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(10);
        panel.setPadding(pad, pad, pad, pad);
        if (bgmPlaylist.size() > 0) {
            Button toggle = overlayButton(bgmEnabled && !bgmPaused ? "暂停背景音乐" : "播放背景音乐");
            toggle.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (!bgmEnabled) {
                        bgmEnabled = true;
                        bgmPaused = false;
                        applyBackgroundMusicPreservingPlayback();
                    } else {
                        bgmPaused = !bgmPaused;
                        applyBackgroundMusicPauseState();
                    }
                    savePlaylists();
                    showBackgroundMusicPlaylistDialogV2();
                }
            });
            panel.addView(toggle, new LinearLayout.LayoutParams(-1, dp(46)));
        }
        panel.addView(buildPlaylistViewV2(bgmPlaylist, backgroundMusicPlaylistIndex(), false), new LinearLayout.LayoutParams(-1, -2));
        return panel;
    }

    private View buildPlaylistViewV2(final ArrayList<Uri> playlist, int currentIndex, final boolean fileList) {
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(10);
        list.setPadding(pad, pad, pad, pad);
        scroll.addView(list, new ScrollView.LayoutParams(-1, -2));
        if (playlist.size() == 0) {
            TextView empty = new TextView(this);
            empty.setText("暂无条目");
            empty.setTextSize(16);
            empty.setTextColor(Color.DKGRAY);
            list.addView(empty, new LinearLayout.LayoutParams(-1, dp(52)));
            return scroll;
        }
        for (int i = 0; i < playlist.size(); i++) {
            final int index = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(4), 0, dp(4));
            TextView name = new TextView(this);
            name.setText((i == currentIndex ? "正在播放  " : "") + (i + 1) + ". " + displayName(playlist.get(i)));
            name.setTextSize(15);
            name.setTextColor(Color.BLACK);
            name.setSingleLine(false);
            if (fileList) {
                name.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        filePlaylistIndex = index;
                        fileUri = filePlaylist.get(filePlaylistIndex);
                        getSharedPreferences("live", Context.MODE_PRIVATE).edit().putString("fileUri", fileUri.toString()).apply();
                        savePlaylists();
                        fileMode = true;
                        configureFileMode(true);
                        log("已切换直播文件：" + displayName(fileUri));
                    }
                });
            }
            row.addView(name, new LinearLayout.LayoutParams(0, -2, 1.0f));
            boolean current = i == currentIndex;
            boolean paused = current && (fileList ? isCurrentFilePlaybackPaused() : bgmPaused);
            Button play = new Button(this);
            play.setText(current && !paused ? "⏸" : "▶");
            play.setTextSize(16);
            play.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    playPlaylistItemV2(fileList, index);
                }
            });
            row.addView(play, new LinearLayout.LayoutParams(dp(54), dp(44)));
            Button delete = new Button(this);
            delete.setText("删");
            delete.setTextSize(14);
            delete.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    removePlaylistItemV2(fileList, index);
                }
            });
            row.addView(delete, new LinearLayout.LayoutParams(dp(58), dp(44)));
            list.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
        return scroll;
    }

    private boolean isCurrentFilePlaylistItem(int index) {
        return index >= 0 && index < filePlaylist.size()
                && fileUri != null && fileUri.equals(filePlaylist.get(index));
    }

    private boolean isCurrentFilePlaybackPaused() {
        return filePublisher != null && filePublisher.isStreaming() && filePublisher.isPlaybackPaused();
    }

    private void toggleCurrentFilePlaylistPause() {
        if (filePublisher == null || !filePublisher.isStreaming()) return;
        boolean paused = !filePublisher.isPlaybackPaused();
        filePublisher.setPlaybackPaused(paused);
        if (!isImageUri(fileUri) && filePlayer != null) {
            if (paused) {
                filePlayer.pause();
            } else {
                fileLiveStartMs = filePublisher.getStartElapsedMs();
                if (!filePlayer.isPlaying()) filePlayer.start();
            }
        }
        syncStreamingUi();
    }

    private int backgroundMusicPlaylistIndex() {
        Uri current = currentBackgroundMusicUri();
        if (current != null) {
            String value = current.toString();
            for (int i = 0; i < bgmPlaylist.size(); i++) {
                Uri item = bgmPlaylist.get(i);
                if (item != null && value.equals(item.toString())) return i;
            }
        }
        return bgmEnabled && bgmPlaylist.size() > 0 ? 0 : -1;
    }

    private Uri currentBackgroundMusicUri() {
        if (filePublisher != null && filePublisher.isStreaming()) {
            Uri uri = filePublisher.getBackgroundMusicCurrentUri();
            if (uri != null) return uri;
        }
        if (publisher != null && publisher.isStreaming()) {
            Uri uri = publisher.getBackgroundMusicCurrentUri();
            if (uri != null) return uri;
        }
        return null;
    }

    private void playPlaylistItemV2(boolean fileList, int index) {
        if (fileList) {
            if (index < 0 || index >= filePlaylist.size()) return;
            if (isCurrentFilePlaylistItem(index) && filePublisher != null && filePublisher.isStreaming()) {
                toggleCurrentFilePlaylistPause();
                showFilePlaylistDialogV2();
                return;
            }
            filePlaylistIndex = index;
            fileUri = filePlaylist.get(filePlaylistIndex);
            getSharedPreferences("live", Context.MODE_PRIVATE).edit().putString("fileUri", fileUri.toString()).apply();
            savePlaylists();
            if (filePublisher != null && filePublisher.isStreaming()) {
                pendingFilePlaylistIndex = -1;
                filePublisher.setPlaybackPaused(false);
                filePublisher.stop();
                fileLiveStartMs = 0L;
                showFilePreview(fileUri);
                previewBox.postDelayed(new Runnable() {
                    @Override public void run() {
                        if (fileMode && fileUri != null) startStreamingFromSettings(false);
                    }
                }, 250);
                log("已立即切换直播文件：" + displayName(fileUri));
                showFilePlaylistDialogV2();
                return;
            }
            fileMode = true;
            configureFileMode(true);
            log("插队播放直播文件：" + displayName(fileUri));
            if (filePublisher != null && filePublisher.isStreaming()) {
                filePublisher.stop();
                previewBox.postDelayed(new Runnable() {
                    @Override public void run() {
                        if (fileMode && fileUri != null) startStreamingFromSettings(false);
                    }
                }, 500);
            }
            showFilePlaylistDialogV2();
        } else {
            if (index < 0 || index >= bgmPlaylist.size()) return;
            if (index == backgroundMusicPlaylistIndex() && bgmEnabled) {
                bgmPaused = !bgmPaused;
                applyBackgroundMusicPauseState();
                savePlaylists();
                log(bgmPaused ? "背景音乐已暂停。" : "背景音乐已继续。");
                showBackgroundMusicPlaylistDialogV2();
                return;
            }
            Uri selected = bgmPlaylist.remove(index);
            bgmPlaylist.add(0, selected);
            bgmEnabled = true;
            bgmPaused = false;
            savePlaylists();
            applyBackgroundMusic();
            log("插队播放背景音乐：" + displayName(selected));
            showBackgroundMusicPlaylistDialogV2();
        }
    }

    private void removePlaylistItemV2(boolean fileList, int index) {
        if (fileList) {
            if (index < 0 || index >= filePlaylist.size()) return;
            boolean runningFileStream = filePublisher != null && filePublisher.isStreaming();
            Uri removed = filePlaylist.remove(index);
            if (pendingFilePlaylistIndex == index) pendingFilePlaylistIndex = -1;
            else if (pendingFilePlaylistIndex > index) pendingFilePlaylistIndex--;
            if (filePlaylistIndex >= filePlaylist.size()) filePlaylistIndex = Math.max(0, filePlaylist.size() - 1);
            if (filePlaylist.size() == 0) {
                if (!runningFileStream) fileUri = null;
                if (fileMode && !runningFileStream) configureFileMode(false);
            } else if (fileUri != null && fileUri.equals(removed)) {
                if (!runningFileStream) {
                    fileUri = filePlaylist.get(filePlaylistIndex);
                    configureFileMode(true);
                }
            }
            savePlaylists();
            log("已删除直播文件列表条目：" + displayName(removed));
            showFilePlaylistDialogV2();
        } else {
            if (index < 0 || index >= bgmPlaylist.size()) return;
            Uri removed = bgmPlaylist.remove(index);
            if (bgmPlaylist.size() == 0) bgmEnabled = false;
            savePlaylists();
            applyBackgroundMusicPreservingPlayback();
            log("已删除背景音乐列表条目：" + displayName(removed));
            showBackgroundMusicPlaylistDialogV2();
        }
    }

    private void showFilePlaylistDialog() {
        final String[] items = playlistLabels(filePlaylist, filePlaylistIndex);
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("直播文件播放列表")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        if (filePlaylist.size() == 0 || which >= filePlaylist.size()) return;
                        filePlaylistIndex = which;
                        fileUri = filePlaylist.get(filePlaylistIndex);
                        getSharedPreferences("live", Context.MODE_PRIVATE).edit().putString("fileUri", fileUri.toString()).apply();
                        savePlaylists();
                        fileMode = true;
                        configureFileMode(true);
                        log("已切换直播文件：" + displayName(fileUri));
                    }
                })
                .setPositiveButton("添加文件", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        pickFilePlaylist();
                    }
                })
                .setNegativeButton("关闭", null);
        if (filePlaylist.size() > 0) {
            builder.setNeutralButton("清空列表", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    filePlaylist.clear();
                    filePlaylistIndex = 0;
                    fileUri = null;
                    savePlaylists();
                    if (fileMode) configureFileMode(false);
                    log("已清空直播文件播放列表。");
                }
            });
        }
        builder.show();
    }

    private void showBackgroundMusicPlaylistDialog() {
        final String[] items = playlistLabels(bgmPlaylist, -1);
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("背景音乐播放列表")
                .setItems(items, null)
                .setPositiveButton("添加音乐", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        pickBackgroundMusic();
                    }
                })
                .setNegativeButton("关闭", null);
        if (bgmPlaylist.size() > 0) {
            builder.setNeutralButton("清空列表", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    bgmPlaylist.clear();
                    savePlaylists();
                    applyBackgroundMusic();
                    log("已清空背景音乐播放列表。");
                }
            });
        }
        builder.show();
    }

    private String[] playlistLabels(ArrayList<Uri> playlist, int currentIndex) {
        if (playlist.size() == 0) return new String[]{"暂无文件"};
        String[] labels = new String[playlist.size()];
        for (int i = 0; i < playlist.size(); i++) {
            labels[i] = (i == currentIndex ? "正在播放  " : "") + (i + 1) + ". " + displayName(playlist.get(i));
        }
        return labels;
    }

    private String displayName(Uri uri) {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                String name = cursor.getString(0);
                if (name != null && name.length() > 0) return name;
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        String value = uri == null ? "" : uri.getLastPathSegment();
        if (value == null || value.length() == 0) value = uri == null ? "" : uri.toString();
        int slash = value.lastIndexOf('/');
        return slash >= 0 && slash + 1 < value.length() ? value.substring(slash + 1) : value;
    }

    private ArrayList<Uri> getSelectedUris(Intent data) {
        ArrayList<Uri> uris = new ArrayList<Uri>();
        if (data == null) return uris;
        ClipData clipData = data.getClipData();
        if (clipData != null) {
            for (int i = 0; i < clipData.getItemCount(); i++) {
                Uri uri = clipData.getItemAt(i).getUri();
                if (uri != null) uris.add(uri);
            }
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        return uris;
    }

    private void persistReadPermission(Uri uri) {
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
        }
    }

    private boolean isImageUri(Uri uri) {
        try {
            String type = getContentResolver().getType(uri);
            if (type != null && type.startsWith("image/")) return true;
        } catch (Exception ignored) {
        }
        String text = uri == null ? "" : uri.toString().toLowerCase();
        return text.endsWith(".jpg") || text.endsWith(".jpeg") || text.endsWith(".png")
                || text.endsWith(".webp") || text.endsWith(".bmp");
    }

    private void showFilePreview(Uri uri) {
        if (isImageUri(uri)) {
            filePlayer.stopPlayback();
            filePreviewUri = null;
            filePreviewPrepared = false;
            filePlayer.setVisibility(View.GONE);
            fileImagePreview.setImageURI(uri);
            fileImagePreview.setVisibility(View.VISIBLE);
        } else {
            fileImagePreview.setVisibility(View.GONE);
            fileImagePreview.setImageDrawable(null);
            filePlayer.setVisibility(View.VISIBLE);
            boolean samePreview = filePreviewUri != null && filePreviewUri.equals(uri);
            if (samePreview && filePublisher != null && filePublisher.isStreaming()) {
                if (filePreviewPrepared) {
                    syncFilePreviewPosition();
                    if (!filePlayer.isPlaying()) filePlayer.start();
                }
                return;
            }
            if (samePreview && filePreviewPrepared) {
                syncFilePreviewPosition();
                if (filePublisher != null && filePublisher.isStreaming() && !filePlayer.isPlaying()) {
                    filePlayer.start();
                }
                return;
            }
            filePreviewUri = uri;
            filePreviewPrepared = false;
            filePlayer.setVideoURI(uri);
            filePlayer.start();
        }
    }

    private void syncFilePreviewPosition() {
        if (!fileMode || fileUri == null || filePlayer == null || isImageUri(fileUri)) return;
        if (filePublisher == null || !filePublisher.isStreaming() || fileLiveStartMs <= 0) return;
        int target = (int) Math.max(0, SystemClock.elapsedRealtime() - fileLiveStartMs);
        int current = filePlayer.getCurrentPosition();
        if (Math.abs(target - current) > 1500) {
            filePlayer.seekTo(target);
        }
    }

    private void updatePlaybackProgressUi() {
        if (progressPanel == null || fileProgressViews == null || bgmProgressViews == null) return;
        if (Build.VERSION.SDK_INT >= 26 && isInPictureInPictureMode()) {
            progressPanel.setVisibility(View.GONE);
            return;
        }
        boolean fileVisible = fileMode && fileUri != null && !isImageUri(fileUri);
        if (fileVisible) {
            updateFileProgressUi();
        }
        fileProgressViews.root.setVisibility(fileVisible ? View.VISIBLE : View.GONE);

        boolean bgmVisible = bgmEnabled && bgmPlaylist.size() > 0;
        if (bgmVisible) {
            updateBgmProgressUi();
        }
        bgmProgressViews.root.setVisibility(bgmVisible ? View.VISIBLE : View.GONE);
        progressPanel.setVisibility((fileVisible || bgmVisible) ? View.VISIBLE : View.GONE);
    }

    private void updateFileProgressUi() {
        if (fileUri == null) return;
        if (progressFileUri == null || !progressFileUri.equals(fileUri)) {
            progressFileUri = fileUri;
            fileProgressViews.durationMs = 0L;
            fileProgressViews.bar.setProgress(0);
        }
        long durationMs = filePublisher != null && filePublisher.isStreaming()
                ? filePublisher.getCurrentDurationMs()
                : 0L;
        if (durationMs <= 0L && filePlayer != null) {
            try {
                durationMs = Math.max(0L, filePlayer.getDuration());
            } catch (Exception ignored) {
            }
        }
        if (durationMs <= 0L && fileProgressViews.durationMs <= 0L) {
            durationMs = readMediaDurationMs(fileUri);
        }
        if (durationMs > 0L) fileProgressViews.durationMs = durationMs;
        long positionMs = filePublisher != null && filePublisher.isStreaming()
                ? filePublisher.getCurrentPositionMs()
                : (filePlayer == null ? 0L : Math.max(0L, filePlayer.getCurrentPosition()));
        updateProgressViews(fileProgressViews, positionMs, fileProgressViews.durationMs);
    }

    private void updateBgmProgressUi() {
        Uri uri = currentBackgroundMusicUri();
        if (uri == null && bgmPlaylist.size() > 0) {
            int index = backgroundMusicPlaylistIndex();
            uri = bgmPlaylist.get(index >= 0 ? index : 0);
        }
        if (uri == null) return;
        if (progressBgmUri == null || !progressBgmUri.equals(uri)) {
            progressBgmUri = uri;
            bgmProgressViews.durationMs = 0L;
            bgmProgressViews.bar.setProgress(0);
        }
        long positionUs = 0L;
        long durationUs = 0L;
        if (filePublisher != null && filePublisher.isStreaming()) {
            positionUs = filePublisher.getBackgroundMusicPositionUs();
            durationUs = filePublisher.getBackgroundMusicDurationUs();
        } else if (publisher != null && publisher.isStreaming()) {
            positionUs = publisher.getBackgroundMusicPositionUs();
            durationUs = publisher.getBackgroundMusicDurationUs();
        }
        long durationMs = durationUs > 0L ? durationUs / 1000L : 0L;
        if (durationMs <= 0L && bgmProgressViews.durationMs <= 0L) {
            durationMs = readMediaDurationMs(uri);
        }
        if (durationMs > 0L) bgmProgressViews.durationMs = durationMs;
        updateProgressViews(bgmProgressViews, positionUs / 1000L, bgmProgressViews.durationMs);
    }

    private void updateProgressViews(ProgressViews views, long positionMs, long durationMs) {
        if (views == null) return;
        long safeDuration = Math.max(0L, durationMs);
        long safePosition = safeDuration > 0L
                ? Math.min(Math.max(0L, positionMs), safeDuration)
                : Math.max(0L, positionMs);
        views.durationMs = safeDuration;
        views.left.setText("00:00");
        views.right.setText(safeDuration > 0L ? formatDuration(safeDuration) : "--:--");
        if (!views.tracking) {
            views.current.setText(formatDuration(safePosition));
            int progress = safeDuration <= 0L ? 0 : (int) Math.min(1000L, safePosition * 1000L / safeDuration);
            views.bar.setProgress(progress);
        }
    }

    private void seekLiveFileTo(long targetMs) {
        if (!fileMode || fileUri == null || isImageUri(fileUri)) return;
        long safeTargetMs = Math.max(0L, targetMs);
        pendingFileSeekMs = safeTargetMs;
        fileLiveStartMs = SystemClock.elapsedRealtime() - safeTargetMs;
        if (filePlayer != null) {
            filePlayer.seekTo((int) safeTargetMs);
            if (filePublisher == null || !filePublisher.isPlaybackPaused()) filePlayer.start();
        }
        if (filePublisher != null && filePublisher.isStreaming()) {
            filePublisher.setPlaybackPaused(false);
            filePublisher.stop();
            previewBox.postDelayed(new Runnable() {
                @Override public void run() {
                    if (fileMode && fileUri != null) startStreamingFromSettings(false);
                }
            }, 250);
        }
    }

    private void seekBackgroundMusicTo(long targetMs) {
        long targetUs = Math.max(0L, targetMs) * 1000L;
        if (filePublisher != null && filePublisher.isStreaming()) {
            filePublisher.seekBackgroundMusic(targetUs);
        }
        if (publisher != null && publisher.isStreaming()) {
            publisher.seekBackgroundMusic(targetUs);
        }
    }

    private long readMediaDurationMs(Uri uri) {
        if (uri == null) return 0L;
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(this, uri);
            String duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            return duration == null ? 0L : Math.max(0L, Long.parseLong(duration));
        } catch (Exception ignored) {
            return 0L;
        } finally {
            try {
                retriever.release();
            } catch (Exception ignored) {
            }
        }
    }

    private String formatDuration(long ms) {
        long totalSeconds = Math.max(0L, ms) / 1000L;
        long hours = totalSeconds / 3600L;
        long minutes = (totalSeconds % 3600L) / 60L;
        long seconds = totalSeconds % 60L;
        if (hours > 0L) {
            return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds);
        }
        return String.format(Locale.US, "%02d:%02d", minutes, seconds);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_STORAGE_ACCESS) {
            Toast.makeText(this, "授权返回后，请再次点击备份或恢复。", Toast.LENGTH_SHORT).show();
            return;
        }
        if (requestCode == REQ_PICK_FILE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            fileUri = data.getData();
            persistReadPermission(fileUri);
            getSharedPreferences("live", Context.MODE_PRIVATE).edit().putString("fileUri", fileUri.toString()).apply();
            fileMode = true;
            configureFileMode(true);
            log("已选择本地文件，摄像头和麦克风已关闭。");
        } else if (requestCode == REQ_PICK_BGM && resultCode == RESULT_OK) {
            ArrayList<Uri> selected = getSelectedUris(data);
            for (Uri uri : selected) {
                persistReadPermission(uri);
                bgmPlaylist.add(uri);
            }
            if (selected.size() > 0) bgmEnabled = true;
            preserveNextBackgroundMusicApply = true;
            savePlaylists();
            applyBackgroundMusic();
            log("已添加背景音乐：" + selected.size() + " 首。");
            reopenPlaylistDialogAfterPicker();
        } else if (requestCode == REQ_PICK_FILE_PLAYLIST && resultCode == RESULT_OK) {
            ArrayList<Uri> selected = getSelectedUris(data);
            for (Uri uri : selected) {
                persistReadPermission(uri);
                filePlaylist.add(uri);
            }
            if (filePlaylist.size() > 0) {
                filePlaylistIndex = Math.min(filePlaylistIndex, filePlaylist.size() - 1);
                if (filePublisher == null || !filePublisher.isStreaming()) {
                    fileUri = filePlaylist.get(filePlaylistIndex);
                    getSharedPreferences("live", Context.MODE_PRIVATE).edit().putString("fileUri", fileUri.toString()).apply();
                    fileMode = true;
                    configureFileMode(true);
                }
            }
            savePlaylists();
            log("已添加直播文件：" + selected.size() + " 个。");
            reopenPlaylistDialogAfterPicker();
        }
    }

    private void reopenPlaylistDialogAfterPicker() {
        final int target = reopenPlaylistAfterPicker;
        reopenPlaylistAfterPicker = REOPEN_NONE;
        if (target == REOPEN_NONE || previewBox == null) return;
        previewBox.postDelayed(new Runnable() {
            @Override public void run() {
                if (target == REOPEN_FILE_PLAYLIST) {
                    showFilePlaylistDialogV2();
                } else if (target == REOPEN_BGM_PLAYLIST) {
                    showBackgroundMusicPlaylistDialogV2();
                }
            }
        }, 250);
    }

    private void configureFileMode(boolean active) {
        fileMode = active;
        if (active) {
            cameraClosed = true;
            publisher.stopStreaming();
            publisher.closeCamera();
            hideStreamMirror();
            preview.setVisibility(View.GONE);
            showFilePreview(fileUri);
            zoomControls.setVisibility(View.GONE);
            cameraButton.setEnabled(true);
            cameraButton.setText("取消文件");
            closeCameraButton.setEnabled(true);
            closeCameraButton.setText("取消文件");
            recordButton.setEnabled(false);
            recordButton.setVisibility(View.GONE);
        } else {
            filePlayer.stopPlayback();
            filePreviewUri = null;
            filePreviewPrepared = false;
            filePlayer.setVisibility(View.GONE);
            fileImagePreview.setVisibility(View.GONE);
            fileImagePreview.setImageDrawable(null);
            preview.setVisibility(View.VISIBLE);
            hideStreamMirror();
            cameraClosed = true;
            publisher.closeCamera();
            zoomControls.setVisibility(fullscreen ? View.GONE : View.VISIBLE);
            cameraButton.setEnabled(true);
            cameraButton.setText("开启摄像头");
            closeCameraButton.setEnabled(true);
            closeCameraButton.setText("开启摄像头");
            recordButton.setVisibility(View.VISIBLE);
        }
        syncStreamingUi();
    }

    private void cancelFileMode() {
        if (filePublisher != null) filePublisher.stop();
        if (filePlayer != null) filePlayer.stopPlayback();
        filePreviewUri = null;
        filePreviewPrepared = false;
        fileLiveStartMs = 0;
        fileUri = null;
        getSharedPreferences("live", Context.MODE_PRIVATE).edit().remove("fileUri").apply();
        configureFileMode(false);
        log("已取消本地文件播放和推流，请手动开启摄像头和麦克风。");
    }

    private void advanceFilePlaylistAndRestart() {
        if (!fileMode || userStoppingFileStream || filePlaylist.size() == 0) return;
        if (pendingFilePlaylistIndex >= 0 && pendingFilePlaylistIndex < filePlaylist.size()) {
            filePlaylistIndex = pendingFilePlaylistIndex;
            pendingFilePlaylistIndex = -1;
        } else {
            filePlaylistIndex = nextPlaylistIndex(filePlaylistIndex, filePlaylist.size(), filePlayMode);
        }
        fileUri = filePlaylist.get(filePlaylistIndex);
        getSharedPreferences("live", Context.MODE_PRIVATE).edit().putString("fileUri", fileUri.toString()).apply();
        savePlaylists();
        if (filePlayer != null) {
            showFilePreview(fileUri);
        }
        previewBox.postDelayed(new Runnable() {
            @Override public void run() {
                if (fileMode && !userStoppingFileStream && fileUri != null && !filePublisher.isStreaming()) {
                    startStreamingFromSettings(false);
                }
            }
        }, 600);
    }

    private int nextPlaylistIndex(int current, int size, int mode) {
        if (size <= 1) return 0;
        if (mode == PLAY_MODE_RANDOM) {
            int next = random.nextInt(size);
            return next == current ? (next + 1) % size : next;
        }
        if (mode == PLAY_MODE_SINGLE_LOOP) return Math.max(0, Math.min(current, size - 1));
        return (current + 1) % size;
    }

    private void applyBackgroundMusic() {
        if (preserveNextBackgroundMusicApply) {
            preserveNextBackgroundMusicApply = false;
            applyBackgroundMusicPreservingPlayback();
            return;
        }
        ArrayList<Uri> active = activeBackgroundMusicPlaylist();
        if (publisher != null) {
            publisher.setBackgroundMusic(active, bgmPlayMode);
        }
        if (filePublisher != null) {
            filePublisher.setBackgroundMusic(active, bgmPlayMode);
        }
        applyBackgroundMusicPauseState();
    }

    private void applyBackgroundMusicPreservingPlayback() {
        ArrayList<Uri> active = activeBackgroundMusicPlaylist();
        if (publisher != null) {
            publisher.setBackgroundMusicPreservingPlayback(active, bgmPlayMode);
        }
        if (filePublisher != null) {
            filePublisher.setBackgroundMusicPreservingPlayback(active, bgmPlayMode);
        }
        applyBackgroundMusicPauseState();
    }

    private void updateBackgroundMusicMode() {
        savePlaylists();
        if (publisher != null) {
            publisher.setBackgroundMusicMode(bgmPlayMode);
        }
        if (filePublisher != null) {
            filePublisher.setBackgroundMusicMode(bgmPlayMode);
        }
    }

    private ArrayList<Uri> activeBackgroundMusicPlaylist() {
        ArrayList<Uri> active = new ArrayList<Uri>();
        if (bgmEnabled) active.addAll(bgmPlaylist);
        return active;
    }

    private void applyBackgroundMusicPauseState() {
        boolean paused = bgmPaused || !bgmEnabled;
        if (publisher != null) publisher.setBackgroundMusicPaused(paused);
        if (filePublisher != null) filePublisher.setBackgroundMusicPaused(paused);
    }

    @Override
    public void onStatus(String message) {
        final String text = message;
        runOnUiThread(new Runnable() {
            @Override public void run() { log(text); }
        });
    }

    @Override
    public void onStreamingChanged(boolean streaming) {
        final boolean active = streaming;
        runOnUiThread(new Runnable() {
            @Override public void run() {
                if (active) {
                    startKeepAliveService();
                    updateLivePictureInPictureParams();
                } else if (!isAnyStreaming() && !pipRestartingStream) {
                    stopKeepAliveService();
                    fileLiveStartMs = 0;
                }
                syncStreamingUi();
            }
        });
    }

    @Override
    public void onFileStreamFinished(final boolean completed) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                if (completed && fileMode && !userStoppingFileStream && filePlaylist.size() > 0) {
                    advanceFilePlaylistAndRestart();
                }
            }
        });
    }

    @Override
    public void onMirrorFrame(final Bitmap bitmap) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                if (!shouldShowStreamMirror()) {
                    bitmap.recycle();
                    return;
                }
                showStreamMirrorBitmap(bitmap, false);
            }
        });
    }

    private boolean shouldShowStreamMirror() {
        return isAnyStreaming() && !fileMode && (isInPictureInPictureMode() || !landscape);
    }

    private void startPipMirrorFrames() {
        if (previewBox == null || fileMode || publisher == null || !publisher.isStreaming()) return;
        previewBox.removeCallbacks(pipMirrorFrameRunnable);
        samplePipMirrorFrame();
        previewBox.postDelayed(pipMirrorFrameRunnable, 250);
    }

    private void stopPipMirrorFrames() {
        if (previewBox != null) {
            previewBox.removeCallbacks(pipMirrorFrameRunnable);
        }
    }

    private void samplePipMirrorFrame() {
        if (preview == null || !preview.isAvailable() || !shouldShowStreamMirror()) return;
        int width = landscape ? 576 : 324;
        int height = landscape ? 324 : 576;
        Bitmap bitmap = null;
        try {
            bitmap = preview.getBitmap(width, height);
        } catch (Exception ignored) {
        }
        if (bitmap == null) return;
        showStreamMirrorBitmap(bitmap, true);
    }

    private void showStreamMirrorBitmap(Bitmap bitmap, boolean keepLastWhenBlank) {
        if (bitmap == null) return;
        if (keepLastWhenBlank && lastMirrorBitmap != null && isMostlyBlack(bitmap)) {
            bitmap.recycle();
            streamMirror.setVisibility(View.VISIBLE);
            return;
        }
        Bitmap old = lastMirrorBitmap;
        lastMirrorBitmap = bitmap;
        streamMirror.setImageBitmap(bitmap);
        streamMirror.setVisibility(View.VISIBLE);
        if (old != null && old != bitmap && !old.isRecycled()) {
            old.recycle();
        }
    }

    private boolean isMostlyBlack(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        if (width <= 0 || height <= 0) return true;
        int samples = 0;
        int dark = 0;
        int stepX = Math.max(1, width / 8);
        int stepY = Math.max(1, height / 8);
        for (int y = stepY / 2; y < height; y += stepY) {
            for (int x = stepX / 2; x < width; x += stepX) {
                int color = bitmap.getPixel(x, y);
                int r = (color >> 16) & 0xff;
                int g = (color >> 8) & 0xff;
                int b = color & 0xff;
                if (r + g + b < 36) dark++;
                samples++;
            }
        }
        return samples > 0 && dark * 100 / samples > 96;
    }

    private void syncStreamingUi() {
        boolean active = isAnyStreaming();
        startButton.setText(active ? "停止直播" : "开始直播");
        stopLiveButton.setEnabled(active);
        recordButton.setVisibility(fileMode ? View.GONE : View.VISIBLE);
        recordButton.setEnabled(active && !fileMode);
        settingsButton.setEnabled(!active);
        orientationButton.setEnabled(!active || !fileMode);
        zoomControls.setVisibility((fileMode || fullscreen || isInPictureInPictureMode()) ? View.GONE : View.VISIBLE);
        cameraButton.setText(fileMode ? "取消文件" : (cameraClosed ? "开启摄像头" : "切摄像头"));
        closeCameraButton.setText(fileMode ? "取消文件" : (cameraClosed ? "开启摄像头" : "关闭摄像头"));
        if (!active) recordButton.setText("录像");
        if (shouldShowStreamMirror()) {
            streamMirror.setVisibility(View.VISIBLE);
        } else {
            hideStreamMirror();
        }
        if (isInPictureInPictureMode()) {
            setPipUi(true);
            return;
        }
        if (active && !landscape) {
            previewBox.removeCallbacks(hideLiveControlsRunnable);
            previewBox.postDelayed(hideLiveControlsRunnable, 3000);
        } else if (!active) {
            previewBox.removeCallbacks(hideLiveControlsRunnable);
            setLiveControlsHidden(false);
        }
    }

    private void hideStreamMirror() {
        if (streamMirror == null) return;
        streamMirror.setVisibility(View.GONE);
        streamMirror.setImageBitmap(null);
        if (lastMirrorBitmap != null && !lastMirrorBitmap.isRecycled()) {
            lastMirrorBitmap.recycle();
        }
        lastMirrorBitmap = null;
    }

    private boolean isAnyStreaming() {
        return (publisher != null && publisher.isStreaming())
                || (filePublisher != null && filePublisher.isStreaming());
    }

    private void startKeepAliveService() {
        if (liveWakeLock != null && !liveWakeLock.isHeld()) {
            liveWakeLock.acquire();
        }
        if (liveWifiLock != null && !liveWifiLock.isHeld()) {
            liveWifiLock.acquire();
        }
        Intent intent = new Intent(this, LiveForegroundService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
        } catch (RuntimeException e) {
            Log.w("CoryKuiLive", "keep alive service start skipped: " + e.getMessage());
        }
    }

    private void stopKeepAliveService() {
        if (liveWakeLock != null && liveWakeLock.isHeld()) {
            liveWakeLock.release();
        }
        if (liveWifiLock != null && liveWifiLock.isHeld()) {
            liveWifiLock.release();
        }
        stopService(new Intent(this, LiveForegroundService.class));
    }

    @Override
    public void onRecordingChanged(boolean recording) {
        final boolean active = recording;
        runOnUiThread(new Runnable() {
            @Override public void run() { recordButton.setText(active ? "停止录像" : "录像"); }
        });
    }

    private void log(String message) {
        String time = new SimpleDateFormat("HH:mm:ss", Locale.CHINA).format(new Date());
        status.setText(time + "  " + message + "\n" + status.getText());
    }
}
