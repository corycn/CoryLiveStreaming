package cn.ohpt.livestream;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URI;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;

final class RtmpClient {
    private Socket socket;
    private DataInputStream in;
    private OutputStream out;
    private int chunkStreamId = 4;
    private int messageStreamId = 1;
    private int commandTransactionId = 1;
    private String app;
    private String streamName;
    private String tcUrl;
    private final LinkedBlockingDeque<RtmpPacket> writeQueue = new LinkedBlockingDeque<RtmpPacket>(720);
    private volatile boolean closed;
    private volatile IOException writerError;
    private Thread writerThread;

    void connect(String url) throws IOException {
        URI uri = URI.create(url);
        validatePushUrlNotExpired(uri);
        if (!"rtmp".equalsIgnoreCase(uri.getScheme())) {
            throw new IOException("仅支持 rtmp:// 推流地址");
        }
        String host = uri.getHost();
        int port = uri.getPort() > 0 ? uri.getPort() : 1935;
        String rawPath = uri.getPath().replaceFirst("^/+", "");
        int lastSlash = rawPath.lastIndexOf('/');
        if (lastSlash <= 0 || lastSlash >= rawPath.length() - 1) {
            throw new IOException("RTMP 地址应包含 app 和 stream key，例如 rtmp://host/live/key");
        }
        app = rawPath.substring(0, lastSlash);
        streamName = rawPath.substring(lastSlash + 1);
        if (uri.getRawQuery() != null && uri.getRawQuery().length() > 0) {
            streamName = streamName + "?" + uri.getRawQuery();
        }
        tcUrl = "rtmp://" + host + ":" + port + "/" + app;

        socket = new Socket();
        socket.connect(new InetSocketAddress(host, port), 5000);
        socket.setTcpNoDelay(true);
        socket.setSoTimeout(3500);
        in = new DataInputStream(socket.getInputStream());
        out = socket.getOutputStream();

        handshake();
        sendSetChunkSize(4096);
        sendConnect();
        drainServerReply();
        sendCreateStream();
        drainServerReply();
        sendPublish();
        drainServerReply();
        startWriter();
    }

    private void validatePushUrlNotExpired(URI uri) throws IOException {
        String query = uri.getRawQuery();
        if (query == null || query.length() == 0) return;
        String[] parts = query.split("&");
        for (String part : parts) {
            int equals = part.indexOf('=');
            if (equals <= 0) continue;
            String name = part.substring(0, equals);
            if (!"txTime".equalsIgnoreCase(name)) continue;
            String value = part.substring(equals + 1);
            try {
                long expireSeconds = Long.parseLong(value, 16);
                long nowSeconds = System.currentTimeMillis() / 1000L;
                if (expireSeconds + 30L < nowSeconds) {
                    throw new IOException("推流密钥已过期(txTime=" + value + ")，请从直播后台复制新的推流密钥。");
                }
            } catch (NumberFormatException e) {
                throw new IOException("推流密钥 txTime 格式无效：" + value, e);
            }
            return;
        }
    }

    void sendVideoConfig(byte[] avcc, int timestamp) throws IOException {
        ByteArrayOutputStream payload = new ByteArrayOutputStream();
        payload.write(0x17);
        payload.write(0);
        writeMedium(payload, 0);
        payload.write(avcc);
        enqueueMessage(9, 6, timestamp, payload.toByteArray());
    }

    void sendMetadata(int width, int height, int frameRate, int videoBitrate, int timestamp) throws IOException {
        ByteArrayOutputStream payload = new ByteArrayOutputStream();
        amfString(payload, "@setDataFrame");
        amfString(payload, "onMetaData");
        payload.write(8);
        writeInt(payload, 8);
        amfPropNumber(payload, "width", width);
        amfPropNumber(payload, "height", height);
        amfPropNumber(payload, "framerate", frameRate);
        amfPropNumber(payload, "videocodecid", 7);
        amfPropString(payload, "encoder", "CoryKui Livestream");
        amfPropNumber(payload, "videodatarate", videoBitrate / 1000.0);
        amfPropNumber(payload, "audiocodecid", 10);
        amfPropNumber(payload, "audiodatarate", 128);
        amfObjectEnd(payload);
        enqueueMessage(18, 5, timestamp, payload.toByteArray());
    }

    void sendVideoFrame(byte[] sample, boolean keyFrame, int timestamp) throws IOException {
        ByteArrayOutputStream payload = new ByteArrayOutputStream();
        payload.write(keyFrame ? 0x17 : 0x27);
        payload.write(1);
        writeMedium(payload, 0);
        payload.write(sample);
        enqueueMessage(9, 6, timestamp, payload.toByteArray());
    }

    void sendAudioConfig(byte[] config, int timestamp) throws IOException {
        ByteArrayOutputStream payload = new ByteArrayOutputStream();
        payload.write(0xAF);
        payload.write(0);
        payload.write(config);
        enqueueMessage(8, 4, timestamp, payload.toByteArray());
    }

    void sendAudioFrame(byte[] sample, int timestamp) throws IOException {
        ByteArrayOutputStream payload = new ByteArrayOutputStream();
        payload.write(0xAF);
        payload.write(1);
        payload.write(sample);
        enqueueMessage(8, 4, timestamp, payload.toByteArray());
    }

    void close() {
        closed = true;
        if (writerThread != null) writerThread.interrupt();
        try {
            if (socket != null) socket.close();
        } catch (IOException ignored) {
        }
        writeQueue.clear();
    }

    private void handshake() throws IOException {
        byte[] c1 = new byte[1536];
        new Random().nextBytes(c1);
        c1[0] = c1[1] = c1[2] = c1[3] = 0;
        out.write(3);
        out.write(c1);
        out.flush();
        byte[] s0s1s2 = new byte[1 + 1536 + 1536];
        in.readFully(s0s1s2);
        out.write(s0s1s2, 1, 1536);
        out.flush();
    }

    private void sendConnect() throws IOException {
        ByteArrayOutputStream p = new ByteArrayOutputStream();
        amfString(p, "connect");
        amfNumber(p, commandTransactionId++);
        amfObjectStart(p);
        amfPropString(p, "app", app);
        amfPropString(p, "type", "nonprivate");
        amfPropString(p, "tcUrl", tcUrl);
        amfPropBoolean(p, "fpad", false);
        amfPropNumber(p, "capabilities", 15);
        amfPropNumber(p, "audioCodecs", 4071);
        amfPropNumber(p, "videoCodecs", 252);
        amfObjectEnd(p);
        sendMessage(20, 3, 0, 0, p.toByteArray());
    }

    private void sendCreateStream() throws IOException {
        ByteArrayOutputStream p = new ByteArrayOutputStream();
        amfString(p, "createStream");
        amfNumber(p, commandTransactionId++);
        p.write(5);
        sendMessage(20, 3, 0, 0, p.toByteArray());
    }

    private void sendPublish() throws IOException {
        ByteArrayOutputStream p = new ByteArrayOutputStream();
        amfString(p, "publish");
        amfNumber(p, 3);
        p.write(5);
        amfString(p, streamName);
        amfString(p, "live");
        sendMessage(20, 3, 0, messageStreamId, p.toByteArray());
    }

    private void sendSetChunkSize(int size) throws IOException {
        ByteArrayOutputStream p = new ByteArrayOutputStream();
        p.write((size >> 24) & 0xff);
        p.write((size >> 16) & 0xff);
        p.write((size >> 8) & 0xff);
        p.write(size & 0xff);
        sendMessage(1, 2, 0, 0, p.toByteArray());
    }

    private void startWriter() {
        closed = false;
        writerError = null;
        writerThread = new Thread(new Runnable() {
            @Override public void run() {
                while (!closed) {
                    try {
                        RtmpPacket packet = writeQueue.poll(500, TimeUnit.MILLISECONDS);
                        if (packet == null) continue;
                        sendMessage(packet.type, packet.csid, packet.timestamp, packet.streamId, packet.payload);
                    } catch (InterruptedException e) {
                        if (closed) return;
                    } catch (IOException e) {
                        writerError = e;
                        close();
                        return;
                    }
                }
            }
        }, "rtmp-writer");
        writerThread.start();
    }

    private void enqueueMessage(int type, int csid, int timestamp, byte[] payload) throws IOException {
        enqueueMessage(type, csid, timestamp, messageStreamId, payload);
    }

    private void enqueueMessage(int type, int csid, int timestamp, int streamId, byte[] payload) throws IOException {
        checkWriter();
        RtmpPacket packet = new RtmpPacket(type, csid, timestamp, streamId, payload);
        if (writeQueue.offerLast(packet)) return;
        if (isDroppableVideo(packet)) return;
        dropDroppableVideoFrames(80);
        if (writeQueue.offerLast(packet)) return;
        throw new IOException("RTMP 发送队列已满");
    }

    private void checkWriter() throws IOException {
        if (writerError != null) throw writerError;
        if (closed) throw new IOException("RTMP 连接已关闭");
    }

    private boolean isDroppableVideo(RtmpPacket packet) {
        return packet.type == 9 && packet.payload.length > 1 && packet.payload[0] == 0x27;
    }

    private void dropDroppableVideoFrames(int maxDrops) {
        int dropped = 0;
        int count = writeQueue.size();
        for (int i = 0; i < count; i++) {
            RtmpPacket packet = writeQueue.pollFirst();
            if (packet == null) return;
            if (dropped < maxDrops && isDroppableVideo(packet)) {
                dropped++;
                continue;
            }
            writeQueue.offerLast(packet);
        }
    }

    private static final class RtmpPacket {
        final int type;
        final int csid;
        final int timestamp;
        final int streamId;
        final byte[] payload;

        RtmpPacket(int type, int csid, int timestamp, int streamId, byte[] payload) {
            this.type = type;
            this.csid = csid;
            this.timestamp = timestamp;
            this.streamId = streamId;
            this.payload = payload;
        }
    }

    private void sendMessage(int type, int csid, int timestamp, byte[] payload) throws IOException {
        sendMessage(type, csid, timestamp, messageStreamId, payload);
    }

    private void sendMessage(int type, int csid, int timestamp, int streamId, byte[] payload) throws IOException {
        out.write(0x00 | csid);
        writeMedium(out, Math.min(timestamp, 0xFFFFFF));
        writeMedium(out, payload.length);
        out.write(type);
        writeIntLe(out, streamId);
        if (timestamp >= 0xFFFFFF) {
            writeInt(out, timestamp);
        }
        int offset = 0;
        while (offset < payload.length) {
            int count = Math.min(4096, payload.length - offset);
            out.write(payload, offset, count);
            offset += count;
            if (offset < payload.length) {
                out.write(0xC0 | csid);
                if (timestamp >= 0xFFFFFF) {
                    writeInt(out, timestamp);
                }
            }
        }
        out.flush();
        chunkStreamId = csid;
    }

    private void drainServerReply() {
        long end = System.currentTimeMillis() + 900;
        byte[] buf = new byte[4096];
        try {
            while (System.currentTimeMillis() < end && in.available() > 0) {
                in.read(buf, 0, Math.min(buf.length, in.available()));
            }
        } catch (IOException ignored) {
        }
    }

    private static void amfString(ByteArrayOutputStream out, String value) {
        out.write(2);
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        out.write((bytes.length >> 8) & 0xff);
        out.write(bytes.length & 0xff);
        out.write(bytes, 0, bytes.length);
    }

    private static void amfNumber(ByteArrayOutputStream out, double value) {
        out.write(0);
        long bits = Double.doubleToLongBits(value);
        for (int i = 7; i >= 0; i--) out.write((int) (bits >> (8 * i)) & 0xff);
    }

    private static void amfObjectStart(ByteArrayOutputStream out) {
        out.write(3);
    }

    private static void amfObjectEnd(ByteArrayOutputStream out) {
        out.write(0);
        out.write(0);
        out.write(9);
    }

    private static void amfPropString(ByteArrayOutputStream out, String name, String value) {
        amfPropName(out, name);
        amfString(out, value);
    }

    private static void amfPropNumber(ByteArrayOutputStream out, String name, double value) {
        amfPropName(out, name);
        amfNumber(out, value);
    }

    private static void amfPropBoolean(ByteArrayOutputStream out, String name, boolean value) {
        amfPropName(out, name);
        out.write(1);
        out.write(value ? 1 : 0);
    }

    private static void amfPropName(ByteArrayOutputStream out, String name) {
        byte[] bytes = name.getBytes(StandardCharsets.UTF_8);
        out.write((bytes.length >> 8) & 0xff);
        out.write(bytes.length & 0xff);
        out.write(bytes, 0, bytes.length);
    }

    private static void writeMedium(OutputStream out, int value) throws IOException {
        out.write((value >> 16) & 0xff);
        out.write((value >> 8) & 0xff);
        out.write(value & 0xff);
    }

    private static void writeInt(OutputStream out, int value) throws IOException {
        out.write((value >> 24) & 0xff);
        out.write((value >> 16) & 0xff);
        out.write((value >> 8) & 0xff);
        out.write(value & 0xff);
    }

    private static void writeIntLe(OutputStream out, int value) throws IOException {
        out.write(value & 0xff);
        out.write((value >> 8) & 0xff);
        out.write((value >> 16) & 0xff);
        out.write((value >> 24) & 0xff);
    }
}
