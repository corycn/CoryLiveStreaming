package cn.ohpt.livestream;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.MeteringRectangle;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaRecorder;
import android.media.MediaScannerConnection;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Log;
import android.util.Range;
import android.view.Surface;
import android.view.TextureView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

final class RtmpPublisher {
    private static final String TAG = "CoryKuiLive";
    static final int CAMERA_BACK_MAIN = 0;
    static final int CAMERA_BACK_ULTRAWIDE = 1;
    static final int CAMERA_FRONT = 2;

    interface Listener {
        void onStatus(String message);
        void onStreamingChanged(boolean streaming);
        void onRecordingChanged(boolean recording);
        void onMirrorFrame(Bitmap bitmap);
    }

    private final Context context;
    private TextureView preview;
    private Listener listener;
    private CameraManager cameraManager;
    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private CaptureRequest.Builder previewRequest;
    private int cameraGeneration;
    private String cameraId;
    private Rect sensorRect;
    private int maxAfRegions;
    private int maxAeRegions;
    private int sensorOrientation = 90;
    private float maxZoom = 1.0f;
    private float zoom = 1.0f;
    private MediaCodec videoEncoder;
    private MediaCodec audioEncoder;
    private Surface encoderSurface;
    private ImageReader imageReader;
    private int videoInputColorFormat = MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar;
    private AudioRecord audioRecord;
    private volatile List<RtmpClient> rtmps = new ArrayList<RtmpClient>();
    private final AtomicBoolean streaming = new AtomicBoolean(false);
    private final Object recordLock = new Object();
    private MediaMuxer muxer;
    private MediaFormat videoMuxFormat;
    private MediaFormat audioMuxFormat;
    private int videoTrack = -1;
    private int audioTrack = -1;
    private boolean recording;
    private volatile boolean muted;
    private volatile boolean microphoneEnabled = true;
    private volatile float microphoneVolume = 1.0f;
    private boolean muxerStarted;
    private String recordingPath;
    private Uri recordingUri;
    private ParcelFileDescriptor recordingFd;
    private long startUs;
    private StreamConfig activeConfig;
    private List<String> activeUrls = new ArrayList<String>();
    private final AtomicBoolean reconnecting = new AtomicBoolean(false);
    private boolean videoConfigLogged;
    private boolean firstVideoFrameLogged;
    private long videoFramesSent;
    private long audioFramesSent;
    private volatile boolean forcePreviewFrames;
    private volatile boolean previewSurfaceEnabled = true;
    private volatile boolean trialWatermark;
    private final BackgroundMusicMixer backgroundMusicMixer;
    private byte[] lastVideoYuv;
    private Bitmap trialIcon;
    private long lastCameraFrameMs;
    private long lastStreamSessionRestartMs;
    private Thread videoThread;
    private Thread audioThread;
    private int streamGeneration;
    private final TextureView.SurfaceTextureListener surfaceTextureListener = new TextureView.SurfaceTextureListener() {
        @Override public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
            if (streaming.get()) {
                updatePreviewTransform();
                startPreviewSession(streamInputSurface());
                requestKeyFrame();
            } else {
                openCamera(false);
            }
        }
        @Override public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) { updatePreviewTransform(); }
        @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) { return !streaming.get(); }
        @Override public void onSurfaceTextureUpdated(SurfaceTexture surface) {}
    };

    RtmpPublisher(Context context, TextureView preview, Listener listener) {
        this.context = context.getApplicationContext();
        this.backgroundMusicMixer = new BackgroundMusicMixer(context);
        this.backgroundMusicMixer.setMonitorPlayback(true);
        cameraManager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        cameraThread = new HandlerThread("camera");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
        attach(preview, listener);
    }

    void attach(TextureView preview, Listener listener) {
        TextureView oldPreview = this.preview;
        if (oldPreview != null && oldPreview != preview) {
            oldPreview.setSurfaceTextureListener(null);
        }
        this.preview = preview;
        this.listener = listener;
        preview.setSurfaceTextureListener(surfaceTextureListener);
        if (preview.isAvailable() && streaming.get()) {
            updatePreviewTransform();
            startPreviewSession(streamInputSurface());
            requestKeyFrame();
        }
    }

    boolean isStreaming() {
        return streaming.get();
    }

    boolean isRecording() {
        synchronized (recordLock) {
            return recording;
        }
    }

    float getMaxZoom() {
        return maxZoom;
    }

    void setZoom(float value) {
        zoom = Math.max(1.0f, Math.min(value, maxZoom));
        applyRepeatingRequest();
    }

    void setMuted(boolean muted) {
        if (this.muted == muted) return;
        this.muted = muted;
        listener.onStatus(muted ? "麦克风已静音。" : "麦克风已恢复。");
    }

    void setMicrophoneEnabled(boolean enabled) {
        microphoneEnabled = enabled;
        listener.onStatus(enabled ? "麦克风已开启。" : "麦克风已关闭。");
    }

    void setMicrophoneVolume(float volume) {
        microphoneVolume = Math.max(0.0f, Math.min(2.0f, volume));
    }

    void setTrialWatermark(boolean enabled) {
        trialWatermark = enabled;
    }

    void setBackgroundMusic(List<Uri> playlist, int playMode) {
        backgroundMusicMixer.setPlaylist(playlist, playMode);
        Log.i(TAG, "camera background music playlist size="
                + (playlist == null ? 0 : playlist.size()) + " mode=" + playMode);
        listener.onStatus(playlist != null && playlist.size() > 0 ? "背景音乐播放列表已启用。" : "背景音乐播放列表为空。");
    }

    void setBackgroundMusicPreservingPlayback(List<Uri> playlist, int playMode) {
        backgroundMusicMixer.setPlaylistPreservingPlayback(playlist, playMode);
        Log.i(TAG, "camera background music playlist updated without interrupt size="
                + (playlist == null ? 0 : playlist.size()) + " mode=" + playMode);
    }

    void setBackgroundMusicMode(int playMode) {
        backgroundMusicMixer.setPlayMode(playMode);
        Log.i(TAG, "camera background music mode=" + playMode);
    }

    void setBackgroundMusicPaused(boolean paused) {
        backgroundMusicMixer.setPaused(paused);
        Log.i(TAG, "camera background music paused=" + paused);
    }

    void setBackgroundMusicVolume(float volume) {
        backgroundMusicMixer.setVolume(volume);
    }

    Uri getBackgroundMusicCurrentUri() {
        return backgroundMusicMixer.getCurrentUri();
    }

    long getBackgroundMusicPositionUs() {
        return backgroundMusicMixer.getCurrentPositionUs();
    }

    long getBackgroundMusicDurationUs() {
        return backgroundMusicMixer.getCurrentDurationUs();
    }

    void seekBackgroundMusic(long positionUs) {
        backgroundMusicMixer.seekToCurrent(positionUs);
    }

    boolean isBackgroundMusicPaused() {
        return backgroundMusicMixer.isPaused();
    }

    void refreshPreview() {
        if (streaming.get()) return;
        if (streaming.get() && encoderSurface != null) return;
        startPreviewSession(streamInputSurface());
    }

    void restartStreamCaptureSession() {
        if (!streaming.get()) return;
        startPreviewSession(streamInputSurface());
    }

    void setPreviewSurfaceEnabled(boolean enabled) {
        if (previewSurfaceEnabled == enabled) return;
        previewSurfaceEnabled = enabled;
        startPreviewSession(streamInputSurface());
    }

    void requestKeyFrame() {
        try {
            if (videoEncoder == null) return;
            Bundle params = new Bundle();
            params.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0);
            videoEncoder.setParameters(params);
        } catch (Exception ignored) {
        }
    }

    void setForcePreviewFrames(boolean force) {
        forcePreviewFrames = force;
    }

    void resendStreamHeaders() {
        try {
            StreamConfig config = activeConfig;
            if (!streaming.get() || config == null || videoEncoder == null) return;
            sendMetadata(config.width, config.height, config.fps, config.videoBitrate, timestamp());
            sendVideoConfig(makeAvcc(videoEncoder.getOutputFormat()), timestamp());
            sendAudioConfig(new byte[]{0x12, 0x10}, timestamp());
            requestKeyFrame();
        } catch (Exception ignored) {
        }
    }

    void focusAt(float viewX, float viewY) {
        if (session == null || previewRequest == null || sensorRect == null) return;
        try {
            Rect crop = currentCropRegion();
            int area = Math.max(crop.width(), crop.height()) / 5;
            float nx = Math.max(0.0f, Math.min(1.0f, viewX / Math.max(1, preview.getWidth())));
            float ny = Math.max(0.0f, Math.min(1.0f, viewY / Math.max(1, preview.getHeight())));
            int rotation = ((android.view.WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRotation();
            float sx = nx;
            float sy = ny;
            if (rotation == Surface.ROTATION_90) {
                sx = ny;
                sy = 1.0f - nx;
            } else if (rotation == Surface.ROTATION_270) {
                sx = 1.0f - ny;
                sy = nx;
            }
            int sensorX = crop.left + (int) (sx * crop.width());
            int sensorY = crop.top + (int) (sy * crop.height());
            Rect focusRect = new Rect(
                    clamp(sensorX - area / 2, crop.left, crop.right - 1),
                    clamp(sensorY - area / 2, crop.top, crop.bottom - 1),
                    clamp(sensorX + area / 2, crop.left + 1, crop.right),
                    clamp(sensorY + area / 2, crop.top + 1, crop.bottom));
            MeteringRectangle[] regions = new MeteringRectangle[]{
                    new MeteringRectangle(focusRect, MeteringRectangle.METERING_WEIGHT_MAX)
            };
            previewRequest.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_CANCEL);
            session.capture(previewRequest.build(), null, cameraHandler);
            previewRequest.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO);
            if (maxAfRegions > 0) previewRequest.set(CaptureRequest.CONTROL_AF_REGIONS, regions);
            if (maxAeRegions > 0) previewRequest.set(CaptureRequest.CONTROL_AE_REGIONS, regions);
            previewRequest.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START);
            session.capture(previewRequest.build(), null, cameraHandler);
            previewRequest.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_IDLE);
            session.setRepeatingRequest(previewRequest.build(), null, cameraHandler);
            listener.onStatus("已对焦。");
        } catch (Exception e) {
            listener.onStatus("对焦失败：" + e.getMessage());
        }
    }

    void openCamera(final boolean front) {
        openCameraMode(front ? CAMERA_FRONT : CAMERA_BACK_MAIN);
    }

    void openCameraMode(final int mode) {
        if (context.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED || !preview.isAvailable()) {
            return;
        }
        final int generation = ++cameraGeneration;
        closeCameraInternal();
        try {
            cameraId = chooseCamera(mode);
            CameraCharacteristics c = cameraManager.getCameraCharacteristics(cameraId);
            sensorRect = c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            Integer af = c.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF);
            Integer ae = c.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE);
            maxAfRegions = af == null ? 0 : af;
            maxAeRegions = ae == null ? 0 : ae;
            Integer orientation = c.get(CameraCharacteristics.SENSOR_ORIENTATION);
            sensorOrientation = orientation == null ? 90 : orientation;
            Float mz = c.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
            maxZoom = Math.max(1.0f, Math.min(mz == null ? 1.0f : mz, 10.0f));
            cameraManager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice cameraDevice) {
                    if (generation != cameraGeneration) {
                        cameraDevice.close();
                        return;
                    }
                    camera = cameraDevice;
                    listener.onStatus(cameraModeLabel(mode));
                    startPreviewSession(streamInputSurface());
                }
                @Override public void onDisconnected(CameraDevice cameraDevice) {
                    if (generation == cameraGeneration) closeCamera();
                    else cameraDevice.close();
                }
                @Override public void onError(CameraDevice cameraDevice, int error) {
                    if (generation == cameraGeneration) {
                        listener.onStatus("摄像头打开失败：" + error);
                        closeCamera();
                    } else {
                        cameraDevice.close();
                    }
                }
            }, cameraHandler);
        } catch (Exception e) {
            listener.onStatus("摄像头初始化失败：" + e.getMessage());
        }
    }

    boolean hasUltraWideCamera() {
        try {
            return findBackCamera(true) != null;
        } catch (Exception e) {
            return false;
        }
    }

    void closeCamera() {
        cameraGeneration++;
        closeCameraInternal();
    }

    private void closeCameraInternal() {
        try {
            if (session != null) session.close();
            if (camera != null) camera.close();
        } catch (Exception ignored) {
        }
        session = null;
        camera = null;
    }

    void startStreaming(final List<String> urls, final StreamConfig config, final boolean front) {
        final int runGeneration;
        synchronized (this) {
            if (streaming.get()) return;
            streamGeneration++;
            runGeneration = streamGeneration;
            streaming.set(true);
        }
        listener.onStreamingChanged(true);
        listener.onStatus("正在连接直播服务器...");
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    synchronized (recordLock) {
                        videoMuxFormat = null;
                        audioMuxFormat = null;
                    }
                    activeConfig = config;
                    activeUrls = new ArrayList<String>(urls);
                    videoConfigLogged = false;
                    firstVideoFrameLogged = false;
                    videoFramesSent = 0;
                    audioFramesSent = 0;
                    lastCameraFrameMs = SystemClock.elapsedRealtime();
                    lastStreamSessionRestartMs = 0;
                    prepareVideoEncoder(config);
                    prepareAudioEncoder(config);
                    synchronized (rtmps) {
                        rtmps.clear();
                    }
                    for (String url : urls) {
                        RtmpClient client = new RtmpClient();
                        client.connect(url);
                        synchronized (rtmps) {
                            rtmps.add(client);
                        }
                        listener.onStatus("已连接：" + url);
                    }
                    if (rtmps.size() == 0) {
                        throw new IOException("没有可用推流地址");
                    }
                    startUs = System.nanoTime() / 1000L;
                    startPreviewSession(streamInputSurface());
                    listener.onStatus("服务器已连接，开始推流。");
                    startVideoLoop(runGeneration);
                    startAudioLoop(config, runGeneration);
                } catch (Exception e) {
                    listener.onStatus("推流启动失败：" + e.getMessage());
                    stopStreamingIfCurrent(runGeneration);
                }
            }
        }, "stream-start").start();
    }

    void stopStreaming() {
        synchronized (this) {
            streamGeneration++;
        }
        stopStreamingInternal();
    }

    private void stopStreamingIfCurrent(int runGeneration) {
        synchronized (this) {
            if (runGeneration != streamGeneration) return;
            streamGeneration++;
        }
        stopStreamingInternal();
    }

    private synchronized boolean isCurrentStream(int runGeneration) {
        return runGeneration == streamGeneration;
    }

    private void stopStreamingInternal() {
        if (!streaming.getAndSet(false)) return;
        stopRecording();
        listener.onStreamingChanged(false);
        listener.onStatus("直播已停止。");
        try {
            if (audioRecord != null) audioRecord.stop();
        } catch (Exception ignored) {
        }
        try {
            if (videoEncoder != null) videoEncoder.stop();
        } catch (Exception ignored) {
        }
        try {
            if (audioEncoder != null) audioEncoder.stop();
        } catch (Exception ignored) {
        }
        try {
            if (videoEncoder != null) videoEncoder.release();
            if (audioEncoder != null) audioEncoder.release();
            if (audioRecord != null) audioRecord.release();
            if (backgroundMusicMixer != null) backgroundMusicMixer.release();
        } catch (Exception ignored) {
        }
        videoEncoder = null;
        audioEncoder = null;
        audioRecord = null;
        encoderSurface = null;
        try {
            if (imageReader != null) imageReader.close();
        } catch (Exception ignored) {
        }
        imageReader = null;
        synchronized (rtmps) {
            for (RtmpClient client : rtmps) client.close();
            rtmps.clear();
        }
        activeConfig = null;
        activeUrls = new ArrayList<String>();
        startPreviewSession(null);
    }

    void reconnectRtmp() {
        if (!streaming.get() || reconnecting.getAndSet(true)) return;
        new Thread(new Runnable() {
            @Override public void run() {
                List<String> urls = new ArrayList<String>(activeUrls);
                StreamConfig config = activeConfig;
                if (urls.isEmpty() || config == null) {
                    reconnecting.set(false);
                    return;
                }
                List<RtmpClient> fresh = new ArrayList<RtmpClient>();
                try {
                    List<RtmpClient> old = rtmps;
                    rtmps = new ArrayList<RtmpClient>();
                    for (RtmpClient client : old) client.close();
                    try {
                        Thread.sleep(350);
                    } catch (InterruptedException ignored) {
                    }
                    for (String url : urls) {
                        RtmpClient client = new RtmpClient();
                        client.connect(url);
                        client.sendMetadata(config.width, config.height, config.fps, config.videoBitrate, timestamp());
                        if (videoEncoder != null) {
                            client.sendVideoConfig(makeAvcc(videoEncoder.getOutputFormat()), timestamp());
                        }
                        client.sendAudioConfig(new byte[]{0x12, 0x10}, timestamp());
                        fresh.add(client);
                    }
                    rtmps = fresh;
                    requestKeyFrame();
                    listener.onStatus("已重连推流服务器。");
                } catch (Exception e) {
                    for (RtmpClient client : fresh) client.close();
                    listener.onStatus("重连推流服务器失败：" + e.getMessage());
                } finally {
                    reconnecting.set(false);
                }
            }
        }, "rtmp-reconnect").start();
    }

    void startRecording() {
        if (!streaming.get()) {
            listener.onStatus("请先开始直播，再开始录像。");
            return;
        }
        synchronized (recordLock) {
            if (recording) return;
            try {
                String fileName = "CoryKuiLive_" + System.currentTimeMillis() + ".mp4";
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                    values.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4");
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/CoryKui Live");
                    values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                    recordingUri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (recordingUri == null) throw new IOException("无法创建 Download 录像文件");
                    recordingFd = context.getContentResolver().openFileDescriptor(recordingUri, "w");
                    if (recordingFd == null) throw new IOException("无法打开 Download 录像文件");
                    recordingPath = "Download/CoryKui Live/" + fileName;
                    muxer = new MediaMuxer(recordingFd.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                } else {
                    File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "CoryKui Live");
                    if (!dir.exists() && !dir.mkdirs()) {
                        throw new IOException("无法创建 Download 录像目录");
                    }
                    File out = new File(dir, fileName);
                    recordingPath = out.getAbsolutePath();
                    muxer = new MediaMuxer(recordingPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                }
                videoTrack = -1;
                audioTrack = -1;
                muxerStarted = false;
                recording = true;
                addKnownTracksLocked();
                listener.onRecordingChanged(true);
                listener.onStatus("开始录像，等待音视频轨道就绪。");
            } catch (Exception e) {
                recording = false;
                muxer = null;
                listener.onStatus("录像启动失败：" + e.getMessage());
            }
        }
    }

    void stopRecording() {
        String savedPath = null;
        Uri savedUri = null;
        synchronized (recordLock) {
            if (!recording && muxer == null) return;
            try {
                if (muxer != null) {
                    if (muxerStarted) muxer.stop();
                    muxer.release();
                }
                savedPath = recordingPath;
                savedUri = recordingUri;
            } catch (Exception e) {
                listener.onStatus("录像保存异常：" + e.getMessage());
            }
            try {
                if (recordingFd != null) recordingFd.close();
            } catch (Exception ignored) {
            }
            if (recordingUri != null && Build.VERSION.SDK_INT >= 29) {
                try {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    context.getContentResolver().update(recordingUri, values, null, null);
                } catch (Exception e) {
                    listener.onStatus("Download 录像发布失败：" + e.getMessage());
                }
            }
            muxer = null;
            videoTrack = -1;
            audioTrack = -1;
            muxerStarted = false;
            recording = false;
            recordingPath = null;
            recordingUri = null;
            recordingFd = null;
        }
        listener.onRecordingChanged(false);
        if (savedPath != null) {
            if (savedUri == null) {
                MediaScannerConnection.scanFile(context, new String[]{savedPath}, new String[]{"video/mp4"}, null);
            }
            listener.onStatus("录像已保存：" + savedPath);
        }
    }

    private String chooseCamera(int mode) throws CameraAccessException {
        if (mode == CAMERA_FRONT) {
            for (String id : cameraManager.getCameraIdList()) {
                Integer facing = cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_FRONT) return id;
            }
        }
        if (mode == CAMERA_BACK_ULTRAWIDE) {
            String ultra = findBackCamera(true);
            if (ultra != null) return ultra;
            listener.onStatus("未检测到后置超广角镜头，已切回后置主摄。");
        }
        String back = findBackCamera(false);
        if (back != null) return back;
        for (String id : cameraManager.getCameraIdList()) {
            Integer facing = cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING);
            if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) return id;
        }
        return cameraManager.getCameraIdList()[0];
    }

    private String findBackCamera(boolean ultraWide) throws CameraAccessException {
        String bestId = null;
        float bestFocal = ultraWide ? Float.MAX_VALUE : -1.0f;
        for (String id : cameraManager.getCameraIdList()) {
            CameraCharacteristics c = cameraManager.getCameraCharacteristics(id);
            Integer facing = c.get(CameraCharacteristics.LENS_FACING);
            if (facing == null || facing != CameraCharacteristics.LENS_FACING_BACK) continue;
            float focal = representativeFocalLength(c);
            if (ultraWide) {
                if (focal > 0.0f && focal < bestFocal) {
                    bestFocal = focal;
                    bestId = id;
                }
            } else if (focal > bestFocal) {
                bestFocal = focal;
                bestId = id;
            }
        }
        return bestId;
    }

    private float representativeFocalLength(CameraCharacteristics c) {
        float[] focalLengths = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
        if (focalLengths == null || focalLengths.length == 0) return 0.0f;
        float min = focalLengths[0];
        for (float value : focalLengths) {
            if (value > 0.0f && value < min) min = value;
        }
        return min;
    }

    private String cameraModeLabel(int mode) {
        if (mode == CAMERA_FRONT) return "已切换前置摄像头。";
        if (mode == CAMERA_BACK_ULTRAWIDE) return "已切换后置超广角 0.6x 摄像头。";
        return "已切换后置主摄 1x。";
    }

    private void startPreviewSession(final Surface streamSurface) {
        if (camera == null) return;
        try {
            final int generation = cameraGeneration;
            final CameraDevice activeCamera = camera;
            Surface previewSurface = null;
            if (previewSurfaceEnabled && preview.isAvailable()) {
                SurfaceTexture texture = preview.getSurfaceTexture();
                if (texture != null) {
                    int rotation = ((android.view.WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRotation();
                    if (rotation == Surface.ROTATION_90 || rotation == Surface.ROTATION_270) {
                        texture.setDefaultBufferSize(1280, 720);
                    } else {
                        texture.setDefaultBufferSize(720, 1280);
                    }
                    updatePreviewTransform();
                    previewSurface = new Surface(texture);
                }
            }
            final List<Surface> surfaces = new ArrayList<Surface>();
            if (previewSurface != null) surfaces.add(previewSurface);
            if (streamSurface != null) surfaces.add(streamSurface);
            if (surfaces.size() == 0) return;
            final Surface activePreviewSurface = previewSurface;
            activeCamera.createCaptureSession(surfaces, new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession cameraCaptureSession) {
                    if (generation != cameraGeneration || camera != activeCamera) {
                        cameraCaptureSession.close();
                        return;
                    }
                    session = cameraCaptureSession;
                    try {
                        previewRequest = activeCamera.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);
                        if (activePreviewSurface != null) previewRequest.addTarget(activePreviewSurface);
                        if (streamSurface != null) previewRequest.addTarget(streamSurface);
                        previewRequest.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
                        previewRequest.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO);
                        previewRequest.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, new Range<Integer>(24, 30));
                        applyRepeatingRequest();
                    } catch (Exception e) {
                        if (generation == cameraGeneration) {
                            listener.onStatus("预览启动失败：" + e.getMessage());
                        }
                    }
                }
                @Override public void onConfigureFailed(CameraCaptureSession cameraCaptureSession) {
                    if (generation == cameraGeneration) {
                        listener.onStatus("摄像头会话创建失败。");
                    }
                }
            }, cameraHandler);
        } catch (Exception e) {
            if (camera != null) {
                listener.onStatus("预览异常：" + e.getMessage());
            }
        }
    }

    private void applyRepeatingRequest() {
        if (session == null || previewRequest == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                previewRequest.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom);
            } else if (sensorRect != null && zoom > 1.0f) {
                int cropW = (int) (sensorRect.width() / zoom);
                int cropH = (int) (sensorRect.height() / zoom);
                int left = sensorRect.left + (sensorRect.width() - cropW) / 2;
                int top = sensorRect.top + (sensorRect.height() - cropH) / 2;
                previewRequest.set(CaptureRequest.SCALER_CROP_REGION, new Rect(left, top, left + cropW, top + cropH));
            }
            session.setRepeatingRequest(previewRequest.build(), null, cameraHandler);
        } catch (Exception e) {
            listener.onStatus("变焦设置失败：" + e.getMessage());
        }
    }

    private void restoreContinuousFocus() {
        if (session == null || previewRequest == null) return;
        try {
            previewRequest.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO);
            previewRequest.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_CANCEL);
            previewRequest.set(CaptureRequest.CONTROL_AF_REGIONS, null);
            previewRequest.set(CaptureRequest.CONTROL_AE_REGIONS, null);
            session.capture(previewRequest.build(), null, cameraHandler);
            previewRequest.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_IDLE);
            session.setRepeatingRequest(previewRequest.build(), null, cameraHandler);
        } catch (Exception ignored) {
        }
    }

    private Rect currentCropRegion() {
        if (sensorRect == null || zoom <= 1.0f) return sensorRect;
        int cropW = (int) (sensorRect.width() / zoom);
        int cropH = (int) (sensorRect.height() / zoom);
        int left = sensorRect.left + (sensorRect.width() - cropW) / 2;
        int top = sensorRect.top + (sensorRect.height() - cropH) / 2;
        return new Rect(left, top, left + cropW, top + cropH);
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private void prepareVideoEncoder(StreamConfig config) throws IOException {
        MediaFormat format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, config.width, config.height);
        boolean portraitStream = config.height > config.width;
        videoEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        int colorFormat = portraitStream
                ? selectYuvColorFormat(videoEncoder.getCodecInfo().getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC))
                : MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface;
        videoInputColorFormat = colorFormat;
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT, colorFormat);
        format.setInteger(MediaFormat.KEY_BIT_RATE, config.videoBitrate);
        format.setInteger(MediaFormat.KEY_FRAME_RATE, config.fps);
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
        videoEncoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        if (portraitStream) {
            encoderSurface = null;
            imageReader = ImageReader.newInstance(config.height, config.width, ImageFormat.YUV_420_888, 3);
        } else {
            encoderSurface = videoEncoder.createInputSurface();
            imageReader = null;
        }
        videoEncoder.start();
    }

    private Surface streamInputSurface() {
        if (encoderSurface != null) return encoderSurface;
        return imageReader == null ? null : imageReader.getSurface();
    }

    private int selectYuvColorFormat(MediaCodecInfo.CodecCapabilities caps) {
        int fallback = MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible;
        for (int color : caps.colorFormats) {
            if (color == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar) return color;
            if (color == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar) fallback = color;
            if (color == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible) fallback = color;
        }
        return fallback;
    }

    private void prepareAudioEncoder(StreamConfig config) throws IOException {
        MediaFormat format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, 44100, 2);
        format.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        format.setInteger(MediaFormat.KEY_BIT_RATE, config.audioBitrate);
        audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
        audioEncoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        audioEncoder.start();
        int min = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT);
        audioRecord = new AudioRecord(MediaRecorder.AudioSource.CAMCORDER, 44100, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min * 2, 8192));
    }

    private void startVideoLoop(final int runGeneration) {
        videoThread = new Thread(new Runnable() {
            @Override public void run() {
                MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                boolean sentConfig = false;
                long nextFrameNs = System.nanoTime();
                int frameIndex = 0;
                while (streaming.get() && isCurrentStream(runGeneration)) {
                    try {
                        StreamConfig frameConfig = activeConfig;
                        if (encoderSurface == null && imageReader != null && frameConfig != null && System.nanoTime() >= nextFrameNs) {
                            if (forcePreviewFrames) {
                                queuePreviewFrame(frameConfig, frameIndex);
                            } else {
                                queueCameraImageFrame(frameConfig, frameIndex);
                            }
                            frameIndex++;
                            nextFrameNs += 1000000000L / Math.max(1, frameConfig.fps);
                        }
                        int outIndex = videoEncoder.dequeueOutputBuffer(info, 1000);
                        if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                            videoMuxFormat = videoEncoder.getOutputFormat();
                            onVideoFormat(videoMuxFormat);
                            byte[] avcc = makeAvcc(videoMuxFormat);
                            StreamConfig metadataConfig = activeConfig;
                            if (metadataConfig != null) {
                                sendMetadata(metadataConfig.width, metadataConfig.height,
                                        metadataConfig.fps, metadataConfig.videoBitrate, timestamp());
                            }
                            sendVideoConfig(avcc, timestamp());
                            sentConfig = true;
                        } else if (outIndex >= 0) {
                            ByteBuffer data = videoEncoder.getOutputBuffer(outIndex);
                            if (data != null && info.size > 0 && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                                data.position(info.offset);
                                data.limit(info.offset + info.size);
                                boolean key = (info.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0;
                                if (key) {
                                    StreamConfig metadataConfig = activeConfig;
                                    if (metadataConfig != null) {
                                        sendMetadata(metadataConfig.width, metadataConfig.height,
                                                metadataConfig.fps, metadataConfig.videoBitrate, timestamp());
                                    }
                                    sendVideoConfig(makeAvcc(videoEncoder.getOutputFormat()), timestamp());
                                    sentConfig = true;
                                }
                                byte[] sample = new byte[info.size];
                                data.get(sample);
                                writeVideoSample(sample, info);
                                sendVideoFrame(annexBToAvccSample(sample), key, timestamp());
                            }
                            videoEncoder.releaseOutputBuffer(outIndex, false);
                        }
                    } catch (Exception e) {
                        if (isCurrentStream(runGeneration)) {
                            listener.onStatus("视频推送异常：" + e.getMessage());
                            stopStreamingIfCurrent(runGeneration);
                        }
                    }
                }
            }
        }, "video-loop");
        videoThread.start();
    }

    private void queuePreviewFrame(StreamConfig config, int frameIndex) throws IOException {
        int input = videoEncoder.dequeueInputBuffer(1000);
        if (input < 0) {
            if (frameIndex % Math.max(1, config.fps * 2) == 0) {
                Log.i(TAG, "preview frame skipped: no encoder input buffer");
            }
            return;
        }
        Bitmap bitmap = capturePreviewBitmap(config.width, config.height);
        byte[] yuv;
        if (bitmap != null) {
            if (trialWatermark) drawTrialWatermark(bitmap);
            if ((frameIndex & 1) == 0) {
                try {
                    listener.onMirrorFrame(bitmap.copy(Bitmap.Config.ARGB_8888, false));
                } catch (Exception ignored) {
                }
            }
            yuv = bitmapToNV12(bitmap, config.width, config.height);
            bitmap.recycle();
            lastVideoYuv = yuv;
        } else if (lastVideoYuv != null) {
            yuv = lastVideoYuv;
            if (frameIndex % Math.max(1, config.fps * 2) == 0) {
                Log.i(TAG, "preview bitmap unavailable, queued cached frame");
            }
        } else {
            yuv = blackYuv(config.width, config.height);
            if (frameIndex % Math.max(1, config.fps * 2) == 0) {
                Log.i(TAG, "preview bitmap unavailable, queued black frame");
            }
        }
        ByteBuffer in = videoEncoder.getInputBuffer(input);
        in.clear();
        in.put(yuv, 0, Math.min(yuv.length, in.remaining()));
        long ptsUs = frameIndex * 1000000L / Math.max(1, config.fps);
        videoEncoder.queueInputBuffer(input, 0, Math.min(yuv.length, in.position()), ptsUs, 0);
        if (frameIndex % Math.max(1, config.fps * 2) == 0) {
            Log.i(TAG, "queued preview frame index=" + frameIndex + " bytes=" + yuv.length);
        }
    }

    private byte[] blackYuv(int width, int height) {
        byte[] yuv = new byte[width * height * 3 / 2];
        Arrays.fill(yuv, 0, width * height, (byte) 16);
        Arrays.fill(yuv, width * height, yuv.length, (byte) 128);
        return yuv;
    }

    private Bitmap capturePreviewBitmap(final int width, final int height) {
        if (!preview.isAvailable()) return null;
        if (Looper.myLooper() == Looper.getMainLooper()) {
            return preview.getBitmap(width, height);
        }
        final Bitmap[] result = new Bitmap[1];
        final CountDownLatch latch = new CountDownLatch(1);
        preview.post(new Runnable() {
            @Override public void run() {
                try {
                    if (preview.isAvailable()) {
                        result[0] = preview.getBitmap(width, height);
                    }
                } finally {
                    latch.countDown();
                }
            }
        });
        try {
            latch.await(80, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return result[0];
    }

    private void queueCameraImageFrame(StreamConfig config, int frameIndex) throws IOException {
        Image image = null;
        try {
            image = imageReader.acquireLatestImage();
            if (image == null) {
                restartStreamSessionIfStale();
                return;
            }
            int input = videoEncoder.dequeueInputBuffer(1000);
            if (input < 0) return;
            byte[] yuv = imageToPortraitYuv(image, config.width, config.height);
            if (trialWatermark) {
                Bitmap bitmap = yuvToBitmap(yuv, config.width, config.height);
                drawTrialWatermark(bitmap);
                yuv = bitmapToNV12(bitmap, config.width, config.height);
                bitmap.recycle();
            }
            lastCameraFrameMs = SystemClock.elapsedRealtime();
            lastVideoYuv = yuv;
            if ((frameIndex % Math.max(1, config.fps / 4)) == 0) {
                try {
                    listener.onMirrorFrame(yuvToBitmap(yuv, config.width, config.height));
                } catch (Exception ignored) {
                }
            }
            ByteBuffer in = videoEncoder.getInputBuffer(input);
            in.clear();
            in.put(yuv, 0, Math.min(yuv.length, in.remaining()));
            long ptsUs = frameIndex * 1000000L / Math.max(1, config.fps);
            videoEncoder.queueInputBuffer(input, 0, Math.min(yuv.length, in.position()), ptsUs, 0);
        } finally {
            if (image != null) image.close();
        }
    }

    private void queueCachedFrame(StreamConfig config, int frameIndex) throws IOException {
        byte[] yuv = lastVideoYuv;
        if (yuv == null) return;
        int input = videoEncoder.dequeueInputBuffer(1000);
        if (input < 0) return;
        ByteBuffer in = videoEncoder.getInputBuffer(input);
        in.clear();
        in.put(yuv, 0, Math.min(yuv.length, in.remaining()));
        long ptsUs = frameIndex * 1000000L / Math.max(1, config.fps);
        videoEncoder.queueInputBuffer(input, 0, Math.min(yuv.length, in.position()), ptsUs, 0);
    }

    private void restartStreamSessionIfStale() {
        long now = SystemClock.elapsedRealtime();
        if (now - lastCameraFrameMs < 900) return;
        if (now - lastStreamSessionRestartMs < 1600) return;
        lastStreamSessionRestartMs = now;
        Log.i(TAG, "camera image stream stale, restarting capture session");
        startPreviewSession(streamInputSurface());
    }

    private byte[] imageToPortraitYuv(Image image, int outW, int outH) {
        int srcW = image.getWidth();
        int srcH = image.getHeight();
        Image.Plane[] planes = image.getPlanes();
        byte[] yuv = new byte[outW * outH * 3 / 2];
        int yIndex = 0;
        for (int y = 0; y < outH; y++) {
            for (int x = 0; x < outW; x++) {
                int srcX = clamp(y * srcW / outH, 0, srcW - 1);
                int srcY = clamp(srcH - 1 - (x * srcH / outW), 0, srcH - 1);
                yuv[yIndex++] = samplePlane(planes[0], srcX, srcY);
            }
        }
        if (videoInputColorFormat == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar) {
            int uIndex = outW * outH;
            int vIndex = uIndex + (outW * outH / 4);
            for (int y = 0; y < outH; y += 2) {
                for (int x = 0; x < outW; x += 2) {
                    int srcX = clamp(y * srcW / outH, 0, srcW - 1);
                    int srcY = clamp(srcH - 1 - (x * srcH / outW), 0, srcH - 1);
                    if (uIndex < vIndex && vIndex < yuv.length) {
                        yuv[uIndex++] = samplePlane(planes[1], srcX / 2, srcY / 2);
                        yuv[vIndex++] = samplePlane(planes[2], srcX / 2, srcY / 2);
                    }
                }
            }
        } else {
            int uvIndex = outW * outH;
            for (int y = 0; y < outH; y += 2) {
                for (int x = 0; x < outW; x += 2) {
                    int srcX = clamp(y * srcW / outH, 0, srcW - 1);
                    int srcY = clamp(srcH - 1 - (x * srcH / outW), 0, srcH - 1);
                    if (uvIndex + 1 < yuv.length) {
                        yuv[uvIndex++] = samplePlane(planes[1], srcX / 2, srcY / 2);
                        yuv[uvIndex++] = samplePlane(planes[2], srcX / 2, srcY / 2);
                    }
                }
            }
        }
        return yuv;
    }

    private Bitmap yuvToBitmap(byte[] yuv, int width, int height) {
        int[] argb = new int[width * height];
        int frameSize = width * height;
        boolean planar = videoInputColorFormat == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar;
        for (int y = 0; y < height; y++) {
            int yRow = y * width;
            int uvRow = (y >> 1) * (width >> 1);
            for (int x = 0; x < width; x++) {
                int yValue = (yuv[yRow + x] & 0xff) - 16;
                int uValue;
                int vValue;
                if (planar) {
                    int uvIndex = uvRow + (x >> 1);
                    uValue = (yuv[frameSize + uvIndex] & 0xff) - 128;
                    vValue = (yuv[frameSize + frameSize / 4 + uvIndex] & 0xff) - 128;
                } else {
                    int uvIndex = frameSize + (y >> 1) * width + (x & ~1);
                    uValue = (yuv[uvIndex] & 0xff) - 128;
                    vValue = (yuv[uvIndex + 1] & 0xff) - 128;
                }
                if (yValue < 0) yValue = 0;
                int r = (298 * yValue + 409 * vValue + 128) >> 8;
                int g = (298 * yValue - 100 * uValue - 208 * vValue + 128) >> 8;
                int b = (298 * yValue + 516 * uValue + 128) >> 8;
                argb[yRow + x] = 0xff000000
                        | (clamp(r, 0, 255) << 16)
                        | (clamp(g, 0, 255) << 8)
                        | clamp(b, 0, 255);
            }
        }
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        bitmap.setPixels(argb, 0, width, 0, 0, width, height);
        return bitmap;
    }

    private void drawTrialWatermark(Bitmap bitmap) {
        if (bitmap == null || bitmap.isRecycled()) return;
        Canvas canvas = new Canvas(bitmap);
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(Math.max(24.0f, width / 32.0f));
        textPaint.setShadowLayer(5.0f, 1.0f, 2.0f, Color.BLACK);
        textPaint.setTextAlign(Paint.Align.RIGHT);
        String text = "未激活版本，请联系mail@pt20.cn购买";
        canvas.drawText(text, width - Math.max(18, width / 40), Math.max(38, height / 24), textPaint);

        if (trialIcon == null || trialIcon.isRecycled()) {
            trialIcon = BitmapFactory.decodeResource(context.getResources(), R.mipmap.ic_launcher);
        }
        int iconSize = Math.max(54, Math.min(width, height) / 9);
        int margin = Math.max(16, width / 42);
        Rect iconRect = new Rect(width - margin - iconSize, height - margin - iconSize,
                width - margin, height - margin);
        if (trialIcon != null) {
            Paint iconPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            canvas.drawBitmap(trialIcon, null, iconRect, iconPaint);
        }
        Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        labelPaint.setColor(Color.WHITE);
        labelPaint.setTextSize(Math.max(20.0f, width / 42.0f));
        labelPaint.setShadowLayer(5.0f, 1.0f, 2.0f, Color.BLACK);
        labelPaint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText("小魁直播", width - margin, iconRect.top - 8, labelPaint);
    }

    private byte samplePlane(Image.Plane plane, int x, int y) {
        ByteBuffer buffer = plane.getBuffer();
        int offset = y * plane.getRowStride() + x * plane.getPixelStride();
        if (offset < 0 || offset >= buffer.limit()) return 0;
        return buffer.get(offset);
    }

    private byte[] bitmapToNV12(Bitmap bitmap, int width, int height) {
        int[] argb = new int[width * height];
        bitmap.getPixels(argb, 0, width, 0, 0, width, height);
        byte[] yuv = new byte[width * height * 3 / 2];
        int yIndex = 0;
        int uvIndex = width * height;
        for (int j = 0; j < height; j++) {
            for (int i = 0; i < width; i++) {
                int c = argb[j * width + i];
                int r = (c >> 16) & 0xff;
                int g = (c >> 8) & 0xff;
                int b = c & 0xff;
                int y = ((66 * r + 129 * g + 25 * b + 128) >> 8) + 16;
                int u = ((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128;
                int v = ((112 * r - 94 * g - 18 * b + 128) >> 8) + 128;
                yuv[yIndex++] = (byte) clamp(y, 0, 255);
                if ((j & 1) == 0 && (i & 1) == 0 && uvIndex + 1 < yuv.length) {
                    yuv[uvIndex++] = (byte) clamp(u, 0, 255);
                    yuv[uvIndex++] = (byte) clamp(v, 0, 255);
                }
            }
        }
        return yuv;
    }

    private void startAudioLoop(final StreamConfig config, final int runGeneration) {
        audioThread = new Thread(new Runnable() {
            @Override public void run() {
                MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                byte[] pcm = new byte[4096];
                boolean sentConfig = false;
                long audioPtsUs = 0L;
                try {
                    audioRecord.startRecording();
                    Log.i(TAG, "camera audio loop started");
                    while (streaming.get() && isCurrentStream(runGeneration)) {
                        int input = audioEncoder.dequeueInputBuffer(10000);
                        if (input >= 0) {
                            ByteBuffer inBuf = audioEncoder.getInputBuffer(input);
                            inBuf.clear();
                            int read = audioRecord.read(pcm, 0, Math.min(pcm.length, inBuf.remaining()));
                            if (read > 0) {
                                if (muted || !microphoneEnabled) {
                                    Arrays.fill(pcm, 0, read, (byte) 0);
                                } else {
                                    applyPcmVolume(pcm, read, microphoneVolume);
                                }
                                try {
                                    backgroundMusicMixer.mixInto(pcm, read);
                                } catch (Exception e) {
                                    Log.e(TAG, "camera background music mix failed", e);
                                }
                                inBuf.put(pcm, 0, read);
                                audioEncoder.queueInputBuffer(input, 0, read, audioPtsUs, 0);
                                audioPtsUs += (read / 4) * 1000000L / 44100L;
                            }
                        }
                        int outIndex;
                        while ((outIndex = audioEncoder.dequeueOutputBuffer(info, 0)) >= 0) {
                            ByteBuffer out = audioEncoder.getOutputBuffer(outIndex);
                            if (out != null && info.size > 0 && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                                if (!sentConfig) {
                                    sendAudioConfig(new byte[]{0x12, 0x10}, timestamp());
                                    sentConfig = true;
                                }
                                out.position(info.offset);
                                out.limit(info.offset + info.size);
                                byte[] sample = new byte[info.size];
                                out.get(sample);
                                writeAudioSample(sample, info);
                                sendAudioFrame(sample, (int) (Math.max(0L, info.presentationTimeUs) / 1000L));
                            }
                            audioEncoder.releaseOutputBuffer(outIndex, false);
                        }
                        if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                            audioMuxFormat = audioEncoder.getOutputFormat();
                            onAudioFormat(audioMuxFormat);
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "camera audio loop failed", e);
                    if (isCurrentStream(runGeneration)) {
                        listener.onStatus("音频推送异常：" + e.getMessage());
                        stopStreamingIfCurrent(runGeneration);
                    }
                }
            }
        }, "audio-loop");
        audioThread.start();
    }

    private int timestamp() {
        return (int) ((System.nanoTime() / 1000L - startUs) / 1000L);
    }

    private void applyPcmVolume(byte[] pcm, int length, float volume) {
        float safeVolume = Math.max(0.0f, Math.min(2.0f, volume));
        if (Math.abs(safeVolume - 1.0f) < 0.001f) return;
        int limit = Math.min(length, pcm.length - 1);
        for (int i = 0; i + 1 < limit; i += 2) {
            int sample = (short) ((pcm[i] & 0xff) | (pcm[i + 1] << 8));
            int scaled = Math.round(sample * safeVolume);
            if (scaled > Short.MAX_VALUE) scaled = Short.MAX_VALUE;
            if (scaled < Short.MIN_VALUE) scaled = Short.MIN_VALUE;
            pcm[i] = (byte) scaled;
            pcm[i + 1] = (byte) (scaled >> 8);
        }
    }

    private void updatePreviewTransform() {
        int viewW = preview.getWidth();
        int viewH = preview.getHeight();
        if (viewW <= 0 || viewH <= 0) return;
        int rotation = ((android.view.WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRotation();
        Matrix matrix = new Matrix();
        float bufferW = (rotation == Surface.ROTATION_90 || rotation == Surface.ROTATION_270) ? 1280.0f : 720.0f;
        float bufferH = (rotation == Surface.ROTATION_90 || rotation == Surface.ROTATION_270) ? 720.0f : 1280.0f;
        if (rotation == Surface.ROTATION_90 || rotation == Surface.ROTATION_270) {
            float centerX = viewW * 0.5f;
            float centerY = viewH * 0.5f;
            RectF viewRect = new RectF(0, 0, viewW, viewH);
            RectF bufferRect = new RectF(0, 0, bufferH, bufferW);
            bufferRect.offset(centerX - bufferRect.centerX(), centerY - bufferRect.centerY());
            matrix.setRectToRect(viewRect, bufferRect, Matrix.ScaleToFit.FILL);
            float scale = Math.max(viewH / bufferH, viewW / bufferW);
            matrix.postScale(scale, scale, centerX, centerY);
            float degrees = rotation == Surface.ROTATION_90 ? -90.0f : 90.0f;
            matrix.postRotate(degrees, centerX, centerY);
        } else {
            float scale = Math.min(viewW / bufferW, viewH / bufferH);
            float dx = (viewW - bufferW * scale) * 0.5f;
            float dy = (viewH - bufferH * scale) * 0.5f;
            matrix.setScale(scale, scale);
            matrix.postTranslate(dx, dy);
        }
        preview.setTransform(matrix);
    }

    private void onVideoFormat(MediaFormat format) {
        synchronized (recordLock) {
            videoMuxFormat = format;
            if (recording) addKnownTracksLocked();
        }
    }

    private void onAudioFormat(MediaFormat format) {
        synchronized (recordLock) {
            audioMuxFormat = format;
            if (recording) addKnownTracksLocked();
        }
    }

    private void addKnownTracksLocked() {
        if (muxer == null) return;
        if (videoTrack < 0 && videoMuxFormat != null) {
            videoTrack = muxer.addTrack(videoMuxFormat);
        }
        if (audioTrack < 0 && audioMuxFormat != null) {
            audioTrack = muxer.addTrack(audioMuxFormat);
        }
        if (!muxerStarted && videoTrack >= 0 && audioTrack >= 0) {
            muxer.start();
            muxerStarted = true;
            listener.onStatus("录像写入已开始。");
        }
    }

    private void writeVideoSample(byte[] sample, MediaCodec.BufferInfo sourceInfo) {
        writeSample(videoTrack, sample, sourceInfo);
    }

    private void writeAudioSample(byte[] sample, MediaCodec.BufferInfo sourceInfo) {
        writeSample(audioTrack, sample, sourceInfo);
    }

    private void writeSample(int track, byte[] sample, MediaCodec.BufferInfo sourceInfo) {
        synchronized (recordLock) {
            if (!recording || !muxerStarted || muxer == null || track < 0) return;
            try {
                MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                info.set(0, sample.length, sourceInfo.presentationTimeUs, sourceInfo.flags);
                muxer.writeSampleData(track, ByteBuffer.wrap(sample), info);
            } catch (Exception e) {
                listener.onStatus("录像写入失败：" + e.getMessage());
                stopRecording();
            }
        }
    }

    private void sendVideoConfig(byte[] avcc, int timestamp) throws IOException {
        synchronized (rtmps) {
            for (Iterator<RtmpClient> it = rtmps.iterator(); it.hasNext();) {
                RtmpClient client = it.next();
                try {
                    client.sendVideoConfig(avcc, timestamp);
                } catch (IOException e) {
                    client.close();
                    it.remove();
                    listener.onStatus("一个推流地址断开：" + e.getMessage());
                }
            }
            if (rtmps.size() == 0 && !reconnecting.get()) throw new IOException("所有推流地址都已断开");
        }
        if (!videoConfigLogged) {
            videoConfigLogged = true;
            listener.onStatus("已发送 H.264 视频头。");
        }
    }

    private void sendMetadata(int width, int height, int frameRate, int bitrate, int timestamp) throws IOException {
        synchronized (rtmps) {
            for (Iterator<RtmpClient> it = rtmps.iterator(); it.hasNext();) {
                RtmpClient client = it.next();
                try {
                    client.sendMetadata(width, height, frameRate, bitrate, timestamp);
                } catch (IOException e) {
                    client.close();
                    it.remove();
                    listener.onStatus("一个推流地址断开：" + e.getMessage());
                }
            }
            if (rtmps.size() == 0 && !reconnecting.get()) throw new IOException("所有推流地址都已断开");
        }
        listener.onStatus("已发送直播元数据：" + width + "x" + height);
    }

    private void sendVideoFrame(byte[] sample, boolean keyFrame, int timestamp) throws IOException {
        videoFramesSent++;
        if (videoFramesSent == 1 || videoFramesSent % 60 == 0) {
            Log.i(TAG, "rtmp video frames sent=" + videoFramesSent + " key=" + keyFrame
                    + " bytes=" + sample.length + " timestamp=" + timestamp + " clients=" + rtmps.size());
        }
        synchronized (rtmps) {
            for (Iterator<RtmpClient> it = rtmps.iterator(); it.hasNext();) {
                RtmpClient client = it.next();
                try {
                    client.sendVideoFrame(sample, keyFrame, timestamp);
                } catch (IOException e) {
                    client.close();
                    it.remove();
                    listener.onStatus("一个推流地址断开：" + e.getMessage());
                }
            }
            if (rtmps.size() == 0 && !reconnecting.get()) throw new IOException("所有推流地址都已断开");
        }
        if (!firstVideoFrameLogged) {
            firstVideoFrameLogged = true;
            listener.onStatus("已发送首个视频帧。");
        }
    }

    private void sendAudioConfig(byte[] config, int timestamp) throws IOException {
        synchronized (rtmps) {
            for (Iterator<RtmpClient> it = rtmps.iterator(); it.hasNext();) {
                RtmpClient client = it.next();
                try {
                    client.sendAudioConfig(config, timestamp);
                } catch (IOException e) {
                    client.close();
                    it.remove();
                    listener.onStatus("一个推流地址断开：" + e.getMessage());
                }
            }
            if (rtmps.size() == 0 && !reconnecting.get()) throw new IOException("所有推流地址都已断开");
        }
    }

    private void sendAudioFrame(byte[] sample, int timestamp) throws IOException {
        audioFramesSent++;
        if (audioFramesSent == 1 || audioFramesSent % 120 == 0) {
            Log.i(TAG, "rtmp audio frames sent=" + audioFramesSent
                    + " bytes=" + sample.length + " timestamp=" + timestamp + " clients=" + rtmps.size());
        }
        synchronized (rtmps) {
            for (Iterator<RtmpClient> it = rtmps.iterator(); it.hasNext();) {
                RtmpClient client = it.next();
                try {
                    client.sendAudioFrame(sample, timestamp);
                } catch (IOException e) {
                    client.close();
                    it.remove();
                    listener.onStatus("一个推流地址断开：" + e.getMessage());
                }
            }
            if (rtmps.size() == 0 && !reconnecting.get()) throw new IOException("所有推流地址都已断开");
        }
    }

    private byte[] makeAvcc(MediaFormat format) {
        ByteBuffer sps = format.getByteBuffer("csd-0");
        ByteBuffer pps = format.getByteBuffer("csd-1");
        byte[] spsBytes = stripStartCode(sps);
        byte[] ppsBytes = stripStartCode(pps);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(1);
        out.write(spsBytes.length > 3 ? spsBytes[1] & 0xff : 0x64);
        out.write(spsBytes.length > 4 ? spsBytes[2] & 0xff : 0);
        out.write(spsBytes.length > 5 ? spsBytes[3] & 0xff : 0x1f);
        out.write(0xff);
        out.write(0xe1);
        out.write((spsBytes.length >> 8) & 0xff);
        out.write(spsBytes.length & 0xff);
        out.write(spsBytes, 0, spsBytes.length);
        out.write(1);
        out.write((ppsBytes.length >> 8) & 0xff);
        out.write(ppsBytes.length & 0xff);
        out.write(ppsBytes, 0, ppsBytes.length);
        return out.toByteArray();
    }

    private byte[] stripStartCode(ByteBuffer buffer) {
        if (buffer == null) return new byte[0];
        ByteBuffer copy = buffer.duplicate();
        byte[] data = new byte[copy.remaining()];
        copy.get(data);
        if (data.length > 4 && data[0] == 0 && data[1] == 0 && data[2] == 0 && data[3] == 1) {
            return Arrays.copyOfRange(data, 4, data.length);
        }
        if (data.length > 3 && data[0] == 0 && data[1] == 0 && data[2] == 1) {
            return Arrays.copyOfRange(data, 3, data.length);
        }
        return data;
    }

    private byte[] annexBToAvccSample(byte[] sample) {
        if (!startsWithStartCode(sample, 0)) return sample;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int pos = nextNalStart(sample, 0);
        while (pos >= 0) {
            int nalStart = pos + startCodeLength(sample, pos);
            int next = nextNalStart(sample, nalStart);
            int nalEnd = next >= 0 ? next : sample.length;
            int len = nalEnd - nalStart;
            if (len > 0) {
                int nalType = sample[nalStart] & 0x1f;
                if (nalType != 7 && nalType != 8 && nalType != 9) {
                    out.write((len >> 24) & 0xff);
                    out.write((len >> 16) & 0xff);
                    out.write((len >> 8) & 0xff);
                    out.write(len & 0xff);
                    out.write(sample, nalStart, len);
                }
            }
            pos = next;
        }
        byte[] data = out.toByteArray();
        return data.length == 0 ? sample : data;
    }

    private boolean startsWithStartCode(byte[] data, int offset) {
        return offset + 3 < data.length
                && data[offset] == 0
                && data[offset + 1] == 0
                && ((data[offset + 2] == 1) || (offset + 4 < data.length && data[offset + 2] == 0 && data[offset + 3] == 1));
    }

    private int startCodeLength(byte[] data, int offset) {
        return offset + 3 < data.length && data[offset] == 0 && data[offset + 1] == 0 && data[offset + 2] == 1 ? 3 : 4;
    }

    private int nextNalStart(byte[] data, int from) {
        for (int i = Math.max(0, from); i + 3 < data.length; i++) {
            if (data[i] == 0 && data[i + 1] == 0 && (data[i + 2] == 1 || (i + 4 < data.length && data[i + 2] == 0 && data[i + 3] == 1))) {
                return i;
            }
        }
        return -1;
    }
}
