package cn.ohpt.livestream;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;
import android.util.Log;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

final class BackgroundMusicMixer {
    private static final String TAG = "CoryKuiLive";
    private static final int PLAY_MODE_LIST_LOOP = 0;
    private static final int PLAY_MODE_RANDOM = 1;
    private static final int PLAY_MODE_SINGLE_LOOP = 2;
    private static final int OUT_RATE = 44100;
    private static final int OUT_CHANNELS = 2;

    private final Context context;
    private final Random random = new Random();
    private final ArrayList<Uri> playlist = new ArrayList<Uri>();
    private MediaExtractor extractor;
    private MediaCodec decoder;
    private int playMode;
    private int index;
    private int sampleRate = OUT_RATE;
    private int channels = OUT_CHANNELS;
    private int pcmEncoding = AudioFormat.ENCODING_PCM_16BIT;
    private boolean inputDone;
    private double resampleCarry;
    private short[] queued = new short[OUT_RATE * OUT_CHANNELS * 2];
    private int queuedSamples;
    private long mixCalls;
    private long decodedSamples;
    private boolean monitorPlayback;
    private AudioTrack monitorTrack;
    private long initialSeekUs;
    private long currentPositionUs;
    private long currentDurationUs;
    private boolean paused;
    private float volume = 1.0f;

    BackgroundMusicMixer(Context context) {
        this.context = context.getApplicationContext();
    }

    synchronized void setPlaylist(List<Uri> uris, int mode) {
        playlist.clear();
        if (uris != null) playlist.addAll(uris);
        playMode = mode;
        if (index >= playlist.size()) index = 0;
        releaseDecoder();
        queuedSamples = 0;
        currentPositionUs = 0L;
        currentDurationUs = 0L;
    }

    synchronized void setPlaylistStartingAt(List<Uri> uris, int mode, Uri startUri, long startPositionUs) {
        playlist.clear();
        if (uris != null) playlist.addAll(uris);
        playMode = mode;
        int startIndex = indexOf(playlist, startUri);
        index = startIndex >= 0 ? startIndex : 0;
        initialSeekUs = Math.max(0L, startPositionUs);
        currentPositionUs = initialSeekUs;
        currentDurationUs = 0L;
        releaseDecoder();
        queuedSamples = 0;
    }

    synchronized void setPlaylistPreservingPlayback(List<Uri> uris, int mode) {
        Uri current = currentUri();
        ArrayList<Uri> next = new ArrayList<Uri>();
        if (uris != null) next.addAll(uris);
        playMode = mode;
        if (next.size() == 0) {
            playlist.clear();
            index = 0;
            releaseDecoder();
            queuedSamples = 0;
            currentPositionUs = 0L;
            currentDurationUs = 0L;
            return;
        }
        int nextIndex = current == null ? -1 : indexOf(next, current);
        playlist.clear();
        playlist.addAll(next);
        if (nextIndex >= 0) {
            index = nextIndex;
            Log.i(TAG, "background mixer playlist updated without restarting current track");
            return;
        }
        if (index >= playlist.size()) index = 0;
        releaseDecoder();
        queuedSamples = 0;
        currentPositionUs = 0L;
        currentDurationUs = 0L;
    }

    synchronized void setPlayMode(int mode) {
        playMode = mode;
    }

    synchronized void setStartOffsetUs(long offsetUs) {
        initialSeekUs = Math.max(0L, offsetUs);
        currentPositionUs = initialSeekUs;
    }

    synchronized void setPaused(boolean paused) {
        this.paused = paused;
    }

    synchronized void setVolume(float volume) {
        this.volume = Math.max(0.0f, Math.min(2.0f, volume));
    }

    synchronized boolean isPaused() {
        return paused;
    }

    synchronized Uri getCurrentUri() {
        return currentUri();
    }

    synchronized long getCurrentPositionUs() {
        return currentPositionUs;
    }

    synchronized long getCurrentDurationUs() {
        return currentDurationUs;
    }

    synchronized void seekToCurrent(long positionUs) {
        if (playlist.size() == 0) return;
        initialSeekUs = Math.max(0L, positionUs);
        currentPositionUs = initialSeekUs;
        queuedSamples = 0;
        releaseDecoder();
    }

    synchronized void setMonitorPlayback(boolean enabled) {
        monitorPlayback = enabled;
        if (!enabled) releaseMonitorTrack();
    }

    synchronized void mixInto(byte[] pcm, int length) {
        try {
            if (playlist.size() == 0 || pcm == null || length <= 1) return;
            if (paused) return;
            mixCalls++;
            int neededSamples = length / 2;
            while (queuedSamples < neededSamples) {
                if (!decodeMore()) break;
            }
            int samples = Math.min(neededSamples, queuedSamples);
            int peak = 0;
            for (int i = 0; i < samples; i++) {
                int offset = i * 2;
                short live = (short) ((pcm[offset] & 0xff) | (pcm[offset + 1] << 8));
                int bgm = (int) (queued[i] * volume);
                int abs = Math.abs(bgm);
                if (abs > peak) peak = abs;
                int mixed = live + bgm;
                if (mixed > Short.MAX_VALUE) mixed = Short.MAX_VALUE;
                if (mixed < Short.MIN_VALUE) mixed = Short.MIN_VALUE;
                pcm[offset] = (byte) mixed;
                pcm[offset + 1] = (byte) (mixed >> 8);
            }
            if (samples > 0 && (mixCalls == 1 || mixCalls % 1000 == 0)) {
                Log.i(TAG, "background mixer mixed samples=" + samples
                        + " queued=" + queuedSamples + " peak=" + peak + " calls=" + mixCalls);
            } else if (samples == 0 && mixCalls % 1000 == 0) {
                Log.i(TAG, "background mixer has playlist but no decoded pcm yet calls=" + mixCalls);
            }
            playMonitor(queued, samples);
            if (samples > 0) {
                System.arraycopy(queued, samples, queued, 0, queuedSamples - samples);
                queuedSamples -= samples;
                int frames = samples / OUT_CHANNELS;
                currentPositionUs += frames * 1000000L / OUT_RATE;
            }
        } catch (Exception e) {
            Log.e(TAG, "background mixer mixInto failed", e);
            moveToNextTrack();
        }
    }

    synchronized void release() {
        releaseDecoder();
        releaseMonitorTrack();
        queuedSamples = 0;
        mixCalls = 0;
        decodedSamples = 0;
    }

    private boolean decodeMore() {
        try {
            if (decoder == null && !openCurrent()) return false;
            if (!inputDone) {
                int inIndex = decoder.dequeueInputBuffer(10000);
                if (inIndex >= 0) {
                    ByteBuffer in = decoder.getInputBuffer(inIndex);
                    in.clear();
                    int size = extractor.readSampleData(in, 0);
                    long pts = extractor.getSampleTime();
                    if (size < 0) {
                        decoder.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        inputDone = true;
                    } else {
                        decoder.queueInputBuffer(inIndex, 0, size, Math.max(0, pts), 0);
                        extractor.advance();
                    }
                }
            }
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            int outIndex = decoder.dequeueOutputBuffer(info, 10000);
            if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                MediaFormat format = decoder.getOutputFormat();
                if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = Math.max(1, format.getInteger(MediaFormat.KEY_CHANNEL_COUNT));
                if (format.containsKey(MediaFormat.KEY_PCM_ENCODING)) pcmEncoding = format.getInteger(MediaFormat.KEY_PCM_ENCODING);
                return true;
            }
            if (outIndex >= 0) {
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    decoder.releaseOutputBuffer(outIndex, false);
                    moveToNextTrack();
                    return true;
                }
                ByteBuffer out = decoder.getOutputBuffer(outIndex);
                if (out != null && info.size > 1) {
                    out.position(info.offset);
                    out.limit(info.offset + info.size);
                appendPcm(out);
                }
                decoder.releaseOutputBuffer(outIndex, false);
                return true;
            }
        } catch (Exception e) {
            Log.e(TAG, "background mixer decode failed", e);
            moveToNextTrack();
        }
        return true;
    }

    private boolean openCurrent() throws Exception {
        if (playlist.size() == 0) return false;
        releaseDecoder();
        extractor = new MediaExtractor();
        extractor.setDataSource(context, playlist.get(index), null);
        int audioTrack = -1;
        MediaFormat audioFormat = null;
        for (int i = 0; i < extractor.getTrackCount(); i++) {
            MediaFormat format = extractor.getTrackFormat(i);
            String mime = format.getString(MediaFormat.KEY_MIME);
            if (mime != null && mime.startsWith("audio/")) {
                audioTrack = i;
                audioFormat = format;
                break;
            }
        }
        if (audioTrack < 0 || audioFormat == null) {
            moveToNextTrack();
            return false;
        }
        extractor.selectTrack(audioTrack);
        long startUs = initialSeekUs;
        if (startUs > 0L) {
            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            initialSeekUs = 0L;
        }
        currentPositionUs = startUs;
        currentDurationUs = audioFormat.containsKey(MediaFormat.KEY_DURATION) ? Math.max(0L, audioFormat.getLong(MediaFormat.KEY_DURATION)) : 0L;
        sampleRate = audioFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? audioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) : OUT_RATE;
        channels = audioFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? Math.max(1, audioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)) : OUT_CHANNELS;
        pcmEncoding = audioFormat.containsKey(MediaFormat.KEY_PCM_ENCODING) ? audioFormat.getInteger(MediaFormat.KEY_PCM_ENCODING) : AudioFormat.ENCODING_PCM_16BIT;
        resampleCarry = 0.0;
        decoder = MediaCodec.createDecoderByType(audioFormat.getString(MediaFormat.KEY_MIME));
        decoder.configure(audioFormat, null, null, 0);
        decoder.start();
        Log.i(TAG, "background mixer opened mime=" + audioFormat.getString(MediaFormat.KEY_MIME)
                + " rate=" + sampleRate + " channels=" + channels + " pcm=" + pcmEncoding
                + " uri=" + playlist.get(index));
        inputDone = false;
        return true;
    }

    private Uri currentUri() {
        if (playlist.size() == 0 || index < 0 || index >= playlist.size()) return null;
        return playlist.get(index);
    }

    private int indexOf(List<Uri> list, Uri uri) {
        if (uri == null || list == null) return -1;
        String value = uri.toString();
        for (int i = 0; i < list.size(); i++) {
            Uri candidate = list.get(i);
            if (candidate != null && value.equals(candidate.toString())) return i;
        }
        return -1;
    }

    private void moveToNextTrack() {
        releaseDecoder();
        if (playlist.size() == 0) return;
        if (playMode == PLAY_MODE_RANDOM && playlist.size() > 1) {
            int next = random.nextInt(playlist.size());
            index = next == index ? (next + 1) % playlist.size() : next;
        } else if (playMode != PLAY_MODE_SINGLE_LOOP) {
            index = (index + 1) % playlist.size();
        }
        currentPositionUs = 0L;
        currentDurationUs = 0L;
        initialSeekUs = 0L;
    }

    private void appendPcm(ByteBuffer buffer) {
        int bytesPerSample = bytesPerSample();
        int bytesPerFrame = Math.max(1, channels) * bytesPerSample;
        int frames = buffer.remaining() / bytesPerFrame;
        if (frames <= 0) return;
        double ratio = sampleRate <= 0 ? 1.0 : (double) OUT_RATE / sampleRate;
        for (int frame = 0; frame < frames; frame++) {
            int base = buffer.position() + frame * bytesPerFrame;
            short left = readSample(buffer, base);
            short right = channels > 1 ? readSample(buffer, base + bytesPerSample) : left;
            resampleCarry += ratio;
            while (resampleCarry >= 1.0) {
                appendSample(left);
                appendSample(right);
                resampleCarry -= 1.0;
            }
        }
        buffer.position(buffer.limit());
    }

    private short readSample(ByteBuffer buffer, int offset) {
        if (pcmEncoding == AudioFormat.ENCODING_PCM_FLOAT) {
            if (offset + 3 >= buffer.limit()) return 0;
            int bits = (buffer.get(offset) & 0xff)
                    | ((buffer.get(offset + 1) & 0xff) << 8)
                    | ((buffer.get(offset + 2) & 0xff) << 16)
                    | ((buffer.get(offset + 3) & 0xff) << 24);
            float value = Float.intBitsToFloat(bits);
            if (value > 1.0f) value = 1.0f;
            if (value < -1.0f) value = -1.0f;
            return (short) (value * Short.MAX_VALUE);
        }
        if (pcmEncoding == AudioFormat.ENCODING_PCM_8BIT) {
            if (offset >= buffer.limit()) return 0;
            return (short) (((buffer.get(offset) & 0xff) - 128) << 8);
        }
        if (pcmEncoding == AudioFormat.ENCODING_PCM_24BIT_PACKED) {
            if (offset + 2 >= buffer.limit()) return 0;
            int value = (buffer.get(offset) & 0xff)
                    | ((buffer.get(offset + 1) & 0xff) << 8)
                    | (buffer.get(offset + 2) << 16);
            return (short) (value >> 8);
        }
        if (pcmEncoding == AudioFormat.ENCODING_PCM_32BIT) {
            if (offset + 3 >= buffer.limit()) return 0;
            int value = (buffer.get(offset) & 0xff)
                    | ((buffer.get(offset + 1) & 0xff) << 8)
                    | ((buffer.get(offset + 2) & 0xff) << 16)
                    | (buffer.get(offset + 3) << 24);
            return (short) (value >> 16);
        }
        return readShort(buffer, offset);
    }

    private int bytesPerSample() {
        if (pcmEncoding == AudioFormat.ENCODING_PCM_FLOAT) return 4;
        if (pcmEncoding == AudioFormat.ENCODING_PCM_8BIT) return 1;
        if (pcmEncoding == AudioFormat.ENCODING_PCM_24BIT_PACKED) return 3;
        if (pcmEncoding == AudioFormat.ENCODING_PCM_32BIT) return 4;
        return 2;
    }

    private short readShort(ByteBuffer buffer, int offset) {
        if (offset + 1 >= buffer.limit()) return 0;
        return (short) ((buffer.get(offset) & 0xff) | (buffer.get(offset + 1) << 8));
    }

    private void appendSample(short value) {
        if (queuedSamples >= queued.length) return;
        queued[queuedSamples++] = value;
        decodedSamples++;
        if (decodedSamples == OUT_CHANNELS || decodedSamples % (OUT_RATE * OUT_CHANNELS * 10L) == 0) {
            Log.i(TAG, "background mixer decoded samples=" + decodedSamples + " queued=" + queuedSamples);
        }
    }

    private void playMonitor(short[] samples, int count) {
        if (!monitorPlayback || count <= 0) return;
        try {
            if (monitorTrack == null) {
                int min = AudioTrack.getMinBufferSize(OUT_RATE,
                        AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
                monitorTrack = new AudioTrack(AudioManager.STREAM_MUSIC, OUT_RATE,
                        AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT,
                        Math.max(min, OUT_RATE), AudioTrack.MODE_STREAM);
                monitorTrack.play();
                Log.i(TAG, "background mixer local monitor started");
            }
            monitorTrack.write(samples, 0, count);
        } catch (Exception e) {
            Log.e(TAG, "background mixer local monitor failed", e);
            releaseMonitorTrack();
        }
    }

    private void releaseMonitorTrack() {
        try {
            if (monitorTrack != null) monitorTrack.stop();
        } catch (Exception ignored) {
        }
        try {
            if (monitorTrack != null) monitorTrack.release();
        } catch (Exception ignored) {
        }
        monitorTrack = null;
    }

    private void releaseDecoder() {
        try {
            if (decoder != null) decoder.stop();
        } catch (Exception ignored) {
        }
        try {
            if (decoder != null) decoder.release();
        } catch (Exception ignored) {
        }
        try {
            if (extractor != null) extractor.release();
        } catch (Exception ignored) {
        }
        decoder = null;
        extractor = null;
        inputDone = false;
    }
}
