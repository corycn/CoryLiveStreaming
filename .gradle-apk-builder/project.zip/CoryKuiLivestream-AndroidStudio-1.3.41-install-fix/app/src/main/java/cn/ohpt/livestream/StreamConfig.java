package cn.ohpt.livestream;

final class StreamConfig {
    final int width;
    final int height;
    final int videoBitrate;
    final int fps;
    final int audioBitrate;

    StreamConfig(int width, int height, int videoBitrate, int fps, int audioBitrate) {
        this.width = width;
        this.height = height;
        this.videoBitrate = videoBitrate;
        this.fps = fps;
        this.audioBitrate = audioBitrate;
    }

    static StreamConfig fromLabel(String label) {
        if ("1080p".equals(label)) {
            return new StreamConfig(1920, 1080, 5000_000, 30, 128_000);
        }
        if ("720p".equals(label)) {
            return new StreamConfig(1280, 720, 2800_000, 30, 128_000);
        }
        return new StreamConfig(854, 480, 1200_000, 24, 96_000);
    }

    StreamConfig oriented(boolean landscape) {
        if (landscape) {
            return this;
        }
        return new StreamConfig(height, width, videoBitrate, fps, audioBitrate);
    }
}
