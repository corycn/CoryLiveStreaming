package cn.ohpt.livestream;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.Image;
import android.net.Uri;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

final class FileRtmpPublisher {
    private static final String TAG = "CoryKuiLive";

    interface Listener {
        void onStatus(String message);
        void onStreamingChanged(boolean streaming);
        void onFileStreamFinished(boolean completed);
    }

    private final Context context;
    private Listener listener;
    private final AtomicBoolean streaming = new AtomicBoolean(false);
    private final List<RtmpClient> clients = new ArrayList<RtmpClient>();
    private final Object reconnectLock = new Object();
    private final ArrayList<String> currentUrls = new ArrayList<String>();
    private boolean videoConfigLogged;
    private boolean firstVideoFrameLogged;
    private volatile boolean muted;
    private volatile float fileAudioVolume = 1.0f;
    private volatile float backgroundMusicVolume = 1.0f;
    private final ArrayList<Uri> bgmPlaylist = new ArrayList<Uri>();
    private int bgmPlayMode;
    private Uri currentFileUri;
    private long startElapsedMs;
    private volatile boolean playbackPaused;
    private volatile boolean backgroundMusicPaused;
    private long pauseStartedElapsedMs;
    private Uri bgmResumeUri;
    private long bgmResumePositionUs;
    private long currentDurationMs;
    private int currentRunGeneration;
    private Thread worker;
    private Thread mixedAudioThread;
    private volatile BackgroundMusicMixer activeMusicMixer;
    private int generation;
    private boolean hasMetadata;
    private int metadataWidth;
    private int metadataHeight;
    private int metadataFrameRate;
    private int metadataBitrate;
    private byte[] cachedVideoConfig;
    private byte[] cachedAudioConfig;

    FileRtmpPublisher(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
    }

    void setListener(Listener listener) {
        this.listener = listener;
    }

    boolean isStreaming() {
        return streaming.get();
    }

    synchronized Uri getCurrentFileUri() {
        return currentFileUri;
    }

    synchronized long getStartElapsedMs() {
        return startElapsedMs;
    }

    synchronized long getCurrentPositionMs() {
        if (!streaming.get() || startElapsedMs <= 0L) return 0L;
        long now = playbackPaused && pauseStartedElapsedMs > 0L
                ? pauseStartedElapsedMs
                : android.os.SystemClock.elapsedRealtime();
        return Math.max(0L, now - startElapsedMs);
    }

    synchronized long getCurrentDurationMs() {
        return currentDurationMs;
    }

    synchronized boolean isPlaybackPaused() {
        return playbackPaused;
    }

    synchronized void setPlaybackPaused(boolean paused) {
        if (playbackPaused == paused) return;
        playbackPaused = paused;
        long now = android.os.SystemClock.elapsedRealtime();
        if (paused) {
            pauseStartedElapsedMs = now;
        } else if (pauseStartedElapsedMs > 0L) {
            startElapsedMs += Math.max(0L, now - pauseStartedElapsedMs);
            pauseStartedElapsedMs = 0L;
        }
        listener.onStatus(paused ? "本地文件播放已暂停。" : "本地文件播放已继续。");
    }

    void setBackgroundMusicPaused(boolean paused) {
        backgroundMusicPaused = paused;
        BackgroundMusicMixer mixer = activeMusicMixer;
        if (mixer != null) mixer.setPaused(paused);
    }

    Uri getBackgroundMusicCurrentUri() {
        BackgroundMusicMixer mixer = activeMusicMixer;
        return mixer == null ? bgmResumeUri : mixer.getCurrentUri();
    }

    long getBackgroundMusicPositionUs() {
        BackgroundMusicMixer mixer = activeMusicMixer;
        return mixer == null ? bgmResumePositionUs : mixer.getCurrentPositionUs();
    }

    long getBackgroundMusicDurationUs() {
        BackgroundMusicMixer mixer = activeMusicMixer;
        return mixer == null ? 0L : mixer.getCurrentDurationUs();
    }

    void seekBackgroundMusic(long positionUs) {
        long safePositionUs = Math.max(0L, positionUs);
        bgmResumePositionUs = safePositionUs;
        BackgroundMusicMixer mixer = activeMusicMixer;
        if (mixer != null) mixer.seekToCurrent(safePositionUs);
    }

    boolean isBackgroundMusicPaused() {
        return backgroundMusicPaused;
    }

    void setMuted(boolean muted) {
        if (this.muted == muted) return;
        this.muted = muted;
        listener.onStatus(muted ? "本地文件音频已静音。" : "本地文件音频已恢复。");
    }

    void setFileAudioVolume(float volume) {
        fileAudioVolume = Math.max(0.0f, Math.min(2.0f, volume));
    }

    void setBackgroundMusicVolume(float volume) {
        backgroundMusicVolume = Math.max(0.0f, Math.min(2.0f, volume));
        BackgroundMusicMixer mixer = activeMusicMixer;
        if (mixer != null) mixer.setVolume(backgroundMusicVolume);
    }

    void setBackgroundMusic(List<Uri> playlist, int playMode) {
        synchronized (bgmPlaylist) {
            bgmPlaylist.clear();
            if (playlist != null) bgmPlaylist.addAll(playlist);
            bgmPlayMode = playMode;
        }
        restartMixedAudioIfRunning();
    }

    void setBackgroundMusicPreservingPlayback(List<Uri> playlist, int playMode) {
        synchronized (bgmPlaylist) {
            bgmPlaylist.clear();
            if (playlist != null) bgmPlaylist.addAll(playlist);
            bgmPlayMode = playMode;
        }
        BackgroundMusicMixer mixer = activeMusicMixer;
        if (mixer != null) {
            mixer.setPlaylistPreservingPlayback(playlist, playMode);
        } else {
            restartMixedAudioIfRunning();
        }
    }

    void setBackgroundMusicMode(int playMode) {
        synchronized (bgmPlaylist) {
            bgmPlayMode = playMode;
        }
        BackgroundMusicMixer mixer = activeMusicMixer;
        if (mixer != null) {
            mixer.setPlayMode(playMode);
        }
    }

    void start(final Uri uri, final List<String> urls) {
        start(uri, urls, 0L);
    }

    void start(final Uri uri, final List<String> urls, final long startOffsetMs) {
        final int runGeneration;
        final long safeStartOffsetMs = Math.max(0L, startOffsetMs);
        synchronized (this) {
            if (streaming.get()) return;
            generation++;
            runGeneration = generation;
            streaming.set(true);
            playbackPaused = false;
            pauseStartedElapsedMs = 0L;
            currentFileUri = uri;
            startElapsedMs = android.os.SystemClock.elapsedRealtime() - safeStartOffsetMs;
            currentDurationMs = 0L;
            currentRunGeneration = runGeneration;
            currentUrls.clear();
            if (urls != null) currentUrls.addAll(urls);
        }
        videoConfigLogged = false;
        firstVideoFrameLogged = false;
        synchronized (this) {
            hasMetadata = false;
            cachedVideoConfig = null;
            cachedAudioConfig = null;
        }
        listener.onStreamingChanged(true);
        worker = new Thread(new Runnable() {
            @Override public void run() {
                MediaExtractor extractor = new MediaExtractor();
                boolean completed = false;
                try {
                    listener.onStatus("正在读取本地文件...");
                    if (isImageUri(uri)) {
                        connectAll(urls);
                        startMixedAudioLoop(uri, runGeneration, 0L);
                        streamImageAsVideo(uri, runGeneration);
                        return;
                    }
                    extractor.setDataSource(context, uri, null);
                    int videoTrack = -1;
                    int audioTrack = -1;
                    MediaFormat videoFormat = null;
                    MediaFormat audioFormat = null;
                    String videoMime = null;
                    boolean useMixedAudio = true;
                    for (int i = 0; i < extractor.getTrackCount(); i++) {
                        MediaFormat format = extractor.getTrackFormat(i);
                        String mime = format.getString(MediaFormat.KEY_MIME);
                        if (mime != null && mime.startsWith("video/") && videoTrack < 0) {
                            if (!MediaFormat.MIMETYPE_VIDEO_AVC.equals(mime) && !MediaFormat.MIMETYPE_VIDEO_HEVC.equals(mime)) {
                                throw new IOException("视频编码暂不支持：" + mime);
                            }
                            videoMime = mime;
                            videoTrack = i;
                            videoFormat = format;
                            if (MediaFormat.MIMETYPE_VIDEO_AVC.equals(mime)) extractor.selectTrack(i);
                        } else if (mime != null && mime.startsWith("audio/") && audioTrack < 0) {
                            if (false && !MediaFormat.MIMETYPE_AUDIO_AAC.equals(mime)) {
                                throw new IOException("音频编码不是 AAC，暂不支持：" + mime);
                            }
                            audioTrack = i;
                            audioFormat = format;
                            if (!useMixedAudio && (videoMime == null || MediaFormat.MIMETYPE_VIDEO_AVC.equals(videoMime))) extractor.selectTrack(i);
                        }
                    }
                    if (videoTrack < 0 && audioTrack < 0) {
                        throw new IOException("文件里没有可推流的 H.264/AAC 音视频轨道");
                    }
                    synchronized (FileRtmpPublisher.this) {
                        currentDurationMs = Math.max(durationMs(videoFormat), durationMs(audioFormat));
                    }
                    connectAll(urls);
                    if (MediaFormat.MIMETYPE_VIDEO_HEVC.equals(videoMime)) {
                        extractor.release();
                        listener.onStatus("检测到 HEVC，正在实时转码为 H.264 边推流...");
                        streamHevcAsAvc(uri, videoTrack, videoFormat, audioTrack, audioFormat);
                        completed = isCurrentRunActive(runGeneration);
                    } else {
                        if (videoFormat != null) {
                            sendMetadata(videoFormat.getInteger(MediaFormat.KEY_WIDTH),
                                    videoFormat.getInteger(MediaFormat.KEY_HEIGHT), 30, 2_800_000, 0);
                            sendVideoConfig(makeAvcc(videoFormat), 0);
                        }
                        if (safeStartOffsetMs > 0) {
                            extractor.seekTo(safeStartOffsetMs * 1000L, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
                        }
                        startMixedAudioLoop(uri, runGeneration, safeStartOffsetMs * 1000L);
                        listener.onStatus("本地文件开始推流。");
                        if (videoTrack >= 0) {
                            streamSamples(extractor, videoTrack, audioTrack);
                            completed = isCurrentRunActive(runGeneration);
                        } else {
                            waitForAudioOnlyStream(runGeneration);
                        }
                    }
                    listener.onStatus("本地文件推流结束。");
                } catch (Exception e) {
                    listener.onStatus("本地文件推流失败：" + e.getMessage());
                } finally {
                    try {
                        extractor.release();
                    } catch (Exception ignored) {
                    }
                    finishWorker(runGeneration, completed);
                }
            }
        }, "file-rtmp");
        worker.start();
    }

    void stop() {
        Thread oldWorker;
        synchronized (this) {
            captureBackgroundMusicPosition();
            generation++;
            if (!streaming.getAndSet(false)) return;
            oldWorker = worker;
            worker = null;
            currentFileUri = null;
            startElapsedMs = 0;
            currentDurationMs = 0L;
            playbackPaused = false;
            pauseStartedElapsedMs = 0L;
        }
        if (oldWorker != null && oldWorker != Thread.currentThread()) {
            oldWorker.interrupt();
        }
        if (mixedAudioThread != null) {
            mixedAudioThread.interrupt();
            mixedAudioThread = null;
        }
        synchronized (clients) {
            for (RtmpClient client : clients) client.close();
            clients.clear();
        }
        listener.onStreamingChanged(false);
    }

    private synchronized boolean isCurrentRunActive(int runGeneration) {
        return streaming.get() && runGeneration == generation;
    }

    private void finishWorker(int runGeneration, boolean completed) {
        synchronized (this) {
            if (runGeneration != generation) return;
            if (!streaming.getAndSet(false)) return;
            captureBackgroundMusicPosition();
            worker = null;
            currentFileUri = null;
            startElapsedMs = 0;
            currentDurationMs = 0L;
            playbackPaused = false;
            pauseStartedElapsedMs = 0L;
        }
        synchronized (clients) {
            for (RtmpClient client : clients) client.close();
            clients.clear();
        }
        if (mixedAudioThread != null) {
            mixedAudioThread.interrupt();
            mixedAudioThread = null;
        }
        listener.onFileStreamFinished(completed);
        listener.onStreamingChanged(false);
    }

    private void connectAll(List<String> urls) throws IOException {
        if (System.nanoTime() >= 0) {
            try {
                connectAllFresh(urls);
            } catch (IOException e) {
                if (!streaming.get()) throw e;
                listener.onStatus("推流连接失败，正在重试：" + e.getMessage());
                ensureClientsOrReconnect();
            }
            return;
        }
        synchronized (clients) {
            clients.clear();
        }
        for (String url : urls) {
            RtmpClient client = new RtmpClient();
            client.connect(url);
            synchronized (clients) {
                clients.add(client);
            }
            listener.onStatus("已连接：" + url);
        }
    }

    private void connectAllFresh(List<String> urls) throws IOException {
        closeAllClients();
        if (urls == null || urls.size() == 0) {
            throw new IOException("没有可用的 RTMP 地址");
        }
        IOException lastError = null;
        for (String url : urls) {
            try {
                RtmpClient client = new RtmpClient();
                client.connect(url);
                synchronized (clients) {
                    clients.add(client);
                }
                listener.onStatus("已连接：" + url);
            } catch (IOException e) {
                lastError = e;
                listener.onStatus("RTMP 连接失败：" + e.getMessage());
            }
        }
        if (!hasClients()) {
            throw lastError == null ? new IOException("所有 RTMP 地址连接失败") : lastError;
        }
    }

    private ArrayList<String> currentUrlSnapshot() {
        synchronized (this) {
            return new ArrayList<String>(currentUrls);
        }
    }

    private boolean hasClients() {
        synchronized (clients) {
            return clients.size() > 0;
        }
    }

    private void ensureClientsOrReconnect() throws IOException {
        if (hasClients()) return;
        synchronized (reconnectLock) {
            if (hasClients()) return;
            IOException lastError = null;
            for (int attempt = 1; streaming.get(); attempt++) {
                try {
                    listener.onStatus("推流异常，正在第 " + attempt + " 次重连...");
                    connectAllFresh(currentUrlSnapshot());
                    resendCachedHeaders();
                    listener.onStatus("推流已重连，继续当前进度。");
                    return;
                } catch (IOException e) {
                    lastError = e;
                    Log.w(TAG, "file RTMP reconnect failed attempt=" + attempt + ": " + e.getMessage());
                    closeAllClients();
                    try {
                        Thread.sleep(Math.min(3000, 500 + attempt * 500));
                    } catch (InterruptedException interrupted) {
                        Thread.currentThread().interrupt();
                        throw new IOException("推流重连被中断", interrupted);
                    }
                }
            }
            throw lastError == null ? new IOException("推流已停止，取消重连") : lastError;
        }
    }

    private void closeAllClients() {
        ArrayList<RtmpClient> oldClients;
        synchronized (clients) {
            oldClients = new ArrayList<RtmpClient>(clients);
            clients.clear();
        }
        for (RtmpClient client : oldClients) client.close();
    }

    private void resendCachedHeaders() throws IOException {
        boolean meta;
        int width;
        int height;
        int frameRate;
        int bitrate;
        byte[] videoConfig;
        byte[] audioConfig;
        synchronized (this) {
            meta = hasMetadata;
            width = metadataWidth;
            height = metadataHeight;
            frameRate = metadataFrameRate;
            bitrate = metadataBitrate;
            videoConfig = cachedVideoConfig == null ? null : cachedVideoConfig.clone();
            audioConfig = cachedAudioConfig == null ? null : cachedAudioConfig.clone();
        }
        if (meta) sendMetadataDirect(width, height, frameRate, bitrate, 0);
        if (videoConfig != null) sendVideoConfigDirect(videoConfig, 0);
        if (audioConfig != null) sendAudioConfigDirect(audioConfig, 0);
    }

    private void streamSamples(MediaExtractor extractor, int videoTrack, int audioTrack) throws IOException, InterruptedException {
        ByteBuffer buffer = ByteBuffer.allocateDirect(2 * 1024 * 1024);
        long wallStartUs = System.nanoTime() / 1000L;
        long mediaStartUs = -1L;
        while (streaming.get()) {
            wallStartUs += waitWhilePlaybackPaused();
            int track = extractor.getSampleTrackIndex();
            if (track < 0) break;
            long sampleTimeUs = extractor.getSampleTime();
            if (mediaStartUs < 0) mediaStartUs = sampleTimeUs;
            long relativeUs = Math.max(0, sampleTimeUs - mediaStartUs);
            long targetUs = wallStartUs + relativeUs;
            long nowUs = System.nanoTime() / 1000L;
            if (targetUs > nowUs) {
                Thread.sleep(Math.min(250, (targetUs - nowUs) / 1000L));
                continue;
            }
            buffer.clear();
            int size = extractor.readSampleData(buffer, 0);
            if (size > 0) {
                byte[] sample = new byte[size];
                buffer.position(0);
                buffer.get(sample);
                int timestamp = (int) (relativeUs / 1000L);
                if (track == videoTrack) {
                    boolean key = (extractor.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0;
                    sendVideoFrame(annexBToAvccSample(sample), key, timestamp);
                } else if (track == audioTrack) {
                    if (!muted) sendAudioFrame(sample, timestamp);
                }
            }
            extractor.advance();
        }
    }

    private void waitForAudioOnlyStream(int runGeneration) throws InterruptedException {
        while (streaming.get() && runGeneration == generation && !Thread.currentThread().isInterrupted()) {
            waitWhilePlaybackPaused();
            Thread.sleep(250);
        }
    }

    private long waitWhilePlaybackPaused() throws InterruptedException {
        if (!playbackPaused) return 0L;
        long startedUs = System.nanoTime() / 1000L;
        while (streaming.get() && playbackPaused && !Thread.currentThread().isInterrupted()) {
            Thread.sleep(100);
        }
        return System.nanoTime() / 1000L - startedUs;
    }

    private void startMixedAudioLoop(final Uri fileUri, final int runGeneration, final long startOffsetUs) {
        if (mixedAudioThread != null) {
            mixedAudioThread.interrupt();
            mixedAudioThread = null;
        }
        final ArrayList<Uri> musicList = new ArrayList<Uri>();
        final int musicMode;
        final boolean fileAudioEnabled = !isImageUri(fileUri);
        synchronized (bgmPlaylist) {
            musicList.addAll(bgmPlaylist);
            musicMode = bgmPlayMode;
        }
        mixedAudioThread = new Thread(new Runnable() {
            @Override public void run() {
                MediaCodec encoder = null;
                BackgroundMusicMixer fileMixer = new BackgroundMusicMixer(context);
                BackgroundMusicMixer musicMixer = new BackgroundMusicMixer(context);
                activeMusicMixer = musicMixer;
                try {
                    musicMixer.setMonitorPlayback(true);
                    if (fileAudioEnabled) {
                        ArrayList<Uri> fileAudio = new ArrayList<Uri>();
                        fileAudio.add(fileUri);
                        fileMixer.setStartOffsetUs(startOffsetUs);
                        fileMixer.setPlaylist(fileAudio, 2);
                    }
                    Uri resumeUri;
                    long resumePositionUs;
                    synchronized (FileRtmpPublisher.this) {
                        resumeUri = bgmResumeUri;
                        resumePositionUs = bgmResumePositionUs;
                    }
                    musicMixer.setPlaylistStartingAt(musicList, musicMode, resumeUri, resumePositionUs);
                    musicMixer.setPaused(backgroundMusicPaused);
                    MediaFormat format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, 44100, 2);
                    format.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
                    format.setInteger(MediaFormat.KEY_BIT_RATE, 128000);
                    encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
                    encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                    encoder.start();
                    MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                    byte[] pcm = new byte[4096];
                    long startUs = System.nanoTime() / 1000L;
                    long audioPtsUs = 0L;
                    boolean sentConfig = false;
                    long mixedAudioPacketsSent = 0L;
                    while (streaming.get() && runGeneration == generation && !Thread.currentThread().isInterrupted()) {
                        long targetUs = startUs + audioPtsUs;
                        long nowUs = System.nanoTime() / 1000L;
                        if (targetUs > nowUs) {
                            Thread.sleep(Math.min(50, (targetUs - nowUs) / 1000L));
                            continue;
                        }
                        int input = encoder.dequeueInputBuffer(10000);
                        if (input >= 0) {
                            ByteBuffer in = encoder.getInputBuffer(input);
                            in.clear();
                            int size = Math.min(pcm.length, in.remaining());
                            for (int i = 0; i < size; i++) pcm[i] = 0;
                            fileMixer.setVolume(fileAudioVolume);
                            musicMixer.setVolume(backgroundMusicVolume);
                            if (fileAudioEnabled && !muted && !playbackPaused) {
                                try {
                                    fileMixer.mixInto(pcm, size);
                                } catch (Exception e) {
                                    Log.e(TAG, "file audio mix failed", e);
                                }
                            }
                            try {
                                musicMixer.mixInto(pcm, size);
                            } catch (Exception e) {
                                Log.e(TAG, "background audio mix failed", e);
                            }
                            in.put(pcm, 0, size);
                            encoder.queueInputBuffer(input, 0, size, audioPtsUs, 0);
                            int frames = size / 4;
                            audioPtsUs += frames * 1000000L / 44100L;
                        }
                        int outIndex;
                        while ((outIndex = encoder.dequeueOutputBuffer(info, 0)) >= 0) {
                            ByteBuffer out = encoder.getOutputBuffer(outIndex);
                            if (out != null && info.size > 0 && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                                if (!sentConfig) {
                                    sendAudioConfig(audioConfig(encoder.getOutputFormat()), 0);
                                    Log.i(TAG, "file mixed audio sent config from encoder format");
                                    sentConfig = true;
                                }
                                out.position(info.offset);
                                out.limit(info.offset + info.size);
                                byte[] sample = new byte[info.size];
                                out.get(sample);
                                sendAudioFrame(sample, (int) (Math.max(0L, info.presentationTimeUs) / 1000L));
                                mixedAudioPacketsSent++;
                                if (mixedAudioPacketsSent == 1 || mixedAudioPacketsSent % 600 == 0) {
                                    Log.i(TAG, "file mixed audio packets sent=" + mixedAudioPacketsSent
                                            + " ts=" + (info.presentationTimeUs / 1000L)
                                            + " size=" + sample.length);
                                }
                            }
                            encoder.releaseOutputBuffer(outIndex, false);
                        }
                        if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED && !sentConfig) {
                            sendAudioConfig(audioConfig(encoder.getOutputFormat()), 0);
                            Log.i(TAG, "file mixed audio sent config on format changed");
                            sentConfig = true;
                        }
                    }
                } catch (Exception e) {
                    if (isExpectedStop(e)) {
                        Log.i(TAG, "file mixed audio loop stopped");
                    } else {
                        Log.e(TAG, "file mixed audio loop failed", e);
                    }
                    if (!isExpectedStop(e) && streaming.get() && runGeneration == generation) {
                        listener.onStatus("文件混音异常：" + e.getMessage());
                    }
                } finally {
                    if (activeMusicMixer == musicMixer) {
                        activeMusicMixer = null;
                    }
                    fileMixer.release();
                    musicMixer.release();
                    try {
                        if (encoder != null) encoder.stop();
                    } catch (Exception ignored) {
                    }
                    try {
                        if (encoder != null) encoder.release();
                    } catch (Exception ignored) {
                    }
                }
            }
        }, "file-mixed-audio");
        mixedAudioThread.start();
    }

    private boolean isExpectedStop(Throwable error) {
        Throwable current = error;
        while (current != null) {
            if (current instanceof InterruptedException) return true;
            current = current.getCause();
        }
        return Thread.currentThread().isInterrupted() || !streaming.get();
    }

    private long durationMs(MediaFormat format) {
        if (format == null || !format.containsKey(MediaFormat.KEY_DURATION)) return 0L;
        try {
            return Math.max(0L, format.getLong(MediaFormat.KEY_DURATION) / 1000L);
        } catch (Exception ignored) {
            return 0L;
        }
    }

    private void restartMixedAudioIfRunning() {
        Uri fileUri;
        int runGeneration;
        long offsetUs;
        synchronized (this) {
            if (!streaming.get() || currentFileUri == null) return;
            fileUri = currentFileUri;
            runGeneration = currentRunGeneration;
            offsetUs = Math.max(0L, android.os.SystemClock.elapsedRealtime() - startElapsedMs) * 1000L;
        }
        startMixedAudioLoop(fileUri, runGeneration, offsetUs);
    }

    private synchronized void captureBackgroundMusicPosition() {
        BackgroundMusicMixer mixer = activeMusicMixer;
        if (mixer == null) return;
        Uri current = mixer.getCurrentUri();
        if (current != null) {
            bgmResumeUri = current;
            bgmResumePositionUs = mixer.getCurrentPositionUs();
        }
    }

    private boolean isImageUri(Uri uri) {
        try {
            String type = context.getContentResolver().getType(uri);
            if (type != null && type.startsWith("image/")) return true;
        } catch (Exception ignored) {
        }
        String text = uri == null ? "" : uri.toString().toLowerCase();
        return text.endsWith(".jpg") || text.endsWith(".jpeg") || text.endsWith(".png")
                || text.endsWith(".webp") || text.endsWith(".bmp");
    }

    private void streamImageAsVideo(Uri uri, int runGeneration) throws Exception {
        int[] imageSize = readImageSize(uri);
        final boolean landscapeImage = imageSize[0] >= imageSize[1];
        final int width = landscapeImage ? 1280 : 720;
        final int height = landscapeImage ? 720 : 1280;
        final int fps = 30;
        final int colorFormat = chooseAvcInputColorFormat();
        Bitmap bitmap = decodeImageFrame(uri, width, height);
        byte[] yuv = bitmapToEncoderYuv(bitmap, width, height, colorFormat);
        bitmap.recycle();

        MediaCodec encoder = null;
        try {
            MediaFormat format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, colorFormat);
            format.setInteger(MediaFormat.KEY_BIT_RATE, 2_000_000);
            format.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
            format.setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline);
            format.setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR);
            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            encoder.start();
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            long startUs = System.nanoTime() / 1000L;
            boolean sentVideoConfig = false;
            for (int frame = 0; streaming.get() && runGeneration == generation; frame++) {
                long ptsUs = frame * 1000000L / fps;
                queueEncoderInput(encoder, yuv, ptsUs);
                int outIndex;
                while ((outIndex = encoder.dequeueOutputBuffer(info, 0)) >= 0) {
                    ByteBuffer out = encoder.getOutputBuffer(outIndex);
                    if (out != null && info.size > 0 && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        out.position(info.offset);
                        out.limit(info.offset + info.size);
                        byte[] sample = new byte[info.size];
                        out.get(sample);
                        boolean key = (info.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0;
                        sendVideoFrame(annexBToAvccSample(sample), key, (int) (info.presentationTimeUs / 1000L));
                    }
                    encoder.releaseOutputBuffer(outIndex, false);
                }
                if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED && !sentVideoConfig) {
                    sendMetadata(width, height, fps, 2_000_000, 0);
                    sendVideoConfig(makeAvcc(encoder.getOutputFormat()), 0);
                    sentVideoConfig = true;
                }
                long targetUs = startUs + ptsUs + 1000000L / fps;
                long nowUs = System.nanoTime() / 1000L;
                if (targetUs > nowUs) Thread.sleep(Math.min(100, (targetUs - nowUs) / 1000L));
            }
        } finally {
            if (encoder != null) {
                try { encoder.stop(); } catch (Exception ignored) {}
                encoder.release();
            }
        }
    }

    private int[] readImageSize(Uri uri) throws IOException {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        InputStream in = context.getContentResolver().openInputStream(uri);
        try {
            BitmapFactory.decodeStream(in, null, options);
        } finally {
            if (in != null) in.close();
        }
        int width = options.outWidth > 0 ? options.outWidth : 720;
        int height = options.outHeight > 0 ? options.outHeight : 1280;
        return new int[]{width, height};
    }

    private Bitmap decodeImageFrame(Uri uri, int width, int height) throws IOException {
        InputStream in = context.getContentResolver().openInputStream(uri);
        Bitmap source = null;
        try {
            source = BitmapFactory.decodeStream(in);
        } finally {
            if (in != null) in.close();
        }
        if (source == null) throw new IOException("鍥剧墖瑙ｇ爜澶辫触");
        Bitmap out = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        canvas.drawColor(Color.BLACK);
        float scale = Math.min((float) width / source.getWidth(), (float) height / source.getHeight());
        int drawW = Math.max(1, Math.round(source.getWidth() * scale));
        int drawH = Math.max(1, Math.round(source.getHeight() * scale));
        Rect dst = new Rect((width - drawW) / 2, (height - drawH) / 2, (width + drawW) / 2, (height + drawH) / 2);
        canvas.drawBitmap(source, null, dst, new Paint(Paint.FILTER_BITMAP_FLAG));
        source.recycle();
        return out;
    }

    private void streamHevcAsAvc(final Uri uri, int videoTrack, MediaFormat videoFormat, final int audioTrack, final MediaFormat audioFormat) throws Exception {
        final long[] firstMediaUs = new long[]{-1L};
        final long wallStartUs = System.nanoTime() / 1000L;
        final Thread[] audioThread = new Thread[]{null};
        final boolean[] audioStarted = new boolean[]{false};

        MediaExtractor videoExtractor = new MediaExtractor();
        MediaCodec decoder = null;
        MediaCodec encoder = null;
        try {
            videoExtractor.setDataSource(context, uri, null);
            videoExtractor.selectTrack(videoTrack);
            final int width = even(videoFormat.getInteger(MediaFormat.KEY_WIDTH));
            final int height = even(videoFormat.getInteger(MediaFormat.KEY_HEIGHT));
            final int encoderColorFormat = chooseAvcInputColorFormat();
            MediaFormat outFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
            outFormat.setInteger(MediaFormat.KEY_COLOR_FORMAT, encoderColorFormat);
            outFormat.setInteger(MediaFormat.KEY_BIT_RATE, 2_800_000);
            outFormat.setInteger(MediaFormat.KEY_FRAME_RATE, 30);
            outFormat.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
            outFormat.setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline);
            outFormat.setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR);
            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            encoder.configure(outFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            encoder.start();

            videoFormat.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);
            decoder = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_HEVC);
            decoder.configure(videoFormat, null, null, 0);
            decoder.start();

            MediaCodec.BufferInfo decInfo = new MediaCodec.BufferInfo();
            MediaCodec.BufferInfo encInfo = new MediaCodec.BufferInfo();
            boolean inputDone = false;
            boolean decoderDone = false;
            boolean encoderDone = false;
            while (streaming.get() && !encoderDone) {
                if (!inputDone) {
                    int inIndex = decoder.dequeueInputBuffer(10000);
                    if (inIndex >= 0) {
                        ByteBuffer in = decoder.getInputBuffer(inIndex);
                        in.clear();
                        int size = videoExtractor.readSampleData(in, 0);
                        long pts = videoExtractor.getSampleTime();
                        if (size < 0) {
                            decoder.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                        } else {
                            if (firstMediaUs[0] < 0) firstMediaUs[0] = pts;
                            decoder.queueInputBuffer(inIndex, 0, size, pts, 0);
                            videoExtractor.advance();
                        }
                    }
                }
                if (!decoderDone) {
                    int outIndex = decoder.dequeueOutputBuffer(decInfo, 10000);
                    if (outIndex >= 0) {
                        if (decInfo.size > 0) {
                            Image image = decoder.getOutputImage(outIndex);
                            if (image != null) {
                                byte[] yuv = imageToEncoderYuv(image, width, height, encoderColorFormat);
                                image.close();
                                queueEncoderInput(encoder, yuv, decInfo.presentationTimeUs);
                            }
                        }
                        if ((decInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            queueEncoderEndOfStream(encoder, decInfo.presentationTimeUs);
                            decoderDone = true;
                        }
                        decoder.releaseOutputBuffer(outIndex, false);
                    } else if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        listener.onStatus("HEVC 解码输出已准备。");
                    }
                }
                int encIndex = encoder.dequeueOutputBuffer(encInfo, 1000);
                if (encIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    sendMetadata(width, height, 30, 2_800_000, 0);
                    sendVideoConfig(makeAvcc(encoder.getOutputFormat()), 0);
                    if (!audioStarted[0]) {
                        audioStarted[0] = true;
                        startMixedAudioLoop(uri, generation, 0L);
                        /*
                        sendAudioConfig(audioConfig(audioFormat), 0);
                        audioThread[0] = new Thread(new Runnable() {
                            @Override public void run() {
                                MediaExtractor audioExtractor = new MediaExtractor();
                                try {
                                    audioExtractor.setDataSource(context, uri, null);
                                    audioExtractor.selectTrack(audioTrack);
                                    streamAudioOnly(audioExtractor, firstMediaUs, wallStartUs);
                                } catch (Exception e) {
                                    if (streaming.get()) listener.onStatus("文件音频推流异常：" + e.getMessage());
                                } finally {
                                    audioExtractor.release();
                                }
                            }
                        }, "file-audio");
                        audioThread[0].start();
                        */
                    }
                } else if (encIndex >= 0) {
                    ByteBuffer out = encoder.getOutputBuffer(encIndex);
                    if (out != null && encInfo.size > 0 && (encInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        long relUs = firstMediaUs[0] < 0 ? 0 : Math.max(0, encInfo.presentationTimeUs - firstMediaUs[0]);
                        long targetUs = wallStartUs + relUs;
                        long nowUs = System.nanoTime() / 1000L;
                        if (targetUs > nowUs) Thread.sleep(Math.min(250, (targetUs - nowUs) / 1000L));
                        byte[] sample = new byte[encInfo.size];
                        out.position(encInfo.offset);
                        out.limit(encInfo.offset + encInfo.size);
                        out.get(sample);
                        boolean key = (encInfo.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0;
                        int ts = (int) (relUs / 1000L);
                        sendVideoFrame(annexBToAvccSample(sample), key, ts);
                    }
                    if ((encInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) encoderDone = true;
                    encoder.releaseOutputBuffer(encIndex, false);
                }
            }
            if (audioThread[0] != null) audioThread[0].join(1000);
        } finally {
            videoExtractor.release();
            if (decoder != null) {
                try { decoder.stop(); } catch (Exception ignored) {}
                decoder.release();
            }
            if (encoder != null) {
                try { encoder.stop(); } catch (Exception ignored) {}
                encoder.release();
            }
        }
    }

    private int even(int value) {
        return value % 2 == 0 ? value : value - 1;
    }

    private void queueEncoderInput(MediaCodec encoder, byte[] yuv, long ptsUs) throws IOException {
        while (streaming.get()) {
            int inIndex = encoder.dequeueInputBuffer(10000);
            if (inIndex >= 0) {
                ByteBuffer in = encoder.getInputBuffer(inIndex);
                in.clear();
                in.put(yuv, 0, Math.min(yuv.length, in.remaining()));
                encoder.queueInputBuffer(inIndex, 0, Math.min(yuv.length, in.position()), ptsUs, 0);
                return;
            }
        }
    }

    private void queueEncoderEndOfStream(MediaCodec encoder, long ptsUs) {
        while (streaming.get()) {
            int inIndex = encoder.dequeueInputBuffer(10000);
            if (inIndex >= 0) {
                encoder.queueInputBuffer(inIndex, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                return;
            }
        }
    }

    private int chooseAvcInputColorFormat() throws IOException {
        MediaCodecList list = new MediaCodecList(MediaCodecList.ALL_CODECS);
        MediaCodecInfo[] infos = list.getCodecInfos();
        int fallback = MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible;
        for (MediaCodecInfo info : infos) {
            if (!info.isEncoder()) continue;
            String[] types = info.getSupportedTypes();
            for (String type : types) {
                if (!MediaFormat.MIMETYPE_VIDEO_AVC.equalsIgnoreCase(type)) continue;
                MediaCodecInfo.CodecCapabilities caps = info.getCapabilitiesForType(type);
                for (int color : caps.colorFormats) {
                    if (color == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar) {
                        listener.onStatus("H.264 编码色彩格式：NV12");
                        return color;
                    }
                    if (color == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar) {
                        fallback = color;
                    }
                }
            }
        }
        listener.onStatus(fallback == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar
                ? "H.264 编码色彩格式：I420"
                : "H.264 编码色彩格式：Flexible");
        return fallback;
    }

    private byte[] imageToEncoderYuv(Image image, int width, int height, int colorFormat) {
        if (colorFormat == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar) {
            return imageToI420(image, width, height);
        }
        return imageToNV12(image, width, height);
    }

    private byte[] bitmapToEncoderYuv(Bitmap bitmap, int width, int height, int colorFormat) {
        byte[] out = new byte[width * height * 3 / 2];
        int[] pixels = new int[width * height];
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height);
        int yIndex = 0;
        int uvIndex = width * height;
        boolean planar = colorFormat == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar;
        int uPlane = width * height;
        int vPlane = uPlane + (width * height / 4);
        for (int j = 0; j < height; j++) {
            for (int i = 0; i < width; i++) {
                int c = pixels[j * width + i];
                int r = (c >> 16) & 0xff;
                int g = (c >> 8) & 0xff;
                int b = c & 0xff;
                int y = ((66 * r + 129 * g + 25 * b + 128) >> 8) + 16;
                int u = ((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128;
                int v = ((112 * r - 94 * g - 18 * b + 128) >> 8) + 128;
                out[yIndex++] = (byte) clamp(y, 0, 255);
                if ((j & 1) == 0 && (i & 1) == 0) {
                    if (planar) {
                        out[uPlane++] = (byte) clamp(u, 0, 255);
                        out[vPlane++] = (byte) clamp(v, 0, 255);
                    } else if (uvIndex + 1 < out.length) {
                        out[uvIndex++] = (byte) clamp(u, 0, 255);
                        out[uvIndex++] = (byte) clamp(v, 0, 255);
                    }
                }
            }
        }
        return out;
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private byte[] imageToI420(Image image, int width, int height) {
        byte[] out = new byte[width * height * 3 / 2];
        Image.Plane[] planes = image.getPlanes();
        copyPlane(planes[0], width, height, out, 0, 1);
        int chromaWidth = width / 2;
        int chromaHeight = height / 2;
        copyPlane(planes[1], chromaWidth, chromaHeight, out, width * height, 1);
        copyPlane(planes[2], chromaWidth, chromaHeight, out, width * height + chromaWidth * chromaHeight, 1);
        return out;
    }

    private byte[] imageToNV12(Image image, int width, int height) {
        byte[] out = new byte[width * height * 3 / 2];
        Image.Plane[] planes = image.getPlanes();
        copyPlane(planes[0], width, height, out, 0, 1);
        int chromaWidth = width / 2;
        int chromaHeight = height / 2;
        byte[] u = new byte[chromaWidth * chromaHeight];
        byte[] v = new byte[chromaWidth * chromaHeight];
        copyPlane(planes[1], chromaWidth, chromaHeight, u, 0, 1);
        copyPlane(planes[2], chromaWidth, chromaHeight, v, 0, 1);
        int offset = width * height;
        for (int i = 0; i < u.length && offset + 1 < out.length; i++) {
            out[offset++] = u[i];
            out[offset++] = v[i];
        }
        return out;
    }

    private void copyPlane(Image.Plane plane, int width, int height, byte[] out, int offset, int outPixelStride) {
        ByteBuffer buffer = plane.getBuffer().duplicate();
        int rowStride = plane.getRowStride();
        int pixelStride = plane.getPixelStride();
        byte[] row = new byte[rowStride];
        int pos = offset;
        for (int rowIndex = 0; rowIndex < height; rowIndex++) {
            int length = Math.min(rowStride, buffer.remaining());
            buffer.get(row, 0, length);
            for (int col = 0; col < width; col++) {
                int source = col * pixelStride;
                if (source < length && pos < out.length) {
                    out[pos] = row[source];
                }
                pos += outPixelStride;
            }
        }
    }

    private void streamAudioOnly(MediaExtractor extractor, long[] firstMediaUs, long wallStartUs) throws IOException, InterruptedException {
        ByteBuffer buffer = ByteBuffer.allocateDirect(512 * 1024);
        while (streaming.get()) {
            int track = extractor.getSampleTrackIndex();
            if (track < 0) break;
            long pts = extractor.getSampleTime();
            if (firstMediaUs[0] < 0) firstMediaUs[0] = pts;
            long relativeUs = Math.max(0, pts - firstMediaUs[0]);
            long targetUs = wallStartUs + relativeUs;
            long nowUs = System.nanoTime() / 1000L;
            if (targetUs > nowUs) {
                Thread.sleep(Math.min(250, (targetUs - nowUs) / 1000L));
                continue;
            }
            buffer.clear();
            int size = extractor.readSampleData(buffer, 0);
            if (size > 0) {
                byte[] sample = new byte[size];
                buffer.position(0);
                buffer.get(sample);
                if (!muted) sendAudioFrame(sample, (int) (relativeUs / 1000L));
            }
            extractor.advance();
        }
    }

    private void sendVideoConfig(byte[] avcc, int timestamp) throws IOException {
        if (System.nanoTime() >= 0) {
            synchronized (this) {
                cachedVideoConfig = avcc == null ? null : avcc.clone();
            }
            ensureClientsOrReconnect();
            sendVideoConfigDirect(avcc, timestamp);
            if (!videoConfigLogged) {
                videoConfigLogged = true;
                listener.onStatus("已发送 H.264 视频头。");
            }
            return;
        }
        for (RtmpClient client : snapshotClients()) client.sendVideoConfig(avcc, timestamp);
        if (!videoConfigLogged) {
            videoConfigLogged = true;
            listener.onStatus("已发送 H.264 视频头。");
        }
    }

    private void sendMetadata(int width, int height, int frameRate, int bitrate, int timestamp) throws IOException {
        if (System.nanoTime() >= 0) {
            synchronized (this) {
                hasMetadata = true;
                metadataWidth = width;
                metadataHeight = height;
                metadataFrameRate = frameRate;
                metadataBitrate = bitrate;
            }
            ensureClientsOrReconnect();
            sendMetadataDirect(width, height, frameRate, bitrate, timestamp);
            listener.onStatus("已发送直播元数据：" + width + "x" + height);
            return;
        }
        for (RtmpClient client : snapshotClients()) client.sendMetadata(width, height, frameRate, bitrate, timestamp);
        listener.onStatus("已发送直播元数据：" + width + "x" + height);
    }

    private void sendMetadataDirect(int width, int height, int frameRate, int bitrate, int timestamp) throws IOException {
        boolean sent = false;
        IOException lastError = null;
        for (RtmpClient client : snapshotClients()) {
            try {
                client.sendMetadata(width, height, frameRate, bitrate, timestamp);
                sent = true;
            } catch (IOException e) {
                lastError = e;
                removeClient(client);
            }
        }
        if (!sent) throw lastError == null ? new IOException("没有可用的 RTMP 连接") : lastError;
    }

    private void sendVideoConfigDirect(byte[] avcc, int timestamp) throws IOException {
        boolean sent = false;
        IOException lastError = null;
        for (RtmpClient client : snapshotClients()) {
            try {
                client.sendVideoConfig(avcc, timestamp);
                sent = true;
            } catch (IOException e) {
                lastError = e;
                removeClient(client);
            }
        }
        if (!sent) throw lastError == null ? new IOException("没有可用的 RTMP 连接") : lastError;
    }

    private void sendAudioConfigDirect(byte[] config, int timestamp) throws IOException {
        boolean sent = false;
        IOException lastError = null;
        for (RtmpClient client : snapshotClients()) {
            try {
                client.sendAudioConfig(config, timestamp);
                sent = true;
            } catch (IOException e) {
                lastError = e;
                removeClient(client);
            }
        }
        if (!sent) throw lastError == null ? new IOException("没有可用的 RTMP 连接") : lastError;
    }

    private void sendVideoFrame(byte[] sample, boolean key, int timestamp) throws IOException {
        if (System.nanoTime() >= 0) {
            sendVideoFrameUnlocked(sample, key, timestamp);
            return;
        }
        synchronized (clients) {
            for (Iterator<RtmpClient> it = clients.iterator(); it.hasNext();) {
                RtmpClient client = it.next();
                try {
                    client.sendVideoFrame(sample, key, timestamp);
                } catch (IOException e) {
                    listener.onStatus("视频推流地址断开：" + e.getMessage());
                    client.close();
                    it.remove();
                }
            }
            if (clients.size() == 0) throw new IOException("所有推流地址都已断开");
        }
        if (!firstVideoFrameLogged) {
            firstVideoFrameLogged = true;
            listener.onStatus("已发送首个视频帧。");
        }
    }

    private void sendAudioConfig(byte[] config, int timestamp) throws IOException {
        if (System.nanoTime() >= 0) {
            synchronized (this) {
                cachedAudioConfig = config == null ? null : config.clone();
            }
            ensureClientsOrReconnect();
            sendAudioConfigDirect(config, timestamp);
            return;
        }
        for (RtmpClient client : snapshotClients()) client.sendAudioConfig(config, timestamp);
    }

    private void sendAudioFrame(byte[] sample, int timestamp) throws IOException {
        if (System.nanoTime() >= 0) {
            sendAudioFrameUnlocked(sample, timestamp);
            return;
        }
        synchronized (clients) {
            if (clients.size() == 0) return;
            for (Iterator<RtmpClient> it = clients.iterator(); it.hasNext();) {
                RtmpClient client = it.next();
                try {
                    client.sendAudioFrame(sample, timestamp);
                } catch (IOException e) {
                    client.close();
                    it.remove();
                }
            }
            if (clients.size() == 0) throw new IOException("所有推流地址都已断开");
        }
    }

    private void sendVideoFrameWithReconnect(byte[] sample, boolean key, int timestamp) throws IOException {
        ensureClientsOrReconnect();
        if (!sendVideoFrameOnce(sample, key, timestamp, true)) {
            ensureClientsOrReconnect();
            if (!sendVideoFrameOnce(sample, key, timestamp, true)) {
                throw new IOException("视频帧发送失败");
            }
        }
        if (!firstVideoFrameLogged) {
            firstVideoFrameLogged = true;
            listener.onStatus("已发送首个视频帧。");
        }
    }

    private boolean sendVideoFrameOnce(byte[] sample, boolean key, int timestamp, boolean reportError) {
        boolean sent = false;
        for (RtmpClient client : snapshotClients()) {
            try {
                client.sendVideoFrame(sample, key, timestamp);
                sent = true;
            } catch (IOException e) {
                if (reportError) listener.onStatus("视频推流地址断开：" + e.getMessage());
                removeClient(client);
            }
        }
        return sent;
    }

    private void sendAudioFrameWithReconnect(byte[] sample, int timestamp) throws IOException {
        ensureClientsOrReconnect();
        if (!sendAudioFrameOnce(sample, timestamp)) {
            ensureClientsOrReconnect();
            if (!sendAudioFrameOnce(sample, timestamp)) {
                throw new IOException("音频帧发送失败");
            }
        }
    }

    private boolean sendAudioFrameOnce(byte[] sample, int timestamp) {
        boolean sent = false;
        for (RtmpClient client : snapshotClients()) {
            try {
                client.sendAudioFrame(sample, timestamp);
                sent = true;
            } catch (IOException e) {
                removeClient(client);
            }
        }
        return sent;
    }

    private void sendVideoFrameUnlocked(byte[] sample, boolean key, int timestamp) throws IOException {
        if (System.nanoTime() >= 0) {
            sendVideoFrameWithReconnect(sample, key, timestamp);
            return;
        }
        List<RtmpClient> targets = snapshotClients();
        for (RtmpClient client : targets) {
            try {
                client.sendVideoFrame(sample, key, timestamp);
            } catch (IOException e) {
                listener.onStatus("视频推流地址断开：" + e.getMessage());
                removeClient(client);
            }
        }
        throwIfNoClients();
        if (!firstVideoFrameLogged) {
            firstVideoFrameLogged = true;
            listener.onStatus("已发送首个视频帧。");
        }
    }

    private void sendAudioFrameUnlocked(byte[] sample, int timestamp) throws IOException {
        if (System.nanoTime() >= 0) {
            sendAudioFrameWithReconnect(sample, timestamp);
            return;
        }
        List<RtmpClient> targets = snapshotClients();
        if (targets.size() == 0) return;
        for (RtmpClient client : targets) {
            try {
                client.sendAudioFrame(sample, timestamp);
            } catch (IOException e) {
                removeClient(client);
            }
        }
        throwIfNoClients();
    }

    private List<RtmpClient> snapshotClients() {
        synchronized (clients) {
            return new ArrayList<RtmpClient>(clients);
        }
    }

    private void removeClient(RtmpClient client) {
        client.close();
        synchronized (clients) {
            clients.remove(client);
        }
    }

    private void throwIfNoClients() throws IOException {
        synchronized (clients) {
            if (clients.size() == 0) throw new IOException("所有推流地址都已断开");
        }
    }

    private byte[] annexBToAvccSample(byte[] sample) {
        if (!startsWithStartCode(sample, 0)) return sample;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int pos = nextNalStart(sample, 0);
        while (pos >= 0) {
            int nalStart = pos + startCodeLength(sample, pos);
            int next = nextNalStart(sample, nalStart);
            int nalEnd = next >= 0 ? next : sample.length;
            int len = nalEnd - nalStart;
            if (len > 0) {
                int nalType = sample[nalStart] & 0x1f;
                if (nalType != 7 && nalType != 8 && nalType != 9) {
                    out.write((len >> 24) & 0xff);
                    out.write((len >> 16) & 0xff);
                    out.write((len >> 8) & 0xff);
                    out.write(len & 0xff);
                    out.write(sample, nalStart, len);
                }
            }
            pos = next;
        }
        byte[] data = out.toByteArray();
        return data.length == 0 ? sample : data;
    }

    private boolean startsWithStartCode(byte[] data, int offset) {
        return offset + 3 < data.length
                && data[offset] == 0
                && data[offset + 1] == 0
                && ((data[offset + 2] == 1) || (offset + 4 < data.length && data[offset + 2] == 0 && data[offset + 3] == 1));
    }

    private int startCodeLength(byte[] data, int offset) {
        return offset + 3 < data.length && data[offset] == 0 && data[offset + 1] == 0 && data[offset + 2] == 1 ? 3 : 4;
    }

    private int nextNalStart(byte[] data, int from) {
        for (int i = Math.max(0, from); i + 3 < data.length; i++) {
            if (data[i] == 0 && data[i + 1] == 0 && (data[i + 2] == 1 || (i + 4 < data.length && data[i + 2] == 0 && data[i + 3] == 1))) {
                return i;
            }
        }
        return -1;
    }

    private byte[] audioConfig(MediaFormat format) {
        ByteBuffer csd = format.getByteBuffer("csd-0");
        if (csd == null) return new byte[]{0x12, 0x10};
        ByteBuffer copy = csd.duplicate();
        byte[] data = new byte[copy.remaining()];
        copy.get(data);
        return data;
    }

    private byte[] makeAvcc(MediaFormat format) {
        byte[] sps = stripStartCode(format.getByteBuffer("csd-0"));
        byte[] pps = stripStartCode(format.getByteBuffer("csd-1"));
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(1);
        out.write(sps.length > 3 ? sps[1] & 0xff : 0x64);
        out.write(sps.length > 4 ? sps[2] & 0xff : 0);
        out.write(sps.length > 5 ? sps[3] & 0xff : 0x1f);
        out.write(0xff);
        out.write(0xe1);
        out.write((sps.length >> 8) & 0xff);
        out.write(sps.length & 0xff);
        out.write(sps, 0, sps.length);
        out.write(1);
        out.write((pps.length >> 8) & 0xff);
        out.write(pps.length & 0xff);
        out.write(pps, 0, pps.length);
        return out.toByteArray();
    }

    private byte[] stripStartCode(ByteBuffer buffer) {
        if (buffer == null) return new byte[0];
        ByteBuffer copy = buffer.duplicate();
        byte[] data = new byte[copy.remaining()];
        copy.get(data);
        if (data.length > 4 && data[0] == 0 && data[1] == 0 && data[2] == 0 && data[3] == 1) {
            return Arrays.copyOfRange(data, 4, data.length);
        }
        if (data.length > 3 && data[0] == 0 && data[1] == 0 && data[2] == 1) {
            return Arrays.copyOfRange(data, 3, data.length);
        }
        return data;
    }
}
