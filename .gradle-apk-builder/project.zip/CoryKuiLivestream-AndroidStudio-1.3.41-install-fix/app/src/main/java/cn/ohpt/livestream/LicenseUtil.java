package cn.ohpt.livestream;

import android.util.Base64;

import java.nio.charset.Charset;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class LicenseUtil {
    static final String VERSION = "CKLIVE1";
    static final String LOCAL_VERSION = "CKLIVELOCAL1";
    private static final String PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsks003RoCbsBMC4NkMLgH8nEoKttj6g/zAMBoquCFHfO+pVU9mPXy6BbsjDnD3gD05hIorbVfat9BAtDaJ6V6CwxtdNKdjDpzxYDO5OoPoZ8Qo/sDoA+jU8wGBMFABKKE88J/D/F3v203XpWkj9HPjEnAbJnRNlwzRZM5dingEhH6Odhhm5GyAxRrpm4tCxiAhSYLo/0Fnz70PwRfLaVNmmiT0cKwCHli96tttxPLSe5cdQCYSy1H4hY5ajoy05dN/fST5akWmlaJOopS099Xe+nYzYLxqLDpS6B3r6m2uSq5aIqZ0HF2R4BWnHL2N5RbYb8nEdrWEOMvYc/Fg/hEQIDAQAB";

    static Result verify(String typedUser, String serial) {
        return verify(typedUser, serial, new Date());
    }

    static Result verify(String typedUser, String serial, Date now) {
        Result result = new Result();
        try {
            String[] parts = serial == null ? new String[0] : serial.trim().split("\\.");
            if (parts.length != 5) return result.fail("序列号格式错误");
            String version = parts[0];
            if (!VERSION.equals(version) && !LOCAL_VERSION.equals(version)) return result.fail("序列号格式错误");
            String user = new String(Base64.decode(parts[1], Base64.URL_SAFE | Base64.NO_WRAP), "UTF-8");
            String expiry = parts[2];
            String nonce = parts[3];
            byte[] signature = Base64.decode(parts[4], Base64.URL_SAFE | Base64.NO_WRAP);
            if (typedUser == null || !typedUser.trim().equals(user)) return result.fail("用户名与序列号不匹配");
            KeyFactory factory = KeyFactory.getInstance("RSA");
            PublicKey publicKey = factory.generatePublic(new X509EncodedKeySpec(Base64.decode(PUBLIC_KEY, Base64.NO_WRAP)));
            Signature verifier = Signature.getInstance("SHA256withRSA");
            verifier.initVerify(publicKey);
            verifier.update(data(version, user, expiry, nonce).getBytes(Charset.forName("UTF-8")));
            if (!verifier.verify(signature)) return result.fail("序列号签名无效");
            if (isExpired(expiry, now)) return result.fail("序列号已过期");
            result.ok = true;
            result.local = LOCAL_VERSION.equals(version);
            result.username = user;
            result.expiry = expiry;
            return result;
        } catch (Exception e) {
            return result.fail("序列号无法识别");
        }
    }

    static boolean isLocalSerial(String serial) {
        return serial != null && serial.trim().startsWith(LOCAL_VERSION + ".");
    }

    static String data(String user, String expiry, String nonce) {
        return data(VERSION, user, expiry, nonce);
    }

    static String data(String version, String user, String expiry, String nonce) {
        return version + "|" + user + "|" + expiry + "|" + nonce;
    }

    static String prettyDate(String value) {
        if (value == null) return "";
        if (value.length() == 14) {
            return value.substring(0, 4) + "-" + value.substring(4, 6) + "-" + value.substring(6, 8)
                    + " " + value.substring(8, 10) + ":" + value.substring(10, 12) + ":" + value.substring(12, 14);
        }
        if (value.length() == 8) return value.substring(0, 4) + "-" + value.substring(4, 6) + "-" + value.substring(6);
        return value;
    }

    private static boolean isExpired(String value, Date now) {
        try {
            Date expiry;
            if (value != null && value.length() == 14) {
                expiry = new SimpleDateFormat("yyyyMMddHHmmss", Locale.US).parse(value);
                return expiry.before(now == null ? new Date() : now);
            }
            expiry = new SimpleDateFormat("yyyyMMdd", Locale.US).parse(value);
            Date base = now == null ? new Date() : now;
            Date today = new SimpleDateFormat("yyyyMMdd", Locale.US)
                    .parse(new SimpleDateFormat("yyyyMMdd", Locale.US).format(base));
            return expiry.before(today);
        } catch (Exception e) {
            return true;
        }
    }

    static final class Result {
        boolean ok;
        boolean local;
        String username = "";
        String expiry = "";
        String error = "";

        Result fail(String message) {
            ok = false;
            error = message;
            return this;
        }
    }
}
