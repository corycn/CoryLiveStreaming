@echo off
setlocal
cd /d "%~dp0"
call gradlew.bat clean assembleRelease
if errorlevel 1 (
  echo.
  echo Build failed. Open this project in Android Studio and install SDK Platform 35.
  pause
  exit /b 1
)
echo.
echo Signed APK created at:
echo app\build\outputs\apk\release\app-release.apk
pause
