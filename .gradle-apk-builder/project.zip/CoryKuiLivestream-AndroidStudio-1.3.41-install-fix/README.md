# 小魁直播 Android Studio 1.3.41 安装修复版

此版本修复了 **Release APK 未签名导致“App not installed / 应用未安装”** 的问题。

## 已修复

- Release 构建自动使用项目内固定密钥签名，不再生成不可安装的 `app-release-unsigned.apk`。
- 同时启用 APK v1、v2、v3 签名，兼容 Android 6.0 及以上。
- `versionCode` 更新为 `168`，`versionName` 更新为 `1.3.41-fix1`。
- 移除了 Manifest 中强制开启的 `android:debuggable="true"`。
- Debug 版本使用 `cn.ohpt.livestream.debug`，避免与正式版混淆。

## 生成可安装 APK

### Android Studio

1. 打开此项目，等待 Gradle 同步完成。
2. 菜单选择 **Build > Build Bundle(s) / APK(s) > Build APK(s)**。
3. 确认当前 Build Variant 为 `release`，或执行 Gradle 任务 `assembleRelease`。
4. 安装这个文件：

   `app/build/outputs/apk/release/app-release.apk`

不要安装名称中含 `unsigned` 的 APK。

### Windows 一键构建

双击 `build-release-signed.bat`。

### macOS / Linux

运行：

```sh
./build-release-signed.sh
```

## 签名密钥

为保证以后可覆盖升级，请始终保留以下两个文件且不要更换：

- `keystore.properties`
- `signing/xiaokui-release.jks`

该密钥用于私人测试/分发。正式上架应用商店时应创建并妥善保管独立的发布密钥。
