#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
./gradlew clean assembleRelease
printf '\nSigned APK created at:\napp/build/outputs/apk/release/app-release.apk\n'
