package com.corykui.wifispeed.records;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class TrackingRestartReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        Intent service = new Intent(context, TrackingForegroundService.class);
        try { if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service); else context.startService(service); } catch (Exception ignored) { }
    }
}
