package com.example.gradleapkbuilder;

import android.os.Build;
import org.apache.commons.compress.archivers.ar.ArArchiveEntry;
import org.apache.commons.compress.archivers.ar.ArArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream;

import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.regex.*;

/** Installs an Android-native Termux PRoot plus an official Alpine mini rootfs. */
final class ProotRuntimeInstaller {
    interface Progress { void onProgress(String message,long done,long total); }

    private static final String[] TERMUX_REPOS = {
            "https://packages.termux.dev/apt/termux-main/",
            "https://packages-cf.termux.dev/apt/termux-main/",
            "https://mirror.iscas.ac.cn/termux/apt/termux-main/",
            "https://mirrors.ustc.edu.cn/termux/apt/termux-main/"
    };
    private static final String ALPINE_INDEX =
            "https://dl-cdn.alpinelinux.org/alpine/latest-stable/releases/aarch64/";

    static void install(File bundleDir, File downloadsDir, Progress progress) throws Exception {
        if (!Arrays.asList(Build.SUPPORTED_ABIS).contains("arm64-v8a")) {
            throw new IOException("PRoot 自动安装首版仅支持 arm64-v8a 设备");
        }
        mkdirs(downloadsDir);
        File staging = new File(bundleDir.getParentFile(), "proot-staging-" + System.currentTimeMillis());
        deleteTree(staging); mkdirs(staging);
        File prefix = new File(staging, "termux-prefix"); mkdirs(prefix);
        File rootfs = new File(staging, "rootfs"); mkdirs(rootfs);
        try {
            if (progress != null) progress.onProgress("正在查询 Termux 官方 PRoot 软件包…",0,-1);
            RepoIndex repo = fetchTermuxIndex(progress);
            String packages = repo.packages;
            Map<String,Pkg> all = parsePackages(packages);
            LinkedHashSet<String> wanted = new LinkedHashSet<>();
            resolve("proot", all, wanted);
            int index=0;
            for (String name : wanted) {
                Pkg pkg=all.get(name); if(pkg==null) continue;
                index++;
                File deb=new File(downloadsDir,name+"_"+pkg.version+".deb.part");
                download(new URL(repo.base + pkg.filename), deb, progress,
                        "["+index+"/"+wanted.size()+"] 下载 Termux "+name+"…");
                verifySha256(deb,pkg.sha256);
                extractDeb(deb,prefix,progress,name);
                deb.delete();
            }
            File proot=findNamed(prefix,"proot");
            if(proot==null||!proot.isFile()) throw new IOException("Termux 软件包已解压，但未找到 proot");
            File actualPrefix=proot.getParentFile()==null?null:proot.getParentFile().getParentFile();
            if(actualPrefix==null)throw new IOException("无法识别 Termux PREFIX 目录");
            if(!actualPrefix.getCanonicalFile().equals(prefix.getCanonicalFile())){
                File normalized=new File(staging,"termux-prefix-normalized");
                deleteTreeLenient(normalized);
                copyTree(actualPrefix,normalized);

                // Do not recursively delete the raw package tree before replacing it.
                // Termux packages contain symlinks and special directory layouts under usr/lib;
                // Android may refuse recursive deletion even though an atomic rename succeeds.
                File rawPrefix=new File(staging,"termux-prefix-raw-"+System.currentTimeMillis());
                deleteTreeLenient(rawPrefix);
                if(!prefix.renameTo(rawPrefix)){
                    // If rename is unavailable, keep the raw tree as a non-fatal residue and
                    // place the normalized tree under the canonical runtime directory by copy.
                    deleteTreeLenient(prefix);
                    if(prefix.exists())throw new IOException("无法替换原始 Termux PREFIX："+prefix);
                }
                if(!normalized.renameTo(prefix)){
                    copyTree(normalized,prefix);
                    deleteTreeLenient(normalized);
                }
                // Raw package metadata is unnecessary at runtime. Failure to remove it must
                // not invalidate an otherwise working PRoot installation.
                deleteTreeLenient(rawPrefix);
                proot=findNamed(prefix,"proot");
            }

            File prootLoader=findProotLoader(prefix);
            if(prootLoader==null||!prootLoader.isFile()){
                throw new IOException("Termux PRoot 软件包缺少 libexec/proot/loader");
            }
            chmod(proot);
            chmod(prootLoader);

            if(progress!=null)progress.onProgress("正在查询 Alpine 官方 ARM64 mini rootfs…",0,-1);
            String html=new String(getBytes(ALPINE_INDEX,"text/html",2_000_000),"UTF-8");
            String rootName=findLatestMiniRootfs(html);
            String rootUrl=ALPINE_INDEX+rootName;
            String checksumText=new String(getBytes(rootUrl+".sha256","text/plain",4096),"UTF-8");
            String rootSha=checksumText.trim().split("\\s+")[0];
            File rootArchive=new File(downloadsDir,rootName+".part");
            download(new URL(rootUrl),rootArchive,progress,"正在下载 Alpine Linux rootfs…");
            verifySha256(rootArchive,rootSha);
            extractTarGz(rootArchive,rootfs,progress); rootArchive.delete();
            validateRootfs(rootfs);

            Properties p=new Properties();
            p.setProperty("version","Termux-proot + "+rootName.replace(".tar.gz",""));
            p.setProperty("abi","arm64-v8a");
            p.setProperty("prootPackage",all.get("proot").version);
            p.setProperty("rootfs",rootName);
            p.setProperty("source",repo.base+" + dl-cdn.alpinelinux.org");
            p.setProperty("jdk","使用 components/jdk 或 rootfs 内自备 JDK");
            p.setProperty("androidSdk","使用 components/android-sdk");
            try(OutputStream out=new FileOutputStream(new File(staging,"bundle.properties"))){p.store(out,"GradleApkBuilder PRoot runtime");}

            markExecutables(prefix);
            deleteTree(bundleDir);
            if(!staging.renameTo(bundleDir)){copyTree(staging,bundleDir);deleteTree(staging);}
            if(progress!=null)progress.onProgress("PRoot Linux 兼容环境安装完成",1,1);
        } catch(Exception e) { try{deleteTreeLenient(staging);}catch(Exception ignored){} throw e; }
    }


    private static final class RepoIndex { final String base, packages; RepoIndex(String b,String p){base=b;packages=p;} }
    private static RepoIndex fetchTermuxIndex(Progress progress) throws Exception {
        ArrayList<String> errors = new ArrayList<>();
        for (String base : TERMUX_REPOS) {
            String[] names = {"dists/stable/main/binary-aarch64/Packages", "dists/stable/main/binary-aarch64/Packages.xz"};
            for (String name : names) {
                String url = base + name;
                try {
                    if(progress!=null)progress.onProgress("正在尝试 Termux 镜像："+new URL(base).getHost(),0,-1);
                    byte[] data=getBytes(url,"application/octet-stream",30_000_000);
                    String text=name.endsWith(".xz")?decompressXzText(data):new String(data,"UTF-8");
                    if(text.contains("Package: proot\n") || text.contains("Package: proot\r\n")) return new RepoIndex(base,text);
                    errors.add(url+"：索引中没有 proot");
                } catch(Exception e){ errors.add(url+"："+e.getMessage()); }
            }
        }
        throw new IOException("所有 Termux 官方/备用镜像均不可用。\n"+joinErrors(errors));
    }
    private static String joinErrors(List<String> xs){StringBuilder b=new StringBuilder();for(String x:xs)b.append("• ").append(x).append('\n');return b.toString();}

    private static final class Pkg {String name,version,filename,sha256,depends;}
    private static Map<String,Pkg> parsePackages(String text){
        LinkedHashMap<String,Pkg> map=new LinkedHashMap<>();
        for(String block:text.split("\\n\\n+")){
            Pkg p=new Pkg();
            for(String line:block.split("\\n")){
                int c=line.indexOf(':'); if(c<1)continue;
                String k=line.substring(0,c),v=line.substring(c+1).trim();
                if(k.equals("Package"))p.name=v; else if(k.equals("Version"))p.version=v;
                else if(k.equals("Filename"))p.filename=v; else if(k.equals("SHA256"))p.sha256=v;
                else if(k.equals("Depends"))p.depends=v;
            }
            if(p.name!=null&&p.filename!=null&&p.sha256!=null)map.put(p.name,p);
        }
        return map;
    }
    private static void resolve(String name,Map<String,Pkg> all,LinkedHashSet<String> out)throws IOException{
        name=name.trim().replaceAll("\\s*\\(.*?\\)","");
        if(name.contains("|"))name=name.substring(0,name.indexOf('|')).trim();
        if(name.isEmpty()||out.contains(name)||name.startsWith("libc"))return;
        Pkg p=all.get(name); if(p==null)throw new IOException("Termux 软件源缺少依赖："+name);
        if(p.depends!=null)for(String d:p.depends.split(","))resolve(d,all,out);
        out.add(name);
    }
    private static String findLatestMiniRootfs(String html)throws IOException{
        Matcher m=Pattern.compile("alpine-minirootfs-([0-9]+\\.[0-9]+\\.[0-9]+)-aarch64\\.tar\\.gz").matcher(html);
        String best=null,bestVer=null;
        while(m.find()){String file=m.group(),ver=m.group(1);if(best==null||compare(ver,bestVer)>0){best=file;bestVer=ver;}}
        if(best==null)throw new IOException("Alpine 官方目录中未找到 ARM64 mini rootfs");
        return best;
    }
    private static int compare(String a,String b){String[]x=a.split("\\."),y=b.split("\\.");for(int i=0;i<Math.max(x.length,y.length);i++){int p=i<x.length?Integer.parseInt(x[i]):0,q=i<y.length?Integer.parseInt(y[i]):0;if(p!=q)return Integer.compare(p,q);}return 0;}

    private static void extractDeb(File deb,File prefix,Progress progress,String name)throws Exception{
        try(ArArchiveInputStream ar=new ArArchiveInputStream(new BufferedInputStream(new FileInputStream(deb)))){
            ArArchiveEntry e;boolean found=false;
            while((e=ar.getNextArEntry())!=null){String n=e.getName();if(n.startsWith("data.tar")){found=true;InputStream data=ar;if(n.endsWith(".xz"))data=new XZCompressorInputStream(ar,true);else if(n.endsWith(".gz"))data=new GzipCompressorInputStream(ar,true);extractTar(data,prefix,progress,"解压 "+name);break;}}
            if(!found)throw new IOException(name+" DEB 中没有 data.tar");
        }
    }
    private static void extractTarGz(File archive,File root,Progress p)throws Exception{try(InputStream in=new GzipCompressorInputStream(new BufferedInputStream(new FileInputStream(archive)),true)){extractTar(in,root,p,"解压 Linux rootfs");}}
    private static void extractTar(InputStream in,File root,Progress p,String message)throws Exception {
        ArrayList<PendingLink> links = new ArrayList<>();
        try (TarArchiveInputStream tar = new TarArchiveInputStream(in)) {
            TarArchiveEntry e;
            byte[] b = new byte[65536];
            long count = 0;
            while ((e = tar.getNextTarEntry()) != null) {
                String name = safe(e.getName());
                if (name.isEmpty()) continue;
                // Documentation and man-page payloads are not required by PRoot at runtime.
                // Across separate Termux DEBs, one package may create a documentation
                // symlink before another package writes a file beneath the same path.
                // Android then follows the dangling link and FileOutputStream fails with
                // ENOENT. Skip these non-runtime trees entirely.
                if (isNonRuntimeDocumentation(name)) {
                    continue;
                }

                File dst = new File(root, name);
                inside(root, dst);

                if (e.isDirectory()) {
                    mkdirs(dst);
                    applyArchiveMode(dst, e.getMode(), true);
                } else if (e.isSymbolicLink() || e.isLink()) {
                    // Termux packages may place files below a path that is also represented
                    // by a symlink. Creating links immediately can make later FileOutputStream
                    // calls follow a target that has not been extracted yet and fail with ENOENT.
                    // Defer every link until all regular files and directories exist.
                    links.add(new PendingLink(dst, e.getLinkName(), e.isSymbolicLink()));
                } else {
                    mkdirs(dst.getParentFile());
                    try (OutputStream out = new FileOutputStream(dst)) {
                        int n;
                        while ((n = tar.read(b)) >= 0) out.write(b, 0, n);
                    }
                    applyArchiveMode(dst, e.getMode(), false);
                }
                count++;
                if (p != null && count % 50 == 0) {
                    // Report actual uncompressed TAR bytes instead of entry count. The UI
                    // formats the numeric value as bytes, so reporting the entry count made a
                    // healthy rootfs extraction appear as only a few hundred bytes.
                    p.onProgress(message + "…", tar.getBytesRead(), -1);
                }
            }
        }

        for (PendingLink link : links) createDeferredLink(root, link);
    }

    private static boolean isNonRuntimeDocumentation(String name) {
        String n = name.replace('\\', '/');
        while (n.startsWith("./")) n = n.substring(2);
        return n.startsWith("data/data/com.termux/files/usr/share/doc/")
                || n.equals("data/data/com.termux/files/usr/share/doc")
                || n.startsWith("data/data/com.termux/files/usr/share/man/")
                || n.equals("data/data/com.termux/files/usr/share/man")
                || n.startsWith("data/data/com.termux/files/usr/share/info/")
                || n.equals("data/data/com.termux/files/usr/share/info");
    }

    private static final class PendingLink {
        final File destination;
        final String target;
        final boolean symbolic;
        PendingLink(File destination, String target, boolean symbolic) {
            this.destination = destination;
            this.target = target;
            this.symbolic = symbolic;
        }
    }

    private static void createDeferredLink(File root, PendingLink link) throws IOException {
        mkdirs(link.destination.getParentFile());
        deleteTreeLenient(link.destination);
        try {
            if (link.symbolic) {
                android.system.Os.symlink(link.target, link.destination.getAbsolutePath());
            } else {
                File target = new File(root, safe(link.target));
                inside(root, target);
                android.system.Os.link(target.getAbsolutePath(), link.destination.getAbsolutePath());
            }
        } catch (Throwable error) {
            // Documentation links are not required to run PRoot. Ignore only missing
            // doc targets; fail for executable/runtime links so broken installs are not hidden.
            String path = link.destination.getAbsolutePath().replace('\\', '/');
            if (!path.contains("/usr/share/doc/") && !path.contains("/usr/share/man/")) {
                throw new IOException("无法创建软件包链接：" + link.destination + " -> " + link.target, error);
            }
        }
    }

    /**
     * Alpine stores /bin/sh as a symbolic link to BusyBox. On the Android host, an
     * absolute link such as /bin/busybox is resolved against Android's own root and
     * File.isFile() therefore reports false, even though PRoot will resolve it inside
     * the guest rootfs. Validate with lstat and normalize the well-known shell link to
     * a relative target so status checks, backup/export and later imports remain stable.
     */
    private static void validateRootfs(File rootfs) throws IOException {
        File bin = new File(rootfs, "bin");
        File busybox = new File(bin, "busybox");
        File shell = new File(bin, "sh");

        if (!pathExistsNoFollow(busybox) || busybox.isDirectory() || busybox.length() == 0) {
            throw new IOException("rootfs 解压不完整：缺少有效的 /bin/busybox");
        }
        chmod(busybox);

        if (!pathExistsNoFollow(shell)) {
            mkdirs(bin);
            try {
                android.system.Os.symlink("busybox", shell.getAbsolutePath());
            } catch (Throwable error) {
                // A regular copy is a safe fallback. It uses more space but guarantees
                // that /bin/sh exists even on devices/filesystems rejecting symlinks.
                copyFile(busybox, shell);
                chmod(shell);
            }
        } else if (isLinkNoFollow(shell)) {
            try {
                String target = android.system.Os.readlink(shell.getAbsolutePath());
                if ("/bin/busybox".equals(target)) {
                    deleteTreeLenient(shell);
                    try {
                        android.system.Os.symlink("busybox", shell.getAbsolutePath());
                    } catch (Throwable linkError) {
                        copyFile(busybox, shell);
                        chmod(shell);
                    }
                }
            } catch (Throwable ignored) {
                // The link exists. PRoot can still resolve an absolute guest link.
            }
        }

        if (!pathExistsNoFollow(shell)) {
            throw new IOException("rootfs 解压完成但缺少 /bin/sh");
        }

        // Android 15/16 devices are stricter about executing files restored from
        // archives. Explicitly restore executable modes for BusyBox, guest shells,
        // loader targets and standard command directories.
        repairRootfsRuntimePermissions(rootfs);
    }

    private static void applyArchiveMode(File file, int archiveMode, boolean directory) {
        int mode = archiveMode & 07777;
        if (mode == 0) mode = directory ? 0755 : 0644;
        if (directory) mode |= 0700;
        else mode |= 0600;
        try {
            android.system.Os.chmod(file.getAbsolutePath(), mode);
        } catch (Throwable ignored) {
            file.setReadable(true, false);
            file.setWritable(true, true);
            if ((mode & 0111) != 0) file.setExecutable(true, false);
        }
    }

    private static void repairRootfsRuntimePermissions(File rootfs) {
        chmodDirectory(new File(rootfs, "bin"));
        chmodDirectory(new File(rootfs, "sbin"));
        chmodDirectory(new File(rootfs, "usr"));
        chmodDirectory(new File(rootfs, "usr/bin"));
        chmodDirectory(new File(rootfs, "usr/sbin"));
        chmodDirectory(new File(rootfs, "lib"));

        markDirectoryChildrenExecutable(new File(rootfs, "bin"));
        markDirectoryChildrenExecutable(new File(rootfs, "sbin"));
        markDirectoryChildrenExecutable(new File(rootfs, "usr/bin"));
        markDirectoryChildrenExecutable(new File(rootfs, "usr/sbin"));

        chmodGuestLinkTarget(rootfs, new File(rootfs, "bin/sh"));
        chmodGuestLinkTarget(rootfs, new File(rootfs, "lib/ld-musl-aarch64.so.1"));
        chmodGuestLinkTarget(rootfs, new File(rootfs, "lib/libc.musl-aarch64.so.1"));
        chmodGuestLinkTarget(rootfs, new File(rootfs, "usr/lib/libc.musl-aarch64.so.1"));
    }

    private static void chmodDirectory(File directory) {
        if (directory == null || !directory.isDirectory()) return;
        try {
            android.system.Os.chmod(directory.getAbsolutePath(), 0755);
        } catch (Throwable ignored) {
            directory.setReadable(true, false);
            directory.setWritable(true, true);
            directory.setExecutable(true, false);
        }
    }

    private static void markDirectoryChildrenExecutable(File directory) {
        File[] files = directory == null ? null : directory.listFiles();
        if (files == null) return;
        for (File file : files) {
            if (file.isDirectory()) chmodDirectory(file);
            else if (!isLinkNoFollow(file)) chmod(file);
        }
    }

    private static void chmodGuestLinkTarget(File rootfs, File path) {
        if (!pathExistsNoFollow(path)) return;
        if (!isLinkNoFollow(path)) {
            chmod(path);
            return;
        }
        try {
            String target = android.system.Os.readlink(path.getAbsolutePath());
            File resolved = target.startsWith("/")
                    ? new File(rootfs, target.substring(1))
                    : new File(path.getParentFile(), target);
            inside(rootfs, resolved);
            if (pathExistsNoFollow(resolved) && !isLinkNoFollow(resolved)) chmod(resolved);
        } catch (Throwable ignored) {
            // Detailed failure is reported by the final PRoot self-test.
        }
    }

    private static void copyFile(File source, File destination) throws IOException {
        mkdirs(destination.getParentFile());
        try (InputStream in = new BufferedInputStream(new FileInputStream(source));
             OutputStream out = new BufferedOutputStream(new FileOutputStream(destination))) {
            byte[] buffer = new byte[65536];
            int count;
            while ((count = in.read(buffer)) >= 0) out.write(buffer, 0, count);
        }
    }

    private static String decompressXzText(byte[] bytes)throws Exception{try(InputStream in=new XZCompressorInputStream(new ByteArrayInputStream(bytes),true);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[]b=new byte[16384];int n;while((n=in.read(b))>=0)out.write(b,0,n);return out.toString("UTF-8");}}
    private static byte[] getBytes(String u,String accept,int max)throws Exception{URL cur=new URL(u);for(int r=0;r<8;r++){HttpURLConnection c=(HttpURLConnection)cur.openConnection();c.setConnectTimeout(25000);c.setReadTimeout(90000);c.setInstanceFollowRedirects(false);c.setRequestProperty("User-Agent","GradleApkBuilder/1.8.2");c.setRequestProperty("Accept",accept);int code=c.getResponseCode();if(code>=300&&code<400){String l=c.getHeaderField("Location");c.disconnect();if(l==null)throw new IOException("重定向缺少地址");cur=new URL(cur,l);continue;}if(code<200||code>=300)throw new IOException("HTTP "+code+"："+cur);try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[]b=new byte[16384];int n;while((n=in.read(b))>=0){out.write(b,0,n);if(out.size()>max)throw new IOException("下载内容过大");}return out.toByteArray();}finally{c.disconnect();}}throw new IOException("重定向次数过多");}
    private static void download(URL url,File dst,Progress p,String msg)throws Exception{URL cur=url;for(int r=0;r<8;r++){HttpURLConnection c=(HttpURLConnection)cur.openConnection();c.setConnectTimeout(25000);c.setReadTimeout(120000);c.setInstanceFollowRedirects(false);c.setRequestProperty("User-Agent","GradleApkBuilder/1.8.2");int code=c.getResponseCode();if(code>=300&&code<400){String l=c.getHeaderField("Location");c.disconnect();if(l==null)throw new IOException("重定向缺少地址");cur=new URL(cur,l);continue;}if(code<200||code>=300)throw new IOException("下载失败 HTTP "+code+"："+cur);long total=c.getContentLengthLong(),done=0;try(InputStream in=c.getInputStream();OutputStream out=new FileOutputStream(dst)){byte[]b=new byte[65536];int n;while((n=in.read(b))>=0){out.write(b,0,n);done+=n;if(p!=null)p.onProgress(msg,done,total);}}finally{c.disconnect();}return;}throw new IOException("下载重定向次数过多");}
    private static void verifySha256(File f,String expected)throws Exception{String actual=sha256(f);if(!actual.equalsIgnoreCase(expected))throw new SecurityException("下载文件 SHA-256 校验失败\n期望："+expected+"\n实际："+actual);}
    private static String sha256(File f)throws Exception{MessageDigest d=MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(f)){byte[]b=new byte[65536];int n;while((n=in.read(b))>=0)d.update(b,0,n);}StringBuilder s=new StringBuilder();for(byte x:d.digest())s.append(String.format(Locale.US,"%02x",x));return s.toString();}
    private static File findNamed(File f,String name){if(f==null||!f.exists())return null;if(f.isFile()&&f.getName().equals(name))return f;File[]a=f.listFiles();if(a!=null)for(File x:a){File r=findNamed(x,name);if(r!=null)return r;}return null;}
    private static File findProotLoader(File prefix){
        File direct=new File(prefix,"libexec/proot/loader");
        if(direct.isFile())return direct;
        return findBySuffix(prefix,"/libexec/proot/loader");
    }
    private static File findBySuffix(File file,String suffix){
        if(file==null||!file.exists())return null;
        if(file.isFile()&&file.getAbsolutePath().replace('\\','/').endsWith(suffix))return file;
        File[] children=file.listFiles();
        if(children!=null)for(File child:children){File found=findBySuffix(child,suffix);if(found!=null)return found;}
        return null;
    }
    private static void markExecutables(File f){if(f==null||!f.exists())return;if(f.isDirectory()){File[]a=f.listFiles();if(a!=null)for(File x:a)markExecutables(x);}else{File p=f.getParentFile();String path=f.getAbsolutePath().replace('\\','/');if((p!=null&&p.getName().equals("bin"))||f.getName().equals("proot")||path.endsWith("/libexec/proot/loader"))chmod(f);}}
    private static void chmod(File f){try{android.system.Os.chmod(f.getAbsolutePath(),0755);}catch(Throwable ignored){f.setExecutable(true,false);}}
    private static String safe(String n)throws IOException{n=n.replace('\\','/');while(n.startsWith("./"))n=n.substring(2);if(n.startsWith("/")||n.contains("../")||n.equals(".."))throw new IOException("压缩包包含不安全路径");return n;}
    private static void inside(File root,File child)throws IOException{String r=root.getCanonicalPath()+File.separator,c=child.getCanonicalPath();if(!c.startsWith(r))throw new IOException("压缩包路径越界");}
    private static void mkdirs(File f)throws IOException{if(f!=null&&!f.exists()&&!f.mkdirs())throw new IOException("无法创建目录："+f);}
    private static boolean pathExistsNoFollow(File f){
        if(f==null)return false;
        try{android.system.Os.lstat(f.getAbsolutePath());return true;}catch(Throwable ignored){return false;}
    }
    private static boolean isLinkNoFollow(File f){
        try{return android.system.OsConstants.S_ISLNK(android.system.Os.lstat(f.getAbsolutePath()).st_mode);}catch(Throwable ignored){return false;}
    }
    private static void deleteTree(File f)throws IOException{
        if(!pathExistsNoFollow(f))return;
        if(isLinkNoFollow(f)){
            if(!f.delete()&&pathExistsNoFollow(f))throw new IOException("无法删除符号链接："+f);
            return;
        }
        if(f.isDirectory()){
            File[] a=f.listFiles();
            if(a==null){
                try{android.system.Os.chmod(f.getAbsolutePath(),0700);}catch(Throwable ignored){}
                a=f.listFiles();
            }
            if(a!=null)for(File x:a)deleteTree(x);
        }
        if(!f.delete()&&pathExistsNoFollow(f))throw new IOException("无法删除："+f);
    }
    private static void deleteTreeLenient(File f){
        if(!pathExistsNoFollow(f))return;
        try{
            if(!isLinkNoFollow(f)&&f.isDirectory()){
                File[] a=f.listFiles();
                if(a==null){try{android.system.Os.chmod(f.getAbsolutePath(),0700);}catch(Throwable ignored){}a=f.listFiles();}
                if(a!=null)for(File x:a)deleteTreeLenient(x);
            }
            if(!f.delete()&&pathExistsNoFollow(f)){
                try{android.system.Os.chmod(f.getAbsolutePath(),0700);}catch(Throwable ignored){}
                f.delete();
            }
        }catch(Throwable ignored){}
    }
    private static void copyTree(File s,File d)throws IOException{if(s.isDirectory()){mkdirs(d);File[]a=s.listFiles();if(a!=null)for(File x:a)copyTree(x,new File(d,x.getName()));}else{mkdirs(d.getParentFile());try(InputStream in=new FileInputStream(s);OutputStream out=new FileOutputStream(d)){byte[]b=new byte[65536];int n;while((n=in.read(b))>=0)out.write(b,0,n);}}}
}
