package com.corykui.wifispeed.records;

import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.location.Location;
import android.location.Criteria;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaScannerConnection;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.os.PowerManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.util.JsonReader;
import android.util.JsonToken;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.FilterInputStream;
import java.io.BufferedReader;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Date;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.CancellationException;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity implements SensorEventListener {
    private static final int REQ_PERMISSIONS = 1001;
    private static final int REQ_ACTIVITY = 1002;
    private static final int REQ_EXPORT_TRACK = 1003;
    private static final int REQ_IMPORT_TRACK = 1004;
    private static final int REQ_EXPORT_BACKUP = 1005;
    private static final int REQ_EXPORT_BUG_REPORT = 1006;
    private static final int REQ_EXPORT_SYSTEM = 1007;
    private static final int REQ_IMPORT_SYSTEM = 1008;
    private static final long SCAN_TIMEOUT_MS = 8000L;
    public static final String ACTION_BACKGROUND_LOCATION = "com.corykui.wifispeed.records.BACKGROUND_LOCATION";
    public static final String ACTION_BACKGROUND_WIFI = "com.corykui.wifispeed.records.BACKGROUND_WIFI";

    private WifiManager wifiManager;
    private LocationManager locationManager;
    private TextView statusText;
    private TextView detailText;
    private SignalView signalView;
    private SpatialView spatialView;
    private FrameLayout mapFrame;
    private MapTileView mapTileView;
    private TextView mapStatusText;
    private double anchorLatitude = Double.NaN;
    private double anchorLongitude = Double.NaN;
    private String activeMapProvider = "none";
    private float anchorAccuracyMeters = Float.NaN;
    private String anchorProvider = "unknown";
    private long anchorTimeMs = 0L;
    private static final String AUTO_BACKUP_DIR = "track_backups";
    private static final String PREFS = "backup_settings";
    private static final String PREF_BACKUP_ENABLED = "backup_enabled";
    private static final String PREF_BACKUP_KEEP = "backup_keep";
    private static final String LOCK_SUFFIX = ".lock";
    private static final String PREF_FILTER_POOR_ACCURACY = "filter_poor_accuracy";
    private static final String PREF_FILTER_JUMP_POINTS = "filter_jump_points";
    private static final String PREF_FILTER_OVER_300 = "filter_over_300";
    private TextView sensorText;
    private SensorManager sensorManager;
    private Sensor stepSensor;
    private Sensor rotationSensor;
    private Sensor accelerometerSensor;
    private float gravityMagnitude = 9.81f;
    private long lastFallbackStepMs = 0L;
    private boolean usingFallbackSteps = false;
    private float headingRad = 0f;
    private boolean mapping = false;
    private int mappedSteps = 0;
    private static final float STEP_METERS = 0.72f;
    private final Map<String, Integer> previousLevels = new HashMap<>();
    private Button scanButton;
    private Button mappingButton;
    private Button replayControlButton;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, Integer> baseline = new HashMap<>();
    private boolean receiverRegistered = false;
    private boolean waitingForScan = false;
    private boolean currentScanUserInitiated = false;
    private long mappingStartElapsedMs = 0L;
    private long lastStepElapsedMs = 0L;
    private float currentSpeedKmh = 0f;
    private float maxSpeedKmh = 0f;
    private float gpsDistanceMeters = 0f;
    private long gpsTrackStartElapsedMs = 0L;
    private long activeRecordingTimeMs = 0L;
    private long currentRecordingSessionStartMs = 0L;
    private long movingTimeMs = 0L;
    private float pendingMaxSpeedKmh = 0f;
    private int pendingMaxSpeedConfirmations = 0;
    private Location lastTrackLocation = null;
    private long lastProcessedLocationElapsedNanos = 0L;
    private long lastProcessedLocationTimeMs = 0L;
    private boolean pendingSegmentStart = true;
    private boolean restoringActiveSession = false;
    private boolean drainingBackgroundJournal = false;
    private boolean batchApplyingBackgroundLocations = false;
    private boolean activityVisible = false;
    private boolean gpsSpeedAvailable = false;
    private Location lastSpeedLocation = null;
    private long lastValidGpsSpeedElapsedMs = 0L;
    private String speedSourceLabel = "等待速度数据";
    private static final long GPS_SPEED_FRESH_MS = 4500L;
    private static final long AUTO_REPAIR_GAP_MIN_MS = 30_000L;
    private static final long AUTO_REPAIR_GAP_MAX_MS = 5L * 60L * 1000L;
    private static final int AUTO_REPAIR_POINT_INTERVAL_SECONDS = 5;
    private File pendingBackupExportFile = null;
    private long lastAutoBackupWriteElapsedMs = 0L;
    private static final long AUTO_BACKUP_MIN_INTERVAL_MS = 5000L;
    private final AtomicBoolean autoBackupWriting = new AtomicBoolean(false);
    private volatile boolean autoBackupPendingRotate = false;
    private final LocationListener continuousLocationListener = new LocationListener() {
        @Override public void onLocationChanged(Location location) {
            handleLocationUpdate(location);
        }
        @Override public void onProviderEnabled(String provider) { }
        @Override public void onProviderDisabled(String provider) { }
        @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
    };
    private long lastLocationCallbackElapsedMs = 0L;
    private boolean locationFallbackRunning = false;
    private final List<CancellationSignal> currentLocationSignals = new ArrayList<>();
    private String locationDebugStatus = "尚未启动定位";
    private final Runnable locationFallbackRunnable = new Runnable() {
        @Override public void run() {
            if (!hasAnyLocationPermission() || locationManager == null) {
                locationFallbackRunning = false;
                return;
            }
            long age = lastLocationCallbackElapsedMs == 0L ? Long.MAX_VALUE :
                    SystemClock.elapsedRealtime() - lastLocationCallbackElapsedMs;
            if (age > 3500L) requestOneShotLocationFallback();
            handler.postDelayed(this, 4000L);
        }
    };

    private boolean replaying = false;
    private boolean replayPaused = false;
    private int replayIndex = 1;
    private int replayCurrentIndex = 0;
    private final Runnable replayRunnable = new Runnable() {
        @Override public void run() {
            List<SpatialView.TrailPoint> points = spatialView.getTrailCopy();
            if (replayPaused) return;
            if (!replaying || points.size() <= 1) { stopReplay(); return; }
            spatialView.setReplayVisibleCount(replayIndex);
            int shownIndex = Math.max(0, Math.min(replayIndex - 1, points.size() - 1));
            replayCurrentIndex = shownIndex;
            spatialView.centerOnTrailPoint(shownIndex);
            showReplayPointContext(points.get(shownIndex), shownIndex + 1, points.size());
            replayIndex++;
            if (replayIndex > points.size()) {
                replaying = false;
                replayPaused = false;
                replayCurrentIndex = points.size() - 1;
                updateReplayButtonText();
                Toast.makeText(MainActivity.this, "轨迹回放完成", Toast.LENGTH_SHORT).show();
                return;
            }
            handler.postDelayed(this, 120L);
        }
    };

    private final Runnable scanTimeout = new Runnable() {
        @Override public void run() {
            if (!waitingForScan) return;
            waitingForScan = false;
            scanButton.setEnabled(true);
            readResults();
            if (getSortedResults().isEmpty()) {
                statusText.setText("扫描没有返回结果，请检查权限和位置服务");
                detailText.setText("请确认：\n1. Wi‑Fi 已开启\n2. 位置服务已开启\n3. 已允许“附近设备”和“精确位置”权限\n\n部分手机还会限制短时间内重复扫描，请等待约 30 秒后重试。");
            } else if (currentScanUserInitiated) {
                Toast.makeText(MainActivity.this, "未收到新广播，已显示最近扫描结果", Toast.LENGTH_SHORT).show();
            }
            currentScanUserInitiated = false;
        }
    };

    private static final long AUTO_WIFI_SCAN_INTERVAL_MS = 15000L;
    private final Runnable autoWifiScanRunnable = new Runnable() {
        @Override public void run() {
            if (!mapping) return;
            if (hasRequiredPermissions() && wifiManager != null && wifiManager.isWifiEnabled()) {
                requestScan(false);
            } else {
                readResults();
            }
            handler.postDelayed(this, AUTO_WIFI_SCAN_INTERVAL_MS);
        }
    };

    private void startAutoWifiScanning() {
        handler.removeCallbacks(autoWifiScanRunnable);
        if (!mapping) return;
        if (hasRequiredPermissions()) requestScan(false);
        else ensurePermissions(true);
        handler.postDelayed(autoWifiScanRunnable, AUTO_WIFI_SCAN_INTERVAL_MS);
    }

    private void stopAutoWifiScanning() {
        handler.removeCallbacks(autoWifiScanRunnable);
    }

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (intent == null) return;
            String action = intent.getAction();
            if (ACTION_BACKGROUND_LOCATION.equals(action)) {
                Location location = Build.VERSION.SDK_INT >= 33
                        ? intent.getParcelableExtra("location", Location.class)
                        : intent.getParcelableExtra("location");
                long journalSeq = intent.getLongExtra("journalSeq", 0L);
                if (location != null) processForegroundServiceLocation(location, journalSeq);
                return;
            }
            if (ACTION_BACKGROUND_WIFI.equals(action)) {
                readResults();
                return;
            }
            waitingForScan = false;
            handler.removeCallbacks(scanTimeout);
            if (scanButton != null) scanButton.setEnabled(true);
            boolean updated = intent.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED, false);
            readResults();
            if (!updated && currentScanUserInitiated) {
                Toast.makeText(MainActivity.this, "系统返回了最近一次扫描结果", Toast.LENGTH_SHORT).show();
            }
            currentScanUserInitiated = false;
        }
    };

    private void processForegroundServiceLocation(Location location, long journalSeq) {
        if (location == null) return;
        // While the screen/Activity is paused the foreground service only journals points.
        // Avoid doing UI work and JSON backups on every lock-screen callback; onResume drains
        // the journal in small batches. This is substantially harder for Samsung to kill.
        if (!activityVisible) return;
        if (!TrackingStateStore.isActive(this)) {
            TrackingStateStore.markConsumed(this, journalSeq);
            return;
        }
        if (restoringActiveSession || drainingBackgroundJournal) return;
        if (!mapping) {
            mapping = true;
            currentRecordingSessionStartMs = SystemClock.elapsedRealtime();
            if (mappingButton != null) mappingButton.setText("暂停轨迹记录");
        }
        handleLocationUpdate(location);
        TrackingStateStore.markConsumed(this, journalSeq);
        if (journalSeq > 0L && journalSeq % 120L == 0L)
            new Thread(() -> TrackingStateStore.compact(MainActivity.this), "tracking-journal-compact").start();
    }

    private void resumeActiveTrackingIfNeeded() {
        if (!TrackingStateStore.isActive(this) || restoringActiveSession) return;
        restoringActiveSession = true;
        File latest = new File(new File(getFilesDir(), AUTO_BACKUP_DIR), "latest.json");
        if (!latest.exists() || latest.length() <= 0L || spatialView == null) {
            finishActiveTrackingResume();
            return;
        }
        new Thread(() -> {
            ImportedTrack imported = null;
            try (InputStream in = new BufferedInputStream(new FileInputStream(latest))) {
                imported = readTrackFromStream(in, null);
            } catch (Exception ignored) { }
            final ImportedTrack restored = imported;
            handler.post(() -> {
                if (restored != null && restored.points != null && !restored.points.isEmpty())
                    applyImportedTrack(restored, "锁屏记录自动恢复");
                finishActiveTrackingResume();
            });
        }, "active-session-restore").start();
    }

    private void finishActiveTrackingResume() {
        restoringActiveSession = false;
        mapping = true;
        currentRecordingSessionStartMs = SystemClock.elapsedRealtime();
        restoreLastTrackLocationFromTrail();
        pendingSegmentStart = lastTrackLocation == null;
        if (mappingButton != null) mappingButton.setText("暂停轨迹记录");
        stopContinuousLocationUpdates();
        startTrackingService();
        drainPendingBackgroundLocations();
        updateSensorText();
    }

    private void restoreLastTrackLocationFromTrail() {
        if (lastTrackLocation != null || spatialView == null) return;
        SpatialView.TrailPoint point = spatialView.getLastTrailPoint();
        if (!hasExactWgs(point)) return;
        Location restored = new Location(point.locationProvider == null
                ? "restored-track" : point.locationProvider);
        restored.setLatitude(point.latitude);
        restored.setLongitude(point.longitude);
        restored.setTime(point.timeMs);
        if (!Float.isNaN(point.accuracyMeters)) restored.setAccuracy(point.accuracyMeters);
        if (point.speedKmh >= 0f) restored.setSpeed(point.speedKmh / 3.6f);
        if (point.headingDegrees >= 0f) restored.setBearing(point.headingDegrees);
        long wallAgeMs = Math.max(0L, System.currentTimeMillis() - point.timeMs);
        long elapsedMs = Math.max(1L, SystemClock.elapsedRealtime() - wallAgeMs);
        restored.setElapsedRealtimeNanos(elapsedMs * 1_000_000L);
        lastTrackLocation = restored;
        lastSpeedLocation = new Location(restored);
    }

    private void drainPendingBackgroundLocations() {
        if (!TrackingStateStore.isActive(this) || restoringActiveSession || drainingBackgroundJournal) return;
        drainingBackgroundJournal = true;
        new Thread(() -> {
            List<TrackingStateStore.JournalLocation> pending = TrackingStateStore.readPending(MainActivity.this);
            handler.post(() -> applyPendingBackgroundBatch(pending, 0));
        }, "tracking-journal-read").start();
    }

    private void applyPendingBackgroundBatch(List<TrackingStateStore.JournalLocation> pending, int start) {
        if (pending == null || start >= pending.size()) {
            boolean appliedAny = pending != null && !pending.isEmpty();
            batchApplyingBackgroundLocations = false;
            drainingBackgroundJournal = false;
            updateSensorText();
            if (appliedAny) {
                saveAutoBackup(true);
                new Thread(() -> TrackingStateStore.compact(MainActivity.this), "tracking-journal-compact").start();
                // One extra pass catches locations that arrived while this batch was applied.
                handler.postDelayed(this::drainPendingBackgroundLocations, 250L);
            }
            return;
        }
        batchApplyingBackgroundLocations = true;
        int end = Math.min(pending.size(), start + 40);
        for (int i = start; i < end; i++) {
            TrackingStateStore.JournalLocation entry = pending.get(i);
            handleLocationUpdate(entry.location);
            TrackingStateStore.markConsumed(this, entry.seq);
        }
        final int next = end;
        handler.postDelayed(() -> applyPendingBackgroundBatch(pending, next), 16L);
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
            rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            accelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        }
        buildUi();
        registerScanReceiver();
        ensurePermissions(false);
        resumeActiveTrackingIfNeeded();
    }

    private TextView label(String text, float size, int color) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setPadding(0, 10, 0, 10);
        return v;
    }

    private void buildUi() {
        int pad = (int)(16 * getResources().getDisplayMetrics().density);
        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(Color.rgb(244, 246, 251));

        ScrollView contentScroll = new ScrollView(this);
        contentScroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        contentScroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("小魁WiFi骑行", 27, Color.rgb(30, 34, 44));
        title.setTypeface(null, 1);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        scanButton = new Button(this);
        scanButton.setText("扫描WiFi");
        scanButton.setTextSize(13);
        scanButton.setTextColor(Color.rgb(24, 80, 120));
        scanButton.setAllCaps(false);
        scanButton.setMinHeight(dp(36));
        scanButton.setMinimumHeight(dp(36));
        scanButton.setPadding(dp(12), 0, dp(12), 0);
        scanButton.setBackgroundColor(Color.rgb(190, 229, 248));
        scanButton.setOnClickListener(v -> onScanClicked());
        LinearLayout.LayoutParams scanTopLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40));
        scanTopLp.setMargins(dp(8), 0, 0, 0);
        titleRow.addView(scanButton, scanTopLp);
        root.addView(titleRow);

        TextView note = label("显示全部 Wi‑Fi 网络详情，并利用 Wi‑Fi 波动与手机传感器估算活动和空间轨迹。结果仅供环境观察。", 14, Color.rgb(90, 98, 115));
        root.addView(note);

        statusText = label("正在检查权限…", 19, Color.rgb(49, 87, 213));
        statusText.setTypeface(null, 1);
        root.addView(statusText);

        signalView = new SignalView(this);
        root.addView(signalView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220)));

        TextView mapTitle = label("空间轨迹草图", 18, Color.rgb(30, 34, 44));
        mapTitle.setTypeface(null, 1);
        root.addView(mapTitle);

        mapFrame = new FrameLayout(this);
        mapTileView = new MapTileView(this);
        mapTileView.setStatusListener((message, error) -> {
            if (mapStatusText != null) {
                mapStatusText.setText(message);
                mapStatusText.setTextColor(error ? Color.rgb(179, 38, 30) : Color.rgb(49, 87, 213));
            }
        });
        mapTileView.setVisibility(View.GONE);
        mapFrame.addView(mapTileView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        spatialView = new SpatialView(this);
        spatialView.setBackgroundColor(Color.TRANSPARENT);
        spatialView.setViewportListener((scale, x, y) -> {
            if (mapTileView != null) mapTileView.setViewport(scale, x, y);
        });
        mapFrame.addView(spatialView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        Button locateOnTrail = new Button(this);
        locateOnTrail.setText("⌖");
        locateOnTrail.setTextSize(24);
        locateOnTrail.setTextColor(Color.WHITE);
        locateOnTrail.setBackgroundColor(0x55000000);
        locateOnTrail.setAlpha(0.78f);
        locateOnTrail.setContentDescription("定位到当前位置或回放位置");
        locateOnTrail.setPadding(0, 0, 0, 0);
        locateOnTrail.setOnClickListener(v -> locateToCurrentTrailPosition());
        FrameLayout.LayoutParams locateParams = new FrameLayout.LayoutParams(dp(52), dp(52));
        locateParams.gravity = Gravity.END | Gravity.BOTTOM;
        locateParams.setMargins(0, 0, dp(14), dp(14));
        mapFrame.addView(locateOnTrail, locateParams);

        root.addView(mapFrame, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(360)));

        LinearLayout mapButtons1 = new LinearLayout(this);
        mapButtons1.setOrientation(LinearLayout.HORIZONTAL);
        Button googleMap = new Button(this);
        googleMap.setText("谷歌地图");
        googleMap.setOnClickListener(v -> showMapBackground("google"));
        mapButtons1.addView(googleMap, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button amap = new Button(this);
        amap.setText("高德地图");
        amap.setOnClickListener(v -> showMapBackground("amap"));
        mapButtons1.addView(amap, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button baiduMap = new Button(this);
        baiduMap.setText("百度地图");
        baiduMap.setOnClickListener(v -> showMapBackground("baidu"));
        mapButtons1.addView(baiduMap, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        root.addView(mapButtons1);

        LinearLayout mapButtons2 = new LinearLayout(this);
        mapButtons2.setOrientation(LinearLayout.HORIZONTAL);
        Button hideMap = new Button(this);
        hideMap.setText("关闭地图底图");
        hideMap.setOnClickListener(v -> hideMapBackground());
        mapButtons2.addView(hideMap, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button resetViewport = new Button(this);
        resetViewport.setText("恢复草图视图");
        resetViewport.setOnClickListener(v -> spatialView.resetViewport());
        mapButtons2.addView(resetViewport, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        replayControlButton = new Button(this);
        replayControlButton.setText("开始回放");
        replayControlButton.setOnClickListener(v -> toggleReplayControl());
        mapButtons2.addView(replayControlButton, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        root.addView(mapButtons2);

        mapStatusText = label("地图状态：未开启底图", 13, Color.rgb(90, 98, 115));
        root.addView(mapStatusText);

        TextView gestureNote = label("草图操作：双指缩放，单指拖动。地图会自动尝试多个备用服务器；若仍失败，请关闭私人 DNS、VPN 或广告拦截后重试。", 13, Color.rgb(90, 98, 115));
        root.addView(gestureNote);

        sensorText = label("传感器：尚未开始空间绘制", 14, Color.rgb(55, 61, 74));
        root.addView(sensorText);

        Button settingsButton = new Button(this);
        settingsButton.setText("打开权限 / 位置设置");
        settingsButton.setOnClickListener(v -> openRelevantSettings());
        root.addView(settingsButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView listTitle = label("全部 Wi‑Fi 网络及详情", 19, Color.rgb(30, 34, 44));
        listTitle.setTypeface(null, 1);
        listTitle.setPadding(0, dp(18), 0, dp(8));
        root.addView(listTitle);

        detailText = label("尚无数据", 14, Color.rgb(55, 61, 74));
        detailText.setTextIsSelectable(true);
        detailText.setPadding(dp(12), dp(8), dp(12), dp(24));
        detailText.setBackgroundColor(Color.WHITE);
        root.addView(detailText, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        screen.addView(contentScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        final int controlsLeft = dp(8);
        final int controlsTop = dp(4);
        final int controlsRight = dp(8);
        final int controlsBottom = dp(8);
        controls.setPadding(controlsLeft, controlsTop, controlsRight, controlsBottom);
        controls.setBackgroundColor(Color.WHITE);
        controls.setOnApplyWindowInsetsListener((view, insets) -> {
            int navigationBottom = 0;
            if (Build.VERSION.SDK_INT >= 30) {
                navigationBottom = insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
            } else {
                navigationBottom = insets.getSystemWindowInsetBottom();
            }
            view.setPadding(controlsLeft, controlsTop, controlsRight,
                    controlsBottom + navigationBottom);
            return insets;
        });

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        mappingButton = new Button(this);
        mappingButton.setText(mapping ? "暂停轨迹记录" : "开始轨迹记录");
        mappingButton.setOnClickListener(v -> toggleMapping());
        row1.addView(mappingButton, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        Button moreFunctions = new Button(this);
        moreFunctions.setText("更多功能");
        moreFunctions.setOnClickListener(v -> showMoreMenu());
        row1.addView(moreFunctions, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        controls.addView(row1);

        screen.addView(controls, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(screen);
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void registerScanReceiver() {
        if (receiverRegistered) return;
        IntentFilter filter = new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        filter.addAction(ACTION_BACKGROUND_LOCATION);
        filter.addAction(ACTION_BACKGROUND_WIFI);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, filter);
        receiverRegistered = true;
    }

    private boolean hasAnyLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasRequiredPermissions() {
        boolean locationGranted = hasAnyLocationPermission();
        boolean nearbyGranted = Build.VERSION.SDK_INT < 33 ||
                checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED;
        return locationGranted && nearbyGranted;
    }

    private void ensurePermissions(boolean fromButton) {
        List<String> missing = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.NEARBY_WIFI_DEVICES);
        }
        if (!hasAnyLocationPermission()) {
            missing.add(Manifest.permission.ACCESS_FINE_LOCATION);
            missing.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        if (!missing.isEmpty()) {
            statusText.setText("需要 Wi‑Fi 和精确位置权限");
            if (fromButton) Toast.makeText(this, "请授予权限后再次点击扫描", Toast.LENGTH_LONG).show();
            requestPermissions(missing.toArray(new String[0]), REQ_PERMISSIONS);
        } else {
            statusText.setText("权限正常，可以扫描");
            readResults();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_ACTIVITY) {
            List<SpatialView.TrailPoint> existingTrack = spatialView.getTrailCopy();
            if (existingTrack.size() <= 1) {
                anchorLatitude = Double.NaN; anchorLongitude = Double.NaN;
                anchorAccuracyMeters = Float.NaN; anchorProvider = "waiting-fresh-fix"; anchorTimeMs = 0L;
                spatialView.clearGeoAnchor();
            }
            TrackingStateStore.beginSession(this);
            mapping = true;
            stopContinuousLocationUpdates();
            startTrackingService();
            usingFallbackSteps = Build.VERSION.SDK_INT >= 29 &&
                    checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED;
            lastTrackLocation = null;
            lastSpeedLocation = null;
            pendingSegmentStart = true;
            currentRecordingSessionStartMs = SystemClock.elapsedRealtime();
            if (mappingStartElapsedMs == 0L) mappingStartElapsedMs = currentRecordingSessionStartMs;
            if (mappingButton != null) mappingButton.setText("暂停轨迹记录");
            startAutoWifiScanning();
            updateSensorText();
            Toast.makeText(this, usingFallbackSteps
                    ? "未授予身体活动权限，已改用加速度计估算步伐"
                    : "空间绘制已开始，请正常骑行", Toast.LENGTH_LONG).show();
            return;
        }
        if (requestCode != REQ_PERMISSIONS) return;
        if (hasRequiredPermissions()) {
            statusText.setText("权限已授予，正在扫描并获取定位…");
            if (TrackingStateStore.isActive(this)) resumeActiveTrackingIfNeeded();
            else {
                startContinuousLocationUpdates();
                ensureGeoAnchor(true);
            }
            requestScan(true);
        } else {
            statusText.setText("权限未授予，无法扫描 Wi‑Fi");
            detailText.setText("请点击“打开权限 / 位置设置”，允许附近设备和精确位置权限，然后返回应用重试。");
            scanButton.setEnabled(true);
        }
    }

    private boolean isLocationEnabled() {
        if (Build.VERSION.SDK_INT >= 28) return locationManager != null && locationManager.isLocationEnabled();
        try {
            int mode = Settings.Secure.getInt(getContentResolver(), Settings.Secure.LOCATION_MODE);
            return mode != Settings.Secure.LOCATION_MODE_OFF;
        } catch (Settings.SettingNotFoundException e) {
            return false;
        }
    }

    private void onScanClicked() {
        Toast.makeText(this, "已收到扫描指令", Toast.LENGTH_SHORT).show();
        if (!hasRequiredPermissions()) {
            ensurePermissions(true);
            return;
        }
        requestScan(true);
    }

    private void requestScan(boolean userInitiated) {
        if (wifiManager == null) {
            statusText.setText("此设备没有可用的 Wi‑Fi 服务");
            return;
        }
        if (!wifiManager.isWifiEnabled()) {
            statusText.setText("请先打开 Wi‑Fi");
            Toast.makeText(this, "Wi‑Fi 尚未开启", Toast.LENGTH_LONG).show();
            if (Build.VERSION.SDK_INT >= 29) startActivity(new Intent(Settings.Panel.ACTION_WIFI));
            else startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
            return;
        }
        if (!isLocationEnabled()) {
            statusText.setText("请开启系统位置服务后再扫描");
            Toast.makeText(this, "Wi‑Fi 扫描需要开启位置服务", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            return;
        }

        readResults(); // 先显示缓存结果，按钮不会看起来毫无反应
        currentScanUserInitiated = userInitiated;
        try {
            waitingForScan = true;
            scanButton.setEnabled(false);
            boolean started = wifiManager.startScan();
            if (userInitiated) statusText.setText(started ? "正在扫描，请稍候…" : "系统限制扫描频率，正在读取最近结果…");
            handler.removeCallbacks(scanTimeout);
            handler.postDelayed(scanTimeout, SCAN_TIMEOUT_MS);
            if (!started) {
                waitingForScan = false;
                handler.removeCallbacks(scanTimeout);
                scanButton.setEnabled(true);
                readResults();
                if (userInitiated) Toast.makeText(this, "Android 限制了本次扫描，已显示最近数据", Toast.LENGTH_LONG).show();
                currentScanUserInitiated = false;
            }
        } catch (SecurityException e) {
            waitingForScan = false;
            scanButton.setEnabled(true);
            statusText.setText("系统拒绝扫描，请重新授权");
            detailText.setText("错误：" + e.getMessage());
        }
    }

    private boolean hasFineLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private List<String> buildLocationProviderOrder() {
        List<String> order = new ArrayList<>();
        if (locationManager == null) return order;
        try {
            Criteria criteria = new Criteria();
            criteria.setAccuracy(Criteria.ACCURACY_FINE);
            criteria.setPowerRequirement(Criteria.POWER_HIGH);
            String best = locationManager.getBestProvider(criteria, true);
            if (best != null && !order.contains(best)) order.add(best);
        } catch (Exception ignored) { }
        try {
            for (String provider : locationManager.getProviders(true)) {
                String lower = provider == null ? "" : provider.toLowerCase(Locale.US);
                if ((lower.contains("fused") || lower.contains("gnss")) && !order.contains(provider)) order.add(provider);
            }
        } catch (Exception ignored) { }
        if (!order.contains(LocationManager.GPS_PROVIDER)) order.add(LocationManager.GPS_PROVIDER);
        if (!order.contains(LocationManager.NETWORK_PROVIDER)) order.add(LocationManager.NETWORK_PROVIDER);
        if (!order.contains(LocationManager.PASSIVE_PROVIDER)) order.add(LocationManager.PASSIVE_PROVIDER);
        try {
            for (String provider : locationManager.getProviders(true)) if (!order.contains(provider)) order.add(provider);
        } catch (Exception ignored) { }
        return order;
    }

    private void requestFrameworkCurrentLocations(List<String> providers) {
        if (locationManager == null || !hasAnyLocationPermission() || Build.VERSION.SDK_INT < 30) return;
        for (CancellationSignal signal : currentLocationSignals) try { signal.cancel(); } catch (Exception ignored) { }
        currentLocationSignals.clear();
        for (String provider : providers) {
            try {
                if (!locationManager.isProviderEnabled(provider)) continue;
                CancellationSignal signal = new CancellationSignal();
                currentLocationSignals.add(signal);
                locationManager.getCurrentLocation(provider, signal, getMainExecutor(), location -> {
                    if (location != null) {
                        locationDebugStatus = "当前定位来源：" + location.getProvider();
                        handleLocationUpdate(location);
                    }
                });
            } catch (Exception ignored) { }
        }
    }

    private void startContinuousLocationUpdates() {
        if (locationManager == null || !hasAnyLocationPermission()) return;
        stopContinuousLocationUpdates();
        List<String> registered = new ArrayList<>();
        List<String> errors = new ArrayList<>();
        try {
            List<String> providers = buildLocationProviderOrder();
            for (String provider : providers) {
                try {
                    locationManager.requestLocationUpdates(provider, 1000L, 0f,
                            continuousLocationListener, Looper.getMainLooper());
                    registered.add(provider);
                } catch (Exception e) {
                    errors.add(provider + ":" + e.getClass().getSimpleName());
                }
            }
            requestFrameworkCurrentLocations(providers);
            Location cached = getBestLastKnownLocation();
            if (cached != null) handleLocationUpdate(cached);
            if (registered.isEmpty()) {
                if (sensorText != null) sensorText.setText("定位监听注册失败：" +
                        (errors.isEmpty() ? "没有已开启的定位来源" : android.text.TextUtils.join(", ", errors)));
                requestOneShotLocationFallback();
            } else if (sensorText != null && Double.isNaN(anchorLatitude)) {
                String precision = hasFineLocationPermission() ? "精确位置已授权" : "仅近似位置，请在系统权限中开启精确位置";
                locationDebugStatus = "等待实时定位 · " + precision + " · 来源：" + android.text.TextUtils.join("/", registered);
                sensorText.setText(locationDebugStatus);
            }
            if (!locationFallbackRunning) {
                locationFallbackRunning = true;
                handler.removeCallbacks(locationFallbackRunnable);
                handler.postDelayed(locationFallbackRunnable, 2500L);
            }
        } catch (Exception e) {
            if (sensorText != null) sensorText.setText("定位启动失败：" + e.getClass().getSimpleName() + " " + e.getMessage());
            requestOneShotLocationFallback();
        }
    }

    private void requestOneShotLocationFallback() {
        if (locationManager == null || !hasAnyLocationPermission() || !isLocationEnabled()) return;
        List<String> providers = buildLocationProviderOrder();
        requestFrameworkCurrentLocations(providers);
        Exception lastError = null;
        for (String chosen : providers) {
            try {
                if (!locationManager.isProviderEnabled(chosen)) continue;
                locationManager.requestSingleUpdate(chosen, new LocationListener() {
                    @Override public void onLocationChanged(Location location) {
                        locationDebugStatus = "单次定位来源：" + location.getProvider();
                        handleLocationUpdate(location);
                    }
                    @Override public void onProviderEnabled(String provider) { }
                    @Override public void onProviderDisabled(String provider) { }
                    @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
                }, Looper.getMainLooper());
                return;
            } catch (Exception e) {
                lastError = e;
            }
        }
        if (sensorText != null && Double.isNaN(anchorLatitude)) {
            sensorText.setText("定位请求失败：" + (lastError == null ? "没有可用来源" : lastError.getClass().getSimpleName()));
        }
    }

    private void stopContinuousLocationUpdates() {
        if (locationManager != null) try { locationManager.removeUpdates(continuousLocationListener); } catch (Exception ignored) { }
        for (CancellationSignal signal : currentLocationSignals) try { signal.cancel(); } catch (Exception ignored) { }
        currentLocationSignals.clear();
        handler.removeCallbacks(locationFallbackRunnable);
        locationFallbackRunning = false;
    }

    private boolean hasRecentGpsSpeed() {
        return lastValidGpsSpeedElapsedMs > 0L &&
                SystemClock.elapsedRealtime() - lastValidGpsSpeedElapsedMs <= GPS_SPEED_FRESH_MS;
    }

    private void handleLocationUpdate(Location location) {
        if (location == null) return;
        lastLocationCallbackElapsedMs = SystemClock.elapsedRealtime();
        locationDebugStatus = "定位已更新 · 来源：" + location.getProvider() +
                (location.hasAccuracy() ? String.format(Locale.CHINA, " · 精度约 %.0f m", location.getAccuracy()) : "");
        long nowElapsed = SystemClock.elapsedRealtime();
        long currentElapsedNanos = location.getElapsedRealtimeNanos();
        long currentTimeMs = location.getTime();
        if (currentElapsedNanos > 0L && lastProcessedLocationElapsedNanos > 0L &&
                currentElapsedNanos <= lastProcessedLocationElapsedNanos) return;
        if (currentElapsedNanos <= 0L && lastProcessedLocationTimeMs > 0L &&
                currentTimeMs <= lastProcessedLocationTimeMs) return;
        if (currentElapsedNanos > 0L) lastProcessedLocationElapsedNanos = currentElapsedNanos;
        lastProcessedLocationTimeMs = Math.max(lastProcessedLocationTimeMs, currentTimeMs);

        SharedPreferences filterPrefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        boolean filterPoorAccuracy = filterPrefs.getBoolean(PREF_FILTER_POOR_ACCURACY, true);
        boolean filterJumpPoints = filterPrefs.getBoolean(PREF_FILTER_JUMP_POINTS, true);
        boolean filterOver300 = filterPrefs.getBoolean(PREF_FILTER_OVER_300, true);
        float accuracyLimit = mapping ? 50f : 100f;
        boolean accuracyOk = !filterPoorAccuracy || !location.hasAccuracy() || location.getAccuracy() <= accuracyLimit;
        boolean jumpOk = true;
        if (filterJumpPoints && lastSpeedLocation != null) {
            long pn = lastSpeedLocation.getElapsedRealtimeNanos();
            long cn = location.getElapsedRealtimeNanos();
            double js = (cn > pn) ? (cn - pn) / 1_000_000_000.0 :
                    (location.getTime() - lastSpeedLocation.getTime()) / 1000.0;
            if (js <= 0.0) jumpOk = false;
            else if (js <= 30.0) {
                float jd = lastSpeedLocation.distanceTo(location);
                float a1 = lastSpeedLocation.hasAccuracy() ? lastSpeedLocation.getAccuracy() : 0f;
                float a2 = location.hasAccuracy() ? location.getAccuracy() : 0f;
                float maxKmh = filterOver300 ? 300f : 500f;
                float physicalLimit = (float)(js * maxKmh / 3.6) + a1 + a2 + 15f;
                float nativeExpected = 0f;
                if (lastSpeedLocation.hasSpeed()) nativeExpected = Math.max(nativeExpected, lastSpeedLocation.getSpeed() * (float)js);
                if (location.hasSpeed()) nativeExpected = Math.max(nativeExpected, location.getSpeed() * (float)js);
                float speedConsistentLimit = nativeExpected > 0f
                        ? nativeExpected * 3f + a1 + a2 + 25f : physicalLimit;
                float allowed = Math.min(physicalLimit, Math.max(45f, speedConsistentLimit));
                boolean providerOscillation = js < 3.0 &&
                        lastSpeedLocation.getProvider() != null && location.getProvider() != null &&
                        !lastSpeedLocation.getProvider().equals(location.getProvider()) &&
                        location.hasAccuracy() && lastSpeedLocation.hasAccuracy() &&
                        location.getAccuracy() > lastSpeedLocation.getAccuracy() * 1.35f &&
                        jd > Math.max(20f, lastSpeedLocation.getAccuracy() * 1.5f);
                jumpOk = jd <= allowed && !providerOscillation;
            }
        }
        boolean locationAccepted = accuracyOk && jumpOk;
        if (locationAccepted && (Double.isNaN(anchorLatitude) || Double.isNaN(anchorLongitude)) &&
                (!location.hasAccuracy() || location.getAccuracy() <= 35f)) {
            setGeoAnchorFromLocation(location);
            if (spatialView != null) spatialView.setGeoAnchor(anchorLatitude, anchorLongitude);
        }
        boolean speedResolved = false;
        boolean speedFromNative = false;
        float resolvedSpeedKmh = 0f;
        float resolvedSpeedAccuracyKmh = Float.NaN;

        // 第一优先：Android/GNSS 原生速度。Location.getSpeed() 单位为 m/s；
        // Android 8.0+ 同时利用速度精度，拒绝明显不可靠的瞬时值。
        if (locationAccepted && location.hasSpeed()) {
            float nativeKmh = location.getSpeed() * 3.6f;
            boolean speedAccuracyOk = true;
            if (Build.VERSION.SDK_INT >= 26 && location.hasSpeedAccuracy()) {
                resolvedSpeedAccuracyKmh = location.getSpeedAccuracyMetersPerSecond() * 3.6f;
                speedAccuracyOk = location.getSpeedAccuracyMetersPerSecond() <= 5f;
            }
            if (speedAccuracyOk && nativeKmh >= 0f && (!filterOver300 || nativeKmh <= 300f)) {
                resolvedSpeedKmh = nativeKmh;
                speedResolved = true;
                speedFromNative = true;
                speedSourceLabel = "GPS 原生速度";
            }
        }

        // 原生速度不可用时，用连续坐标与单调时钟回退计算。
        // 仅允许 1~20 秒连续点，避免极短时间放大抖动或长时间断点制造假速度。
        if (!speedResolved && locationAccepted && lastSpeedLocation != null) {
            long previousNanos = lastSpeedLocation.getElapsedRealtimeNanos();
            long currentNanos = location.getElapsedRealtimeNanos();
            double seconds = (currentNanos > previousNanos) ?
                    (currentNanos - previousNanos) / 1_000_000_000.0 :
                    (location.getTime() - lastSpeedLocation.getTime()) / 1000.0;
            if (seconds >= 1.0 && seconds <= 20.0) {
                float moved = lastSpeedLocation.distanceTo(location);
                float previousAccuracy = lastSpeedLocation.hasAccuracy() ? lastSpeedLocation.getAccuracy() : 0f;
                float currentAccuracy = location.hasAccuracy() ? location.getAccuracy() : 0f;
                float noiseMeters = Math.max(1.5f, Math.min(8f, (previousAccuracy + currentAccuracy) * 0.20f));
                float computedKmh = (float)(moved / seconds * 3.6);
                if (moved <= noiseMeters) {
                    resolvedSpeedKmh = 0f;
                    speedResolved = true;
                    speedSourceLabel = "GPS 位移/时间（静止）";
                } else if (computedKmh >= 0f && (!filterOver300 || computedKmh <= 300f)) {
                    resolvedSpeedKmh = computedKmh;
                    speedResolved = true;
                    speedSourceLabel = "GPS 位移/时间";
                }
            }
        }

        if (locationAccepted) lastSpeedLocation = new Location(location);
        if (speedResolved) {
            // 实时速度采用时间自适应低通：低速更稳，高速仍能及时响应。
            float alpha = resolvedSpeedKmh < 5f ? 0.45f : 0.65f;
            if (lastValidGpsSpeedElapsedMs > 0L) currentSpeedKmh = currentSpeedKmh * (1f - alpha) + resolvedSpeedKmh * alpha;
            else currentSpeedKmh = resolvedSpeedKmh;
            if (resolvedSpeedKmh < 1.0f) currentSpeedKmh = 0f;
            lastValidGpsSpeedElapsedMs = nowElapsed;
            gpsSpeedAvailable = true;

            // 最高速度不使用平滑后的显示值，也不使用步频估算。
            // 高质量原生速度可直接计入；其余候选需连续两次相近确认，过滤单点尖峰。
            boolean highQualityNative = speedFromNative &&
                    (Float.isNaN(resolvedSpeedAccuracyKmh) || resolvedSpeedAccuracyKmh <= 9f);
            if (highQualityNative) {
                maxSpeedKmh = Math.max(maxSpeedKmh, resolvedSpeedKmh);
                pendingMaxSpeedConfirmations = 0;
            } else if (resolvedSpeedKmh > maxSpeedKmh) {
                if (pendingMaxSpeedConfirmations > 0 && pendingMaxSpeedKmh > 0f &&
                        Math.abs(resolvedSpeedKmh - pendingMaxSpeedKmh) <= Math.max(5f, pendingMaxSpeedKmh * 0.20f)) {
                    pendingMaxSpeedConfirmations++;
                    pendingMaxSpeedKmh = Math.max(pendingMaxSpeedKmh, resolvedSpeedKmh);
                    if (pendingMaxSpeedConfirmations >= 2) {
                        maxSpeedKmh = Math.max(maxSpeedKmh, pendingMaxSpeedKmh);
                        pendingMaxSpeedConfirmations = 0;
                    }
                } else {
                    pendingMaxSpeedKmh = resolvedSpeedKmh;
                    pendingMaxSpeedConfirmations = 1;
                }
            }
        } else {
            gpsSpeedAvailable = hasRecentGpsSpeed();
            if (!gpsSpeedAvailable) {
                currentSpeedKmh = 0f;
                speedSourceLabel = "GPS 速度不可用";
            }
        }

        if (mapping && locationAccepted && !Double.isNaN(anchorLatitude) && !Double.isNaN(anchorLongitude)) {
            if (gpsTrackStartElapsedMs == 0L) gpsTrackStartElapsedMs = nowElapsed;
            boolean appendPoint = lastTrackLocation == null;
            boolean segmentStart = pendingSegmentStart || lastTrackLocation == null;
            boolean acceptAsTrackReference = lastTrackLocation == null;
            float movedFromLast = lastTrackLocation == null ? 0f : lastTrackLocation.distanceTo(location);
            if (lastTrackLocation != null) {
                long prevNs = lastTrackLocation.getElapsedRealtimeNanos();
                long currNs = location.getElapsedRealtimeNanos();
                double seconds = currNs > prevNs ? (currNs - prevNs) / 1_000_000_000.0
                        : (location.getTime() - lastTrackLocation.getTime()) / 1000.0;
                float a1 = lastTrackLocation.hasAccuracy() ? lastTrackLocation.getAccuracy() : 0f;
                float a2 = location.hasAccuracy() ? location.getAccuracy() : 0f;
                float noiseMeters = Math.max(2.0f, Math.min(12f, (a1 + a2) * 0.22f));
                float segmentKmh = seconds > 0.0 ? (float)(movedFromLast / seconds * 3.6) : Float.POSITIVE_INFINITY;
                boolean normalInterval = seconds >= 0.5 && seconds <= 30.0;
                boolean longGap = seconds > 30.0 && seconds <= 6 * 60 * 60.0;
                boolean plausibleSpeed = !filterOver300 || segmentKmh <= 300f;
                if (normalInterval && plausibleSpeed) {
                    acceptAsTrackReference = true;
                    if (movedFromLast > noiseMeters) {
                        gpsDistanceMeters += movedFromLast;
                        float movementSpeed = speedResolved ? resolvedSpeedKmh : segmentKmh;
                        if (movementSpeed >= 1.5f) movingTimeMs += (long)(seconds * 1000.0);
                        appendPoint = true;
                        segmentStart = pendingSegmentStart;
                    }
                } else if (longGap && (!location.hasAccuracy() || location.getAccuracy() <= 60f)) {
                    acceptAsTrackReference = true;
                    appendPoint = true;
                    if (!pendingSegmentStart && shouldAutoRepairGap(lastTrackLocation, location,
                            seconds, movedFromLast)) {
                        // No fixes exist inside this interval. Create explicitly marked estimated
                        // points so the visible route stays continuous. These are interpolation,
                        // not recovered GNSS samples, and are exported with provider=estimated-gap.
                        appendEstimatedGapPoints(lastTrackLocation, location, seconds, movedFromLast);
                        gpsDistanceMeters += movedFromLast;
                        float inferredGapKmh = (float)(movedFromLast / seconds * 3.6);
                        if (inferredGapKmh >= 1.5f) movingTimeMs += (long)(seconds * 1000.0);
                        segmentStart = false;
                        speedSourceLabel = "定位中断路段已自动估算补线";
                    } else {
                        // Explicit pause, a very long outage, or unreliable endpoints stay split.
                        segmentStart = true;
                    }
                } else {
                    speedSourceLabel = "已过滤定位跳点";
                }
            }
            if (appendPoint && !Double.isNaN(anchorLatitude) && !Double.isNaN(anchorLongitude)) {
                float[] rel = latLonToRelativeMeters(anchorLatitude, anchorLongitude,
                        location.getLatitude(), location.getLongitude());
                SpatialView.TrailPoint point = attachPointContext(new SpatialView.TrailPoint(
                        rel[0], rel[1], location.getTime(),
                        location.hasBearing() ? location.getBearing() : (float)Math.toDegrees(headingRad),
                        currentSpeedKmh, gpsDistanceMeters, "[]", "none", Double.NaN, Double.NaN,
                        18, 1f, 0f, 0f, "[]", segmentStart,
                        location.getLatitude(), location.getLongitude(),
                        location.hasAccuracy() ? location.getAccuracy() : Float.NaN, location.getProvider()));
                spatialView.appendTrailPoint(point);
                pendingSegmentStart = false;
                if (!batchApplyingBackgroundLocations) saveAutoBackup(false);
            }
            if (acceptAsTrackReference) lastTrackLocation = new Location(location);
        }
        if (!batchApplyingBackgroundLocations) updateSensorText();
    }

    private static float[] latLonToRelativeMeters(double originLat, double originLon, double lat, double lon) {
        double north = Math.toRadians(lat - originLat) * 6378137.0;
        double east = Math.toRadians(lon - originLon) * 6378137.0 * Math.cos(Math.toRadians(originLat));
        return new float[]{(float)east, (float)(-north)};
    }

    private boolean shouldAutoRepairGap(Location from, Location to, double seconds, float meters) {
        if (from == null || to == null || seconds * 1000.0 < AUTO_REPAIR_GAP_MIN_MS ||
                seconds * 1000.0 > AUTO_REPAIR_GAP_MAX_MS || meters < 150f) return false;
        float fromAccuracy = from.hasAccuracy() ? from.getAccuracy() : 50f;
        float toAccuracy = to.hasAccuracy() ? to.getAccuracy() : 50f;
        if (fromAccuracy > 75f || toAccuracy > 75f) return false;
        double impliedKmh = meters / Math.max(0.001, seconds) * 3.6;
        float endpointKmh = Math.max(from.hasSpeed() ? from.getSpeed() * 3.6f : 0f,
                to.hasSpeed() ? to.getSpeed() * 3.6f : 0f);
        return impliedKmh >= 10.0 && impliedKmh <= 130.0 &&
                (endpointKmh >= 8f || impliedKmh >= 20.0);
    }

    private static float interpolateAngleDegrees(float a, float b, float t) {
        float delta = ((b - a + 540f) % 360f) - 180f;
        return (a + delta * t + 360f) % 360f;
    }

    private void appendEstimatedGapPoints(Location from, Location to, double seconds, float meters) {
        if (spatialView == null || Double.isNaN(anchorLatitude) || Double.isNaN(anchorLongitude)) return;
        int pointCount = Math.max(1, Math.min(120,
                (int)Math.ceil(seconds / AUTO_REPAIR_POINT_INTERVAL_SECONDS) - 1));
        float baseDistance = gpsDistanceMeters;
        float inferredKmh = (float)(meters / Math.max(0.001, seconds) * 3.6);
        float fromBearing = from.hasBearing() ? from.getBearing() : to.hasBearing() ? to.getBearing() : 0f;
        float toBearing = to.hasBearing() ? to.getBearing() : fromBearing;
        float estimatedAccuracy = Math.max(from.hasAccuracy() ? from.getAccuracy() : 0f,
                to.hasAccuracy() ? to.getAccuracy() : 0f) + 25f;
        for (int i = 1; i <= pointCount; i++) {
            float t = i / (float)(pointCount + 1);
            double lat = from.getLatitude() + (to.getLatitude() - from.getLatitude()) * t;
            double lon = from.getLongitude() + (to.getLongitude() - from.getLongitude()) * t;
            long time = from.getTime() + Math.round((to.getTime() - from.getTime()) * t);
            float[] rel = latLonToRelativeMeters(anchorLatitude, anchorLongitude, lat, lon);
            SpatialView.TrailPoint estimated = new SpatialView.TrailPoint(
                    rel[0], rel[1], time, interpolateAngleDegrees(fromBearing, toBearing, t),
                    inferredKmh, baseDistance + meters * t, "[]", activeMapProvider,
                    anchorLatitude, anchorLongitude, 18, 1f, 0f, 0f, "[]", false,
                    lat, lon, estimatedAccuracy, "estimated-gap");
            spatialView.appendTrailPoint(estimated);
        }
    }

    /** Returns the exact recorded WGS-84 coordinate when present, with legacy fallback. */
    private double[] pointWgs(SpatialView.TrailPoint point) {
        if (point != null && Double.isFinite(point.latitude) && Double.isFinite(point.longitude) &&
                Math.abs(point.latitude) <= 90.0 && Math.abs(point.longitude) <= 180.0) {
            return new double[]{point.latitude, point.longitude};
        }
        if (point != null && !Double.isNaN(anchorLatitude) && !Double.isNaN(anchorLongitude))
            return SpatialView.relativeMetersToLatLon(anchorLatitude, anchorLongitude, point.x, point.y);
        if (point != null && Double.isFinite(point.mapCenterLatitude) && Double.isFinite(point.mapCenterLongitude))
            return new double[]{point.mapCenterLatitude, point.mapCenterLongitude};
        return new double[]{mapTileView == null ? 0.0 : mapTileView.getCenterLatitude(),
                mapTileView == null ? 0.0 : mapTileView.getCenterLongitude()};
    }

    private Location getBestLastKnownLocation() {
        return getBestLastKnownLocation(120_000L, 100f);
    }

    private Location getBestLastKnownLocation(long maxAgeMs, float maxAccuracyMeters) {
        if (locationManager == null || !hasAnyLocationPermission()) return null;
        Location best = null;
        double bestScore = Double.POSITIVE_INFINITY;
        long now = System.currentTimeMillis();
        try {
            for (String provider : locationManager.getProviders(true)) {
                Location location = locationManager.getLastKnownLocation(provider);
                if (location == null) continue;
                long age = Math.max(0L, now - location.getTime());
                float accuracy = location.hasAccuracy() ? location.getAccuracy() : maxAccuracyMeters;
                if (age > maxAgeMs || accuracy > maxAccuracyMeters) continue;
                double score = accuracy + age / 2000.0;
                if (score < bestScore) { best = location; bestScore = score; }
            }
        } catch (SecurityException ignored) { }
        return best;
    }

    private void ensureGeoAnchor(boolean showFeedback) {
        if (!Double.isNaN(anchorLatitude) && !Double.isNaN(anchorLongitude)) return;
        if (!hasAnyLocationPermission()) return;
        Location location = getBestLastKnownLocation();
        if (location != null) {
            setGeoAnchorFromLocation(location);
            if (spatialView != null) spatialView.setGeoAnchor(anchorLatitude, anchorLongitude);
            updateSensorText();
            return;
        }
        if (locationManager == null || !isLocationEnabled()) return;
        try {
            LocationListener listener = new LocationListener() {
                @Override public void onLocationChanged(Location loc) {
                    try { locationManager.removeUpdates(this); } catch (Exception ignored) { }
                    setGeoAnchorFromLocation(loc);
                    if (spatialView != null) spatialView.setGeoAnchor(anchorLatitude, anchorLongitude);
                    updateSensorText();
                    if (showFeedback) Toast.makeText(MainActivity.this, "已获取地图坐标", Toast.LENGTH_SHORT).show();
                }
                @Override public void onProviderEnabled(String p) { }
                @Override public void onProviderDisabled(String p) { }
                @Override public void onStatusChanged(String p, int status, Bundle extras) { }
            };
            String source = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ?
                    LocationManager.GPS_PROVIDER : LocationManager.NETWORK_PROVIDER;
            locationManager.requestSingleUpdate(source, listener, Looper.getMainLooper());
        } catch (Exception ignored) { }
    }

    private void showMapBackground(String provider) {
        if (!hasAnyLocationPermission()) {
            Toast.makeText(this, "请先授予精确位置权限", Toast.LENGTH_LONG).show();
            ensurePermissions(true);
            return;
        }
        List<SpatialView.TrailPoint> existing = spatialView == null
                ? new ArrayList<>() : spatialView.getTrailCopy();
        if (existing.size() > 1 &&
                ((!Double.isNaN(anchorLatitude) && !Double.isNaN(anchorLongitude)) || hasExactWgs(existing.get(0)))) {
            int index = (replaying || replayPaused)
                    ? Math.max(0, Math.min(replayCurrentIndex, existing.size() - 1))
                    : (mapping ? existing.size() - 1 : 0);
            SpatialView.TrailPoint target = existing.get(index);
            double[] geo = pointWgs(target);
            applyMapBackground(provider, geo[0], geo[1]);
            handler.postDelayed(() -> spatialView.centerOnTrailPoint(index), 180L);
            return;
        }
        if (!isLocationEnabled()) {
            Toast.makeText(this, "请先打开系统位置服务", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            return;
        }
        Location location = getBestLastKnownLocation(30_000L, 40f);
        if (location != null) {
            if (Double.isNaN(anchorLatitude) && existing.size() <= 1) {
                setGeoAnchorFromLocation(location);
                if (spatialView != null) spatialView.setGeoAnchor(anchorLatitude, anchorLongitude);
            }
            applyMapBackground(provider, location.getLatitude(), location.getLongitude());
            return;
        }
        Toast.makeText(this, "正在获取当前位置…", Toast.LENGTH_SHORT).show();
        try {
            LocationListener listener = new LocationListener() {
                @Override public void onLocationChanged(Location loc) {
                    try { locationManager.removeUpdates(this); } catch (Exception ignored) { }
                    if (Double.isNaN(anchorLatitude) && spatialView.getPointCount() <= 1) {
                        setGeoAnchorFromLocation(loc);
                        spatialView.setGeoAnchor(anchorLatitude, anchorLongitude);
                    }
                    applyMapBackground(provider, loc.getLatitude(), loc.getLongitude());
                }
                @Override public void onProviderEnabled(String p) { }
                @Override public void onProviderDisabled(String p) { }
                @Override public void onStatusChanged(String p, int status, Bundle extras) { }
            };
            String source = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ?
                    LocationManager.GPS_PROVIDER : LocationManager.NETWORK_PROVIDER;
            locationManager.requestSingleUpdate(source, listener, Looper.getMainLooper());
            handler.postDelayed(() -> {
                if (mapTileView == null || mapTileView.getVisibility() != View.VISIBLE)
                    Toast.makeText(MainActivity.this, "暂时无法定位，请到室外或等待定位后重试", Toast.LENGTH_LONG).show();
            }, 10000L);
        } catch (Exception e) {
            Toast.makeText(this, "定位失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void setGeoAnchorFromLocation(Location location) {
        if (location == null) return;
        anchorLatitude = location.getLatitude();
        anchorLongitude = location.getLongitude();
        anchorAccuracyMeters = location.hasAccuracy() ? location.getAccuracy() : Float.NaN;
        anchorProvider = location.getProvider() == null ? "unknown" : location.getProvider();
        anchorTimeMs = location.getTime();
    }

    private void applyMapBackground(String provider, double latitude, double longitude) {
        // The trajectory origin and the map viewport center are different concepts.
        // Never overwrite the saved track origin merely because the user switches a map layer.
        activeMapProvider = provider;
        // 地图控件统一接收原始 WGS-84。各地图坐标转换只在 MapTileView 内部完成，
        // 避免百度/高德在不同入口（实时定位、导入、恢复）发生重复转换。
        mapTileView.setVisibility(View.VISIBLE);
        mapTileView.setLocationCoordinateHint(anchorProvider);
        // 标准模式固定使用 WGS-84 输入，百度转换仅在 MapTileView 中执行一次。
        mapTileView.setBaiduCoordinateMode("wgs");
        mapTileView.setMap(provider, latitude, longitude, 18);
        spatialView.resetViewport();
        spatialView.setMapBackgroundVisible(true, latitude, 18);
        String name = "google".equals(provider) ? "谷歌地图" :
                ("amap".equals(provider) ? "高德地图" : "百度地图");
        if (mapStatusText != null) mapStatusText.setText("正在加载" + name + "…");
        Toast.makeText(this, "正在加载" + name + "，将自动切换备用源", Toast.LENGTH_LONG).show();
    }

    private void hideMapBackground() {
        activeMapProvider = "none";
        if (mapTileView != null) {
            mapTileView.clearMap();
            mapTileView.setVisibility(View.GONE);
        }
        if (spatialView != null) spatialView.setMapBackgroundVisible(false, 0.0, 19);
        if (mapStatusText != null) mapStatusText.setText("地图状态：未开启底图");
    }

    private static double[] wgs84ToGcj02(double lat, double lon) {
        if (lon < 72.004 || lon > 137.8347 || lat < 0.8293 || lat > 55.8271) return new double[]{lat, lon};
        double dLat = transformLat(lon - 105.0, lat - 35.0);
        double dLon = transformLon(lon - 105.0, lat - 35.0);
        double radLat = lat / 180.0 * Math.PI;
        double magic = Math.sin(radLat);
        magic = 1 - 0.00669342162296594323 * magic * magic;
        double sqrtMagic = Math.sqrt(magic);
        dLat = (dLat * 180.0) / ((6378245.0 * (1 - 0.00669342162296594323)) / (magic * sqrtMagic) * Math.PI);
        dLon = (dLon * 180.0) / (6378245.0 / sqrtMagic * Math.cos(radLat) * Math.PI);
        return new double[]{lat + dLat, lon + dLon};
    }

    private static double transformLat(double x, double y) {
        double ret = -100.0 + 2.0*x + 3.0*y + 0.2*y*y + 0.1*x*y + 0.2*Math.sqrt(Math.abs(x));
        ret += (20.0*Math.sin(6.0*x*Math.PI) + 20.0*Math.sin(2.0*x*Math.PI))*2.0/3.0;
        ret += (20.0*Math.sin(y*Math.PI) + 40.0*Math.sin(y/3.0*Math.PI))*2.0/3.0;
        ret += (160.0*Math.sin(y/12.0*Math.PI) + 320*Math.sin(y*Math.PI/30.0))*2.0/3.0;
        return ret;
    }

    private static double transformLon(double x, double y) {
        double ret = 300.0 + x + 2.0*y + 0.1*x*x + 0.1*x*y + 0.1*Math.sqrt(Math.abs(x));
        ret += (20.0*Math.sin(6.0*x*Math.PI) + 20.0*Math.sin(2.0*x*Math.PI))*2.0/3.0;
        ret += (20.0*Math.sin(x*Math.PI) + 40.0*Math.sin(x/3.0*Math.PI))*2.0/3.0;
        ret += (150.0*Math.sin(x/12.0*Math.PI) + 300.0*Math.sin(x/30.0*Math.PI))*2.0/3.0;
        return ret;
    }

    private static double[] gcj02ToBd09(double lat, double lon) {
        double xPi = Math.PI * 3000.0 / 180.0;
        double z = Math.sqrt(lon*lon + lat*lat) + 0.00002*Math.sin(lat*xPi);
        double theta = Math.atan2(lat, lon) + 0.000003*Math.cos(lon*xPi);
        return new double[]{z*Math.sin(theta) + 0.006, z*Math.cos(theta) + 0.0065};
    }

    private void openRelevantSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    android.net.Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
        }
    }

    private List<ScanResult> getSortedResults() {
        try {
            List<ScanResult> list = new ArrayList<>(wifiManager.getScanResults());
            Collections.sort(list, new Comparator<ScanResult>() {
                @Override public int compare(ScanResult first, ScanResult second) {
                    return Integer.compare(second.level, first.level);
                }
            });
            return list;
        } catch (SecurityException e) {
            return new ArrayList<>();
        }
    }

    private void calibrate() {
        List<ScanResult> list = getSortedResults();
        if (list.isEmpty()) {
            Toast.makeText(this, "当前没有扫描数据，不能设置基线", Toast.LENGTH_LONG).show();
            return;
        }
        baseline.clear();
        for (ScanResult r : list) baseline.put(r.BSSID, r.level);
        Toast.makeText(this, "已记录 " + baseline.size() + " 个接入点作为基线", Toast.LENGTH_SHORT).show();
        readResults();
    }

    private void readResults() {
        List<ScanResult> list = getSortedResults();
        signalView.setResults(list);
        double sum = 0;
        int matched = 0;
        for (ScanResult r : list) {
            Integer base = baseline.get(r.BSSID);
            if (base != null) {
                sum += Math.abs(r.level - base);
                matched++;
            }
        }
        double change = matched == 0 ? 0 : sum / matched;
        String state = baseline.isEmpty() ? "未设置基线" : (change >= 7 ? "无线环境变化明显" : "无线环境相对稳定");

        double deltaSum = 0.0;
        int deltaCount = 0;
        double signed = 0.0;
        for (ScanResult r : list) {
            Integer prev = previousLevels.get(r.BSSID);
            if (prev != null) {
                int d = r.level - prev;
                deltaSum += Math.abs(d);
                signed += d;
                deltaCount++;
            }
            previousLevels.put(r.BSSID, r.level);
        }
        float activity = deltaCount == 0 ? 0f : (float)Math.min(1.0, (deltaSum / deltaCount) / 10.0);
        float activityDirection = headingRad + (signed >= 0 ? 0.75f : -0.75f);
        if (spatialView != null) spatialView.setActivity(activity, activityDirection);
        String activityLabel = activity > 0.7f ? "疑似明显活动" : activity > 0.35f ? "疑似轻微活动" : "未发现明显活动";
        statusText.setText(String.format(Locale.CHINA, "%s · %s · %d 个网络 · 变化 %.1f dB", state, activityLabel, list.size(), change));

        StringBuilder text = new StringBuilder();
        text.append(String.format(Locale.CHINA, "活动概率（低置信度）：%.0f%%\n", activity * 100f));
        text.append("说明：此结果来自多个 Wi‑Fi 信号短时波动，不能确认人数、身份或人体轮廓。\n\n");
        for (int i = 0; i < list.size(); i++) {
            ScanResult r = list.get(i);
            String ssid = r.SSID == null || r.SSID.isEmpty() ? "隐藏网络" : r.SSID;
            text.append(i + 1).append(". ").append(ssid).append("\n")
                    .append("   BSSID：").append(r.BSSID == null ? "未知" : r.BSSID).append("\n")
                    .append("   信号：").append(r.level).append(" dBm（").append(signalDescription(r.level)).append("）\n")
                    .append("   频段：").append(bandDescription(r.frequency))
                    .append(" · ").append(r.frequency).append(" MHz")
                    .append(" · 信道 ").append(channelForFrequency(r.frequency)).append("\n")
                    .append("   安全：").append(securityDescription(r.capabilities)).append("\n")
                    .append("   能力：").append(r.capabilities == null || r.capabilities.isEmpty() ? "未提供" : r.capabilities)
                    .append("\n\n");
        }
        if (list.isEmpty()) text.append("没有读取到扫描结果。请打开 Wi‑Fi、位置服务，并授予附近设备和精确位置权限。");
        detailText.setText(text.toString());
    }

    private String signalDescription(int rssi) {
        if (rssi >= -50) return "极强";
        if (rssi >= -60) return "强";
        if (rssi >= -70) return "良好";
        if (rssi >= -80) return "较弱";
        return "很弱";
    }

    private String bandDescription(int frequency) {
        if (frequency >= 5925) return "6 GHz";
        if (frequency >= 4900) return "5 GHz";
        if (frequency >= 2400) return "2.4 GHz";
        return "未知频段";
    }

    private int channelForFrequency(int frequency) {
        if (frequency == 2484) return 14;
        if (frequency >= 2412 && frequency <= 2472) return (frequency - 2407) / 5;
        if (frequency >= 5000 && frequency <= 5895) return (frequency - 5000) / 5;
        if (frequency >= 5955 && frequency <= 7115) return (frequency - 5950) / 5;
        return 0;
    }

    private String securityDescription(String capabilities) {
        if (capabilities == null || capabilities.isEmpty()) return "开放或未知";
        String c = capabilities.toUpperCase(Locale.US);
        if (c.contains("WPA3") || c.contains("SAE")) return "WPA3";
        if (c.contains("WPA2")) return "WPA2";
        if (c.contains("WPA")) return "WPA";
        if (c.contains("WEP")) return "WEP（不安全）";
        if (c.contains("OWE")) return "增强开放网络 OWE";
        return c.contains("ESS") ? "开放网络" : "未知";
    }

    private void showMoreMenu() {
        String[] items = {
                "扫描 Wi-Fi",
                "设为 Wi-Fi 基线",
                "重置空间草图",
                "轨迹回放",
                "停止回放",
                "导出轨迹",
                "导入轨迹",
                "保存草图 PNG",
                "保存回放 MP4",
                "自动备份设置",
                "备份记录列表",
                "清除全部备份",
                "导出系统全量数据",
                "恢复系统全量数据",
                "数据修复（重新计算里程）",
                "误差设置",
                "百度坐标模式",
                "权限 / 位置设置",
                "Bug 上报（导出日志）",
                "关于我们"
        };
        new AlertDialog.Builder(this)
                .setTitle("更多功能")
                .setItems(items, (dialog, which) -> {
                    switch (which) {
                        case 0: onScanClicked(); break;
                        case 1: calibrate(); break;
                        case 2:
                            stopReplay();
                            mappedSteps = 0;
                            mappingStartElapsedMs = 0L;
                            lastStepElapsedMs = 0L;
                            currentSpeedKmh = 0f;
                            maxSpeedKmh = 0f;
                            gpsDistanceMeters = 0f;
                            gpsTrackStartElapsedMs = 0L;
                            activeRecordingTimeMs = 0L;
                            currentRecordingSessionStartMs = 0L;
                            movingTimeMs = 0L;
                            pendingMaxSpeedKmh = 0f;
                            pendingMaxSpeedConfirmations = 0;
                            lastTrackLocation = null;
                            lastSpeedLocation = null;
                            lastValidGpsSpeedElapsedMs = 0L;
                            gpsSpeedAvailable = false;
                            speedSourceLabel = "等待速度数据";
                            spatialView.reset();
                            updateSensorText();
                            break;
                        case 3: startReplay(); break;
                        case 4: stopReplay(); break;
                        case 5: exportTrack(); break;
                        case 6: importTrack(); break;
                        case 7: showSaveLayerChoice(false); break;
                        case 8: showSaveLayerChoice(true); break;
                        case 9: showBackupSettings(); break;
                        case 10: showBackupList(); break;
                        case 11: confirmClearBackups(); break;
                        case 12: exportSystemData(); break;
                        case 13: importSystemData(); break;
                        case 14: repairCurrentTrackData(); break;
                        case 15: showErrorSettings(); break;
                        case 16: showBaiduCoordinateModeDialog(); break;
                        case 17: openRelevantSettings(); break;
                        case 18: exportBugReport(); break;
                        default: showAboutDialog(); break;
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }



    private void repairCurrentTrackData() {
        stopReplay();
        List<SpatialView.TrailPoint> oldPoints = spatialView.getTrailCopy();
        if (oldPoints.size() < 2) {
            Toast.makeText(this, "当前轨迹点不足，无法修复", Toast.LENGTH_LONG).show();
            return;
        }

        final double oldDistance = oldPoints.get(oldPoints.size() - 1).distanceMeters;
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        panel.setPadding(pad, dp(8), pad, 0);

        TextView help = new TextView(this);
        help.setText("请选择修复方式。旧轨迹存在时间倒序和长时间缺点时，单纯按速度阈值会漏算。\n\n" +
                "标准修复：按轨迹原始顺序重新累计。\n" +
                "道路估算：对超过500米的缺点段按道路弯曲系数1.35补偿。\n" +
                "按实际里程校正：只调整缺点段，使总里程达到输入值。 ");
        help.setTextSize(16f);
        panel.addView(help);

        RadioGroup group = new RadioGroup(this);
        String[] labels = {"标准修复（直线最低值）", "道路估算修复（推荐）", "按已知实际里程校正"};
        for (int i = 0; i < labels.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(5000 + i);
            rb.setText(labels[i]);
            rb.setTextSize(16f);
            group.addView(rb);
        }
        group.check(5001);
        panel.addView(group);

        EditText targetKm = new EditText(this);
        targetKm.setHint("实际总里程（公里），例如 11.0");
        targetKm.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        targetKm.setVisibility(View.GONE);
        panel.addView(targetKm, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        group.setOnCheckedChangeListener((g, checkedId) -> targetKm.setVisibility(checkedId == 5002 ? View.VISIBLE : View.GONE));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("数据修复")
                .setView(panel)
                .setNegativeButton("取消", null)
                .setPositiveButton("立即修复", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try {
                int mode = group.getCheckedRadioButtonId() - 5000;
                double requestedMeters = 0.0;
                if (mode == 2) {
                    String text = targetKm.getText().toString().trim();
                    if (text.isEmpty()) {
                        targetKm.setError("请输入实际总里程");
                        return;
                    }
                    requestedMeters = Double.parseDouble(text) * 1000.0;
                    if (!Double.isFinite(requestedMeters) || requestedMeters <= 0.0 || requestedMeters > 2_000_000.0) {
                        targetKm.setError("请输入合理的公里数");
                        return;
                    }
                }

                saveAutoBackup(true);
                RepairResult result = rebuildTrackDistance(oldPoints, mode, requestedMeters);
                spatialView.setTrail(result.points);
                gpsDistanceMeters = (float) result.totalMeters;
                // 数据修复只修复距离：不修改实时、平均或最高速度状态。
                // 原始轨迹点中的 speedKmh（包括 >= 80 km/h）全部原样保留。
                mappedSteps = Math.max(0, result.points.size() - 1);
                lastTrackLocation = null;
                lastSpeedLocation = null;
                updateSensorText();
                saveAutoBackup(true);
                dialog.dismiss();

                String message = String.format(Locale.CHINA,
                        "修复完成\n\n修复前：%.1f m\n有效连续轨迹：%.1f m\n缺点段直线距离：%.1f m\n缺点段补偿：%.1f m\n修复后：%.1f m\n总时长：%s\n速度数据：保持原样（包含 >= 80 km/h）\n时间倒序点：%d 个\n长缺点段：%d 段",
                        oldDistance, result.continuousMeters, result.gapStraightMeters,
                        result.gapAddedMeters, result.totalMeters, formatDuration(result.durationMs),
                        result.reversedTimeCount, result.longGapCount);
                new AlertDialog.Builder(this)
                        .setTitle("数据修复完成")
                        .setMessage(message)
                        .setPositiveButton("确定", null)
                        .show();
            } catch (Exception e) {
                Toast.makeText(this, "数据修复失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }));
        dialog.show();
    }

    private static class RepairResult {
        final List<SpatialView.TrailPoint> points;
        final double totalMeters, continuousMeters, gapStraightMeters, gapAddedMeters;
        final int reversedTimeCount, longGapCount;
        final float maxSpeedKmh, averageSpeedKmh, currentSpeedKmh;
        final long durationMs;
        RepairResult(List<SpatialView.TrailPoint> points, double totalMeters, double continuousMeters,
                     double gapStraightMeters, double gapAddedMeters, int reversedTimeCount,
                     int longGapCount, float maxSpeedKmh, float averageSpeedKmh,
                     float currentSpeedKmh, long durationMs) {
            this.points = points; this.totalMeters = totalMeters; this.continuousMeters = continuousMeters;
            this.gapStraightMeters = gapStraightMeters; this.gapAddedMeters = gapAddedMeters;
            this.reversedTimeCount = reversedTimeCount; this.longGapCount = longGapCount;
            this.maxSpeedKmh = maxSpeedKmh; this.averageSpeedKmh = averageSpeedKmh;
            this.currentSpeedKmh = currentSpeedKmh; this.durationMs = durationMs;
        }
    }

    private RepairResult rebuildTrackDistance(List<SpatialView.TrailPoint> source, int mode, double requestedMeters) {
        int n = source.size();
        double[] raw = new double[n];
        boolean[] longGap = new boolean[n];
        double continuous = 0.0, gapStraight = 0.0;
        int reversed = 0, gaps = 0;
        float maxSpeed = 0f;

        for (int i = 1; i < n; i++) {
            SpatialView.TrailPoint a = source.get(i - 1), b = source.get(i);
            double d = Math.hypot(b.x - a.x, b.y - a.y);
            if (!Double.isFinite(d) || d < 0.0 || d > 200_000.0) d = 0.0;
            long dt = b.timeMs - a.timeMs;
            if (dt < 0) reversed++;
            boolean isGap = d >= 500.0 || Math.abs(dt) >= 60_000L;
            raw[i] = d;
            longGap[i] = isGap;
            if (isGap) { gapStraight += d; gaps++; }
            else continuous += d;
            if (Float.isFinite(b.speedKmh) && b.speedKmh >= 0f)
                maxSpeed = Math.max(maxSpeed, b.speedKmh);
        }

        double gapFactor = 1.0;
        if (mode == 1) gapFactor = 1.35;
        else if (mode == 2) {
            if (gapStraight <= 0.01) throw new IllegalArgumentException("没有可校正的缺点路段");
            gapFactor = (requestedMeters - continuous) / gapStraight;
            if (!Double.isFinite(gapFactor) || gapFactor < 1.0 || gapFactor > 3.0)
                throw new IllegalArgumentException("输入里程与现有轨迹差异过大");
        }

        List<SpatialView.TrailPoint> repaired = new ArrayList<>();
        double cumulative = 0.0;
        long minTime = source.get(0).timeMs, maxTime = source.get(0).timeMs;
        repaired.add(copyPointWithDistance(source.get(0), 0f));
        for (int i = 1; i < n; i++) {
            SpatialView.TrailPoint cur = source.get(i);
            double contribution = raw[i] * (longGap[i] ? gapFactor : 1.0);
            cumulative += contribution;
            minTime = Math.min(minTime, cur.timeMs);
            maxTime = Math.max(maxTime, cur.timeMs);
            // 仅更新累计距离，速度字段原样复制，不设置任何速度上限。
            repaired.add(copyPointWithDistance(cur, (float)cumulative));
        }
        long durationMs = Math.max(1L, maxTime - minTime);
        float preservedMax = 0f;
        for (SpatialView.TrailPoint point : source) {
            if (Float.isFinite(point.speedKmh) && point.speedKmh >= 0f) {
                preservedMax = Math.max(preservedMax, point.speedKmh);
            }
        }
        float preservedCurrent = source.get(source.size() - 1).speedKmh;
        if (!Float.isFinite(preservedCurrent) || preservedCurrent < 0f) preservedCurrent = 0f;
        float displayAverage = (float)(cumulative / (durationMs / 1000.0) * 3.6);
        return new RepairResult(repaired, cumulative, continuous, gapStraight,
                gapStraight * Math.max(0.0, gapFactor - 1.0), reversed, gaps,
                preservedMax, displayAverage, preservedCurrent, durationMs);
    }

    private static String formatDuration(long durationMs) {
        long totalSeconds = Math.max(0L, durationMs / 1000L);
        long hours = totalSeconds / 3600L;
        long minutes = (totalSeconds % 3600L) / 60L;
        long seconds = totalSeconds % 60L;
        return String.format(Locale.CHINA, "%02d:%02d:%02d", hours, minutes, seconds);
    }

    private SpatialView.TrailPoint copyPointWithDistance(SpatialView.TrailPoint p, float distance) {
        return copyPointWithDistanceAndSpeed(p, distance, p.speedKmh);
    }

    private SpatialView.TrailPoint copyPointWithDistanceAndSpeed(SpatialView.TrailPoint p, float distance, float speed) {
        return new SpatialView.TrailPoint(p.x, p.y, p.timeMs, p.headingDegrees, speed, distance,
                p.wifiSnapshotJson, p.mapProvider, p.mapCenterLatitude, p.mapCenterLongitude,
                p.mapZoom, p.mapScale, p.mapPanX, p.mapPanY, p.mapTileKeysJson, p.segmentStart,
                p.latitude, p.longitude, p.accuracyMeters, p.locationProvider);
    }

    private void showBaiduCoordinateModeDialog() {
        final String[] values = {"auto", "wgs", "gcj"};
        final String[] labels = {
                "自动判断（推荐：GPS 按 WGS，网络/融合按 GCJ）",
                "强制 WGS-84 → GCJ-02 → BD-09",
                "强制当前位置已是 GCJ-02 → BD-09"
        };
        android.content.SharedPreferences prefs = getSharedPreferences("settings", MODE_PRIVATE);
        String current = prefs.getString("baidu_coordinate_mode", "auto");
        int checked = 0;
        for (int i = 0; i < values.length; i++) if (values[i].equals(current)) checked = i;
        new AlertDialog.Builder(this)
                .setTitle("百度坐标模式")
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    prefs.edit().putString("baidu_coordinate_mode", values[which]).apply();
                    if (mapTileView != null) mapTileView.setBaiduCoordinateMode(values[which]);
                    dialog.dismiss();
                    Toast.makeText(this, "百度坐标模式已更新，请重新点击百度地图", Toast.LENGTH_LONG).show();
                })
                .setNegativeButton("取消", null)
                .show();
    }











    /**
     * 把诊断文件复制到公共 Download/小魁WiFi骑行诊断/。
     * Android 10+ 使用 MediaStore.Downloads，无需存储权限；Android 9 及以下写公共下载目录。
     */


    private void exportBugReport() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, "xiaokui_bug_report_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".txt");
        startActivityForResult(intent, REQ_EXPORT_BUG_REPORT);
    }

    private String buildBugReport() {
        StringBuilder out = new StringBuilder();
        out.append("小魁WiFi骑行 Bug Report\n");
        try {
            android.content.pm.PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            out.append("package=").append(getPackageName()).append('\n');
            out.append("versionName=").append(info.versionName).append('\n');
            if (Build.VERSION.SDK_INT >= 28) out.append("versionCode=").append(info.getLongVersionCode()).append('\n');
            else out.append("versionCode=").append(info.versionCode).append('\n');
        } catch (Exception e) { out.append("packageInfoError=").append(e).append('\n'); }
        out.append("generatedAt=").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date())).append('\n');
        out.append("manufacturer=").append(Build.MANUFACTURER).append('\n');
        out.append("model=").append(Build.MODEL).append('\n');
        out.append("device=").append(Build.DEVICE).append('\n');
        out.append("androidRelease=").append(Build.VERSION.RELEASE).append('\n');
        out.append("sdkInt=").append(Build.VERSION.SDK_INT).append('\n');
        out.append("fineLocationPermission=").append(checkSelfPermissionCompat(Manifest.permission.ACCESS_FINE_LOCATION)).append('\n');
        out.append("coarseLocationPermission=").append(checkSelfPermissionCompat(Manifest.permission.ACCESS_COARSE_LOCATION)).append('\n');
        if (Build.VERSION.SDK_INT >= 33) out.append("nearbyWifiPermission=").append(checkSelfPermissionCompat(Manifest.permission.NEARBY_WIFI_DEVICES)).append('\n');
        out.append("wifiEnabled=").append(wifiManager != null && wifiManager.isWifiEnabled()).append('\n');
        try {
            android.location.LocationManager lm = (android.location.LocationManager)getSystemService(LOCATION_SERVICE);
            out.append("locationEnabled=").append(Build.VERSION.SDK_INT >= 28 ? lm.isLocationEnabled() : "unknown").append('\n');
            out.append("locationProviders=").append(lm.getProviders(true)).append('\n');
        } catch (Exception e) { out.append("locationStateError=").append(e).append('\n'); }
        out.append("mapping=").append(mapping).append('\n');
        boolean storedTrackingActive = TrackingStateStore.isActive(this);
        long heartbeat = TrackingStateStore.getServiceHeartbeatWallMs(this);
        out.append("trackingStateActive=").append(storedTrackingActive).append('\n');
        out.append("trackingServiceHeartbeatAgeMs=")
                .append(heartbeat <= 0L ? -1L : Math.max(0L, System.currentTimeMillis() - heartbeat)).append('\n');
        out.append("trackingJournalBytes=").append(TrackingStateStore.getJournalBytes(this)).append('\n');
        out.append("trackingJournalConsumedSeq=").append(TrackingStateStore.getLastConsumedSeq(this)).append('\n');
        long journalLocationWall = TrackingStateStore.getLastJournalLocationWallMs(this);
        out.append("trackingJournalLastLocationAgeMs=")
                .append(journalLocationWall <= 0L ? -1L : Math.max(0L, System.currentTimeMillis() - journalLocationWall)).append('\n');
        out.append("trackingJournalProvider=").append(TrackingStateStore.getLastJournalProvider(this)).append('\n');
        out.append("lastLocationCallbackAgeMs=")
                .append(lastLocationCallbackElapsedMs <= 0L ? -1L : Math.max(0L, SystemClock.elapsedRealtime() - lastLocationCallbackElapsedMs)).append('\n');
        out.append("trackOrigin=").append(anchorLatitude).append(',').append(anchorLongitude)
                .append(" accuracy=").append(anchorAccuracyMeters).append(" provider=").append(anchorProvider).append('\n');
        out.append("wifiResultCount=").append(getSortedResults().size()).append('\n');
        out.append("currentSpeedKmh=").append(currentSpeedKmh).append('\n');
        out.append("maxSpeedKmh=").append(maxSpeedKmh).append('\n');
        out.append("speedSource=").append(speedSourceLabel).append('\n');
        Location reportLocation = lastSpeedLocation != null ? lastSpeedLocation : lastTrackLocation;
        if (reportLocation != null) {
            out.append("lastLocation=").append(reportLocation.getLatitude()).append(',').append(reportLocation.getLongitude())
                    .append(" accuracy=").append(reportLocation.hasAccuracy() ? reportLocation.getAccuracy() : -1)
                    .append(" provider=").append(reportLocation.getProvider()).append('\n');
        } else out.append("lastLocation=null\n");
        out.append("\n--- Map diagnostics ---\n");
        if (mapTileView != null) {
            out.append(mapTileView.getDiagnosticLog());
        } else out.append("mapTileView=null\n");
        return out.toString();
    }

    private String checkSelfPermissionCompat(String permission) {
        if (Build.VERSION.SDK_INT < 23) return "granted";
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED ? "granted" : "denied";
    }

    private void writeBugReportToUri(Uri uri) {
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new IOException("无法打开日志文件");
            out.write(buildBugReport().getBytes(java.nio.charset.StandardCharsets.UTF_8));
            out.flush();
            Toast.makeText(this, "Bug 日志已导出，请把该 txt 文件发送给开发者", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "导出日志失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void showErrorSettings() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String[] labels = {"排除定位精度过差", "排除瞬间跳点", "排除超过 300 km/h 的异常值"};
        boolean[] checked = {
                prefs.getBoolean(PREF_FILTER_POOR_ACCURACY, true),
                prefs.getBoolean(PREF_FILTER_JUMP_POINTS, true),
                prefs.getBoolean(PREF_FILTER_OVER_300, true)
        };
        new AlertDialog.Builder(this)
                .setTitle("误差设置（可多选；全部取消即不过滤）")
                .setMultiChoiceItems(labels, checked, (dialog, which, isChecked) -> checked[which] = isChecked)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", (dialog, which) -> {
                    prefs.edit()
                            .putBoolean(PREF_FILTER_POOR_ACCURACY, checked[0])
                            .putBoolean(PREF_FILTER_JUMP_POINTS, checked[1])
                            .putBoolean(PREF_FILTER_OVER_300, checked[2])
                            .apply();
                    Toast.makeText(this, "误差设置已保存", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void showAboutDialog() {
        String version = "未知";
        try {
            version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) { }
        String text = "小魁WiFi骑行\n当前版本：" + version +
                "\n\n本应用用于记录骑行速度、轨迹、Wi-Fi 环境与地图信息。" +
                "\n\n客服QQ:653902670\nE-mail:mail@pt20.cn";
        new AlertDialog.Builder(this)
                .setTitle("关于我们")
                .setMessage(text)
                .setPositiveButton("关闭", null)
                .show();
    }

    private void showBackupSettings() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        boolean enabled = prefs.getBoolean(PREF_BACKUP_ENABLED, true);
        int keep = prefs.getInt(PREF_BACKUP_KEEP, 5);
        String[] choices = {"关闭", "仅本机 · 保留 5 份", "仅本机 · 保留 10 份", "仅本机 · 保留 20 份"};
        int checked = !enabled ? 0 : keep == 10 ? 2 : keep == 20 ? 3 : 1;
        new AlertDialog.Builder(this).setTitle("自动备份")
                .setSingleChoiceItems(choices, checked, null)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", (d,w) -> {
                    AlertDialog dialog = (AlertDialog)d;
                    int selected = dialog.getListView().getCheckedItemPosition();
                    boolean on = selected != 0; int count = selected == 2 ? 10 : selected == 3 ? 20 : 5;
                    prefs.edit().putBoolean(PREF_BACKUP_ENABLED, on).putInt(PREF_BACKUP_KEEP, count).apply();
                    Toast.makeText(this, on ? "自动备份已启用，仅保存在本机" : "自动备份已关闭", Toast.LENGTH_LONG).show();
                }).show();
    }

    private void confirmClearBackups() {
        new AlertDialog.Builder(this).setTitle("清除全部备份")
                .setMessage("将删除应用本机保存的所有自动轨迹备份，手动导出的文件不受影响。")
                .setNegativeButton("取消", null)
                .setPositiveButton("清除", (d,w) -> {
                    File dir = new File(getFilesDir(), AUTO_BACKUP_DIR);
                    File[] files = dir.listFiles(); int removed = 0;
                    if (files != null) for (File f : files) {
                        if (f.getName().endsWith(LOCK_SUFFIX)) continue;
                        if (isBackupLocked(f)) continue;
                        if (f.delete()) { backupLockFile(f).delete(); removed++; }
                    }
                    Toast.makeText(this, "已清除 " + removed + " 个本机备份", Toast.LENGTH_LONG).show();
                }).show();
    }

    private File backupLockFile(File backup) {
        return new File(backup.getParentFile(), backup.getName() + LOCK_SUFFIX);
    }

    private boolean isBackupLocked(File backup) {
        return backup != null && backupLockFile(backup).exists();
    }

    private boolean setBackupLocked(File backup, boolean locked) {
        if (backup == null || "latest.json".equals(backup.getName())) return false;
        File marker = backupLockFile(backup);
        try {
            if (locked) return marker.exists() || marker.createNewFile();
            return !marker.exists() || marker.delete();
        } catch (IOException e) { return false; }
    }

    private File[] getBackupFiles() {
        File dir = new File(getFilesDir(), AUTO_BACKUP_DIR);
        File[] files = dir.listFiles((d, name) -> name.endsWith(".json"));
        if (files == null) return new File[0];
        java.util.Arrays.sort(files, (a,b) -> Long.compare(b.lastModified(), a.lastModified()));
        return files;
    }

    private void showBackupList() {
        File[] files = getBackupFiles();
        if (files.length == 0) {
            Toast.makeText(this, "当前没有本机自动备份", Toast.LENGTH_LONG).show();
            return;
        }
        CharSequence[] labels = new CharSequence[files.length];
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA);
        for (int i=0;i<files.length;i++) {
            boolean locked = isBackupLocked(files[i]);
            // FE0E 强制使用文字样式，避免系统把未锁定图标渲染成黄色彩色 Emoji。
            String icon = "🔒\uFE0E ";
            String text = icon + ("latest.json".equals(files[i].getName()) ? "最新自动备份" : "备份快照") +
                    "\n" + df.format(new Date(files[i].lastModified())) + " · " + (files[i].length()/1024+1) + " KB";
            SpannableString styled = new SpannableString(text);
            styled.setSpan(new ForegroundColorSpan(locked ? Color.rgb(190, 125, 20) : Color.rgb(145, 145, 145)),
                    0, icon.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            labels[i] = styled;
        }
        new AlertDialog.Builder(this).setTitle("本机备份记录")
                .setItems(labels, (d, which) -> showBackupActions(files[which]))
                .setNegativeButton("关闭", null).show();
    }

    private void showBackupActions(File file) {
        boolean locked = isBackupLocked(file);
        String[] actions = {"查看并载入", "导出副本", locked ? "🔓 解锁（图标变灰）" : "🔒 锁定防覆盖", "删除"};
        new AlertDialog.Builder(this).setTitle(file.getName()).setItems(actions, (d, which) -> {
            if (which == 0) {
                new AlertDialog.Builder(this).setTitle("载入备份")
                        .setMessage("当前草图将被该备份替换，是否继续？")
                        .setNegativeButton("取消", null)
                        .setPositiveButton("载入", (x,y) -> readTrackFromFile(file)).show();
            } else if (which == 1) {
                pendingBackupExportFile = file;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "backup_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date(file.lastModified())) + ".json");
                startActivityForResult(intent, REQ_EXPORT_BACKUP);
            } else if (which == 2) {
                boolean ok = setBackupLocked(file, !locked);
                Toast.makeText(this, ok ? (!locked ? "备份已锁定，不会被自动清理" : "备份已解锁") : "操作失败", Toast.LENGTH_LONG).show();
                if (ok) showBackupList();
            } else {
                new AlertDialog.Builder(this).setTitle("删除备份")
                        .setMessage("确定删除这份本机备份吗？")
                        .setNegativeButton("取消", null)
                        .setPositiveButton("删除", (x,y) -> {
                            boolean ok = file.delete();
                            if (ok) backupLockFile(file).delete();
                            Toast.makeText(this, ok ? "备份已删除" : "删除失败", Toast.LENGTH_LONG).show();
                            if (ok) showBackupList();
                        }).show();
            }
        }).setNegativeButton("取消", null).show();
    }

    private void readTrackFromFile(File file) {
        final LinearLayout box = createProgressBox("正在打开本机备份…");
        final ProgressBar bar = (ProgressBar) box.getChildAt(0);
        final TextView progress = (TextView) box.getChildAt(1);
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("载入备份")
                .setView(box)
                .setCancelable(false)
                .create();
        dialog.show();
        new Thread(() -> {
            try (CountingInputStream in = new CountingInputStream(new FileInputStream(file))) {
                final long total = Math.max(1L, file.length());
                ImportedTrack imported = readTrackFromStream(in, count -> {
                    if (count == 1 || count % 2000 == 0) {
                        int percent = percentOf(in.getCount(), total);
                        handler.post(() -> updateProgress(bar, progress, percent,
                                "正在后台解析备份… 已读取 " + count + " 个坐标点"));
                    }
                });
                handler.post(() -> {
                    updateProgress(bar, progress, 100, "解析完成，正在载入草图…");
                    try { applyImportedTrack(imported, "本机备份"); }
                    finally { dialog.dismiss(); }
                });
            } catch (OutOfMemoryError oom) {
                handler.post(() -> {
                    dialog.dismiss();
                    Toast.makeText(this, "读取备份失败：可用内存不足", Toast.LENGTH_LONG).show();
                });
            } catch (Exception e) {
                handler.post(() -> {
                    dialog.dismiss();
                    Toast.makeText(this, "读取备份失败：" + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()), Toast.LENGTH_LONG).show();
                });
            }
        }, "backup-import").start();
    }

    private void exportBackupToUri(Uri uri) {
        final File source = pendingBackupExportFile;
        pendingBackupExportFile = null;
        if (source == null) return;
        final LinearLayout box = createProgressBox("正在导出备份…");
        final ProgressBar bar = (ProgressBar) box.getChildAt(0);
        final TextView text = (TextView) box.getChildAt(1);
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("导出备份")
                .setView(box).setCancelable(false).create();
        dialog.show();
        new Thread(() -> {
            try (InputStream in = new FileInputStream(source);
                 OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IOException("无法打开目标文件");
                long total = Math.max(1L, source.length()), copied = 0L;
                byte[] buffer = new byte[65536]; int n; int lastPercent = -1;
                while ((n = in.read(buffer)) > 0) {
                    out.write(buffer, 0, n); copied += n;
                    int percent = percentOf(copied, total);
                    if (percent != lastPercent) {
                        lastPercent = percent;
                        final int shown = percent;
                        handler.post(() -> updateProgress(bar, text, shown, "正在导出备份…"));
                    }
                }
                out.flush();
                handler.post(() -> { dialog.dismiss(); Toast.makeText(this, "备份已导出", Toast.LENGTH_LONG).show(); });
            } catch (Exception e) {
                handler.post(() -> { dialog.dismiss(); Toast.makeText(this, "导出备份失败：" + e.getMessage(), Toast.LENGTH_LONG).show(); });
            }
        }, "backup-export").start();
    }

    private void showSaveLayerChoice(boolean video) {
        boolean mapAvailable = mapTileView != null && mapTileView.getVisibility() == View.VISIBLE && !"none".equals(activeMapProvider);
        String message = mapAvailable ? "是否把当前地图底图一起保存？" : "当前没有启用地图底图。仍可选择仅保存轨迹草图。";
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(video ? "保存回放 MP4" : "保存草图 PNG")
                .setMessage(message)
                .setNegativeButton("取消", null)
                .setNeutralButton("不含地图", (dialog, which) -> {
                    if (video) saveReplayVideo(false); else saveSketchPng(false);
                });
        if (mapAvailable) {
            builder.setPositiveButton("包含地图", (dialog, which) -> {
                if (video) saveReplayVideo(true); else saveSketchPng(true);
            });
        }
        builder.show();
    }

    private static final class ExportMapViewport {
        final float centerX, centerY;
        final double latitude, longitude;
        final int zoom;
        ExportMapViewport(float centerX, float centerY, double latitude, double longitude, int zoom) {
            this.centerX = centerX; this.centerY = centerY;
            this.latitude = latitude; this.longitude = longitude; this.zoom = zoom;
        }
    }

    private ExportMapViewport calculateExportViewport(List<SpatialView.TrailPoint> points, int width, int height) {
        SpatialView.TrailPoint boundsFirst = points.get(0);
        float minX = boundsFirst.x, maxX = boundsFirst.x, minY = boundsFirst.y, maxY = boundsFirst.y;
        int stride = Math.max(1, points.size() / 6000);
        for (int i = 0; i < points.size(); i += stride) {
            SpatialView.TrailPoint q = points.get(i);
            minX = Math.min(minX, q.x); maxX = Math.max(maxX, q.x);
            minY = Math.min(minY, q.y); maxY = Math.max(maxY, q.y);
        }
        SpatialView.TrailPoint last = points.get(points.size() - 1);
        minX = Math.min(minX, last.x); maxX = Math.max(maxX, last.x);
        minY = Math.min(minY, last.y); maxY = Math.max(maxY, last.y);
        float centerX = (minX + maxX) / 2f, centerY = (minY + maxY) / 2f;
        double lat, lon;
        double minLat = Double.POSITIVE_INFINITY, maxLat = Double.NEGATIVE_INFINITY;
        double minLon = Double.POSITIVE_INFINITY, maxLon = Double.NEGATIVE_INFINITY;
        int exactCount = 0;
        for (int i = 0; i < points.size(); i += stride) {
            SpatialView.TrailPoint q = points.get(i);
            if (!hasExactWgs(q)) continue;
            minLat = Math.min(minLat, q.latitude); maxLat = Math.max(maxLat, q.latitude);
            minLon = Math.min(minLon, q.longitude); maxLon = Math.max(maxLon, q.longitude);
            exactCount++;
        }
        if (hasExactWgs(last)) {
            minLat = Math.min(minLat, last.latitude); maxLat = Math.max(maxLat, last.latitude);
            minLon = Math.min(minLon, last.longitude); maxLon = Math.max(maxLon, last.longitude);
            exactCount++;
        }
        float rangeX;
        float rangeY;
        if (exactCount > 0) {
            lat = (minLat + maxLat) / 2.0;
            lon = (minLon + maxLon) / 2.0;
            rangeX = (float)Math.max(80.0, Math.toRadians(maxLon - minLon) * 6378137.0 *
                    Math.cos(Math.toRadians(lat)) + 120.0);
            rangeY = (float)Math.max(80.0, Math.toRadians(maxLat - minLat) * 6378137.0 + 120.0);
        } else {
            if (!Double.isNaN(anchorLatitude) && !Double.isNaN(anchorLongitude)) {
                double[] geo = SpatialView.relativeMetersToLatLon(anchorLatitude, anchorLongitude, centerX, centerY);
                lat = geo[0]; lon = geo[1];
            } else {
                SpatialView.TrailPoint middle = points.get(points.size() / 2);
                lat = Double.isNaN(middle.mapCenterLatitude) ? mapTileView.getCenterLatitude() : middle.mapCenterLatitude;
                lon = Double.isNaN(middle.mapCenterLongitude) ? mapTileView.getCenterLongitude() : middle.mapCenterLongitude;
            }
            rangeX = Math.max(80f, maxX - minX + 120f);
            rangeY = Math.max(80f, maxY - minY + 120f);
        }
        int selectedZoom = 3;
        for (int z = 19; z >= 3; z--) {
            double mpp = 156543.03392 * Math.cos(Math.toRadians(lat)) / Math.pow(2.0, z);
            if (rangeX / mpp <= width * 0.88 && rangeY / mpp <= height * 0.72) {
                selectedZoom = z; break;
            }
        }
        return new ExportMapViewport(centerX, centerY, lat, lon, selectedZoom);
    }

    private static boolean breaksExportPath(SpatialView.TrailPoint previous, SpatialView.TrailPoint current) {
        if (previous == null || current == null || current.segmentStart) return true;
        long dtMs = current.timeMs - previous.timeMs;
        if (dtMs <= 0L || dtMs > 120_000L) return true;
        double meters = Math.hypot(current.x - previous.x, current.y - previous.y);
        double kmh = meters / Math.max(0.001, dtMs / 1000.0) * 3.6;
        double reported = Math.max(previous.speedKmh, current.speedKmh);
        return meters > 250.0 && kmh > Math.max(220.0, reported * 3.0 + 80.0);
    }

    private Bitmap renderProjectedTrailOverlay(List<SpatialView.TrailPoint> points, String provider,
                                                double centerLat, double centerLon, int zoom,
                                                int width, int height, int visibleCount, float heading) {
        boolean anyExact = false;
        for (int i = 0; i < Math.min(points.size(), Math.max(1, visibleCount)); i++) {
            if (hasExactWgs(points.get(i))) { anyExact = true; break; }
        }
        if ((!anyExact) && (Double.isNaN(anchorLatitude) || Double.isNaN(anchorLongitude))) {
            SpatialView.TrailPoint focus = points.get(Math.max(0, Math.min(visibleCount - 1, points.size() - 1)));
            return SpatialView.renderTrailOverlayAtMapCenter(points, heading, width, height,
                    visibleCount, focus.x, focus.y, centerLat, zoom);
        }
        Bitmap overlay = Bitmap.createBitmap(Math.max(1, width), Math.max(1, height), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(overlay);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeWidth(Math.max(5f, width / 150f));
        int count = Math.max(1, Math.min(visibleCount, points.size()));
        int stride = Math.max(1, (count + 5999) / 6000);
        double[] centerWorld = MapTileView.projectWgsToWorldPixels(provider, centerLat, centerLon, zoom);
        Path normalPath = new Path();
        Path estimatedPath = new Path();
        SpatialView.TrailPoint previousDrawn = null;
        float lastX = width / 2f, lastY = height / 2f;
        for (int i = 0; i < count; i++) {
            SpatialView.TrailPoint point = points.get(i);
            if (i != 0 && i != count - 1 && i % stride != 0 &&
                    !point.segmentStart && !isEstimatedGapPoint(point)) continue;
            double[] geo = pointWgs(point);
            double[] world = MapTileView.projectWgsToWorldPixels(provider, geo[0], geo[1], zoom);
            float px = width / 2f + (float)(world[0] - centerWorld[0]);
            float py = height / 2f + (float)(world[1] - centerWorld[1]);
            boolean broken = previousDrawn == null || breaksExportPath(previousDrawn, point);
            boolean estimated = previousDrawn != null &&
                    (isEstimatedGapPoint(previousDrawn) || isEstimatedGapPoint(point));
            if (broken) {
                normalPath.moveTo(px, py);
                estimatedPath.moveTo(px, py);
            } else if (estimated) {
                estimatedPath.lineTo(px, py);
                normalPath.moveTo(px, py);
            } else {
                normalPath.lineTo(px, py);
                estimatedPath.moveTo(px, py);
            }
            previousDrawn = point;
            if (i == count - 1) { lastX = px; lastY = py; }
        }
        paint.setColor(0xFF3157D5);
        paint.setPathEffect(null);
        canvas.drawPath(normalPath, paint);
        paint.setColor(0xFFE58A20);
        paint.setPathEffect(new DashPathEffect(new float[]{18f, 12f}, 0f));
        canvas.drawPath(estimatedPath, paint);
        paint.setPathEffect(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFF1C9B69);
        canvas.drawCircle(lastX, lastY, Math.max(13f, width / 75f), paint);
        paint.setStrokeWidth(Math.max(6f, width / 130f));
        canvas.drawLine(lastX, lastY,
                lastX + (float)Math.sin(heading) * width / 12f,
                lastY - (float)Math.cos(heading) * width / 12f, paint);
        return overlay;
    }

    private Bitmap renderPlainTrackFrame(List<SpatialView.TrailPoint> points, int width, int height,
                                         int visibleCount, float focusX, float focusY,
                                         double mapLatitude, int mapZoom, float heading) {
        Bitmap result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        canvas.drawColor(0xFFF3F5F8);
        Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
        grid.setColor(0x66FFFFFF); grid.setStrokeWidth(Math.max(1.5f, width / 700f));
        for (int i = 1; i < 8; i++) {
            canvas.drawLine(width * i / 8f, 0, width * i / 8f, height, grid);
            canvas.drawLine(0, height * i / 8f, width, height * i / 8f, grid);
        }
        Bitmap overlay = SpatialView.renderTrailOverlayAtMapCenter(points, heading, width, height,
                visibleCount, focusX, focusY, mapLatitude, mapZoom);
        canvas.drawBitmap(overlay, 0, 0, null);
        overlay.recycle();
        return result;
    }

    private Bitmap renderLandscapeExportBitmap(List<SpatialView.TrailPoint> points, boolean includeMapLayer,
                                                AtomicBoolean cancelled, ProgressBar bar, TextView progress) throws Exception {
        final int outW = 2400, outH = 1350;
        ExportMapViewport viewport = calculateExportViewport(points, outW, outH);
        if (!includeMapLayer) {
            handler.post(() -> updateProgress(bar, progress, 45, "正在绘制横向轨迹长图…"));
            return renderPlainTrackFrame(points, outW, outH, points.size(), viewport.centerX, viewport.centerY,
                    viewport.latitude, viewport.zoom, headingRad);
        }
        String provider = activeMapProvider;
        handler.post(() -> updateProgress(bar, progress, 5, "正在下载横向地图底图…"));
        Bitmap map = mapTileView.renderSnapshotBlocking(provider, viewport.latitude, viewport.longitude,
                viewport.zoom, outW, outH, cancelled, (done, total) -> {
                    int pct = 5 + Math.round(55f * done / Math.max(1, total));
                    handler.post(() -> updateProgress(bar, progress, pct,
                            "正在下载横向地图底图 " + done + "/" + total));
                });
        if (cancelled.get()) { map.recycle(); throw new CancellationException("已取消"); }
        Bitmap result = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        canvas.drawBitmap(map, 0, 0, null);
        map.recycle();
        Bitmap overlay = renderProjectedTrailOverlay(points, provider,
                viewport.latitude, viewport.longitude, viewport.zoom,
                outW, outH, points.size(), headingRad);
        canvas.drawBitmap(overlay, 0, 0, null);
        overlay.recycle();
        handler.post(() -> updateProgress(bar, progress, 70, "正在绘制轨迹和统计信息…"));
        return result;
    }

    private void annotateExportBitmap(Bitmap bitmap, List<SpatialView.TrailPoint> points, int visibleCount) {
        if (bitmap == null || points == null || points.isEmpty()) return;
        float exportMaxKmh = 0f;
        int count = Math.max(1, Math.min(visibleCount, points.size()));
        {
            int stride = Math.max(1, count / 6000);
            for (int i = 0; i < count; i += stride) exportMaxKmh = Math.max(exportMaxKmh, points.get(i).speedKmh);
            if (count > 0) exportMaxKmh = Math.max(exportMaxKmh, points.get(count - 1).speedKmh);
        }
        annotateExportBitmap(bitmap, points, visibleCount, exportMaxKmh);
    }

    private void annotateExportBitmap(Bitmap bitmap, List<SpatialView.TrailPoint> points, int visibleCount, float exportMaxKmh) {
        if (bitmap == null || points == null || points.isEmpty()) return;
        int count = Math.max(1, Math.min(visibleCount, points.size()));
        SpatialView.TrailPoint point = points.get(count - 1);
        SpatialView.TrailPoint first = points.get(0);
        long elapsedMs = Math.max(1L, point.timeMs - first.timeMs);
        float averageKmh = point.distanceMeters / (elapsedMs / 1000f) * 3.6f;
        if (exportMaxKmh > 0f && averageKmh > exportMaxKmh) averageKmh = exportMaxKmh;
        Canvas canvas = new Canvas(bitmap);
        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG); bg.setColor(0xCCFFFFFF);
        Paint text = new Paint(Paint.ANTI_ALIAS_FLAG); text.setColor(Color.rgb(35,40,50));
        text.setTextSize(Math.max(20f, Math.min(42f, bitmap.getWidth()/35f)));
        float line = text.getTextSize()*1.35f;
        float panelHeight = Math.min(bitmap.getHeight() * 0.42f, line * 6.25f);
        canvas.drawRect(0, 0, bitmap.getWidth(), panelHeight, bg);
        float x = bitmap.getWidth()/40f, y = text.getTextSize()*1.25f;
        String dms = "经纬度：等待定位"; String decimal = "";
        double[] exportGeo = pointWgs(point);
        if (Double.isFinite(exportGeo[0]) && Double.isFinite(exportGeo[1]) &&
                Math.abs(exportGeo[0]) <= 90.0 && Math.abs(exportGeo[1]) <= 180.0) {
            dms = SpatialView.formatDms(exportGeo[0], true) + " " + SpatialView.formatDms(exportGeo[1], false);
            decimal = String.format(Locale.US, "十进制度：%.6f, %.6f", exportGeo[0], exportGeo[1]);
        }
        canvas.drawText(dms, x, y, text); y += line;
        if (!decimal.isEmpty()) { canvas.drawText(decimal, x, y, text); y += line; }
        canvas.drawText(String.format(Locale.CHINA, "实时 %.2f km/h · 平均 %.2f km/h · 最高 %.2f km/h", point.speedKmh, averageKmh, exportMaxKmh), x, y, text); y += line;
        canvas.drawText(String.format(Locale.CHINA, "距离 %.1f m · 方向 %.1f°", point.distanceMeters, point.headingDegrees), x, y, text); y += line;
        float shownAccuracy = !Float.isNaN(point.accuracyMeters) ? point.accuracyMeters : anchorAccuracyMeters;
        canvas.drawText(String.format(Locale.CHINA, "相对坐标 X %.2f m · Y %.2f m · 定位精度 %s · 比例尺随地图缩放", point.x, point.y, Float.isNaN(shownAccuracy) ? "未知" : String.format(Locale.CHINA, "±%.1f m", shownAccuracy)), x, y, text); y += line;
        canvas.drawText(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date(point.timeMs)), x, y, text);
    }

    private void saveSketchPng(boolean includeMapLayer) {
        if (spatialView == null || spatialView.getPointCount() <= 1) {
            Toast.makeText(this, "当前没有轨迹，无法保存图片", Toast.LENGTH_LONG).show();
            return;
        }
        List<SpatialView.TrailPoint> points = sanitizeTrailPoints(spatialView.getTrailCopy());
        AtomicBoolean cancelled = new AtomicBoolean(false);
        LinearLayout box = createProgressBox("正在准备横向长图…");
        ProgressBar bar = (ProgressBar) box.getChildAt(0);
        TextView text = (TextView) box.getChildAt(1);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("保存横向轨迹长图")
                .setView(box).setNegativeButton("取消", null).setCancelable(false).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
            cancelled.set(true); text.setText("正在取消…"); v.setEnabled(false);
        }));
        dialog.show();
        new Thread(() -> {
            Bitmap bitmap = null;
            try {
                bitmap = renderLandscapeExportBitmap(points, includeMapLayer, cancelled, bar, text);
                if (cancelled.get()) throw new CancellationException("已取消");
                annotateExportBitmap(bitmap, points, points.size());
                handler.post(() -> updateProgress(bar, text, 82, "正在写入 PNG 文件…"));
                String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
                String fileName = "wifi_sketch_landscape_" + (includeMapLayer ? "map_" : "plain_") + stamp + ".png";
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/WiFiEnvironmentMonitor");
                    values.put(MediaStore.Images.Media.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new IOException("无法创建图片记录");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null || !bitmap.compress(Bitmap.CompressFormat.PNG, 100, out))
                            throw new IOException("写入 PNG 失败");
                    }
                    values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0);
                    getContentResolver().update(uri, values, null, null);
                } else {
                    File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "WiFiEnvironmentMonitor");
                    if (!dir.exists() && !dir.mkdirs()) throw new IOException("无法创建保存目录");
                    File file = new File(dir, fileName);
                    try (OutputStream out = new FileOutputStream(file)) {
                        if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) throw new IOException("写入 PNG 失败");
                    }
                    MediaScannerConnection.scanFile(this, new String[]{file.getAbsolutePath()}, new String[]{"image/png"}, null);
                }
                handler.post(() -> { updateProgress(bar, text, 100, "横向长图已保存"); dialog.dismiss();
                    Toast.makeText(this, "横向轨迹长图已保存到 Pictures/WiFiEnvironmentMonitor", Toast.LENGTH_LONG).show(); });
            } catch (CancellationException e) {
                handler.post(() -> { dialog.dismiss(); Toast.makeText(this, "图片保存已取消", Toast.LENGTH_SHORT).show(); });
            } catch (Exception e) {
                handler.post(() -> { dialog.dismiss(); Toast.makeText(this, "保存失败：" + e.getMessage(), Toast.LENGTH_LONG).show(); });
            } finally {
                if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            }
        }, "png-export").start();
    }

    private void requestBatteryOptimizationExemptionIfNeeded() {
        if (Build.VERSION.SDK_INT < 23) return;
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm == null || pm.isIgnoringBatteryOptimizations(getPackageName())) return;
            SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            if (prefs.getBoolean("battery_prompt_shown", false)) return;
            prefs.edit().putBoolean("battery_prompt_shown", true).apply();
            new AlertDialog.Builder(this)
                    .setTitle("允许锁屏持续记录")
                    .setMessage("为避免三星等手机在锁屏后停止定位，请允许本应用不受电池优化限制。")
                    .setNegativeButton("稍后", null)
                    .setPositiveButton("去设置", (d, w) -> {
                        try {
                            Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                    Uri.parse("package:" + getPackageName()));
                            startActivity(intent);
                        } catch (Exception ignored) {
                            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                        }
                    }).show();
        } catch (Exception ignored) { }
    }

    private void toggleMapping() {
        if (mapping) {
            mapping = false;
            TrackingStateStore.setActive(this, false);
            stopAutoWifiScanning();
            stopTrackingService();
            if (currentRecordingSessionStartMs > 0L) {
                activeRecordingTimeMs += Math.max(0L, SystemClock.elapsedRealtime() - currentRecordingSessionStartMs);
                currentRecordingSessionStartMs = 0L;
            }
            currentSpeedKmh = 0f;
            lastTrackLocation = null; // 暂停后不把下一次启动的位置与旧位置跨段相连
            pendingSegmentStart = true;
            if (mappingButton != null) mappingButton.setText("开始轨迹记录");
            updateSensorText();
            saveAutoBackup(true);
            Toast.makeText(this, "空间绘制已暂停并自动备份", Toast.LENGTH_LONG).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= 29 && stepSensor != null &&
                checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, REQ_ACTIVITY);
            return;
        }
        stopReplay();
        List<SpatialView.TrailPoint> existingTrack = spatialView.getTrailCopy();
        if (existingTrack.size() <= 1) {
            // A new ride must wait for a fresh foreground-service fix. Reusing an old
            // cached/map browsing coordinate as the origin can shift the whole route
            // several kilometres and makes exported map layers look incorrect.
            anchorLatitude = Double.NaN;
            anchorLongitude = Double.NaN;
            anchorAccuracyMeters = Float.NaN;
            anchorProvider = "waiting-fresh-fix";
            anchorTimeMs = 0L;
            spatialView.clearGeoAnchor();
        }
        TrackingStateStore.beginSession(this);
        mapping = true;
        requestBatteryOptimizationExemptionIfNeeded();
        stopContinuousLocationUpdates();
        startTrackingService();
        usingFallbackSteps = true;
        lastTrackLocation = null;
        lastSpeedLocation = null;
        lastProcessedLocationElapsedNanos = 0L;
        lastProcessedLocationTimeMs = 0L;
        pendingSegmentStart = true;
        lastStepElapsedMs = 0L;
        waitingForScan = false;
        handler.removeCallbacks(scanTimeout);
        if (scanButton != null) scanButton.setEnabled(true);
        List<SpatialView.TrailPoint> startPoints = spatialView.getTrailCopy();
        if (startPoints.size() == 1 && "[]".equals(startPoints.get(0).wifiSnapshotJson)) {
            startPoints.set(0, attachPointContext(startPoints.get(0)));
            spatialView.setTrail(startPoints);
        }
        if (mappingStartElapsedMs == 0L) mappingStartElapsedMs = SystemClock.elapsedRealtime();
        currentRecordingSessionStartMs = SystemClock.elapsedRealtime();
        lastStepElapsedMs = 0L;
        if (mappingButton != null) mappingButton.setText("暂停轨迹记录");
        startAutoWifiScanning();
        updateSensorText();
        Toast.makeText(this, usingFallbackSteps ?
                "空间绘制已开始：硬件计步器 + 加速度计双通道" :
                "空间绘制已开始：硬件计步器 + 加速度计双通道", Toast.LENGTH_LONG).show();
    }

    private void startTrackingService() {
        Intent intent = new Intent(this, TrackingForegroundService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
        else startService(intent);
    }

    private void stopTrackingService() {
        stopService(new Intent(this, TrackingForegroundService.class));
    }

    private void updateSensorText() {
        String stepState = stepSensor == null ? "加速度计估步" : "双通道计步";
        String rotationState = rotationSensor == null ? "无旋转矢量" : "方向传感器可用";
        float distance = mappedSteps * STEP_METERS;
        long activeElapsedMs = activeRecordingTimeMs;
        if (mapping && currentRecordingSessionStartMs > 0L)
            activeElapsedMs += Math.max(0L, SystemClock.elapsedRealtime() - currentRecordingSessionStartMs);
        float averageSpeed;
        if (gpsDistanceMeters > 0f) {
            averageSpeed = movingTimeMs > 0L ? gpsDistanceMeters / (movingTimeMs / 1000f) * 3.6f : 0f;
            distance = Math.max(distance, gpsDistanceMeters);
        } else averageSpeed = activeElapsedMs == 0L ? 0f : distance / (activeElapsedMs / 1000f) * 3.6f;
        gpsSpeedAvailable = hasRecentGpsSpeed();
        if (!gpsSpeedAvailable && !mapping && lastStepElapsedMs > 0L && SystemClock.elapsedRealtime() - lastStepElapsedMs > 2500L) currentSpeedKmh = 0f;
        if (spatialView != null) spatialView.setRideMetrics(currentSpeedKmh, averageSpeed, maxSpeedKmh,
                distance, movingTimeMs, activeElapsedMs);
        float x = spatialView == null ? 0f : spatialView.getCurrentX();
        float y = spatialView == null ? 0f : spatialView.getCurrentY();
        String geoText;
        if (!Double.isNaN(anchorLatitude) && !Double.isNaN(anchorLongitude)) {
            double[] geo = SpatialView.relativeMetersToLatLon(anchorLatitude, anchorLongitude, x, y);
            geoText = SpatialView.formatDms(geo[0], true) + " " + SpatialView.formatDms(geo[1], false) +
                    String.format(Locale.US, "\n十进制度 %.6f, %.6f", geo[0], geo[1]);
        } else {
            geoText = "经纬度：等待 GPS / 网络定位";
        }
        sensorText.setText(String.format(Locale.CHINA,
                "空间绘制：%s · %d 步 · %.1f 米\n实时速度 %.2f km/h · 移动均速 %.2f km/h · 最高速度 %.2f km/h\n移动时间 %s · 总记录时间 %s\n%s\n相对坐标 X %.2f m · Y %.2f m · %s · %s\n速度来源：%s",
                mapping ? "运行中" : "已暂停", mappedSteps, distance, currentSpeedKmh, averageSpeed, maxSpeedKmh,
                formatDuration(movingTimeMs), formatDuration(activeElapsedMs),
                geoText, x, y, stepState, rotationState, speedSourceLabel));
    }

    private void recordDetectedStep() {
        long nowElapsed = SystemClock.elapsedRealtime();
        if (mappingStartElapsedMs == 0L) mappingStartElapsedMs = nowElapsed;
        if (lastStepElapsedMs > 0L) {
            float seconds = Math.max(0.28f, (nowElapsed - lastStepElapsedMs) / 1000f);
            gpsSpeedAvailable = hasRecentGpsSpeed();
            if (!gpsSpeedAvailable) {
                currentSpeedKmh = Math.min(20f, STEP_METERS / seconds * 3.6f);
                speedSourceLabel = "步频估算（GPS 两级速度均不可用）";
            }
        } else {
            gpsSpeedAvailable = hasRecentGpsSpeed();
            if (!gpsSpeedAvailable) { currentSpeedKmh = 0f; speedSourceLabel = "步频估算（等待下一步）"; }
        }
        maxSpeedKmh = Math.max(maxSpeedKmh, currentSpeedKmh);
        lastStepElapsedMs = nowElapsed;
        mappedSteps++;
        // Do not mix accelerometer/step dead-reckoning points into a GPS cycling path.
        // Interleaving both sources created short spikes, zig-zags and inflated distance.
        long locationAge = lastLocationCallbackElapsedMs == 0L ? Long.MAX_VALUE
                : SystemClock.elapsedRealtime() - lastLocationCallbackElapsedMs;
        boolean useStepFallbackGeometry = !hasRecentGpsSpeed() && locationAge > 15_000L && lastTrackLocation == null;
        if (useStepFallbackGeometry) {
            spatialView.addStep(STEP_METERS, headingRad);
            List<SpatialView.TrailPoint> enriched = spatialView.getTrailCopy();
            if (!enriched.isEmpty()) {
                SpatialView.TrailPoint last = enriched.get(enriched.size()-1);
                enriched.set(enriched.size()-1, attachPointContext(new SpatialView.TrailPoint(last.x, last.y, last.timeMs,
                        (float)Math.toDegrees(headingRad), currentSpeedKmh, mappedSteps * STEP_METERS,
                        pendingSegmentStart || last.segmentStart)));
                spatialView.setTrail(enriched);
                pendingSegmentStart = false;
            }
        }
        updateSensorText();
        if (useStepFallbackGeometry) saveAutoBackup(false);
        handler.postDelayed(() -> {
            if (SystemClock.elapsedRealtime() - lastStepElapsedMs > 2200L && !hasRecentGpsSpeed()) {
                currentSpeedKmh = 0f;
                speedSourceLabel = "步频估算（静止）";
                updateSensorText();
            }
        }, 2300L);
    }

    private String currentWifiSnapshotJson() {
        JSONArray array = new JSONArray();
        try {
            for (ScanResult r : getSortedResults()) {
                JSONObject item = new JSONObject();
                String ssid = r.SSID == null || r.SSID.isEmpty() ? "隐藏网络" : r.SSID;
                item.put("ssid", ssid);
                item.put("bssid", r.BSSID == null ? "" : r.BSSID);
                item.put("rssiDbm", r.level);
                item.put("frequencyMhz", r.frequency);
                item.put("channel", channelForFrequency(r.frequency));
                item.put("band", bandDescription(r.frequency));
                item.put("security", securityDescription(r.capabilities));
                item.put("capabilities", r.capabilities == null ? "" : r.capabilities);
                item.put("capturedAt", System.currentTimeMillis());
                array.put(item);
            }
        } catch (Exception ignored) { }
        return array.toString();
    }

    private SpatialView.TrailPoint attachPointContext(SpatialView.TrailPoint point) {
        String provider = activeMapProvider;
        double centerLat = anchorLatitude;
        double centerLon = anchorLongitude;
        int zoom = 18;
        float scale = spatialView == null ? 1f : spatialView.getViewportScale();
        float panX = spatialView == null ? 0f : spatialView.getViewportPanX();
        float panY = spatialView == null ? 0f : spatialView.getViewportPanY();
        String tileKeys = "[]";
        if (mapTileView != null && mapTileView.getVisibility() == View.VISIBLE) {
            provider = mapTileView.getProviderName();
            centerLat = mapTileView.getCenterLatitude();
            centerLon = mapTileView.getCenterLongitude();
            zoom = mapTileView.getZoomLevel();
            scale = mapTileView.getViewportScale();
            panX = mapTileView.getViewportPanX();
            panY = mapTileView.getViewportPanY();
            tileKeys = mapTileView.getCachedTileKeysJson();
        }
        return new SpatialView.TrailPoint(point.x, point.y, point.timeMs, point.headingDegrees,
                point.speedKmh, point.distanceMeters, currentWifiSnapshotJson(), provider,
                centerLat, centerLon, zoom, scale, panX, panY, tileKeys, point.segmentStart,
                point.latitude, point.longitude, point.accuracyMeters, point.locationProvider);
    }

    private void showReplayPointContext(SpatialView.TrailPoint point, int index, int total) {
        if (point == null || detailText == null) return;
        StringBuilder text = new StringBuilder();
        text.append("轨迹回放：第 ").append(index).append(" / ").append(total).append(" 个时间点\n");
        text.append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(new Date(point.timeMs)));
        text.append(String.format(Locale.CHINA, "\n速度 %.2f km/h · 累计距离 %.1f m · 方向 %.1f°\n",
                point.speedKmh, point.distanceMeters, point.headingDegrees));
        try {
            JSONArray wifi = new JSONArray(point.wifiSnapshotJson);
            text.append("当时 Wi-Fi 列表：").append(wifi.length()).append(" 个网络\n\n");
            for (int i = 0; i < wifi.length(); i++) {
                JSONObject item = wifi.optJSONObject(i);
                if (item == null) continue;
                text.append(i + 1).append(". ").append(item.optString("ssid", "隐藏网络"))
                        .append("  ").append(item.optInt("rssiDbm", 0)).append(" dBm\n")
                        .append("   BSSID: ").append(item.optString("bssid", ""))
                        .append(" · ").append(item.optString("band", ""))
                        .append(" · 信道 ").append(item.optInt("channel", 0))
                        .append(" · ").append(item.optString("security", "")).append("\n");
            }
        } catch (Exception e) {
            text.append("当时 Wi-Fi 快照无法解析：").append(e.getClass().getSimpleName());
        }
        detailText.setText(text.toString());
        statusText.setText("正在回放轨迹，并同步显示当时 Wi-Fi 快照");
    }

    private void toggleReplayControl() {
        if (replaying && !replayPaused) pauseReplay();
        else startReplay();
    }

    private void updateReplayButtonText() {
        if (replayControlButton == null) return;
        if (replayPaused) replayControlButton.setText("继续回放");
        else if (replaying) replayControlButton.setText("暂停回放");
        else replayControlButton.setText("开始回放");
    }

    private void startReplay() {
        List<SpatialView.TrailPoint> points = spatialView.getTrailCopy();
        if (points.size() <= 1) {
            Toast.makeText(this, "当前没有可回放的轨迹", Toast.LENGTH_LONG).show();
            return;
        }
        if (mapping) {
            mapping = false;
            TrackingStateStore.setActive(this, false);
            stopTrackingService();
            stopAutoWifiScanning();
            if (currentRecordingSessionStartMs > 0L) {
                activeRecordingTimeMs += Math.max(0L, SystemClock.elapsedRealtime() - currentRecordingSessionStartMs);
                currentRecordingSessionStartMs = 0L;
            }
            pendingSegmentStart = true;
            saveAutoBackup(true);
        }
        if (replayPaused) {
            replayPaused = false;
            replaying = true;
        } else if (!replaying) {
            replaying = true;
            replayPaused = false;
            replayIndex = 1;
            replayCurrentIndex = 0;
            spatialView.setReplayVisibleCount(1);
            spatialView.centerOnTrailPoint(0);
        }
        handler.removeCallbacks(replayRunnable);
        handler.post(replayRunnable);
        updateReplayButtonText();
        updateSensorText();
    }

    private void pauseReplay() {
        if (!replaying) return;
        replayPaused = true;
        handler.removeCallbacks(replayRunnable);
        updateReplayButtonText();
        if (statusText != null) statusText.setText("轨迹回放已暂停，可从当前进度继续");
    }

    private void stopReplay() {
        replaying = false;
        replayPaused = false;
        replayIndex = 1;
        replayCurrentIndex = 0;
        handler.removeCallbacks(replayRunnable);
        if (spatialView != null) spatialView.stopReplay();
        updateReplayButtonText();
        if (detailText != null) readResults();
    }

    private void locateToCurrentTrailPosition() {
        if (spatialView == null || spatialView.getPointCount() == 0) return;
        int index;
        if (replaying || replayPaused) index = replayCurrentIndex;
        else index = spatialView.getPointCount() - 1;
        spatialView.centerOnTrailPoint(index);
        Toast.makeText(this, (replaying || replayPaused) ? "已定位到当前回放位置" : "已定位到当前位置", Toast.LENGTH_SHORT).show();
    }

    private void exportTrack() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "wifi_track_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".json");
        startActivityForResult(intent, REQ_EXPORT_TRACK);
    }

    private void importTrack() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        startActivityForResult(intent, REQ_IMPORT_TRACK);
    }

    private String buildTrackJson() throws Exception {
        JSONObject root = new JSONObject();
        root.put("format", "xiaokui-wifi-ride-track-v4");
        root.put("schemaVersion", 4);
        root.put("createdAt", System.currentTimeMillis());
        root.put("coordinateSystem", "WGS84");
        long activeElapsedMs = activeRecordingTimeMs;
        if (mapping && currentRecordingSessionStartMs > 0L)
            activeElapsedMs += Math.max(0L, SystemClock.elapsedRealtime() - currentRecordingSessionStartMs);
        root.put("maxSpeedKmh", maxSpeedKmh);
        root.put("averageSpeedKmh", movingTimeMs > 0L ? gpsDistanceMeters / (movingTimeMs / 1000f) * 3.6f : 0f);
        root.put("overallAverageSpeedKmh", activeElapsedMs > 0L ? gpsDistanceMeters / (activeElapsedMs / 1000f) * 3.6f : 0f);
        root.put("movingTimeMs", movingTimeMs);
        root.put("activeRecordingTimeMs", activeElapsedMs);
        root.put("distanceMeters", gpsDistanceMeters);
        JSONObject settings = new JSONObject();
        settings.put("stepLengthMeters", STEP_METERS);
        settings.put("mapType", activeMapProvider);
        root.put("settings", settings);
        if (!Double.isNaN(anchorLatitude) && !Double.isNaN(anchorLongitude)) {
            JSONObject origin = new JSONObject();
            origin.put("latitude", anchorLatitude); origin.put("longitude", anchorLongitude);
            if (!Float.isNaN(anchorAccuracyMeters)) origin.put("accuracyMeters", anchorAccuracyMeters);
            origin.put("provider", anchorProvider); origin.put("timestamp", anchorTimeMs);
            root.put("origin", origin);
        }
        JSONArray array = new JSONArray();
        for (SpatialView.TrailPoint point : spatialView.getTrailCopy()) {
            JSONObject item = new JSONObject();
            item.put("xMeters", point.x); item.put("yMeters", point.y);
            item.put("timestamp", point.timeMs); item.put("headingDegrees", point.headingDegrees);
            item.put("speedKmh", point.speedKmh); item.put("distanceMeters", point.distanceMeters);
            item.put("segmentStart", point.segmentStart);
            try { item.put("wifiNetworks", new JSONArray(point.wifiSnapshotJson)); }
            catch (Exception ignored) { item.put("wifiNetworks", new JSONArray()); }
            JSONObject mapLayer = new JSONObject();
            mapLayer.put("provider", point.mapProvider);
            if (!Double.isNaN(point.mapCenterLatitude)) mapLayer.put("centerLatitude", point.mapCenterLatitude);
            if (!Double.isNaN(point.mapCenterLongitude)) mapLayer.put("centerLongitude", point.mapCenterLongitude);
            mapLayer.put("zoom", point.mapZoom);
            mapLayer.put("scale", point.mapScale);
            mapLayer.put("panX", point.mapPanX);
            mapLayer.put("panY", point.mapPanY);
            try { mapLayer.put("tileKeys", new JSONArray(point.mapTileKeysJson)); }
            catch (Exception ignored) { mapLayer.put("tileKeys", new JSONArray()); }
            mapLayer.put("tileStorage", "references-only; tiles reload from network");
            item.put("mapLayer", mapLayer);
            double[] geo = pointWgs(point);
            if (Double.isFinite(geo[0]) && Double.isFinite(geo[1]) &&
                    Math.abs(geo[0]) <= 90.0 && Math.abs(geo[1]) <= 180.0) {
                item.put("latitude", geo[0]); item.put("longitude", geo[1]);
                if (!Float.isNaN(point.accuracyMeters)) item.put("accuracyMeters", point.accuracyMeters);
                item.put("locationProvider", point.locationProvider);
                item.put("dms", SpatialView.formatDms(geo[0], true) + " " + SpatialView.formatDms(geo[1], false));
            }
            array.put(item);
        }
        root.put("points", array);
        return root.toString(2);
    }

    private void saveAutoBackup(boolean rotate) {
        long nowElapsed = SystemClock.elapsedRealtime();
        if (!rotate && lastAutoBackupWriteElapsedMs > 0L &&
                nowElapsed - lastAutoBackupWriteElapsedMs < AUTO_BACKUP_MIN_INTERVAL_MS) return;
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean(PREF_BACKUP_ENABLED, true)) return;
        if (rotate) autoBackupPendingRotate = true;
        if (!autoBackupWriting.compareAndSet(false, true)) return;
        new Thread(() -> {
            try {
                while (true) {
                    boolean doRotate = autoBackupPendingRotate;
                    autoBackupPendingRotate = false;
                    writeAutoBackupNow(doRotate);
                    lastAutoBackupWriteElapsedMs = SystemClock.elapsedRealtime();
                    if (!autoBackupPendingRotate) break;
                }
            } finally {
                autoBackupWriting.set(false);
                if (autoBackupPendingRotate) saveAutoBackup(true);
            }
        }, "auto-backup-writer").start();
    }

    private void writeAutoBackupNow(boolean rotate) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        int keep = prefs.getInt(PREF_BACKUP_KEEP, 5);
        try {
            File dir = new File(getFilesDir(), AUTO_BACKUP_DIR);
            if (!dir.exists() && !dir.mkdirs()) return;
            byte[] data = buildTrackJson().getBytes(StandardCharsets.UTF_8);
            File latestTemp = new File(dir, "latest.json.tmp");
            File latest = new File(dir, "latest.json");
            try (OutputStream out = new BufferedOutputStream(new FileOutputStream(latestTemp))) {
                out.write(data);
            }
            if (latest.exists()) latest.delete();
            if (!latestTemp.renameTo(latest)) {
                try (OutputStream out = new BufferedOutputStream(new FileOutputStream(latest))) { out.write(data); }
                latestTemp.delete();
            }
            if (rotate) {
                File snapshot = new File(dir, "track_" + System.currentTimeMillis() + ".json");
                try (OutputStream out = new BufferedOutputStream(new FileOutputStream(snapshot))) {
                    out.write(data);
                }
                File[] files = dir.listFiles((d, name) -> name.startsWith("track_") && name.endsWith(".json"));
                if (files != null && files.length > keep) {
                    java.util.Arrays.sort(files, (a,b) -> Long.compare(b.lastModified(), a.lastModified()));
                    int unlockedKept = 0;
                    for (File candidate : files) {
                        if (isBackupLocked(candidate)) continue;
                        if (unlockedKept < keep) { unlockedKept++; continue; }
                        candidate.delete();
                        backupLockFile(candidate).delete();
                    }
                }
            }
        } catch (Exception ignored) { }
    }

    private void writeTrackToUri(Uri uri) {
        final LinearLayout box = createProgressBox("正在准备轨迹备份…");
        final ProgressBar bar = (ProgressBar) box.getChildAt(0);
        final TextView text = (TextView) box.getChildAt(1);
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("导出轨迹")
                .setView(box).setCancelable(false).create();
        dialog.show();
        new Thread(() -> {
            try {
                handler.post(() -> updateProgress(bar, text, 10, "正在序列化轨迹数据…"));
                byte[] data = buildTrackJson().getBytes(StandardCharsets.UTF_8);
                handler.post(() -> updateProgress(bar, text, 45, "正在写入目标文件…"));
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IOException("无法打开目标文件");
                    int offset = 0, last = -1;
                    while (offset < data.length) {
                        int n = Math.min(65536, data.length - offset);
                        out.write(data, offset, n); offset += n;
                        int percent = 45 + (int)Math.round(offset * 55.0 / Math.max(1, data.length));
                        if (percent != last) { last = percent; final int shown = percent;
                            handler.post(() -> updateProgress(bar, text, shown, "正在写入目标文件…")); }
                    }
                    out.flush();
                }
                handler.post(() -> { dialog.dismiss(); Toast.makeText(this, "轨迹已导出", Toast.LENGTH_LONG).show(); });
            } catch (Exception e) {
                handler.post(() -> { dialog.dismiss(); Toast.makeText(this, "导出失败：" + e.getMessage(), Toast.LENGTH_LONG).show(); });
            }
        }, "track-export").start();
    }

    private LinearLayout createProgressBox(String message) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(48, 32, 48, 24);
        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100); bar.setProgress(0);
        TextView text = new TextView(this);
        text.setPadding(0, 20, 0, 0); text.setText(message + "\n0%");
        box.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(text, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return box;
    }

    private void updateProgress(ProgressBar bar, TextView text, int percent, String message) {
        int value = Math.max(0, Math.min(100, percent));
        bar.setIndeterminate(false); bar.setProgress(value);
        text.setText(message + "\n" + value + "%");
    }

    private static int percentOf(long done, long total) {
        if (total <= 0L) return -1;
        return Math.max(0, Math.min(100, (int)Math.round(done * 100.0 / total)));
    }

    private static final class CountingInputStream extends FilterInputStream {
        private long count;
        CountingInputStream(InputStream in) { super(in); }
        long getCount() { return count; }
        @Override public int read() throws IOException {
            int value = super.read(); if (value >= 0) count++; return value;
        }
        @Override public int read(byte[] b, int off, int len) throws IOException {
            int n = super.read(b, off, len); if (n > 0) count += n; return n;
        }
    }

    private static final class ImportedTrack {
        final List<SpatialView.TrailPoint> points = new ArrayList<>();
        JSONObject origin;
        JSONObject settings;
        String mapProvider = "none";
        float maxSpeedKmh = 0f;
        float averageSpeedKmh = 0f;
        float distanceMeters = 0f;
        long movingTimeMs = 0L;
        long activeRecordingTimeMs = 0L;
        boolean hasAverageSpeedKmh = false;
        boolean hasMovingTimeMs = false;
        boolean hasActiveRecordingTimeMs = false;
        int filteredPointCount = 0;
        int repairedGapCount = 0;
        int repairedPointCount = 0;
        float repairedGapMeters = 0f;
    }

    private void readTrackFromUri(Uri uri) {
        final LinearLayout box = createProgressBox("正在打开轨迹文件…");
        final ProgressBar bar = (ProgressBar) box.getChildAt(0);
        final TextView progress = (TextView) box.getChildAt(1);
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("导入轨迹")
                .setView(box)
                .setCancelable(false)
                .create();
        dialog.show();

        new Thread(() -> {
            try {
                long length = -1L;
                try (android.content.res.AssetFileDescriptor afd = getContentResolver().openAssetFileDescriptor(uri, "r")) {
                    if (afd != null) length = afd.getLength();
                } catch (Exception ignored) { }
                final long totalBytes = length;
                try (InputStream raw = getContentResolver().openInputStream(uri)) {
                    if (raw == null) throw new IOException("无法打开轨迹文件");
                    CountingInputStream in = new CountingInputStream(raw);
                    ImportedTrack imported = readTrackFromStream(in, count -> {
                        if (count == 1 || count % 2000 == 0) {
                            int percent = totalBytes > 0L ? percentOf(in.getCount(), totalBytes) : -1;
                            handler.post(() -> {
                                if (percent >= 0) updateProgress(bar, progress, percent,
                                        "正在解析轨迹… 已读取 " + count + " 个坐标点");
                                else {
                                    bar.setIndeterminate(true);
                                    progress.setText("正在解析轨迹…\n已读取 " + count + " 个坐标点");
                                }
                            });
                        }
                    });
                    handler.post(() -> {
                        updateProgress(bar, progress, 100, "解析完成，正在生成草图…");
                        try { applyImportedTrack(imported, "文件"); }
                        finally { dialog.dismiss(); }
                    });
                }
            } catch (OutOfMemoryError oom) {
                handler.post(() -> {
                    dialog.dismiss();
                    Toast.makeText(this, "导入失败：可用内存不足。轨迹文件过大或单点附带数据过多。", Toast.LENGTH_LONG).show();
                });
            } catch (Exception e) {
                handler.post(() -> {
                    dialog.dismiss();
                    Toast.makeText(this, "导入失败：" + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()), Toast.LENGTH_LONG).show();
                });
            }
        }, "track-import").start();
    }

    private interface ImportProgress { void onPoint(int count); }

    private static boolean hasExactWgs(SpatialView.TrailPoint p) {
        return p != null && Double.isFinite(p.latitude) && Double.isFinite(p.longitude) &&
                Math.abs(p.latitude) <= 90.0 && Math.abs(p.longitude) <= 180.0;
    }

    private static double pointDistanceMeters(SpatialView.TrailPoint a, SpatialView.TrailPoint b) {
        if (hasExactWgs(a) && hasExactWgs(b)) {
            float[] out = new float[1];
            Location.distanceBetween(a.latitude, a.longitude, b.latitude, b.longitude, out);
            return out[0];
        }
        return Math.hypot(b.x - a.x, b.y - a.y);
    }

    private SpatialView.TrailPoint copySanitizedPoint(SpatialView.TrailPoint p, float distance, boolean segmentStart) {
        return new SpatialView.TrailPoint(p.x, p.y, p.timeMs, p.headingDegrees, p.speedKmh, distance,
                p.wifiSnapshotJson, p.mapProvider, p.mapCenterLatitude, p.mapCenterLongitude,
                p.mapZoom, p.mapScale, p.mapPanX, p.mapPanY, p.mapTileKeysJson, segmentStart,
                p.latitude, p.longitude, p.accuracyMeters, p.locationProvider);
    }

    private static boolean isEstimatedGapPoint(SpatialView.TrailPoint point) {
        return point != null && point.locationProvider != null &&
                point.locationProvider.startsWith("estimated-gap");
    }

    private static boolean shouldAutoRepairGap(SpatialView.TrailPoint from,
                                               SpatialView.TrailPoint to,
                                               double seconds, double meters) {
        if (from == null || to == null ||
                seconds * 1000.0 < AUTO_REPAIR_GAP_MIN_MS ||
                seconds * 1000.0 > AUTO_REPAIR_GAP_MAX_MS ||
                meters < 150.0) return false;
        float fromAccuracy = Float.isNaN(from.accuracyMeters) ? 50f : from.accuracyMeters;
        float toAccuracy = Float.isNaN(to.accuracyMeters) ? 50f : to.accuracyMeters;
        if (fromAccuracy > 75f || toAccuracy > 75f) return false;
        double inferredKmh = meters / Math.max(0.001, seconds) * 3.6;
        double endpointKmh = Math.max(from.speedKmh, to.speedKmh);
        return inferredKmh >= 10.0 && inferredKmh <= 130.0 &&
                (endpointKmh >= 8.0 || inferredKmh >= 20.0);
    }

    private static SpatialView.TrailPoint interpolateEstimatedGapPoint(
            SpatialView.TrailPoint from, SpatialView.TrailPoint to, float t,
            float cumulativeDistance) {
        double lat = hasExactWgs(from) && hasExactWgs(to)
                ? from.latitude + (to.latitude - from.latitude) * t : Double.NaN;
        double lon = hasExactWgs(from) && hasExactWgs(to)
                ? from.longitude + (to.longitude - from.longitude) * t : Double.NaN;
        long time = from.timeMs + Math.round((to.timeMs - from.timeMs) * t);
        float accuracy = Math.max(Float.isNaN(from.accuracyMeters) ? 0f : from.accuracyMeters,
                Float.isNaN(to.accuracyMeters) ? 0f : to.accuracyMeters) + 25f;
        double seconds = Math.max(0.001, (to.timeMs - from.timeMs) / 1000.0);
        float speed = (float)(pointDistanceMeters(from, to) / seconds * 3.6);
        return new SpatialView.TrailPoint(
                from.x + (to.x - from.x) * t,
                from.y + (to.y - from.y) * t,
                time,
                interpolateAngleDegrees(from.headingDegrees, to.headingDegrees, t),
                speed,
                cumulativeDistance,
                "[]",
                from.mapProvider,
                from.mapCenterLatitude,
                from.mapCenterLongitude,
                from.mapZoom,
                from.mapScale,
                from.mapPanX,
                from.mapPanY,
                "[]",
                false,
                lat,
                lon,
                accuracy,
                "estimated-gap");
    }

    /**
     * Removes impossible provider jumps before displaying/exporting a route. When two reliable
     * moving fixes surround a 30-second to five-minute callback blackout, the route is bridged
     * with explicitly marked estimated points. This restores visual continuity but does not
     * claim that the missing GNSS samples were recovered.
     */
    private List<SpatialView.TrailPoint> sanitizeTrailPoints(List<SpatialView.TrailPoint> raw) {
        ArrayList<SpatialView.TrailPoint> cleaned = new ArrayList<>();
        if (raw == null || raw.isEmpty()) return cleaned;
        SpatialView.TrailPoint first = raw.get(0);
        float cumulative = 0f;
        SpatialView.TrailPoint accepted = copySanitizedPoint(first, 0f, true);
        cleaned.add(accepted);
        for (int i = 1; i < raw.size(); i++) {
            SpatialView.TrailPoint candidate = raw.get(i);
            long dtMs = candidate.timeMs - accepted.timeMs;
            double meters = pointDistanceMeters(accepted, candidate);
            if (!Double.isFinite(meters)) continue;
            if (dtMs <= 0L) {
                if (meters <= 5.0) continue;
                continue;
            }
            double seconds = dtMs / 1000.0;
            double inferredKmh = meters / Math.max(0.001, seconds) * 3.6;
            double reportedKmh = Math.max(accepted.speedKmh, candidate.speedKmh);
            double expectedMeters = Math.max(0.0, reportedKmh / 3.6 * seconds);
            double allowedMeters = Math.max(120.0, expectedMeters * 3.0 + 60.0);
            boolean impossibleTeleport = seconds <= 120.0 && meters > allowedMeters &&
                    inferredKmh > Math.max(180.0, reportedKmh * 3.0 + 60.0);
            boolean poorAccuracyJump = !Float.isNaN(candidate.accuracyMeters) &&
                    candidate.accuracyMeters > 80f && seconds <= 60.0 &&
                    meters > Math.max(150.0, seconds * 35.0);
            if (impossibleTeleport || poorAccuracyJump) continue;

            if (shouldAutoRepairGap(accepted, candidate, seconds, meters)) {
                int pointCount = Math.max(1, Math.min(120,
                        (int)Math.ceil(seconds / AUTO_REPAIR_POINT_INTERVAL_SECONDS) - 1));
                float base = cumulative;
                for (int j = 1; j <= pointCount; j++) {
                    float t = j / (float)(pointCount + 1);
                    cleaned.add(interpolateEstimatedGapPoint(
                            accepted, candidate, t, base + (float)meters * t));
                }
                cumulative += (float)meters;
                SpatialView.TrailPoint kept = copySanitizedPoint(candidate, cumulative, false);
                cleaned.add(kept);
                accepted = kept;
                continue;
            }

            boolean segmentStart = candidate.segmentStart || seconds > 120.0;
            if (!segmentStart) cumulative += (float)meters;
            SpatialView.TrailPoint kept = copySanitizedPoint(candidate, cumulative, segmentStart);
            cleaned.add(kept);
            accepted = kept;
        }
        if (cleaned.size() == 1 && raw.size() > 1) {
            SpatialView.TrailPoint last = raw.get(raw.size() - 1);
            if (last != first) cleaned.add(copySanitizedPoint(last, 0f, true));
        }
        return cleaned;
    }

    private static int countEstimatedGapPoints(List<SpatialView.TrailPoint> points) {
        int count = 0;
        if (points != null) for (SpatialView.TrailPoint point : points)
            if (isEstimatedGapPoint(point)) count++;
        return count;
    }

    private static int countEstimatedGapRuns(List<SpatialView.TrailPoint> points) {
        int runs = 0;
        boolean inside = false;
        if (points != null) for (SpatialView.TrailPoint point : points) {
            boolean estimated = isEstimatedGapPoint(point);
            if (estimated && !inside) runs++;
            inside = estimated;
        }
        return runs;
    }

    private void sanitizeImportedTrack(ImportedTrack imported) {
        if (imported == null || imported.points.size() <= 1) return;
        int originalCount = imported.points.size();
        int oldEstimatedCount = countEstimatedGapPoints(imported.points);
        List<SpatialView.TrailPoint> cleaned = sanitizeTrailPoints(imported.points);
        int newEstimatedCount = countEstimatedGapPoints(cleaned);
        int insertedEstimated = Math.max(0, newEstimatedCount - oldEstimatedCount);
        int removed = Math.max(0, originalCount + insertedEstimated - cleaned.size());
        boolean changed = removed > 0 || insertedEstimated > 0 || cleaned.size() != originalCount;
        if (cleaned.size() >= 2 && changed) {
            imported.points.clear();
            imported.points.addAll(cleaned);
            imported.filteredPointCount = removed;
            imported.repairedPointCount = insertedEstimated;
            imported.repairedGapCount = countEstimatedGapRuns(cleaned);
            float repairedMeters = 0f;
            for (int i = 1; i < cleaned.size(); i++) {
                SpatialView.TrailPoint p = cleaned.get(i);
                SpatialView.TrailPoint prev = cleaned.get(i - 1);
                if (isEstimatedGapPoint(p) || isEstimatedGapPoint(prev))
                    repairedMeters += (float)pointDistanceMeters(prev, p);
            }
            imported.repairedGapMeters = repairedMeters;
            SpatialView.TrailPoint last = cleaned.get(cleaned.size() - 1);
            imported.distanceMeters = last.distanceMeters;
            imported.maxSpeedKmh = 0f;
            long moving = 0L;
            for (int i = 0; i < cleaned.size(); i++) {
                SpatialView.TrailPoint p = cleaned.get(i);
                if (!isEstimatedGapPoint(p))
                    imported.maxSpeedKmh = Math.max(imported.maxSpeedKmh, p.speedKmh);
                if (i == 0 || p.segmentStart) continue;
                SpatialView.TrailPoint prev = cleaned.get(i - 1);
                long dt = p.timeMs - prev.timeMs;
                if (dt > 0L && dt <= 120_000L) {
                    double kmh = pointDistanceMeters(prev, p) / (dt / 1000.0) * 3.6;
                    if (Math.max(kmh, p.speedKmh) >= 1.5) moving += dt;
                }
            }
            imported.movingTimeMs = moving;
            imported.hasMovingTimeMs = true;
            imported.averageSpeedKmh = moving > 0L
                    ? imported.distanceMeters / (moving / 1000f) * 3.6f : 0f;
            imported.hasAverageSpeedKmh = true;
        }
    }

    private ImportedTrack readTrackFromStream(InputStream in, ImportProgress progress) throws Exception {
        ImportedTrack result = new ImportedTrack();
        try (JsonReader reader = new JsonReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            reader.setLenient(true);
            reader.beginObject();
            while (reader.hasNext()) {
                String name = reader.nextName();
                switch (name) {
                    case "origin":
                        result.origin = readJsonObject(reader);
                        break;
                    case "settings":
                        result.settings = readJsonObject(reader);
                        break;
                    case "mapProvider":
                        result.mapProvider = nextStringOr(reader, "none");
                        break;
                    case "maxSpeedKmh":
                        result.maxSpeedKmh = (float)nextDoubleOr(reader, 0.0);
                        break;
                    case "averageSpeedKmh":
                        result.averageSpeedKmh = (float)nextDoubleOr(reader, 0.0);
                        result.hasAverageSpeedKmh = true;
                        break;
                    case "distanceMeters":
                        result.distanceMeters = (float)nextDoubleOr(reader, 0.0);
                        break;
                    case "movingTimeMs":
                        result.movingTimeMs = nextLongOr(reader, 0L);
                        result.hasMovingTimeMs = true;
                        break;
                    case "activeRecordingTimeMs":
                        result.activeRecordingTimeMs = nextLongOr(reader, 0L);
                        result.hasActiveRecordingTimeMs = true;
                        break;
                    case "points":
                        reader.beginArray();
                        int index = 0;
                        while (reader.hasNext()) {
                            JSONObject item = readJsonObject(reader);
                            result.points.add(parseTrailPoint(item, index++, result));
                            if (progress != null) progress.onPoint(index);
                        }
                        reader.endArray();
                        break;
                    default:
                        reader.skipValue();
                }
            }
            reader.endObject();
        }
        if (result.points.isEmpty()) throw new IOException("轨迹文件中没有坐标点");
        sanitizeImportedTrack(result);
        return result;
    }

    private SpatialView.TrailPoint parseTrailPoint(JSONObject item, int index, ImportedTrack imported) throws Exception {
        JSONObject origin = imported.origin;
        double fallbackLat = origin == null ? Double.NaN : origin.optDouble("latitude", Double.NaN);
        double fallbackLon = origin == null ? Double.NaN : origin.optDouble("longitude", Double.NaN);
        String fallbackMap = imported.settings != null ? imported.settings.optString("mapType", imported.mapProvider) : imported.mapProvider;
        float x = (float)(item.has("xMeters") ? item.getDouble("xMeters") : item.getDouble("x"));
        float y = (float)(item.has("yMeters") ? item.getDouble("yMeters") : item.getDouble("y"));
        long timestamp = item.has("timestamp") ? item.optLong("timestamp", System.currentTimeMillis()) : item.optLong("timeMs", System.currentTimeMillis());
        float hdg = (float)item.optDouble("headingDegrees", 0.0);
        float spd = (float)item.optDouble("speedKmh", 0.0);
        float dist = (float)item.optDouble("distanceMeters", index * STEP_METERS);
        imported.maxSpeedKmh = Math.max(imported.maxSpeedKmh, spd);
        imported.distanceMeters = Math.max(imported.distanceMeters, dist);
        JSONArray wifiArray = item.optJSONArray("wifiNetworks");
        JSONObject mapLayer = item.optJSONObject("mapLayer");
        String pointMapProvider = mapLayer == null ? fallbackMap : mapLayer.optString("provider", fallbackMap);
        double pointMapLat = mapLayer == null ? fallbackLat : mapLayer.optDouble("centerLatitude", fallbackLat);
        double pointMapLon = mapLayer == null ? fallbackLon : mapLayer.optDouble("centerLongitude", fallbackLon);
        int pointMapZoom = mapLayer == null ? 18 : mapLayer.optInt("zoom", 18);
        float pointMapScale = mapLayer == null ? 1f : (float)mapLayer.optDouble("scale", 1.0);
        float pointMapPanX = mapLayer == null ? 0f : (float)mapLayer.optDouble("panX", 0.0);
        float pointMapPanY = mapLayer == null ? 0f : (float)mapLayer.optDouble("panY", 0.0);
        JSONArray tileKeys = mapLayer == null ? null : mapLayer.optJSONArray("tileKeys");
        boolean segmentStart = item.optBoolean("segmentStart", index == 0);
        double latitude = item.optDouble("latitude", Double.NaN);
        double longitude = item.optDouble("longitude", Double.NaN);
        float accuracyMeters = item.has("accuracyMeters")
                ? (float)item.optDouble("accuracyMeters", Double.NaN) : Float.NaN;
        String locationProvider = item.optString("locationProvider", "legacy");
        return new SpatialView.TrailPoint(x, y, timestamp, hdg, spd, dist,
                wifiArray == null ? "[]" : wifiArray.toString(), pointMapProvider,
                pointMapLat, pointMapLon, pointMapZoom, pointMapScale, pointMapPanX,
                pointMapPanY, tileKeys == null ? "[]" : tileKeys.toString(), segmentStart,
                latitude, longitude, accuracyMeters, locationProvider);
    }

    private void applyImportedTrack(ImportedTrack imported, String sourceName) {
        JSONObject origin = imported.origin;
        if (origin != null) {
            anchorLatitude = origin.optDouble("latitude", Double.NaN);
            anchorLongitude = origin.optDouble("longitude", Double.NaN);
            anchorAccuracyMeters = (float)origin.optDouble("accuracyMeters", Double.NaN);
            anchorProvider = origin.optString("provider", "imported");
            anchorTimeMs = origin.optLong("timestamp", 0L);
        } else {
            anchorLatitude = Double.NaN; anchorLongitude = Double.NaN;
            anchorAccuracyMeters = Float.NaN; anchorProvider = "legacy"; anchorTimeMs = 0L;
        }

        // v1.6.9 stores exact WGS-84 on every GPS point. It can also repair an old/stale
        // origin by solving the relative-coordinate origin from the first absolute point.
        SpatialView.TrailPoint firstPoint = imported.points.isEmpty() ? null : imported.points.get(0);
        if (hasExactWgs(firstPoint)) {
            boolean repairOrigin = Double.isNaN(anchorLatitude) || Double.isNaN(anchorLongitude);
            if (!repairOrigin) {
                double[] predicted = SpatialView.relativeMetersToLatLon(anchorLatitude, anchorLongitude,
                        firstPoint.x, firstPoint.y);
                float[] mismatch = new float[1];
                Location.distanceBetween(predicted[0], predicted[1],
                        firstPoint.latitude, firstPoint.longitude, mismatch);
                repairOrigin = mismatch[0] > 250f;
            }
            if (repairOrigin) {
                double derivedLat = firstPoint.latitude + Math.toDegrees(firstPoint.y / 6378137.0);
                double cosine = Math.max(0.1, Math.cos(Math.toRadians(derivedLat)));
                double derivedLon = firstPoint.longitude -
                        Math.toDegrees(firstPoint.x / (6378137.0 * cosine));
                anchorLatitude = derivedLat; anchorLongitude = derivedLon;
                anchorAccuracyMeters = firstPoint.accuracyMeters;
                anchorProvider = "repaired-from-point"; anchorTimeMs = firstPoint.timeMs;
            }
        }
        if (spatialView != null) {
            if (!Double.isNaN(anchorLatitude) && !Double.isNaN(anchorLongitude))
                spatialView.setGeoAnchor(anchorLatitude, anchorLongitude);
            else spatialView.clearGeoAnchor();
        }

        activeMapProvider = imported.settings != null
                ? imported.settings.optString("mapType", imported.mapProvider)
                : imported.mapProvider;
        stopReplay();
        spatialView.setTrail(imported.points);
        spatialView.centerOnTrailPoint(0);
        mappedSteps = Math.max(0, imported.points.size() - 1);
        mappingStartElapsedMs = SystemClock.elapsedRealtime();
        currentRecordingSessionStartMs = 0L;
        reconstructImportedMetrics(imported);
        SpatialView.TrailPoint importedLast = imported.points.get(imported.points.size() - 1);
        currentSpeedKmh = Math.max(0f, importedLast.speedKmh);
        maxSpeedKmh = imported.maxSpeedKmh;
        gpsDistanceMeters = imported.distanceMeters;
        movingTimeMs = imported.movingTimeMs;
        activeRecordingTimeMs = imported.activeRecordingTimeMs;
        lastTrackLocation = null;
        lastSpeedLocation = null;
        lastProcessedLocationElapsedNanos = 0L;
        lastProcessedLocationTimeMs = 0L;
        pendingSegmentStart = true;
        updateSensorText();
        if (!"none".equals(activeMapProvider) && !Double.isNaN(anchorLatitude) &&
                !Double.isNaN(anchorLongitude)) {
            final String restoredMap = activeMapProvider;
            final double[] firstGeo = pointWgs(imported.points.get(0));
            handler.post(() -> {
                applyMapBackground(restoredMap, firstGeo[0], firstGeo[1]);
                handler.postDelayed(() -> spatialView.centerOnTrailPoint(0), 250L);
            });
        }
        String anchorNote = Double.isNaN(anchorLatitude)
                ? "（旧版备份：无地图坐标锚点）" : "（已恢复 WGS-84 地图锚点）";
        String filteredNote = imported.filteredPointCount > 0
                ? "，已过滤 " + imported.filteredPointCount + " 个异常定位点" : "";
        String repairedNote = imported.repairedGapCount > 0
                ? String.format(Locale.CHINA, "，已估算补全 %d 段（约 %.2f km）",
                imported.repairedGapCount, imported.repairedGapMeters / 1000f) : "";
        Toast.makeText(this, sourceName + "已载入，共 " + imported.points.size() + " 个坐标点" +
                filteredNote + repairedNote + anchorNote, Toast.LENGTH_LONG).show();
    }

    private void reconstructImportedMetrics(ImportedTrack imported) {
        if (imported == null || imported.points.isEmpty()) return;
        List<SpatialView.TrailPoint> points = imported.points;
        SpatialView.TrailPoint first = points.get(0);
        SpatialView.TrailPoint last = points.get(points.size() - 1);

        if (imported.activeRecordingTimeMs <= 0L) {
            long total = Math.max(0L, last.timeMs - first.timeMs);
            imported.activeRecordingTimeMs = total;
        }

        if (imported.distanceMeters <= 0f) {
            float maxDistance = 0f;
            for (SpatialView.TrailPoint point : points)
                maxDistance = Math.max(maxDistance, point.distanceMeters);
            imported.distanceMeters = maxDistance;
        }

        if (imported.maxSpeedKmh <= 0f) {
            float maxSpeed = 0f;
            for (SpatialView.TrailPoint point : points)
                maxSpeed = Math.max(maxSpeed, point.speedKmh);
            imported.maxSpeedKmh = maxSpeed;
        }

        // 旧版轨迹没有 movingTimeMs。不能用稀疏点之间的少量有效片段猜测移动时间，
        // 否则会把几十分钟的轨迹压缩成几十秒，产生数百 km/h 的虚假平均速度。
        // v1.5.1 的平均速度语义是“总距离 / 轨迹总时长”，因此旧轨迹直接以总时长
        // 作为可用统计时长；新版文件若明确保存了 movingTimeMs，则仍保留移动均速语义。
        if (!imported.hasMovingTimeMs || imported.movingTimeMs <= 0L) {
            imported.movingTimeMs = imported.activeRecordingTimeMs;
        }

        if (imported.activeRecordingTimeMs < imported.movingTimeMs)
            imported.activeRecordingTimeMs = imported.movingTimeMs;

        if (!imported.hasAverageSpeedKmh || imported.averageSpeedKmh <= 0f) {
            imported.averageSpeedKmh = imported.activeRecordingTimeMs > 0L
                    ? imported.distanceMeters / (imported.activeRecordingTimeMs / 1000f) * 3.6f
                    : 0f;
        }
    }

    private JSONObject readJsonObject(JsonReader reader) throws IOException {
        Object value = readJsonValue(reader);
        if (!(value instanceof Map)) throw new IOException("JSON 对象格式错误");
        return new JSONObject((Map) value);
    }

    private Object readJsonValue(JsonReader reader) throws IOException {
        JsonToken token = reader.peek();
        switch (token) {
            case BEGIN_OBJECT: {
                Map<String, Object> map = new LinkedHashMap<>();
                reader.beginObject();
                while (reader.hasNext()) map.put(reader.nextName(), readJsonValue(reader));
                reader.endObject();
                return map;
            }
            case BEGIN_ARRAY: {
                List<Object> list = new ArrayList<>();
                reader.beginArray();
                while (reader.hasNext()) list.add(readJsonValue(reader));
                reader.endArray();
                return list;
            }
            case STRING: return reader.nextString();
            case NUMBER: {
                String number = reader.nextString();
                try { return Long.valueOf(number); }
                catch (NumberFormatException ignored) {
                    try { return Double.valueOf(number); }
                    catch (NumberFormatException e) { return 0.0; }
                }
            }
            case BOOLEAN: return reader.nextBoolean();
            case NULL: reader.nextNull(); return JSONObject.NULL;
            default: reader.skipValue(); return JSONObject.NULL;
        }
    }

    private String nextStringOr(JsonReader reader, String fallback) throws IOException {
        if (reader.peek() == JsonToken.NULL) { reader.nextNull(); return fallback; }
        return reader.nextString();
    }

    private double nextDoubleOr(JsonReader reader, double fallback) throws IOException {
        if (reader.peek() == JsonToken.NULL) { reader.nextNull(); return fallback; }
        try { return reader.nextDouble(); } catch (NumberFormatException e) { return fallback; }
    }

    private long nextLongOr(JsonReader reader, long fallback) throws IOException {
        if (reader.peek() == JsonToken.NULL) { reader.nextNull(); return fallback; }
        try { return reader.nextLong(); } catch (NumberFormatException e) { return fallback; }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        if (requestCode == REQ_EXPORT_TRACK) writeTrackToUri(data.getData());
        else if (requestCode == REQ_IMPORT_TRACK) readTrackFromUri(data.getData());
        else if (requestCode == REQ_EXPORT_BACKUP) exportBackupToUri(data.getData());
        else if (requestCode == REQ_EXPORT_BUG_REPORT) writeBugReportToUri(data.getData());
        else if (requestCode == REQ_EXPORT_SYSTEM) writeSystemDataToUri(data.getData());
        else if (requestCode == REQ_IMPORT_SYSTEM) restoreSystemDataFromUri(data.getData());
    }


    private void exportSystemData() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_TITLE, "xiaokui_system_backup_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".zip");
        startActivityForResult(intent, REQ_EXPORT_SYSTEM);
    }

    private void importSystemData() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/zip");
        startActivityForResult(intent, REQ_IMPORT_SYSTEM);
    }

    private void writeSystemDataToUri(Uri uri) {
        final LinearLayout box = createProgressBox("正在准备系统全量备份…");
        final ProgressBar bar = (ProgressBar) box.getChildAt(0);
        final TextView text = (TextView) box.getChildAt(1);
        final AlertDialog dialog = new AlertDialog.Builder(this).setTitle("导出系统全量数据")
                .setView(box).setCancelable(false).create();
        dialog.show();
        new Thread(() -> {
            try (OutputStream raw = getContentResolver().openOutputStream(uri);
                 ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(raw))) {
                if (raw == null) throw new IOException("无法打开目标文件");
                byte[] track = buildTrackJson().getBytes(StandardCharsets.UTF_8);
                putZipEntry(zip, "current_track.json", track);
                handler.post(() -> updateProgress(bar, text, 35, "已写入当前轨迹"));
                JSONObject prefsJson = new JSONObject();
                for (Map.Entry<String, ?> e : getSharedPreferences(PREFS, MODE_PRIVATE).getAll().entrySet())
                    prefsJson.put(e.getKey(), e.getValue());
                putZipEntry(zip, "preferences.json", prefsJson.toString(2).getBytes(StandardCharsets.UTF_8));
                File[] backups = getBackupFiles();
                long total = 0; for (File f : backups) total += Math.max(1, f.length());
                long done = 0;
                byte[] buffer = new byte[65536];
                for (File f : backups) {
                    zip.putNextEntry(new ZipEntry("backups/" + f.getName()));
                    try (InputStream in = new FileInputStream(f)) { int n; while ((n=in.read(buffer))>0) { zip.write(buffer,0,n); done+=n; } }
                    zip.closeEntry();
                    if (isBackupLocked(f)) putZipEntry(zip, "locks/" + f.getName() + LOCK_SUFFIX, new byte[0]);
                    final int pct = 35 + (int)Math.round(done * 64.0 / Math.max(1,total));
                    handler.post(() -> updateProgress(bar, text, pct, "正在写入备份记录…"));
                }
                zip.finish();
                handler.post(() -> { updateProgress(bar,text,100,"系统全量数据已导出"); dialog.dismiss(); Toast.makeText(this,"系统全量数据已导出",Toast.LENGTH_LONG).show(); });
            } catch (Exception e) {
                handler.post(() -> { dialog.dismiss(); Toast.makeText(this,"全量备份导出失败："+e.getMessage(),Toast.LENGTH_LONG).show(); });
            }
        }, "system-export").start();
    }

    private void putZipEntry(ZipOutputStream zip, String name, byte[] data) throws IOException {
        zip.putNextEntry(new ZipEntry(name)); zip.write(data); zip.closeEntry();
    }

    private void restoreSystemDataFromUri(Uri uri) {
        final LinearLayout box = createProgressBox("正在读取系统全量备份…");
        final ProgressBar bar = (ProgressBar) box.getChildAt(0);
        final TextView text = (TextView) box.getChildAt(1);
        final AlertDialog dialog = new AlertDialog.Builder(this).setTitle("恢复系统全量数据")
                .setView(box).setCancelable(false).create(); dialog.show();
        new Thread(() -> {
            File tempTrack = new File(getCacheDir(), "restore_current_track.json");
            try (InputStream raw = getContentResolver().openInputStream(uri); ZipInputStream zip = new ZipInputStream(new BufferedInputStream(raw))) {
                if (raw == null) throw new IOException("无法打开备份文件");
                File dir = new File(getFilesDir(), AUTO_BACKUP_DIR); if (!dir.exists()) dir.mkdirs();
                ZipEntry entry; byte[] buffer = new byte[65536]; int entries=0;
                while ((entry=zip.getNextEntry()) != null) {
                    String name=entry.getName();
                    if (name.contains("..") || name.startsWith("/")) { zip.closeEntry(); continue; }
                    if ("current_track.json".equals(name)) copyZipEntry(zip,tempTrack,buffer);
                    else if ("preferences.json".equals(name)) {
                        ByteArrayOutputStream out=new ByteArrayOutputStream(); int n; while((n=zip.read(buffer))>0) out.write(buffer,0,n);
                        JSONObject o=new JSONObject(out.toString("UTF-8")); SharedPreferences.Editor ed=getSharedPreferences(PREFS,MODE_PRIVATE).edit().clear();
                        java.util.Iterator<String> it=o.keys(); while(it.hasNext()){String k=it.next();Object v=o.get(k); if(v instanceof Boolean)ed.putBoolean(k,(Boolean)v); else if(v instanceof Integer)ed.putInt(k,(Integer)v); else if(v instanceof Long)ed.putLong(k,(Long)v); else if(v instanceof Number)ed.putFloat(k,((Number)v).floatValue()); else ed.putString(k,String.valueOf(v));} ed.apply();
                    } else if (name.startsWith("backups/")) copyZipEntry(zip,new File(dir,new File(name).getName()),buffer);
                    else if (name.startsWith("locks/")) { File marker=new File(dir,new File(name).getName()); marker.createNewFile(); }
                    zip.closeEntry(); entries++; final int pct=Math.min(85,5+entries*5); handler.post(() -> updateProgress(bar,text,pct,"正在恢复系统文件…"));
                }
                if (!tempTrack.exists()) throw new IOException("备份中缺少 current_track.json");
                try (CountingInputStream in=new CountingInputStream(new FileInputStream(tempTrack))) {
                    ImportedTrack imported=readTrackFromStream(in,count->{ if(count%5000==0){ final int c=count; handler.post(() -> updateProgress(bar,text,90,"正在恢复当前轨迹，已读取 "+c+" 点")); }});
                    handler.post(() -> { applyImportedTrack(imported,"系统全量备份"); updateProgress(bar,text,100,"恢复完成"); dialog.dismiss(); Toast.makeText(this,"系统全量数据恢复完成",Toast.LENGTH_LONG).show(); });
                }
            } catch(Exception e){ handler.post(() -> {dialog.dismiss();Toast.makeText(this,"系统恢复失败："+e.getMessage(),Toast.LENGTH_LONG).show();}); }
            finally { tempTrack.delete(); }
        },"system-import").start();
    }

    private void copyZipEntry(ZipInputStream zip, File target, byte[] buffer) throws IOException {
        File parent=target.getParentFile(); if(parent!=null&&!parent.exists()) parent.mkdirs();
        try(OutputStream out=new BufferedOutputStream(new FileOutputStream(target))){int n;while((n=zip.read(buffer))>0)out.write(buffer,0,n);}
    }

    private static final class VideoMapSnapshot {
        final Bitmap bitmap;
        final int pointIndex;
        final double latitude, longitude;
        final int zoom;
        VideoMapSnapshot(Bitmap bitmap, int pointIndex, double latitude, double longitude, int zoom) {
            this.bitmap = bitmap;
            this.pointIndex = pointIndex;
            this.latitude = latitude;
            this.longitude = longitude;
            this.zoom = zoom;
        }
    }

    private void saveReplayVideo(boolean includeMapLayer) {
        List<SpatialView.TrailPoint> points = sanitizeTrailPoints(spatialView.getTrailCopy());
        if (points.size() <= 1) {
            Toast.makeText(this, "当前没有轨迹，无法生成视频", Toast.LENGTH_LONG).show();
            return;
        }
        final float videoHeading = headingRad;
        final float activityScore = spatialView.getActivityScore();
        final float activityAngle = spatialView.getActivityAngle();
        final String provider = activeMapProvider;
        final AtomicBoolean cancelled = new AtomicBoolean(false);
        final LinearLayout box = createProgressBox(includeMapLayer ? "正在准备路线地图…" : "正在准备视频…");
        final ProgressBar bar = (ProgressBar) box.getChildAt(0);
        final TextView text = (TextView) box.getChildAt(1);
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("保存回放 MP4")
                .setView(box).setNegativeButton("取消", null).setCancelable(false).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
            cancelled.set(true);
            text.setText("正在安全取消视频导出…");
            v.setEnabled(false);
        }));
        dialog.show();

        new Thread(() -> {
            File temp = new File(getCacheDir(), "track_replay_" + System.currentTimeMillis() + ".mp4");
            List<VideoMapSnapshot> snapshots = null;
            try {
                if (includeMapLayer) {
                    if (mapTileView == null || "none".equals(provider)) throw new IOException("没有启用地图底图");
                    snapshots = prepareVideoMapSnapshots(points, provider, cancelled, bar, text);
                    if (snapshots.isEmpty()) throw new IOException("路线地图底图加载失败");
                } else {
                    handler.post(() -> updateProgress(bar, text, 5, "正在准备轨迹视频…"));
                }
                if (cancelled.get()) throw new CancellationException("已取消");
                encodeReplayMp4(points, videoHeading, activityScore, activityAngle, provider, snapshots, temp,
                        cancelled, bar, text);
                if (cancelled.get()) throw new CancellationException("已取消");
                saveVideoFile(temp, cancelled, bar, text);
                handler.post(() -> {
                    updateProgress(bar, text, 100, "MP4 已保存");
                    dialog.dismiss();
                    Toast.makeText(MainActivity.this,
                            "回放视频已保存到 Movies/WiFiEnvironmentMonitor", Toast.LENGTH_LONG).show();
                });
            } catch (CancellationException e) {
                handler.post(() -> { dialog.dismiss(); Toast.makeText(MainActivity.this,
                        "视频导出已取消", Toast.LENGTH_SHORT).show(); });
            } catch (Exception e) {
                handler.post(() -> { dialog.dismiss(); Toast.makeText(MainActivity.this,
                        "视频保存失败：" + e.getMessage(), Toast.LENGTH_LONG).show(); });
            } finally {
                if (snapshots != null) for (VideoMapSnapshot snapshot : snapshots)
                    if (snapshot != null && snapshot.bitmap != null && !snapshot.bitmap.isRecycled()) snapshot.bitmap.recycle();
                if (temp.exists()) temp.delete();
            }
        }, "mp4-export").start();
    }

    private List<VideoMapSnapshot> prepareVideoMapSnapshots(List<SpatialView.TrailPoint> points, String provider,
                                                             AtomicBoolean cancelled, ProgressBar bar, TextView text) throws Exception {
        final int snapshotSize = 1024, maxSnapshots = 18;
        SpatialView.TrailPoint boundsFirst = points.get(0);
        float minX = boundsFirst.x, maxX = boundsFirst.x, minY = boundsFirst.y, maxY = boundsFirst.y;
        int boundsStride = Math.max(1, points.size() / 6000);
        for (int i = 0; i < points.size(); i += boundsStride) {
            SpatialView.TrailPoint q = points.get(i);
            minX = Math.min(minX, q.x); maxX = Math.max(maxX, q.x);
            minY = Math.min(minY, q.y); maxY = Math.max(maxY, q.y);
        }
        SpatialView.TrailPoint endPoint = points.get(points.size() - 1);
        minX = Math.min(minX, endPoint.x); maxX = Math.max(maxX, endPoint.x);
        minY = Math.min(minY, endPoint.y); maxY = Math.max(maxY, endPoint.y);
        double routeRangeMeters = Math.hypot(maxX - minX, maxY - minY);
        double referenceLat = pointWgs(points.get(points.size() / 2))[0];
        int desiredZoom = routeRangeMeters > 25_000 ? 13
                : routeRangeMeters > 12_000 ? 14
                : routeRangeMeters > 6_000 ? 15
                : routeRangeMeters > 3_000 ? 16 : 17;
        int currentZoom = Math.max(13, Math.min(18, mapTileView.getZoomLevel()));
        int videoZoom = Math.min(currentZoom, desiredZoom);
        double mpp = 156543.03392 * Math.cos(Math.toRadians(referenceLat)) / Math.pow(2.0, videoZoom);
        double safeSpacingMeters = Math.max(250.0, 220.0 * mpp);

        // Select snapshots by travelled geometry rather than point index. Index sampling clusters
        // snapshots in slow/stop sections and leaves the fast middle/end of a route without map.
        double[] cumulative = new double[points.size()];
        double total = 0.0;
        for (int i = 1; i < points.size(); i++) {
            SpatialView.TrailPoint p = points.get(i);
            if (!p.segmentStart) total += pointDistanceMeters(points.get(i - 1), p);
            cumulative[i] = total;
        }
        int desiredCount = 1 + (int)Math.ceil(total / safeSpacingMeters);
        desiredCount = Math.max(2, Math.min(maxSnapshots, Math.min(points.size(), desiredCount)));
        ArrayList<Integer> sampleIndices = new ArrayList<>();
        int cursor = 0;
        for (int i = 0; i < desiredCount; i++) {
            double target = total * i / Math.max(1, desiredCount - 1);
            while (cursor + 1 < cumulative.length && cumulative[cursor] < target) cursor++;
            int index = Math.max(0, Math.min(points.size() - 1, cursor));
            if (sampleIndices.isEmpty() || sampleIndices.get(sampleIndices.size() - 1) != index)
                sampleIndices.add(index);
        }
        for (int i = 1; i < points.size() && sampleIndices.size() < maxSnapshots; i++) {
            if (points.get(i).segmentStart && !sampleIndices.contains(i)) sampleIndices.add(i);
        }
        if (!sampleIndices.contains(points.size() - 1)) sampleIndices.add(points.size() - 1);
        java.util.Collections.sort(sampleIndices);
        while (sampleIndices.size() > maxSnapshots) sampleIndices.remove(sampleIndices.size() - 2);

        ArrayList<VideoMapSnapshot> snapshots = new ArrayList<>();
        final int snapshotCount = sampleIndices.size();
        for (int i = 0; i < snapshotCount; i++) {
            if (cancelled.get()) throw new CancellationException("已取消");
            int index = sampleIndices.get(i);
            SpatialView.TrailPoint point = points.get(index);
            double[] geo = pointWgs(point);
            double lat = geo[0], lon = geo[1];
            final int snapshotNumber = i;
            Bitmap bitmap = mapTileView.renderSnapshotBlocking(provider, lat, lon, videoZoom,
                    snapshotSize, snapshotSize, cancelled, (done, tileTotal) -> {
                        float one = done / (float)Math.max(1, tileTotal);
                        int pct = Math.round(35f * (snapshotNumber + one) / snapshotCount);
                        handler.post(() -> updateProgress(bar, text, pct,
                                "正在加载路线地图 " + (snapshotNumber + 1) + "/" + snapshotCount));
                    });
            snapshots.add(new VideoMapSnapshot(bitmap, index, lat, lon, videoZoom));
        }
        handler.post(() -> updateProgress(bar, text, 35, "路线地图已准备，正在编码视频…"));
        return snapshots;
    }

    private VideoMapSnapshot nearestVideoSnapshot(List<VideoMapSnapshot> snapshots, String provider,
                                                  double latitude, double longitude) {
        VideoMapSnapshot best = snapshots.get(0);
        double[] currentWorld = MapTileView.projectWgsToWorldPixels(provider, latitude, longitude, best.zoom);
        double[] bestWorld = MapTileView.projectWgsToWorldPixels(provider, best.latitude, best.longitude, best.zoom);
        double bestDelta = Math.hypot(bestWorld[0] - currentWorld[0], bestWorld[1] - currentWorld[1]);
        for (int i = 1; i < snapshots.size(); i++) {
            VideoMapSnapshot candidate = snapshots.get(i);
            double[] candidateWorld = MapTileView.projectWgsToWorldPixels(provider,
                    candidate.latitude, candidate.longitude, candidate.zoom);
            double delta = Math.hypot(candidateWorld[0] - currentWorld[0], candidateWorld[1] - currentWorld[1]);
            if (delta < bestDelta) { best = candidate; bestDelta = delta; }
        }
        return best;
    }

    private void encodeReplayMp4(List<SpatialView.TrailPoint> points, float videoHeading,
                                 float activityScore, float activityAngle, String provider,
                                 List<VideoMapSnapshot> mapSnapshots,
                                 File output, AtomicBoolean cancelled, ProgressBar bar, TextView progress) throws Exception {
        final int width = 720, height = 720, fps = 15;
        long desiredFrames = (long)points.size() * 2L;
        final int frameCount = (int)Math.max(120L, Math.min(900L, desiredFrames));
        MediaFormat format = MediaFormat.createVideoFormat("video/avc", width, height);
        int encoderColorFormat = chooseEncoderColorFormat("video/avc");
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT, encoderColorFormat);
        format.setInteger(MediaFormat.KEY_BIT_RATE, 2500000);
        format.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
        MediaCodec codec = MediaCodec.createEncoderByType("video/avc");
        MediaMuxer muxer = null;
        boolean muxerStarted = false;
        int trackIndex = -1;
        int[] argbBuffer = new int[width * height];
        byte[] yuvBuffer = new byte[width * height * 3 / 2];
        int maxScannedIndex = -1;
        float runningMaxKmh = 0f;
        int lastProgress = -1;
        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            codec.start();
            muxer = new MediaMuxer(output.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            for (int frame = 0; frame < frameCount; frame++) {
                if (cancelled.get()) throw new CancellationException("已取消");
                int visible = 1 + Math.round((points.size() - 1) * frame / (float)Math.max(1, frameCount - 1));
                SpatialView.TrailPoint current = points.get(visible - 1);
                while (maxScannedIndex + 1 < visible) {
                    maxScannedIndex++;
                    runningMaxKmh = Math.max(runningMaxKmh, points.get(maxScannedIndex).speedKmh);
                }
                Bitmap bitmap;
                if (mapSnapshots != null && !mapSnapshots.isEmpty()) {
                    bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                    Canvas frameCanvas = new Canvas(bitmap);
                    frameCanvas.drawColor(0xFFF3F5F8);
                    double[] currentGeo = pointWgs(current);
                    double currentLat = currentGeo[0];
                    double currentLon = currentGeo[1];
                    VideoMapSnapshot snapshot = nearestVideoSnapshot(mapSnapshots, provider, currentLat, currentLon);
                    double[] snapshotWorld = MapTileView.projectWgsToWorldPixels(provider,
                            snapshot.latitude, snapshot.longitude, snapshot.zoom);
                    double[] currentWorld = MapTileView.projectWgsToWorldPixels(provider,
                            currentLat, currentLon, snapshot.zoom);
                    float left = (width - snapshot.bitmap.getWidth()) / 2f
                            + (float)(snapshotWorld[0] - currentWorld[0]);
                    float top = (height - snapshot.bitmap.getHeight()) / 2f
                            + (float)(snapshotWorld[1] - currentWorld[1]);
                    frameCanvas.drawBitmap(snapshot.bitmap, left, top, null);
                    Bitmap overlay = renderProjectedTrailOverlay(points, provider,
                            currentLat, currentLon, snapshot.zoom, width, height, visible,
                            (float)Math.toRadians(current.headingDegrees));
                    frameCanvas.drawBitmap(overlay, 0, 0, null);
                    overlay.recycle();
                } else {
                    double currentLat = pointWgs(current)[0];
                    bitmap = renderPlainTrackFrame(points, width, height, visible, current.x, current.y,
                            currentLat, 17, (float)Math.toRadians(current.headingDegrees));
                }
                annotateExportBitmap(bitmap, points, visible, runningMaxKmh);
                bitmapToYuv420(bitmap, encoderColorFormat, argbBuffer, yuvBuffer);
                bitmap.recycle();
                boolean queued = false;
                while (!queued) {
                    if (cancelled.get()) throw new CancellationException("已取消");
                    int inputIndex = codec.dequeueInputBuffer(10000);
                    if (inputIndex >= 0) {
                        ByteBuffer input = codec.getInputBuffer(inputIndex);
                        input.clear(); input.put(yuvBuffer);
                        codec.queueInputBuffer(inputIndex, 0, yuvBuffer.length, frame * 1000000L / fps, 0);
                        queued = true;
                    }
                    MediaMuxerState state = drainEncoder(codec, muxer, info, muxerStarted, trackIndex, false);
                    muxerStarted = state.started; trackIndex = state.trackIndex;
                }
                MediaMuxerState state = drainEncoder(codec, muxer, info, muxerStarted, trackIndex, false);
                muxerStarted = state.started; trackIndex = state.trackIndex;
                int pct = 35 + Math.round(58f * (frame + 1) / frameCount);
                if (pct != lastProgress) {
                    lastProgress = pct; final int shown = pct; final int shownFrame = frame + 1;
                    handler.post(() -> updateProgress(bar, progress, shown,
                            "正在编码视频帧 " + shownFrame + "/" + frameCount));
                }
            }
            int inputIndex;
            do {
                if (cancelled.get()) throw new CancellationException("已取消");
                inputIndex = codec.dequeueInputBuffer(10000);
            } while (inputIndex < 0);
            codec.queueInputBuffer(inputIndex, 0, 0, frameCount * 1000000L / fps,
                    MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            boolean done = false;
            while (!done) {
                if (cancelled.get()) throw new CancellationException("已取消");
                MediaMuxerState state = drainEncoder(codec, muxer, info, muxerStarted, trackIndex, true);
                muxerStarted = state.started; trackIndex = state.trackIndex; done = state.eos;
            }
        } finally {
            try { codec.stop(); } catch (Exception ignored) {}
            codec.release();
            if (muxer != null) {
                try { if (muxerStarted) muxer.stop(); } catch (Exception ignored) {}
                muxer.release();
            }
        }
    }

    private static class MediaMuxerState {
        final boolean started; final int trackIndex; final boolean eos;
        MediaMuxerState(boolean started, int trackIndex, boolean eos) {
            this.started = started; this.trackIndex = trackIndex; this.eos = eos;
        }
    }

    private MediaMuxerState drainEncoder(MediaCodec codec, MediaMuxer muxer, MediaCodec.BufferInfo info,
                                         boolean started, int trackIndex, boolean waitForEos) {
        boolean eos = false;
        while (true) {
            int outputIndex = codec.dequeueOutputBuffer(info, waitForEos ? 10000 : 0);
            if (outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER) break;
            if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (!started) {
                    trackIndex = muxer.addTrack(codec.getOutputFormat());
                    muxer.start(); started = true;
                }
            } else if (outputIndex >= 0) {
                ByteBuffer output = codec.getOutputBuffer(outputIndex);
                if (output != null && info.size > 0 && started) {
                    output.position(info.offset); output.limit(info.offset + info.size);
                    muxer.writeSampleData(trackIndex, output, info);
                }
                eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                codec.releaseOutputBuffer(outputIndex, false);
                if (eos) break;
            }
        }
        return new MediaMuxerState(started, trackIndex, eos);
    }

    private int chooseEncoderColorFormat(String mime) throws IOException {
        android.media.MediaCodecList list = new android.media.MediaCodecList(android.media.MediaCodecList.ALL_CODECS);
        for (android.media.MediaCodecInfo info : list.getCodecInfos()) {
            if (!info.isEncoder()) continue;
            for (String type : info.getSupportedTypes()) {
                if (!type.equalsIgnoreCase(mime)) continue;
                int fallback = -1;
                for (int f : info.getCapabilitiesForType(type).colorFormats) {
                    if (f == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar) return f;
                    if (f == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar) fallback = f;
                    if (f == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible && fallback < 0) fallback = f;
                }
                if (fallback >= 0) return fallback;
            }
        }
        throw new IOException("设备不支持可用的 H.264 YUV420 编码格式");
    }

    private byte[] bitmapToYuv420(Bitmap bitmap, int colorFormat) {
        int width = bitmap.getWidth(), height = bitmap.getHeight();
        int[] argb = new int[width * height];
        byte[] out = new byte[width * height * 3 / 2];
        bitmapToYuv420(bitmap, colorFormat, argb, out);
        return out;
    }

    private void bitmapToYuv420(Bitmap bitmap, int colorFormat, int[] argb, byte[] out) {
        int width = bitmap.getWidth(), height = bitmap.getHeight();
        if (argb.length < width * height || out.length < width * height * 3 / 2)
            throw new IllegalArgumentException("YUV 缓冲区尺寸不足");
        bitmap.getPixels(argb, 0, width, 0, 0, width, height);
        int yIndex = 0, uIndex = width * height, vIndex = uIndex + width * height / 4;
        for (int j = 0; j < height; j++) {
            for (int i = 0; i < width; i++) {
                int c = argb[j * width + i];
                int r = (c >> 16) & 0xff, g = (c >> 8) & 0xff, b = c & 0xff;
                int y = ((66 * r + 129 * g + 25 * b + 128) >> 8) + 16;
                int u = ((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128;
                int v = ((112 * r - 94 * g - 18 * b + 128) >> 8) + 128;
                out[yIndex++] = (byte)Math.max(0, Math.min(255, y));
                if ((j & 1) == 0 && (i & 1) == 0) {
                    int uu = Math.max(0, Math.min(255, u));
                    int vv = Math.max(0, Math.min(255, v));
                    if (colorFormat == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar) {
                        int chromaBase = width * height + (j / 2) * width + i;
                        out[chromaBase] = (byte)uu;
                        out[chromaBase + 1] = (byte)vv;
                    } else {
                        out[uIndex++] = (byte)uu;
                        out[vIndex++] = (byte)vv;
                    }
                }
            }
        }
    }

    private void saveVideoFile(File temp, AtomicBoolean cancelled, ProgressBar bar, TextView progress) throws Exception {
        String name = "wifi_track_replay_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".mp4";
        long total = Math.max(1L, temp.length());
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/WiFiEnvironmentMonitor");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("无法创建视频文件");
            boolean completed = false;
            try (InputStream in = new FileInputStream(temp); OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IOException("无法打开视频目标文件");
                byte[] buffer = new byte[65536]; int n; long copied = 0L; int lastPct = -1;
                while ((n = in.read(buffer)) > 0) {
                    if (cancelled.get()) throw new CancellationException("已取消");
                    out.write(buffer, 0, n); copied += n;
                    int pct = 93 + Math.round(7f * copied / total);
                    if (pct != lastPct) { lastPct = pct; final int shown = pct;
                        handler.post(() -> updateProgress(bar, progress, shown, "正在写入 MP4 文件…")); }
                }
                out.flush(); completed = true;
            } finally {
                if (completed) {
                    values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0);
                    getContentResolver().update(uri, values, null, null);
                } else {
                    try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
                }
            }
        } else {
            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "WiFiEnvironmentMonitor");
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("无法创建视频目录");
            File target = new File(dir, name);
            boolean completed = false;
            try (InputStream in = new FileInputStream(temp); OutputStream out = new FileOutputStream(target)) {
                byte[] buffer = new byte[65536]; int n; long copied = 0L; int lastPct = -1;
                while ((n = in.read(buffer)) > 0) {
                    if (cancelled.get()) throw new CancellationException("已取消");
                    out.write(buffer, 0, n); copied += n;
                    int pct = 93 + Math.round(7f * copied / total);
                    if (pct != lastPct) { lastPct = pct; final int shown = pct;
                        handler.post(() -> updateProgress(bar, progress, shown, "正在写入 MP4 文件…")); }
                }
                out.flush(); completed = true;
            } finally {
                if (!completed && target.exists()) target.delete();
            }
            MediaScannerConnection.scanFile(this, new String[]{target.getAbsolutePath()}, new String[]{"video/mp4"}, null);
        }
    }

    @Override public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ROTATION_VECTOR) {
            float[] matrix = new float[9];
            float[] orientation = new float[3];
            SensorManager.getRotationMatrixFromVector(matrix, event.values);
            SensorManager.getOrientation(matrix, orientation);
            headingRad = orientation[0];
            if (spatialView != null) spatialView.setHeading(headingRad);
        } else if (event.sensor.getType() == Sensor.TYPE_STEP_DETECTOR && mapping) {
            long now = System.currentTimeMillis();
            if (now - lastFallbackStepMs > 280L) {
                lastFallbackStepMs = now;
                recordDetectedStep();
            }
        } else if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER && mapping) {
            float x = event.values[0], y = event.values[1], z = event.values[2];
            float magnitude = (float)Math.sqrt(x*x + y*y + z*z);
            gravityMagnitude = 0.90f * gravityMagnitude + 0.10f * magnitude;
            float impulse = Math.abs(magnitude - gravityMagnitude);
            long now = System.currentTimeMillis();
            if (impulse > 0.72f && now - lastFallbackStepMs > 300L) {
                lastFallbackStepMs = now;
                recordDetectedStep();
            }
        }
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    @Override protected void onResume() {
        super.onResume();
        activityVisible = true;
        if (statusText != null && hasRequiredPermissions()) { readResults(); ensureGeoAnchor(false); }
        if (sensorManager != null) {
            if (stepSensor != null) sensorManager.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_NORMAL);
            if (rotationSensor != null) sensorManager.registerListener(this, rotationSensor, SensorManager.SENSOR_DELAY_GAME);
            if (accelerometerSensor != null) sensorManager.registerListener(this, accelerometerSensor, SensorManager.SENSOR_DELAY_GAME);
        }
        if (TrackingStateStore.isActive(this) && !mapping) resumeActiveTrackingIfNeeded();
        if (mapping) {
            stopContinuousLocationUpdates();
            startTrackingService();
            drainPendingBackgroundLocations();
            startAutoWifiScanning();
        } else {
            startContinuousLocationUpdates();
        }
        updateSensorText();
    }

    @Override protected void onPause() {
        activityVisible = false;
        // 锁屏后只保留前台服务和增量日志。Activity 的传感器、UI 重绘、JSON
        // 序列化全部停止，解锁回来后再分批补点。
        stopAutoWifiScanning();
        stopContinuousLocationUpdates();
        if (sensorManager != null) sensorManager.unregisterListener(this);
        saveAutoBackup(true);
        super.onPause();
    }

    @Override protected void onDestroy() {

        handler.removeCallbacks(scanTimeout);
        handler.removeCallbacks(autoWifiScanRunnable);
        handler.removeCallbacks(replayRunnable);
        if (receiverRegistered) unregisterReceiver(receiver);
        super.onDestroy();
    }
}
