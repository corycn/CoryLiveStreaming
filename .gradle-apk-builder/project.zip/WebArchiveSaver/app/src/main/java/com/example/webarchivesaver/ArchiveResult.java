package com.example.webarchivesaver;

import java.io.File;

public final class ArchiveResult {
    public final File file;
    public final String suggestedName;
    public final String mimeType;
    public final int savedResources;
    public final int failedResources;
    public final long downloadedBytes;

    public ArchiveResult(File file, String suggestedName, String mimeType,
                         int savedResources, int failedResources, long downloadedBytes) {
        this.file = file;
        this.suggestedName = suggestedName;
        this.mimeType = mimeType;
        this.savedResources = savedResources;
        this.failedResources = failedResources;
        this.downloadedBytes = downloadedBytes;
    }
}
