package com.example.webarchivesaver;

public final class ArchiveOptions {
    public enum Mode { SINGLE_HTML, ZIP_PACKAGE }

    public final Mode mode;
    public final boolean includeScripts;
    public final boolean includeMedia;
    public final long maxTotalBytes;
    public final long maxSingleResourceBytes;
    public final int maxResources;

    public ArchiveOptions(Mode mode, boolean includeScripts, boolean includeMedia) {
        this(mode, includeScripts, includeMedia,
                mode == Mode.SINGLE_HTML ? 160L * 1024 * 1024 : 500L * 1024 * 1024,
                mode == Mode.SINGLE_HTML ? 32L * 1024 * 1024 : 100L * 1024 * 1024,
                2000);
    }

    public ArchiveOptions(Mode mode, boolean includeScripts, boolean includeMedia,
                          long maxTotalBytes, long maxSingleResourceBytes, int maxResources) {
        this.mode = mode;
        this.includeScripts = includeScripts;
        this.includeMedia = includeMedia;
        this.maxTotalBytes = maxTotalBytes;
        this.maxSingleResourceBytes = maxSingleResourceBytes;
        this.maxResources = maxResources;
    }
}
