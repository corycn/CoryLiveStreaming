package com.example.webarchivesaver;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int REQUEST_CREATE_FILE = 2001;
    private static final long MAX_CAPTURE_CHARS = 100L * 1024 * 1024;

    private WebView webView;
    private EditText urlInput;
    private Button loadButton;
    private Button saveHtmlButton;
    private Button saveZipButton;
    private Button saveMhtmlButton;
    private CheckBox includeScripts;
    private CheckBox includeMedia;
    private ProgressBar progressBar;
    private TextView statusText;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private CaptureBridge captureBridge;
    private File pendingExport;
    private String pendingMime;
    private String pendingName;
    private boolean busy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
        configureWebView();
        bindActions();
        if (savedInstanceState != null) webView.restoreState(savedInstanceState);
    }

    private void bindViews() {
        webView = findViewById(R.id.webView);
        urlInput = findViewById(R.id.urlInput);
        loadButton = findViewById(R.id.loadButton);
        saveHtmlButton = findViewById(R.id.saveHtmlButton);
        saveZipButton = findViewById(R.id.saveZipButton);
        saveMhtmlButton = findViewById(R.id.saveMhtmlButton);
        includeScripts = findViewById(R.id.includeScripts);
        includeMedia = findViewById(R.id.includeMedia);
        progressBar = findViewById(R.id.progressBar);
        statusText = findViewById(R.id.statusText);
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        captureBridge = new CaptureBridge();
        webView.addJavascriptInterface(captureBridge, "OfflineArchiveBridge");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (!busy) statusText.setText("网页加载 " + newProgress + "%");
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                setArchiveButtons(false);
                if (!busy) showBusy("正在打开网页…");
                urlInput.setText(url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (!busy) {
                    hideBusy("页面已加载，可滚动或登录后再归档");
                    setArchiveButtons(true);
                }
                urlInput.setText(url);
            }
        });
    }

    private void bindActions() {
        loadButton.setOnClickListener(v -> loadTypedUrl());
        urlInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO) {
                loadTypedUrl();
                return true;
            }
            return false;
        });
        saveHtmlButton.setOnClickListener(v -> startDomArchive(ArchiveOptions.Mode.SINGLE_HTML));
        saveZipButton.setOnClickListener(v -> startDomArchive(ArchiveOptions.Mode.ZIP_PACKAGE));
        saveMhtmlButton.setOnClickListener(v -> saveMhtml());
    }

    private void loadTypedUrl() {
        if (busy) return;
        String value = urlInput.getText().toString().trim();
        if (value.isEmpty()) {
            toast("请输入网址");
            return;
        }
        if (!value.matches("(?i)^https?://.*")) value = "https://" + value;
        webView.loadUrl(value);
    }

    private void startDomArchive(ArchiveOptions.Mode mode) {
        if (busy || webView.getUrl() == null) return;
        busy = true;
        setArchiveButtons(false);
        showBusy("正在提取渲染后的页面 DOM…");
        final String token = UUID.randomUUID().toString();
        captureBridge.start(token, new CaptureBridge.Callback() {
            @Override
            public void onCaptured(String html) {
                runArchive(mode, html);
            }

            @Override
            public void onError(String message) {
                failUi(message);
            }
        });
        webView.evaluateJavascript(buildCaptureScript(token), null);
    }

    private void runArchive(ArchiveOptions.Mode mode, String html) {
        final String pageUrl = webView.getUrl();
        final String userAgent = webView.getSettings().getUserAgentString();
        final ArchiveOptions options = new ArchiveOptions(mode, includeScripts.isChecked(), includeMedia.isChecked());
        executor.execute(() -> {
            try {
                ArchiveEngine engine = new ArchiveEngine(userAgent,
                        url -> CookieManager.getInstance().getCookie(url),
                        (message, completed, totalHint) -> mainHandler.post(() -> statusText.setText(message)));
                File root = new File(getCacheDir(), "exports");
                ArchiveResult result = engine.archive(pageUrl, html, root, options);
                mainHandler.post(() -> requestExport(result));
            } catch (Exception e) {
                mainHandler.post(() -> failUi("归档失败：" + safeMessage(e)));
            }
        });
    }

    private void saveMhtml() {
        if (busy || webView.getUrl() == null) return;
        busy = true;
        setArchiveButtons(false);
        showBusy("正在生成 MHTML…");
        File dir = new File(getCacheDir(), "mhtml");
        if (!dir.exists() && !dir.mkdirs()) {
            failUi("无法创建临时目录");
            return;
        }
        String host = Uri.parse(webView.getUrl()).getHost();
        if (host == null || host.isBlank()) host = "webpage";
        String name = host.replaceAll("[^a-zA-Z0-9._-]", "_") + "_archive.mht";
        File file = new File(dir, name);
        webView.saveWebArchive(file.getAbsolutePath(), false, savedPath -> {
            if (savedPath == null) {
                failUi("WebView 无法生成 MHTML");
            } else {
                requestExport(new ArchiveResult(new File(savedPath), name, "multipart/related", 0, 0, file.length()));
            }
        });
    }

    private void requestExport(ArchiveResult result) {
        pendingExport = result.file;
        pendingMime = result.mimeType;
        pendingName = result.suggestedName;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(result.mimeType);
        intent.putExtra(Intent.EXTRA_TITLE, result.suggestedName);
        try {
            startActivityForResult(intent, REQUEST_CREATE_FILE);
            statusText.setText(String.format(Locale.ROOT, "资源 %d 个，失败 %d 个；请选择保存位置", result.savedResources, result.failedResources));
        } catch (Exception e) {
            failUi("无法打开系统文件保存器：" + safeMessage(e));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CREATE_FILE) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            finishBusy("已取消保存");
            return;
        }
        Uri destination = data.getData();
        File source = pendingExport;
        executor.execute(() -> {
            try {
                copyToUri(source, destination);
                mainHandler.post(() -> finishBusy("保存成功：" + pendingName));
            } catch (Exception e) {
                mainHandler.post(() -> failUi("写入文件失败：" + safeMessage(e)));
            }
        });
    }

    private void copyToUri(File source, Uri destination) throws IOException {
        if (source == null || !source.isFile()) throw new IOException("临时文件不存在");
        try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(source));
             OutputStream raw = getContentResolver().openOutputStream(destination, "w")) {
            if (raw == null) throw new IOException("无法打开目标文件");
            try (BufferedOutputStream out = new BufferedOutputStream(raw)) {
                byte[] buffer = new byte[32_768];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            }
        }
    }

    private String buildCaptureScript(String token) {
        String quoted = jsQuote(token);
        return "(function(){try{" +
                "var src=document.documentElement,dst=src.cloneNode(true);" +
                "var s=src.querySelectorAll('*'),d=dst.querySelectorAll('*');" +
                "for(var i=0;i<s.length&&i<d.length;i++){var a=s[i],b=d[i];" +
                "if(a.tagName==='INPUT'){if(a.type==='checkbox'||a.type==='radio'){if(a.checked)b.setAttribute('checked','checked');else b.removeAttribute('checked');}else b.setAttribute('value',a.value||'');}" +
                "else if(a.tagName==='TEXTAREA'){b.textContent=a.value||'';}" +
                "else if(a.tagName==='OPTION'){if(a.selected)b.setAttribute('selected','selected');else b.removeAttribute('selected');}" +
                "else if(a.tagName==='DETAILS'){if(a.open)b.setAttribute('open','open');}" +
                "if(a.tagName==='IMG'){var cs=a.currentSrc||a.getAttribute('src')||a.getAttribute('data-src')||a.getAttribute('data-original')||a.getAttribute('data-lazy-src');if(cs)b.setAttribute('src',cs);var ss=a.getAttribute('srcset')||a.getAttribute('data-srcset');if(ss)b.setAttribute('srcset',ss);}" +
                "if(a.tagName==='SOURCE'){var ssrc=a.getAttribute('src')||a.getAttribute('data-src');var sset=a.getAttribute('srcset')||a.getAttribute('data-srcset');if(ssrc)b.setAttribute('src',ssrc);if(sset)b.setAttribute('srcset',sset);}" +
                "if(a.shadowRoot){try{var t=document.createElement('template');t.setAttribute('shadowrootmode','open');t.innerHTML=a.shadowRoot.innerHTML;b.insertBefore(t,b.firstChild);}catch(_){}}" +
                "}" +
                "var sc=src.querySelectorAll('canvas'),dc=dst.querySelectorAll('canvas');" +
                "for(var j=0;j<sc.length&&j<dc.length;j++){try{var im=document.createElement('img');im.src=sc[j].toDataURL('image/png');im.width=sc[j].width;im.height=sc[j].height;dc[j].replaceWith(im);}catch(_){}}" +
                "var html='<!DOCTYPE html>\\n'+dst.outerHTML;" +
                "var size=180000,total=Math.ceil(html.length/size);" +
                "if(html.length>" + MAX_CAPTURE_CHARS + "){OfflineArchiveBridge.fail(" + quoted + ",'页面 DOM 超过 100 MB 限制');return;}" +
                "for(var k=0;k<total;k++)OfflineArchiveBridge.push(" + quoted + ",k,total,html.substring(k*size,(k+1)*size));" +
                "}catch(e){OfflineArchiveBridge.fail(" + quoted + ",String(e&&e.message||e));}})();";
    }

    private static String jsQuote(String value) {
        return "'" + value.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "") + "'";
    }

    private void setArchiveButtons(boolean enabled) {
        saveHtmlButton.setEnabled(enabled && !busy);
        saveZipButton.setEnabled(enabled && !busy);
        saveMhtmlButton.setEnabled(enabled && !busy);
        loadButton.setEnabled(!busy);
    }

    private void showBusy(String message) {
        progressBar.setVisibility(View.VISIBLE);
        statusText.setText(message);
    }

    private void hideBusy(String message) {
        progressBar.setVisibility(View.GONE);
        statusText.setText(message);
    }

    private void finishBusy(String message) {
        busy = false;
        deletePendingExport();
        hideBusy(message);
        setArchiveButtons(webView.getUrl() != null);
        toast(message);
    }

    private void failUi(String message) {
        busy = false;
        deletePendingExport();
        hideBusy(message);
        setArchiveButtons(webView.getUrl() != null);
        toast(message);
    }

    private void deletePendingExport() {
        File file = pendingExport;
        pendingExport = null;
        if (file != null && file.exists()) {
            file.delete();
            File parent = file.getParentFile();
            if (parent != null) parent.delete();
        }
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private static String safeMessage(Throwable e) {
        return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        captureBridge.cancel();
        deletePendingExport();
        webView.removeJavascriptInterface("OfflineArchiveBridge");
        webView.destroy();
        executor.shutdownNow();
        super.onDestroy();
    }

    private final class CaptureBridge {
        interface Callback {
            void onCaptured(String html);
            void onError(String message);
        }

        private String token;
        private String[] chunks;
        private int received;
        private long chars;
        private Callback callback;

        synchronized void start(String token, Callback callback) {
            this.token = token;
            this.callback = callback;
            this.chunks = null;
            this.received = 0;
            this.chars = 0;
        }

        synchronized void cancel() {
            token = null;
            chunks = null;
            callback = null;
            received = 0;
            chars = 0;
        }

        @JavascriptInterface
        public synchronized void push(String incomingToken, int index, int total, String chunk) {
            if (token == null || !token.equals(incomingToken) || total <= 0 || total > 10000 || index < 0 || index >= total) return;
            if (chunks == null) chunks = new String[total];
            if (chunks.length != total || chunks[index] != null) return;
            chars += chunk == null ? 0 : chunk.length();
            if (chars > MAX_CAPTURE_CHARS) {
                Callback cb = callback;
                cancel();
                if (cb != null) mainHandler.post(() -> cb.onError("页面 DOM 超过 100 MB 限制"));
                return;
            }
            chunks[index] = chunk == null ? "" : chunk;
            received++;
            if (received == total) {
                StringBuilder b = new StringBuilder((int) Math.min(chars, Integer.MAX_VALUE));
                for (String part : chunks) b.append(part);
                Callback cb = callback;
                cancel();
                if (cb != null) mainHandler.post(() -> cb.onCaptured(b.toString()));
            }
        }

        @JavascriptInterface
        public synchronized void fail(String incomingToken, String message) {
            if (token == null || !token.equals(incomingToken)) return;
            Callback cb = callback;
            cancel();
            if (cb != null) mainHandler.post(() -> cb.onError("提取 DOM 失败：" + message));
        }
    }
}
