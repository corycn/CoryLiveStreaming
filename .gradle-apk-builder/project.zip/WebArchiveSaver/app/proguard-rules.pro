# WebArchiveSaver does not enable minification by default.
# Keep JavaScript interface methods if release shrinking is enabled later.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
