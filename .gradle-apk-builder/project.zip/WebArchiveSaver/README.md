# WebArchiveSaver（网页离线归档 Android App）

一个可直接导入 Android Studio 的 Gradle 工程。用户手动输入网址，在内置 WebView 中完成加载、滚动、登录或展开内容后，可将“当前渲染状态”导出。

## 三种导出模式

1. **单文件 HTML**：把可下载的 CSS、图片、字体、脚本和媒体转换为 data URI 或内联文本，输出一个 `.html` 文件。
2. **HTML + 资源 ZIP**：输出 `index.html`、`assets/` 和 `archive-report.txt`，再打包为 ZIP。大网页推荐此模式。
3. **原生 MHTML**：调用 Android WebView 的 `saveWebArchive()` 生成 `.mht`。

## 构建环境

- Android Gradle Plugin 9.3.0
- Gradle 9.5.0
- Java / JDK 17
- NIO core-library desugaring 2.1.5（Jsoup Android 要求）
- compileSdk / targetSdk 37（Android 17）
- minSdk 26（Android 8.0）

在 Android Studio 中打开项目，等待 Gradle 同步，然后运行 `app`。工程内含一个可审计的轻量 Wrapper 引导 JAR；它读取 `gradle-wrapper.properties`、校验官方 Gradle ZIP 的 SHA-256，然后启动 Gradle。命令行可使用：

```bash
./gradlew assembleDebug
```

生成 APK：`app/build/outputs/apk/debug/app-debug.apk`

## 使用方法

1. 输入 `https://...` 或域名，点击“打开网页”。
2. 等页面加载完成；需要登录、滚动加载、点击展开的内容，应先在 WebView 中完成。
3. 勾选是否保存脚本、音视频。
4. 选择“单文件 HTML”“HTML + 资源 ZIP”或“原生 MHTML”。
5. 在 Android 系统文件选择器中指定保存位置。

## 技术实现

- WebView 执行 JavaScript，分块回传当前 DOM，避免大型页面一次性回调限制。
- 同步表单值、选中状态、`details` 展开状态、当前图片资源、canvas 快照和开放式 Shadow DOM。
- Jsoup 解析 DOM。
- 递归处理 CSS `@import` 与 `url(...)`。
- 使用当前 WebView User-Agent 和按资源域名读取的 Cookie 请求资源。
- 重写 HTML/CSS 资源链接，或转换为 data URI。
- 每次 ZIP 归档包含失败清单和已知限制报告。

## 无法承诺“100%”的原因

任何客户端工具都无法对所有网站保证 100% 复刻。以下内容可能无法完整保存：

- DRM、加密音视频、流媒体分片与受保护内容；
- CAPTCHA、反爬、设备校验、证书绑定或临时签名 URL；
- 跨域 iframe 内部 DOM、closed Shadow DOM；
- Service Worker/IndexedDB 的完整运行状态；
- 依赖服务器 API 的交互逻辑、WebSocket 和登录过期后的请求；
- 超过应用资源数量或大小保护上限的文件。

失败资源会尽量保留原始在线 URL，并记录在报告中。请仅归档您有权保存的网页，遵守网站条款、robots 规则、版权、隐私和当地法律。应用不会绕过登录、DRM、验证码或访问控制。

## 安全说明

保存并再次打开网页脚本，等同于运行原网站代码。只对可信网页启用“保存脚本”。应用不会忽略 TLS 证书错误，也不会尝试绕过安全控制。

## 主要源码

- `MainActivity.java`：WebView、DOM 分块捕获、导出 UI、系统文件保存器。
- `ArchiveEngine.java`：资源下载、CSS 递归处理、单文件内联、ZIP 打包和报告。
- `ArchiveOptions.java`：脚本/媒体及资源大小限制。

## 许可

项目示例代码采用 MIT License。第三方依赖 Jsoup 使用其自身许可。
