package org.gradle.wrapper;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Small, auditable Gradle bootstrap used only because this generated source bundle
 * cannot fetch the official binary wrapper JAR during packaging. It downloads the
 * distribution declared in gradle-wrapper.properties, verifies SHA-256, extracts it,
 * and delegates to its gradle executable.
 */
public final class GradleWrapperMain {
    private static final int BUFFER = 64 * 1024;

    private GradleWrapperMain() { }

    public static void main(String[] args) throws Exception {
        File jar = new File(GradleWrapperMain.class.getProtectionDomain().getCodeSource().getLocation().toURI());
        File wrapperDir = jar.getParentFile();
        File propertiesFile = new File(wrapperDir, "gradle-wrapper.properties");
        if (!propertiesFile.isFile()) fail("Missing " + propertiesFile);

        Properties properties = new Properties();
        try (InputStream in = new FileInputStream(propertiesFile)) {
            properties.load(in);
        }
        String distributionUrl = required(properties, "distributionUrl").replace("\\:", ":");
        String expectedSha = properties.getProperty("distributionSha256Sum", "").trim().toLowerCase(Locale.ROOT);
        int timeout = parseInt(properties.getProperty("networkTimeout"), 10_000);

        String gradleUserHomeValue = System.getenv("GRADLE_USER_HOME");
        File gradleUserHome = gradleUserHomeValue == null || gradleUserHomeValue.isBlank()
                ? new File(System.getProperty("user.home"), ".gradle")
                : new File(gradleUserHomeValue);
        String archiveName = new File(URI.create(distributionUrl).getPath()).getName();
        String versionName = archiveName.replaceFirst("-bin\\.zip$", "").replaceFirst("-all\\.zip$", "");
        File installRoot = new File(gradleUserHome, "wrapper/dists/webarchivesaver/" + versionName + "-" + sha256(distributionUrl).substring(0, 12));
        File lockFile = new File(installRoot.getParentFile(), installRoot.getName() + ".lock");
        if (!lockFile.getParentFile().exists() && !lockFile.getParentFile().mkdirs()) fail("Cannot create " + lockFile.getParent());

        try (FileChannel channel = FileChannel.open(lockFile.toPath(), java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.WRITE);
             FileLock ignored = channel.lock()) {
            File executable = findGradleExecutable(installRoot);
            if (executable == null) {
                installDistribution(distributionUrl, expectedSha, timeout, installRoot);
                executable = findGradleExecutable(installRoot);
            }
            if (executable == null) fail("Gradle executable was not found after extraction: " + installRoot);
            if (!isWindows()) executable.setExecutable(true);
            runGradle(executable, args);
        }
    }

    private static void installDistribution(String url, String expectedSha, int timeout, File installRoot) throws Exception {
        File parent = installRoot.getParentFile();
        File zip = new File(parent, installRoot.getName() + ".zip");
        File part = new File(parent, installRoot.getName() + ".zip.part");
        File tempDir = new File(parent, installRoot.getName() + ".tmp");
        deleteRecursively(part);
        deleteRecursively(tempDir);
        if (!tempDir.mkdirs()) fail("Cannot create temporary directory " + tempDir);

        System.out.println("Downloading " + url);
        download(url, part, timeout);
        if (!expectedSha.isEmpty()) {
            String actual = sha256(part);
            if (!actual.equalsIgnoreCase(expectedSha)) {
                deleteRecursively(part);
                deleteRecursively(tempDir);
                fail("Gradle distribution SHA-256 mismatch. Expected " + expectedSha + " but got " + actual);
            }
        }
        Files.move(part.toPath(), zip.toPath(), StandardCopyOption.REPLACE_EXISTING);
        unzip(zip, tempDir);
        deleteRecursively(zip);
        deleteRecursively(installRoot);
        try {
            Files.move(tempDir.toPath(), installRoot.toPath(), StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException atomicNotSupported) {
            Files.move(tempDir.toPath(), installRoot.toPath(), StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private static void download(String value, File destination, int timeout) throws IOException {
        URL current = new URL(value);
        for (int redirect = 0; redirect < 10; redirect++) {
            HttpURLConnection connection = (HttpURLConnection) current.openConnection();
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(timeout);
            connection.setReadTimeout(Math.max(timeout, 30_000));
            connection.setRequestProperty("User-Agent", "WebArchiveSaver-Gradle-Bootstrap/1.0");
            int code = connection.getResponseCode();
            if (code >= 300 && code < 400) {
                String location = connection.getHeaderField("Location");
                connection.disconnect();
                if (location == null) throw new IOException("Redirect without Location from " + current);
                current = new URL(current, location);
                continue;
            }
            if (code < 200 || code >= 300) {
                connection.disconnect();
                throw new IOException("HTTP " + code + " downloading " + current);
            }
            long length = connection.getContentLengthLong();
            try (InputStream in = new BufferedInputStream(connection.getInputStream());
                 OutputStream out = new BufferedOutputStream(new FileOutputStream(destination))) {
                byte[] buffer = new byte[BUFFER];
                long copied = 0;
                int n;
                while ((n = in.read(buffer)) != -1) {
                    out.write(buffer, 0, n);
                    copied += n;
                    if (length > 0 && copied % (10L * 1024 * 1024) < n) {
                        System.out.printf(Locale.ROOT, "Downloaded %.1f / %.1f MB%n", copied / 1048576.0, length / 1048576.0);
                    }
                }
            } finally {
                connection.disconnect();
            }
            return;
        }
        throw new IOException("Too many redirects downloading " + value);
    }

    private static void unzip(File zipFile, File destination) throws IOException {
        Path root = destination.toPath().toAbsolutePath().normalize();
        try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(new FileInputStream(zipFile)))) {
            ZipEntry entry;
            byte[] buffer = new byte[BUFFER];
            while ((entry = zip.getNextEntry()) != null) {
                Path target = root.resolve(entry.getName()).normalize();
                if (!target.startsWith(root)) throw new IOException("Unsafe ZIP entry: " + entry.getName());
                if (entry.isDirectory()) {
                    Files.createDirectories(target);
                } else {
                    Files.createDirectories(target.getParent());
                    try (OutputStream out = new BufferedOutputStream(new FileOutputStream(target.toFile()))) {
                        int n;
                        while ((n = zip.read(buffer)) != -1) out.write(buffer, 0, n);
                    }
                }
                zip.closeEntry();
            }
        }
    }

    private static File findGradleExecutable(File root) {
        if (!root.isDirectory()) return null;
        File[] children = root.listFiles();
        if (children == null) return null;
        String executableName = isWindows() ? "gradle.bat" : "gradle";
        for (File child : children) {
            File candidate = new File(new File(child, "bin"), executableName);
            if (candidate.isFile()) return candidate;
        }
        File direct = new File(new File(root, "bin"), executableName);
        return direct.isFile() ? direct : null;
    }

    private static void runGradle(File executable, String[] args) throws IOException, InterruptedException {
        List<String> command = new ArrayList<>();
        if (isWindows()) {
            command.add("cmd.exe");
            command.add("/d");
            command.add("/c");
        }
        command.add(executable.getAbsolutePath());
        for (String arg : args) command.add(arg);
        Process process = new ProcessBuilder(command)
                .directory(new File(System.getProperty("user.dir")))
                .inheritIO()
                .start();
        int code = process.waitFor();
        if (code != 0) System.exit(code);
    }

    private static String required(Properties properties, String key) {
        String value = properties.getProperty(key);
        if (value == null || value.isBlank()) fail("Missing wrapper property: " + key);
        return value.trim();
    }

    private static int parseInt(String value, int fallback) {
        try { return value == null ? fallback : Integer.parseInt(value.trim()); }
        catch (NumberFormatException ignored) { return fallback; }
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }

    private static String sha256(String value) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        return hex(digest.digest(value.getBytes(StandardCharsets.UTF_8)));
    }

    private static String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new BufferedInputStream(new FileInputStream(file))) {
            byte[] buffer = new byte[BUFFER];
            int n;
            while ((n = in.read(buffer)) != -1) digest.update(buffer, 0, n);
        }
        return hex(digest.digest());
    }

    private static String hex(byte[] bytes) {
        StringBuilder out = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) out.append(String.format(Locale.ROOT, "%02x", b));
        return out.toString();
    }

    private static void deleteRecursively(File file) throws IOException {
        if (!file.exists()) return;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteRecursively(child);
        }
        if (!file.delete() && file.exists()) throw new IOException("Cannot delete " + file);
    }

    private static void fail(String message) {
        System.err.println("ERROR: " + message);
        System.exit(1);
        throw new IllegalStateException(message);
    }
}
