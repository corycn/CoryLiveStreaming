# Third-party notices

This project uses jsoup, the Java HTML parser:

- Project: https://jsoup.org/
- Dependency: `org.jsoup:jsoup:1.22.2`
- License: MIT License

Android and Android Studio are trademarks of Google LLC.
