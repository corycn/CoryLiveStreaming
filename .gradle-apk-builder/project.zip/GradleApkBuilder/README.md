# 安卓工程编译器 1.3.0

本版修复“连接 AndroidIDE 清单后仍提示无法安装”的问题：

- 自动解析 AndroidIDEOfficial/androidide-tools 的 manifest.json
- 按设备 ABI 选择最新版 Build Tools 与 Platform Tools
- 自动下载 android-sdk、cmdline-tools、build-tools、platform-tools、JDK 11（清单存在时）
- 使用 Apache Commons Compress + XZ 解压 `.tar.xz`
- 安全路径检查、重定向处理、分阶段安装与失败回滚
- SDK 组件和完整 PRoot 运行时分开显示状态

重要限制：AndroidIDE 清单不提供完整 PRoot/rootfs。SDK 组件可以全自动安装，但本地 Gradle 按钮只有在完整 PRoot 运行时 ZIP 已导入时才启用。云端 GitHub Actions 构建不受影响。


## v1.4.0
- SDK 组件安装完成后直接启用 Android 原生本地构建，不再强制要求 PRoot/rootfs。
- 新增 Java、Android SDK、aapt2 环境自检。
- 修复 tar.xz 符号链接恢复和可执行权限。

## v1.5.0 可迁移工具链程序包

SDK 工具链操作新增：安装/更新环境组件、导入工具链程序包、导出全部组件程序包。

导出的 `.gaptoolchain.zip` 包含：

- `toolchain-package.properties`：格式、版本、ABI、创建时间与组件范围
- `checksums.sha256`：逐文件 SHA-256 完整性清单
- `components/`：已安装的 JDK、Android SDK、Build Tools、Platform Tools、Command-line Tools 等
- `runtime/`：可选 PRoot、rootfs、Gradle 与 Linux 运行环境

导入流程会先安全解压和校验所有文件，再原子替换本地环境、恢复可执行权限并运行 Java/SDK/aapt2 自检；失败时自动恢复导入前环境。旧版完整 PRoot ZIP 继续兼容。
