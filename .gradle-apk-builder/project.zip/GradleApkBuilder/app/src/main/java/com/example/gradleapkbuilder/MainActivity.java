package com.example.gradleapkbuilder;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import java.io.*;

public class MainActivity extends Activity {
    private static final int PICK_PROJECT=10, EXPORT_APK=11, IMPORT_RUNTIME=12, EXPORT_RUNTIME=13;
    private TextView projectText,statusText,runtimeText;
    private EditText ownerInput,repoInput,branchInput,tokenInput,taskInput;
    private Button cloudButton,localButton,exportButton;
    private File projectZip,builtApk;
    private RuntimeBundleManager runtime;
    private LocalBuildEngine activeLocalBuild;

    @Override public void onCreate(Bundle state){super.onCreate(state);runtime=new RuntimeBundleManager(this);setContentView(buildUi());refreshRuntime();}

    private View buildUi(){
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setBackgroundColor(Color.rgb(245,247,252));
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(18),0,dp(8),0);bar.setBackgroundColor(Color.rgb(51,92,255));
        TextView title=new TextView(this);title.setText("安卓工程编译器");title.setTextSize(20);title.setTextColor(Color.WHITE);bar.addView(title,new LinearLayout.LayoutParams(0,-1,1));
        Button menu=new Button(this);menu.setText("⋮");menu.setTextSize(24);menu.setTextColor(Color.WHITE);menu.setBackgroundColor(Color.TRANSPARENT);menu.setOnClickListener(v->showTopMenu(menu));bar.addView(menu,new LinearLayout.LayoutParams(dp(56),-1));page.addView(bar,new LinearLayout.LayoutParams(-1,dp(58)));
        ScrollView scroll=new ScrollView(this);LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(16),dp(14),dp(16),dp(30));scroll.addView(body);page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        body.addView(section("1. 导入 Android Studio / Gradle 工程"));
        Button pick=button("选择工程 ZIP");pick.setOnClickListener(v->pickProject());body.addView(pick);
        projectText=text("尚未选择工程。请将完整 Android Studio 项目压缩为 ZIP。 ");body.addView(projectText);

        body.addView(section("2. 手机本地构建"));
        runtimeText=text("");runtimeText.setTextIsSelectable(true);body.addView(runtimeText);
        LinearLayout tools=new LinearLayout(this);tools.setOrientation(LinearLayout.HORIZONTAL);
        Button manage=button("SDK / Linux 环境管理");manage.setOnClickListener(v->showRuntimeManager());tools.addView(manage,new LinearLayout.LayoutParams(0,-2,1));
        body.addView(tools);
        taskInput=input("Gradle 任务，默认 assembleDebug",false);taskInput.setText("assembleDebug");body.addView(taskInput);
        localButton=button("在手机本地编译 APK");localButton.setEnabled(false);localButton.setOnClickListener(v->startLocalBuild());body.addView(localButton);
        body.addView(text("本地构建优先直接使用 AndroidIDE 的 Android 原生 JDK、SDK 和 ARM64 aapt2，不再强制要求 Linux rootfs。部分现代工程需要 JDK 17；环境自检会显示实际 Java 版本。"));

        body.addView(section("3. GitHub Actions 云端备用引擎"));
        ownerInput=input("GitHub 用户名或组织名",false);body.addView(ownerInput);
        repoInput=input("仓库名称",false);body.addView(repoInput);
        branchInput=input("分支（默认 main）",false);branchInput.setText("main");body.addView(branchInput);
        tokenInput=input("GitHub Token（不会保存）",true);body.addView(tokenInput);
        cloudButton=button("上传并云端编译 APK");cloudButton.setEnabled(false);cloudButton.setOnClickListener(v->startCloudBuild());body.addView(cloudButton);

        body.addView(section("4. 构建状态与导出"));
        statusText=text("等待导入工程。 ");statusText.setTextIsSelectable(true);body.addView(statusText);
        exportButton=button("导出已编译 APK");exportButton.setEnabled(false);exportButton.setOnClickListener(v->exportApk());body.addView(exportButton);
        return page;
    }

    private void showTopMenu(View anchor){PopupMenu m=new PopupMenu(this,anchor);m.getMenu().add("SDK / Linux 环境管理");m.getMenu().add("关于我们 / 版本信息");m.getMenu().add("使用说明");m.setOnMenuItemClickListener(item->{String t=item.getTitle().toString();if(t.startsWith("SDK"))showRuntimeManager();else if(t.startsWith("关于"))showAbout();else showHelp();return true;});m.show();}

    private void showRuntimeManager(){
        String message=runtime.status()+"\n\n点击“自动下载安装”，应用会下载 AndroidIDE 的 Android 原生 JDK、SDK、Build Tools 和 Platform Tools。安装完成后可直接进行本地构建；PRoot/rootfs 仅作为可选兼容模式。";
        AlertDialog dialog=new AlertDialog.Builder(this)
                .setTitle("SDK / Linux 环境管理")
                .setMessage(message)
                .setPositiveButton("自动下载安装",null)
                .setNeutralButton("导入 / 导出",null)
                .setNegativeButton("关闭",null)
                .create();
        dialog.setOnShowListener(ignored->{
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{dialog.dismiss();downloadRuntimeAutomatically();});
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{dialog.dismiss();showRuntimeActions();});
        });
        dialog.show();
    }

    private void downloadRuntimeAutomatically(){
        setBusy("正在自动搜索兼容工具链…");
        new Thread(()->{
            try{
                runtime.installAutomatically((m,d,t)->runOnUiThread(()->statusText.setText(progress(m,d,t))));
                runOnUiThread(()->{statusText.setText(runtime.isBuildReady()?"✓ 本地 JDK/SDK/Build Tools 已安装并可用于编译":"✓ 组件已下载，但环境自检尚未通过。请进入更多操作运行环境自检。");refreshRuntime();setIdle();});
            }catch(Exception e){runOnUiThread(()->{setIdle();error("自动安装失败",e);statusText.setText("自动安装失败：\n"+safe(e.getMessage()));});}
        }).start();
    }

    private void showRuntimeActions(){String[] items={"安装 / 更新环境组件","运行环境自检","导入工具链程序包","导出全部组件程序包","删除本地工具链","刷新环境状态"};new AlertDialog.Builder(this).setTitle("SDK 工具链操作").setItems(items,(d,w)->{if(w==0)downloadRuntimeAutomatically();else if(w==1)runRuntimeSelfTest();else if(w==2)pickRuntime();else if(w==3)exportRuntime();else if(w==4)confirmRemoveRuntime();else refreshRuntime();}).show();}

    private void runRuntimeSelfTest(){setBusy("正在检查 Java、Android SDK 与 aapt2…");new Thread(()->{try{String result=runtime.selfTest();runOnUiThread(()->{setIdle();refreshRuntime();new AlertDialog.Builder(this).setTitle("环境自检通过").setMessage(result).setPositiveButton("确定",null).show();});}catch(Exception e){runOnUiThread(()->{setIdle();refreshRuntime();error("环境自检失败",e);});}}).start();}

    private void downloadRuntime(String url,String sha){setBusy("准备下载 Linux 工具链…");new Thread(()->{try{runtime.installFromUrl(url,sha,(m,d,t)->runOnUiThread(()->statusText.setText(progress(m,d,t))));runOnUiThread(()->{statusText.setText("✓ Linux 工具链安装完成");refreshRuntime();setIdle();});}catch(Exception e){runOnUiThread(()->{setIdle();error("工具链安装失败",e);});}}).start();}
    private void pickRuntime(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");startActivityForResult(i,IMPORT_RUNTIME);}
    private void exportRuntime(){if(!runtime.isBuildReady()&&!runtime.isSdkComponentsInstalled()){Toast.makeText(this,"尚未安装工具链",Toast.LENGTH_LONG).show();return;}Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");i.putExtra(Intent.EXTRA_TITLE,"GradleApkBuilder-toolchain-all-components.gaptoolchain.zip");startActivityForResult(i,EXPORT_RUNTIME);}
    private void confirmRemoveRuntime(){new AlertDialog.Builder(this).setTitle("删除本地工具链？").setMessage("将删除 Linux rootfs、JDK、Gradle、Android SDK 和缓存。工程与已导出的 APK 不受影响。 ").setPositiveButton("删除",(d,w)->{try{runtime.remove();refreshRuntime();statusText.setText("本地工具链已删除。 ");}catch(Exception e){error("删除失败",e);}}).setNegativeButton("取消",null).show();}
    private void refreshRuntime(){runtimeText.setText(runtime.status());updateBuildButtons();}

    private void pickProject(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/zip","application/octet-stream"});startActivityForResult(i,PICK_PROJECT);}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();if(request==PICK_PROJECT)importProject(uri);else if(request==EXPORT_APK)writeExport(uri);else if(request==IMPORT_RUNTIME)importRuntime(uri);else if(request==EXPORT_RUNTIME)writeRuntimeExport(uri);}

    private void importProject(Uri uri){try{String name=displayName(uri);projectZip=new File(getCacheDir(),"imported-project.zip");try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(projectZip)){copy(in,out);}ProjectInspector.Result r=ProjectInspector.inspect(projectZip);projectText.setText("文件："+(name==null?"project.zip":name)+"\n大小："+human(projectZip.length())+"\n\n"+r.summary());statusText.setText(r.valid?"工程检查通过，可选择本地或云端构建。":"工程检查未通过。 ");if(!r.valid)projectZip=null;updateBuildButtons();}catch(Exception e){error("导入失败",e);}}
    private void importRuntime(Uri uri){setBusy("正在导入 SDK 工具链…");new Thread(()->{try(InputStream in=getContentResolver().openInputStream(uri)){runtime.importBundle(in,(m,d,t)->runOnUiThread(()->statusText.setText(progress(m,d,t))));runOnUiThread(()->{setIdle();refreshRuntime();statusText.setText("✓ 工具链程序包已安装，权限已恢复，环境自检通过");});}catch(Exception e){runOnUiThread(()->{setIdle();error("工具链导入失败",e);});}}).start();}
    private void writeRuntimeExport(Uri uri){setBusy("正在导出 SDK 工具链…");new Thread(()->{try(OutputStream out=getContentResolver().openOutputStream(uri)){runtime.exportBundle(out,(m,d,t)->runOnUiThread(()->statusText.setText(m)));runOnUiThread(()->{setIdle();statusText.setText("✓ 已下载的全部环境组件和程序已导出");});}catch(Exception e){runOnUiThread(()->{setIdle();error("工具链导出失败",e);});}}).start();}

    private void startLocalBuild(){if(projectZip==null)return;setBusy("启动手机本地 Gradle 构建…");builtApk=null;activeLocalBuild=new LocalBuildEngine(runtime,line->runOnUiThread(()->statusText.append("\n"+line)));new Thread(()->{try{File apk=activeLocalBuild.build(projectZip,new File(getFilesDir(),"local-builds"),taskInput.getText().toString());builtApk=apk;runOnUiThread(()->{statusText.append("\n✓ 本地构建成功："+apk.getName());setIdle();exportButton.setEnabled(true);});}catch(Exception e){runOnUiThread(()->{setIdle();error("本地构建失败",e);statusText.append("\n构建失败："+safe(e.getMessage()));});}}).start();}
    private void startCloudBuild(){if(projectZip==null)return;String owner=ownerInput.getText().toString().trim(),repo=repoInput.getText().toString().trim(),branch=branchInput.getText().toString().trim(),token=tokenInput.getText().toString().trim();if(owner.isEmpty()||repo.isEmpty()||token.isEmpty()){Toast.makeText(this,"请填写 GitHub 用户名、仓库和令牌",Toast.LENGTH_LONG).show();return;}setBusy("准备云端构建…");builtApk=null;new Thread(()->{try{GitHubBuilder g=new GitHubBuilder(token,owner,repo,branch,s->runOnUiThread(()->statusText.setText(s)));File apk=g.build(projectZip,new File(getFilesDir(),"outputs"));builtApk=apk;runOnUiThread(()->{statusText.setText("✓ 云端构建成功\n"+apk.getName()+"\n"+human(apk.length()));setIdle();exportButton.setEnabled(true);});}catch(Exception e){runOnUiThread(()->{setIdle();error("云端构建失败",e);statusText.setText("构建失败：\n"+safe(e.getMessage()));});}}).start();}

    private void exportApk(){if(builtApk==null||!builtApk.exists())return;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/vnd.android.package-archive");i.putExtra(Intent.EXTRA_TITLE,builtApk.getName());startActivityForResult(i,EXPORT_APK);}
    private void writeExport(Uri uri){try(InputStream in=new FileInputStream(builtApk);OutputStream out=getContentResolver().openOutputStream(uri)){copy(in,out);Toast.makeText(this,"APK 已导出",Toast.LENGTH_LONG).show();}catch(Exception e){error("导出失败",e);}}

    private void showAbout(){new AlertDialog.Builder(this).setTitle("关于我们 / 版本信息").setMessage("产品：安卓工程编译器\n版本：1.5.0\n版本代码：10500\n\n本地引擎：ARM64 PRoot Linux 用户态环境\n备用引擎：GitHub Actions\n\n用于导入 Android Studio/Gradle 工程、管理 SDK 工具链、编译并导出 APK。\n\n本应用与任何 WiFi 骑行应用无关。 ").setPositiveButton("确定",null).show();}
    private void showHelp(){new AlertDialog.Builder(this).setTitle("使用说明").setMessage("本地编译：\n1. 在 SDK 管理器点击“自动下载安装”。应用会自动查询 AndroidIDE 工具清单，下载并解压 Android SDK、Build Tools、Platform Tools、Command-line Tools 和可用 JDK 组件。\n2. 如自动目录不可用，也可通过导入功能安装受信任的工具链 ZIP。\n2. 导入 Android Studio 工程 ZIP。\n3. 选择 Gradle 任务并开始构建。\n4. 构建成功后导出 APK。\n\n新版可迁移工具链包会包含：\ntoolchain-package.properties\nchecksums.sha256\ncomponents/（JDK、SDK、Build Tools 等）\nruntime/（可选 PRoot/rootfs）\n\n导入后会自动校验、安装、恢复执行权限并运行环境自检。旧版完整 PRoot ZIP 仍兼容\n\n完整工具链通常占用 2–6 GB。建议接通电源并保留足够空间。 ").setPositiveButton("知道了",null).show();}

    private void setBusy(String msg){statusText.setText(msg);localButton.setEnabled(false);cloudButton.setEnabled(false);exportButton.setEnabled(false);}
    private void setIdle(){updateBuildButtons();exportButton.setEnabled(builtApk!=null&&builtApk.exists());}
    private void updateBuildButtons(){boolean has=projectZip!=null&&projectZip.exists();if(localButton!=null)localButton.setEnabled(has&&runtime.isBuildReady());if(cloudButton!=null)cloudButton.setEnabled(has);}
    private static String progress(String m,long d,long t){if(t>0)return m+"\n"+human(d)+" / "+human(t)+"（"+(d*100/Math.max(1,t))+"%）";return m+"\n"+human(d);}
    private void error(String title,Exception e){new AlertDialog.Builder(this).setTitle(title).setMessage(safe(e.getMessage())).setPositiveButton("确定",null).show();}
    private static String safe(String s){if(s==null)return"未知错误";return s.replaceAll("gh[pousr]_[A-Za-z0-9_]+","[令牌已隐藏]");}
    private String displayName(Uri uri){try(android.database.Cursor c=getContentResolver().query(uri,null,null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}catch(Exception ignored){}return null;}
    private static void copy(InputStream in,OutputStream out)throws IOException{if(in==null||out==null)throw new IOException("无法打开文件");byte[]b=new byte[65536];int n;while((n=in.read(b))>=0)out.write(b,0,n);}
    private TextView section(String s){TextView v=text(s);v.setTextSize(19);v.setTextColor(Color.rgb(25,35,65));v.setPadding(0,dp(18),0,dp(8));return v;}
    private TextView text(String s){TextView v=new TextView(this);v.setText(s);v.setTextSize(15);v.setTextColor(Color.rgb(55,65,85));v.setPadding(dp(2),dp(8),dp(2),dp(12));return v;}
    private EditText input(String hint,boolean password){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setTextSize(15);e.setPadding(dp(12),dp(10),dp(12),dp(10));if(password)e.setInputType(0x81);return e;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(16);return b;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private static String human(long n){if(n<1024)return n+" B";if(n<1048576)return String.format(java.util.Locale.US,"%.1f KB",n/1024.0);if(n<1073741824)return String.format(java.util.Locale.US,"%.1f MB",n/1048576.0);return String.format(java.util.Locale.US,"%.2f GB",n/1073741824.0);}
}
