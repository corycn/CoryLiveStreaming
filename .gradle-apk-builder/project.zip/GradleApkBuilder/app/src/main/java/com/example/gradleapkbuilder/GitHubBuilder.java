package com.example.gradleapkbuilder;

import android.util.Base64;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

final class GitHubBuilder {
    interface Listener { void onStatus(String text); }
    static final String API = "https://api.github.com";

    private final String token, owner, repo, branch;
    private final Listener listener;

    GitHubBuilder(String token, String owner, String repo, String branch, Listener listener) {
        this.token = token.trim(); this.owner = owner.trim(); this.repo = repo.trim();
        this.branch = branch.trim().isEmpty() ? "main" : branch.trim(); this.listener = listener;
    }

    File build(File projectZip, File outputDir) throws Exception {
        status("正在检查 GitHub 仓库…");
        request("GET", "/repos/" + enc(owner) + "/" + enc(repo), null, false);

        status("正在上传工程 ZIP…");
        putContent(".gradle-apk-builder/project.zip", readBytes(projectZip), "Upload Android project for build");
        status("正在写入安全构建工作流…");
        putContent(".github/workflows/gradle-apk-builder.yml", workflow().getBytes(StandardCharsets.UTF_8), "Configure Android APK build");

        status("正在触发 GitHub Actions…");
        JSONObject dispatch = new JSONObject().put("ref", branch);
        request("POST", "/repos/" + enc(owner) + "/" + enc(repo) + "/actions/workflows/gradle-apk-builder.yml/dispatches", dispatch.toString().getBytes(StandardCharsets.UTF_8), false);

        long runId = waitForRun();
        waitForCompletion(runId);
        status("构建成功，正在下载 APK 产物…");
        JSONObject arts = json(request("GET", "/repos/" + enc(owner) + "/" + enc(repo) + "/actions/runs/" + runId + "/artifacts", null, false));
        JSONArray arr = arts.getJSONArray("artifacts");
        if (arr.length() == 0) throw new IOException("构建完成，但没有找到 APK artifact");
        long artifactId = arr.getJSONObject(0).getLong("id");
        byte[] artifactZip = request("GET", "/repos/" + enc(owner) + "/" + enc(repo) + "/actions/artifacts/" + artifactId + "/zip", null, true);
        if (!outputDir.exists() && !outputDir.mkdirs()) throw new IOException("无法创建输出目录");
        File zip = new File(outputDir, "github-apk-artifact.zip");
        write(zip, artifactZip);
        File apk = extractFirstApk(zip, outputDir);
        status("APK 已下载：" + apk.getName());
        return apk;
    }

    private void putContent(String path, byte[] content, String message) throws Exception {
        String endpoint = "/repos/" + enc(owner) + "/" + enc(repo) + "/contents/" + path;
        String sha = null;
        try { sha = json(request("GET", endpoint + "?ref=" + enc(branch), null, false)).optString("sha", null); }
        catch (HttpError e) { if (e.code != 404) throw e; }
        JSONObject body = new JSONObject()
                .put("message", message)
                .put("branch", branch)
                .put("content", Base64.encodeToString(content, Base64.NO_WRAP));
        if (sha != null && !sha.isEmpty()) body.put("sha", sha);
        request("PUT", endpoint, body.toString().getBytes(StandardCharsets.UTF_8), false);
    }

    private long waitForRun() throws Exception {
        for (int i = 0; i < 30; i++) {
            Thread.sleep(3000);
            JSONObject o = json(request("GET", "/repos/" + enc(owner) + "/" + enc(repo) + "/actions/workflows/gradle-apk-builder.yml/runs?branch=" + enc(branch) + "&event=workflow_dispatch&per_page=5", null, false));
            JSONArray runs = o.getJSONArray("workflow_runs");
            if (runs.length() > 0) return runs.getJSONObject(0).getLong("id");
            status("等待云端任务出现… " + (i + 1));
        }
        throw new IOException("未找到刚触发的 GitHub Actions 任务");
    }

    private void waitForCompletion(long runId) throws Exception {
        for (int i = 0; i < 120; i++) {
            JSONObject run = json(request("GET", "/repos/" + enc(owner) + "/" + enc(repo) + "/actions/runs/" + runId, null, false));
            String state = run.optString("status");
            String conclusion = run.optString("conclusion");
            status("云端构建状态：" + state + (conclusion.isEmpty() ? "" : " / " + conclusion));
            if ("completed".equals(state)) {
                if (!"success".equals(conclusion)) throw new IOException("GitHub Actions 构建失败：" + conclusion + "\n请在仓库 Actions 页面查看日志。");
                return;
            }
            Thread.sleep(5000);
        }
        throw new IOException("等待构建超时");
    }

    private byte[] request(String method, String path, byte[] body, boolean binary) throws Exception {
        URL url = new URL(path.startsWith("http") ? path : API + path);
        for (int redirects = 0; redirects < 6; redirects++) {
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            c.setInstanceFollowRedirects(false); c.setConnectTimeout(20000); c.setReadTimeout(120000);
            c.setRequestMethod(method); c.setRequestProperty("Accept", binary ? "application/octet-stream" : "application/vnd.github+json");
            c.setRequestProperty("Authorization", "Bearer " + token); c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
            c.setRequestProperty("User-Agent", "GradleApkBuilder-Android");
            if (body != null) { c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json; charset=utf-8"); try (OutputStream out = c.getOutputStream()) { out.write(body); } }
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) { String loc = c.getHeaderField("Location"); c.disconnect(); if (loc == null) throw new IOException("重定向缺少地址"); url = new URL(loc); method = "GET"; body = null; continue; }
            InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            byte[] data = in == null ? new byte[0] : readAll(in);
            if (code < 200 || code >= 300) throw new HttpError(code, new String(data, StandardCharsets.UTF_8));
            return data;
        }
        throw new IOException("重定向次数过多");
    }

    private static JSONObject json(byte[] bytes) throws JSONException { return new JSONObject(new String(bytes, StandardCharsets.UTF_8)); }
    private static String enc(String s) throws UnsupportedEncodingException { return URLEncoder.encode(s, "UTF-8").replace("+", "%20"); }
    private void status(String s) { if (listener != null) listener.onStatus(s); }
    private static byte[] readBytes(File f) throws IOException { try (InputStream in = new FileInputStream(f)) { return readAll(in); } }
    private static byte[] readAll(InputStream in) throws IOException { ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] b = new byte[32768]; int n; while ((n = in.read(b)) >= 0) out.write(b, 0, n); return out.toByteArray(); }
    private static void write(File f, byte[] b) throws IOException { try (OutputStream out = new FileOutputStream(f)) { out.write(b); } }

    private static File extractFirstApk(File zip, File dir) throws IOException {
        try (java.util.zip.ZipInputStream in = new java.util.zip.ZipInputStream(new FileInputStream(zip))) {
            java.util.zip.ZipEntry e;
            while ((e = in.getNextEntry()) != null) {
                String name = new File(e.getName()).getName();
                if (!e.isDirectory() && name.toLowerCase(Locale.US).endsWith(".apk")) {
                    File out = new File(dir, name);
                    try (OutputStream os = new FileOutputStream(out)) { byte[] b = new byte[32768]; int n; while ((n = in.read(b)) >= 0) os.write(b, 0, n); }
                    return out;
                }
            }
        }
        throw new IOException("Artifact 中未找到 APK");
    }

    private static String workflow() {
        return "name: Gradle APK Builder\n" +
                "on:\n" +
                "  workflow_dispatch:\n" +
                "permissions:\n" +
                "  contents: read\n" +
                "jobs:\n" +
                "  build:\n" +
                "    runs-on: ubuntu-latest\n" +
                "    timeout-minutes: 45\n" +
                "    steps:\n" +
                "      - uses: actions/checkout@v4\n" +
                "      - uses: actions/setup-java@v4\n" +
                "        with:\n" +
                "          distribution: temurin\n" +
                "          java-version: '17'\n" +
                "      - name: Extract imported project\n" +
                "        run: |\n" +
                "          rm -rf imported-project\n" +
                "          mkdir imported-project\n" +
                "          unzip -q .gradle-apk-builder/project.zip -d imported-project\n" +
                "          ROOT=$(find imported-project -maxdepth 3 \\( -name settings.gradle -o -name settings.gradle.kts \\) -printf '%h\\n' | head -1)\n" +
                "          test -n \"$ROOT\"\n" +
                "          echo \"PROJECT_ROOT=$ROOT\" >> $GITHUB_ENV\n" +
                "      - uses: gradle/actions/setup-gradle@v4\n" +
                "      - name: Build debug APK\n" +
                "        run: |\n" +
                "          cd \"$PROJECT_ROOT\"\n" +
                "          if [ -f gradlew ]; then chmod +x gradlew; ./gradlew --no-daemon assembleDebug; else gradle --no-daemon assembleDebug; fi\n" +
                "      - name: Collect APK files\n" +
                "        run: |\n" +
                "          mkdir -p collected-apks\n" +
                "          find \"$PROJECT_ROOT\" -type f -path '*/build/outputs/apk/*.apk' -exec cp {} collected-apks/ \\;\n" +
                "          test -n \"$(find collected-apks -name '*.apk' -print -quit)\"\n" +
                "      - uses: actions/upload-artifact@v4\n" +
                "        with:\n" +
                "          name: compiled-apks\n" +
                "          path: collected-apks/*.apk\n" +
                "          if-no-files-found: error\n";
    }

    static final class HttpError extends IOException { final int code; HttpError(int code, String body) { super("GitHub API " + code + ": " + body); this.code = code; } }
}
