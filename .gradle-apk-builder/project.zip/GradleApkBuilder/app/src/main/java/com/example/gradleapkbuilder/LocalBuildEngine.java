package com.example.gradleapkbuilder;

import java.io.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.zip.*;

/** Runs Gradle directly with Android-native AndroidIDE tools, with PRoot as a fallback. */
final class LocalBuildEngine {
    interface Listener { void onLine(String line); }
    private final RuntimeBundleManager runtime;
    private final Listener listener;
    private volatile Process process;

    LocalBuildEngine(RuntimeBundleManager runtime, Listener listener) { this.runtime=runtime; this.listener=listener; }

    File build(File projectZip, File workBase, String task) throws Exception {
        if (!runtime.isBuildReady()) throw new IOException("本地构建环境尚未通过自检，请打开 SDK 管理器重新安装或运行环境自检");
        File work = new File(workBase, "local-build-" + System.currentTimeMillis());
        File project = new File(work, "project"), out = new File(work, "outputs");
        mkdirs(project); mkdirs(out); unzip(projectZip, project);
        File projectRoot = findProjectRoot(project);
        if(runtime.isDirectBuildReady()) runDirect(projectRoot,task);
        else runProot(projectRoot,out,task);
        File apk=findFirstApk(projectRoot); if(apk==null)throw new IOException("构建完成但未找到 APK");
        File result=new File(out,apk.getName()); copy(apk,result); return result;
    }

    private void runDirect(File projectRoot,String task)throws Exception{
        File java=runtime.getJavaExecutable(),sdk=runtime.getAndroidSdkDir(),aapt2=runtime.getAapt2Executable();
        if(java==null||sdk==null||aapt2==null)throw new IOException("没有找到本地 Java、Android SDK 或 ARM64 aapt2");
        java.setExecutable(true,true);
        File jdk=java.getParentFile().getParentFile();
        String cleanTask=cleanTask(task);
        File gradlew=new File(projectRoot,"gradlew");
        String aaptOverride=" -Pandroid.aapt2FromMavenOverride=\""+aapt2.getAbsolutePath()+"\" ";
        String command=gradlew.isFile()?"sh ./gradlew --no-daemon --stacktrace"+aaptOverride+cleanTask:"gradle --no-daemon --stacktrace"+aaptOverride+cleanTask;
        ProcessBuilder pb=new ProcessBuilder("/system/bin/sh","-c",command);
        pb.directory(projectRoot);pb.redirectErrorStream(true);
        Map<String,String> env=pb.environment();
        env.put("HOME",new File(projectRoot,".home").getAbsolutePath());
        env.put("JAVA_HOME",jdk.getAbsolutePath());
        env.put("ANDROID_HOME",sdk.getAbsolutePath());env.put("ANDROID_SDK_ROOT",sdk.getAbsolutePath());
        env.put("GRADLE_USER_HOME",new File(projectRoot,".gradle-user-home").getAbsolutePath());
        env.put("PATH",java.getParentFile().getAbsolutePath()+":"+System.getenv("PATH"));
        notifyLine("使用 Android 原生工具链构建（无需 PRoot/rootfs）");
        execute(pb);
    }

    private void runProot(File projectRoot,File out,String task)throws Exception{
        File proot=runtime.getProotFile(),rootfs=runtime.getRootfsDir();proot.setExecutable(true,true);
        List<String> cmd=new ArrayList<>();Collections.addAll(cmd,proot.getAbsolutePath(),"--link2symlink","-0","-r",rootfs.getAbsolutePath(),"-b","/dev","-b","/proc","-b","/sys","-b",projectRoot.getCanonicalPath()+":/workspace","-b",out.getCanonicalPath()+":/outputs","-w","/workspace","/usr/bin/env","-i","HOME=/root","PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin","ANDROID_HOME=/opt/android-sdk","ANDROID_SDK_ROOT=/opt/android-sdk","GRADLE_USER_HOME=/root/.gradle","/bin/sh","-lc",buildScript(task));
        notifyLine("使用 PRoot Linux 兼容环境构建");execute(new ProcessBuilder(cmd).redirectErrorStream(true));
    }

    private void execute(ProcessBuilder pb)throws Exception{
        process=pb.start();try(BufferedReader r=new BufferedReader(new InputStreamReader(process.getInputStream()))){String line;while((line=r.readLine())!=null)notifyLine(line);}
        if(!process.waitFor(90,TimeUnit.MINUTES)){process.destroyForcibly();throw new IOException("本地构建超时");}
        if(process.exitValue()!=0)throw new IOException("Gradle 构建失败，退出代码 "+process.exitValue());
    }
    private void notifyLine(String s){if(listener!=null)listener.onLine(s);}
    void cancel(){Process p=process;if(p!=null)p.destroyForcibly();}
    private static String cleanTask(String task){return(task==null||task.trim().isEmpty())?"assembleDebug":task.trim().replaceAll("[^A-Za-z0-9:_-]","");}
    private static String buildScript(String task){String t=cleanTask(task);return "set -e; chmod +x ./gradlew 2>/dev/null || true; if [ -x ./gradlew ]; then ./gradlew --no-daemon --stacktrace "+t+"; else gradle --no-daemon --stacktrace "+t+"; fi";}
    private static File findProjectRoot(File dir){if(new File(dir,"settings.gradle").isFile()||new File(dir,"settings.gradle.kts").isFile())return dir;File[]a=dir.listFiles(File::isDirectory);if(a!=null&&a.length==1)return findProjectRoot(a[0]);return dir;}
    private static File findFirstApk(File f){if(f.isFile()&&f.getName().endsWith(".apk")&&f.getPath().contains("build"+File.separator+"outputs"+File.separator+"apk"))return f;if(f.isDirectory()){File[]a=f.listFiles();if(a!=null)for(File c:a){File r=findFirstApk(c);if(r!=null)return r;}}return null;}
    private static void unzip(File zip,File dst)throws IOException{try(ZipInputStream in=new ZipInputStream(new FileInputStream(zip))){ZipEntry e;while((e=in.getNextEntry())!=null){String n=e.getName().replace('\\','/');if(n.startsWith("/")||n.contains("../"))throw new IOException("工程 ZIP 路径不安全");File x=new File(dst,n);if(e.isDirectory())mkdirs(x);else{mkdirs(x.getParentFile());try(OutputStream o=new FileOutputStream(x)){byte[]b=new byte[65536];int k;while((k=in.read(b))>=0)o.write(b,0,k);}}}}}
    private static void copy(File a,File b)throws IOException{mkdirs(b.getParentFile());try(InputStream i=new FileInputStream(a);OutputStream o=new FileOutputStream(b)){byte[]x=new byte[65536];int n;while((n=i.read(x))>=0)o.write(x,0,n);}}
    private static void mkdirs(File f)throws IOException{if(f!=null&&!f.exists()&&!f.mkdirs())throw new IOException("无法创建目录："+f);}
}
