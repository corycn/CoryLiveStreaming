package com.corykui.wifispeed.records;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.os.SystemClock;

import java.util.ArrayList;
import java.util.List;

public class SpatialView extends View {
    public interface ViewportListener { void onViewportChanged(float scale, float panX, float panY); }
    private ViewportListener viewportListener;
    public static class TrailPoint {
        public final float x;
        public final float y;
        public final long timeMs;
        public final float headingDegrees;
        public final float speedKmh;
        public final float distanceMeters;
        public final String wifiSnapshotJson;
        public final String mapProvider;
        public final double mapCenterLatitude;
        public final double mapCenterLongitude;
        public final int mapZoom;
        public final float mapScale;
        public final float mapPanX;
        public final float mapPanY;
        public final String mapTileKeysJson;
        public TrailPoint(float x, float y, long timeMs) {
            this(x, y, timeMs, 0f, 0f, 0f);
        }
        public TrailPoint(float x, float y, long timeMs, float headingDegrees, float speedKmh, float distanceMeters) {
            this(x, y, timeMs, headingDegrees, speedKmh, distanceMeters,
                    "[]", "none", Double.NaN, Double.NaN, 18, 1f, 0f, 0f, "[]");
        }
        public TrailPoint(float x, float y, long timeMs, float headingDegrees, float speedKmh, float distanceMeters,
                          String wifiSnapshotJson, String mapProvider, double mapCenterLatitude,
                          double mapCenterLongitude, int mapZoom, float mapScale, float mapPanX,
                          float mapPanY, String mapTileKeysJson) {
            this.x = x; this.y = y; this.timeMs = timeMs;
            this.headingDegrees = headingDegrees; this.speedKmh = speedKmh; this.distanceMeters = distanceMeters;
            this.wifiSnapshotJson = wifiSnapshotJson == null ? "[]" : wifiSnapshotJson;
            this.mapProvider = mapProvider == null ? "none" : mapProvider;
            this.mapCenterLatitude = mapCenterLatitude; this.mapCenterLongitude = mapCenterLongitude;
            this.mapZoom = mapZoom; this.mapScale = mapScale; this.mapPanX = mapPanX; this.mapPanY = mapPanY;
            this.mapTileKeysJson = mapTileKeysJson == null ? "[]" : mapTileKeysJson;
        }
    }

    private final List<TrailPoint> trail = new ArrayList<>();
    private float heading = 0f;
    private float activityAngle = 0f;
    private float activityScore = 0f;
    private int replayVisibleCount = -1;
    private final ScaleGestureDetector scaleDetector;
    private float userScale = 1f;
    private float panX = 0f;
    private float panY = 0f;
    private float trailMinX = 0f, trailMaxX = 0f, trailMinY = 0f, trailMaxY = 0f;
    private float lastTouchX = 0f;
    private float lastTouchY = 0f;
    private boolean mapBackgroundVisible = false;
    private double mapLatitude = 0.0;
    private int mapZoom = 19;
    private double anchorLatitude = Double.NaN;
    private double anchorLongitude = Double.NaN;
    private boolean rideMetricsOverride = false;
    private float rideCurrentKmh = 0f;
    private float rideAverageKmh = 0f;
    private float rideMaxKmh = 0f;
    private float rideDistanceMeters = 0f;
    private long rideMovingTimeMs = 0L;
    private long rideActiveTimeMs = 0L;
    private boolean statsPanelHidden = false;
    private float touchDownX = 0f;
    private float touchDownY = 0f;
    private boolean touchMoved = false;
    private boolean gestureInProgress = false;
    private long lastViewportDispatchMs = 0L;
    private boolean viewportDispatchPending = false;

    public void setRideMetrics(float currentKmh, float averageKmh, float maxKmh,
                               float distanceMeters, long movingTimeMs, long activeTimeMs) {
        rideMetricsOverride = true;
        rideCurrentKmh = Math.max(0f, currentKmh);
        rideAverageKmh = Math.max(0f, averageKmh);
        rideMaxKmh = Math.max(0f, maxKmh);
        rideDistanceMeters = Math.max(0f, distanceMeters);
        rideMovingTimeMs = Math.max(0L, movingTimeMs);
        rideActiveTimeMs = Math.max(0L, activeTimeMs);
        invalidate();
    }

    public SpatialView(Context c) {
        super(c);
        setFocusable(true);
        scaleDetector = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScaleBegin(ScaleGestureDetector detector) {
                gestureInProgress = true;
                return true;
            }
            @Override public boolean onScale(ScaleGestureDetector detector) {
                userScale *= detector.getScaleFactor();
                userScale = Math.max(0.35f, Math.min(userScale, 8f));
                requestGestureFrame(false);
                return true;
            }
            @Override public void onScaleEnd(ScaleGestureDetector detector) {
                gestureInProgress = false;
                requestGestureFrame(true);
            }
        });
        reset();
    }

    public synchronized void reset() {
        trail.clear();
        trail.add(new TrailPoint(0, 0, System.currentTimeMillis()));
        recomputeTrailBoundsLocked();
        replayVisibleCount = -1;
        invalidate();
    }

    public synchronized void addStep(float meters, float headingRad) {
        TrailPoint last = trail.get(trail.size() - 1);
        TrailPoint added = new TrailPoint(
                last.x + (float) Math.sin(headingRad) * meters,
                last.y - (float) Math.cos(headingRad) * meters,
                System.currentTimeMillis(), (float)Math.toDegrees(headingRad), 0f, last.distanceMeters + meters);
        trail.add(added);
        trailMinX = Math.min(trailMinX, added.x); trailMaxX = Math.max(trailMaxX, added.x);
        trailMinY = Math.min(trailMinY, added.y); trailMaxY = Math.max(trailMaxY, added.y);
        heading = headingRad;
        replayVisibleCount = -1;
        invalidate();
    }

    public synchronized void setHeading(float rad) { heading = rad; invalidate(); }
    public synchronized void setActivity(float score, float angle) { activityScore = score; activityAngle = angle; invalidate(); }
    public synchronized int getPointCount() { return trail.size(); }
    public synchronized float getCurrentX() { return trail.get(trail.size() - 1).x; }
    public synchronized float getCurrentY() { return trail.get(trail.size() - 1).y; }
    public synchronized float getHeading() { return heading; }
    public synchronized float getActivityScore() { return activityScore; }
    public synchronized float getActivityAngle() { return activityAngle; }
    public synchronized void setGeoAnchor(double latitude, double longitude) {
        anchorLatitude = latitude;
        anchorLongitude = longitude;
        invalidate();
    }

    public synchronized void clearGeoAnchor() {
        anchorLatitude = Double.NaN;
        anchorLongitude = Double.NaN;
        invalidate();
    }

    public synchronized void setMapBackgroundVisible(boolean visible, double latitude, int zoom) {
        mapBackgroundVisible = visible;
        mapLatitude = latitude;
        mapZoom = zoom;
        invalidate();
    }

    public synchronized void setViewportListener(ViewportListener listener) { this.viewportListener = listener; }

    private void requestGestureFrame(boolean immediate) {
        postInvalidateOnAnimation();
        long now = SystemClock.uptimeMillis();
        long elapsed = now - lastViewportDispatchMs;
        if (immediate || elapsed >= 48L) {
            lastViewportDispatchMs = now;
            viewportDispatchPending = false;
            ViewportListener listener = viewportListener;
            if (listener != null) listener.onViewportChanged(userScale, panX, panY);
            return;
        }
        if (viewportDispatchPending) return;
        viewportDispatchPending = true;
        postDelayed(() -> {
            viewportDispatchPending = false;
            lastViewportDispatchMs = SystemClock.uptimeMillis();
            ViewportListener listener = viewportListener;
            if (listener != null) listener.onViewportChanged(userScale, panX, panY);
            postInvalidateOnAnimation();
        }, Math.max(1L, 48L - elapsed));
    }

    public synchronized void resetViewport() {
        setViewportState(1f, 0f, 0f);
    }

    public synchronized void setViewportState(float scale, float x, float y) {
        userScale = Math.max(0.35f, Math.min(scale, 8f));
        panX = x; panY = y;
        invalidate();
        if (viewportListener != null) viewportListener.onViewportChanged(userScale, panX, panY);
    }

    public synchronized float getViewportScale() { return userScale; }
    public synchronized float getViewportPanX() { return panX; }
    public synchronized float getViewportPanY() { return panY; }

    private void recomputeTrailBoundsLocked() {
        trailMinX = trailMaxX = trailMinY = trailMaxY = 0f;
        for (TrailPoint q : trail) {
            trailMinX = Math.min(trailMinX, q.x); trailMaxX = Math.max(trailMaxX, q.x);
            trailMinY = Math.min(trailMinY, q.y); trailMaxY = Math.max(trailMaxY, q.y);
        }
    }

    public synchronized void centerOnTrailPoint(int index) {
        if (trail.isEmpty() || getWidth() <= 0 || getHeight() <= 0) return;
        int safeIndex = Math.max(0, Math.min(index, trail.size() - 1));
        TrailPoint target = trail.get(safeIndex);
        float w = getWidth();
        float h = getHeight();
        float minX = trailMinX, maxX = trailMaxX, minY = trailMinY, maxY = trailMaxY;
        float baseScale;
        float baseCx;
        float baseCy;
        if (mapBackgroundVisible) {
            double metersPerPixel = 156543.03392 * Math.cos(Math.toRadians(mapLatitude)) / Math.pow(2.0, mapZoom);
            baseScale = (float)(1.0 / Math.max(0.02, metersPerPixel));
            baseCx = w / 2f;
            baseCy = h / 2f;
        } else {
            float range = Math.max(4f, Math.max(maxX - minX, maxY - minY) + 2f);
            baseScale = Math.min(w, h) / range;
            baseCx = w / 2f - (minX + maxX) / 2f * baseScale;
            baseCy = h / 2f - (minY + maxY) / 2f * baseScale;
        }
        panX = -((baseCx - w / 2f) + target.x * baseScale) * userScale;
        panY = -((baseCy - h / 2f) + target.y * baseScale) * userScale;
        invalidate();
        if (viewportListener != null) viewportListener.onViewportChanged(userScale, panX, panY);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        getParent().requestDisallowInterceptTouchEvent(true);
        scaleDetector.onTouchEvent(event);
        if (!scaleDetector.isInProgress()) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastTouchX = event.getX();
                    lastTouchY = event.getY();
                    touchDownX = lastTouchX;
                    touchDownY = lastTouchY;
                    touchMoved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getX() - lastTouchX;
                    float dy = event.getY() - lastTouchY;
                    if (Math.abs(event.getX() - touchDownX) > 12f || Math.abs(event.getY() - touchDownY) > 12f)
                        touchMoved = true;
                    if (touchMoved) {
                        gestureInProgress = true;
                        panX += dx;
                        panY += dy;
                        requestGestureFrame(false);
                    }
                    lastTouchX = event.getX();
                    lastTouchY = event.getY();
                    return true;
                case MotionEvent.ACTION_UP:
                    gestureInProgress = false;
                    requestGestureFrame(true);
                    if (!touchMoved) {
                        RectF actionRect = getStatsActionRect();
                        if (actionRect.contains(event.getX(), event.getY())) {
                            statsPanelHidden = !statsPanelHidden;
                            invalidate();
                            performClick();
                            getParent().requestDisallowInterceptTouchEvent(false);
                            return true;
                        }
                    }
                    performClick();
                    getParent().requestDisallowInterceptTouchEvent(false);
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    gestureInProgress = false;
                    requestGestureFrame(true);
                    getParent().requestDisallowInterceptTouchEvent(false);
                    return true;
            }
        }
        return true;
    }

    private RectF getStatsActionRect() {
        float w = Math.max(1f, getWidth());
        float margin = Math.max(10f, w / 55f);
        float textSize = Math.max(16f, Math.min(23f, w / 45f));
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setTextSize(textSize);
        if (statsPanelHidden) {
            float bw = paint.measureText("速度") + margin * 1.5f;
            float bh = textSize * 1.8f;
            return new RectF(margin, margin, margin + bw, margin + bh);
        }
        String[] lines = buildStatsLines();
        float maxTextWidth = 0f;
        for (String line : lines) maxTextWidth = Math.max(maxTextWidth, paint.measureText(line));
        float hideWidth = paint.measureText("隐藏") + margin;
        float panelWidth = Math.min(w - margin * 2f, Math.max(maxTextWidth + margin * 2f, hideWidth + margin * 2f));
        float lineHeight = Math.max(23f, textSize * 1.38f);
        return new RectF(margin + panelWidth - hideWidth - margin * 0.35f,
                margin + margin * 0.25f,
                margin + panelWidth - margin * 0.25f,
                margin + margin * 0.25f + lineHeight);
    }

    private String[] buildStatsLines() {
        List<TrailPoint> points = trail;
        if (points.isEmpty()) points.add(new TrailPoint(0, 0, 0));
        int count = replayVisibleCount < 0 ? points.size() : Math.max(1, Math.min(replayVisibleCount, points.size()));
        TrailPoint last = points.get(count - 1);
        float visibleMax = rideMetricsOverride ? rideMaxKmh : 0f;
        long elapsedMs = Math.max(0L, last.timeMs - points.get(0).timeMs);
        float visibleAverage = 0f;
        if (!rideMetricsOverride) {
            int stride = Math.max(1, count / 6000);
            for (int i = 0; i < count; i += stride) visibleMax = Math.max(visibleMax, points.get(i).speedKmh);
            visibleMax = Math.max(visibleMax, last.speedKmh);
            visibleAverage = elapsedMs > 0L ? last.distanceMeters / (elapsedMs / 1000f) * 3.6f : 0f;
        }
        float shownCurrent = rideMetricsOverride ? rideCurrentKmh : last.speedKmh;
        float shownAverage = rideMetricsOverride ? rideAverageKmh : visibleAverage;
        float shownMax = rideMetricsOverride ? rideMaxKmh : visibleMax;
        float shownDistance = rideMetricsOverride ? rideDistanceMeters : last.distanceMeters;
        long shownMovingMs = rideMetricsOverride ? rideMovingTimeMs : elapsedMs;
        long shownActiveMs = rideMetricsOverride ? rideActiveTimeMs : elapsedMs;
        long movingSeconds = Math.max(0L, shownMovingMs / 1000L);
        long activeSeconds = Math.max(0L, shownActiveMs / 1000L);
        return new String[]{
                String.format(java.util.Locale.CHINA, "实时速度  %.2f km/h", shownCurrent),
                String.format(java.util.Locale.CHINA, "平均速度  %.2f km/h", shownAverage),
                String.format(java.util.Locale.CHINA, "最高速度  %.2f km/h", shownMax),
                String.format(java.util.Locale.CHINA, "行驶距离  %.2f km", shownDistance / 1000f),
                String.format(java.util.Locale.CHINA, "移动时长  %02d:%02d:%02d",
                        movingSeconds / 3600L, (movingSeconds % 3600L) / 60L, movingSeconds % 60L),
                String.format(java.util.Locale.CHINA, "总时长    %02d:%02d:%02d",
                        activeSeconds / 3600L, (activeSeconds % 3600L) / 60L, activeSeconds % 60L)
        };
    }

    @Override public boolean performClick() {
        super.performClick();
        return true;
    }

    public synchronized List<TrailPoint> getTrailCopy() {
        return new ArrayList<>(trail);
    }


    public synchronized void appendTrailPoint(TrailPoint point) {
        if (point == null) return;
        trail.add(point);
        trailMinX = Math.min(trailMinX, point.x); trailMaxX = Math.max(trailMaxX, point.x);
        trailMinY = Math.min(trailMinY, point.y); trailMaxY = Math.max(trailMaxY, point.y);
        replayVisibleCount = -1;
        invalidate();
    }

    public synchronized void setTrail(List<TrailPoint> points) {
        trail.clear();
        if (points != null && !points.isEmpty()) trail.addAll(points);
        else trail.add(new TrailPoint(0, 0, System.currentTimeMillis()));
        recomputeTrailBoundsLocked();
        replayVisibleCount = -1;
        invalidate();
    }

    public synchronized void setReplayVisibleCount(int count) {
        replayVisibleCount = Math.max(1, Math.min(count, trail.size()));
        invalidate();
    }

    public synchronized void stopReplay() {
        replayVisibleCount = -1;
        invalidate();
    }

    public synchronized Bitmap renderBitmap(int targetLongSidePx) {
        int vw = Math.max(1, getWidth());
        int vh = Math.max(1, getHeight());
        float scale = targetLongSidePx <= 0 ? 1f : targetLongSidePx / (float) Math.max(vw, vh);
        if (scale < 1f) scale = 1f;
        int outW = Math.max(1, Math.round(vw * scale));
        int outH = Math.max(1, Math.round(vh * scale));
        return renderTrailBitmap(new ArrayList<>(trail), heading, activityScore, activityAngle,
                outW, outH, replayVisibleCount < 0 ? trail.size() : replayVisibleCount, anchorLatitude, anchorLongitude);
    }

    public static Bitmap renderTrailBitmap(List<TrailPoint> points, float heading, float activityScore,
                                            float activityAngle, int width, int height, int visibleCount,
                                            double anchorLatitude, double anchorLongitude) {
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawScene(canvas, points, heading, activityScore, activityAngle, width, height, visibleCount,
                1f, 0f, 0f, false, 0.0, 19, anchorLatitude, anchorLongitude, true,
                false, 0f, 0f, 0f, 0f, 0L, 0L, false, 6000);
        return bitmap;
    }

    public static Bitmap renderTrailOverlayBitmap(List<TrailPoint> points, float heading, float activityScore,
                                            float activityAngle, int width, int height, int visibleCount,
                                            double anchorLatitude, double anchorLongitude) {
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawScene(canvas, points, heading, activityScore, activityAngle, width, height, visibleCount,
                1f, 0f, 0f, true, anchorLatitude, 18, anchorLatitude, anchorLongitude, false,
                false, 0f, 0f, 0f, 0f, 0L, 0L, false, 6000);
        return bitmap;
    }

    public static Bitmap renderTrailOverlayAtMapCenter(List<TrailPoint> allPoints, float heading,
                                                        int width, int height, int visibleCount,
                                                        float focusX, float focusY,
                                                        double mapLatitude, int mapZoom) {
        Bitmap bitmap = Bitmap.createBitmap(Math.max(1, width), Math.max(1, height), Bitmap.Config.ARGB_8888);
        if (allPoints == null || allPoints.isEmpty()) return bitmap;
        Canvas c = new Canvas(bitmap);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int count = Math.max(1, Math.min(visibleCount, allPoints.size()));
        double metersPerPixel = 156543.03392 * Math.cos(Math.toRadians(mapLatitude)) / Math.pow(2.0, mapZoom);
        float scale = (float)(1.0 / Math.max(0.02, metersPerPixel));
        float cx = width / 2f - focusX * scale;
        float cy = height / 2f - focusY * scale;
        int stride = Math.max(1, (count + 5999) / 6000);

        if (count > 2) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x183157D5);
            Path hull = new Path();
            TrailPoint first = allPoints.get(0);
            hull.moveTo(cx + first.x * scale, cy + first.y * scale);
            for (int i = stride; i < count; i += stride) {
                TrailPoint q = allPoints.get(i);
                hull.lineTo(cx + q.x * scale, cy + q.y * scale);
            }
            TrailPoint end = allPoints.get(count - 1);
            hull.lineTo(cx + end.x * scale, cy + end.y * scale);
            hull.close();
            c.drawPath(hull, p);
        }

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(5f, width / 150f));
        p.setColor(0xFF3157D5);
        Path path = new Path();
        TrailPoint first = allPoints.get(0);
        path.moveTo(cx + first.x * scale, cy + first.y * scale);
        for (int i = stride; i < count; i += stride) {
            TrailPoint q = allPoints.get(i);
            path.lineTo(cx + q.x * scale, cy + q.y * scale);
        }
        TrailPoint last = allPoints.get(count - 1);
        path.lineTo(cx + last.x * scale, cy + last.y * scale);
        c.drawPath(path, p);

        p.setStyle(Paint.Style.FILL);
        float px = cx + last.x * scale, py = cy + last.y * scale;
        p.setColor(0xFF1C9B69);
        c.drawCircle(px, py, Math.max(13f, width / 75f), p);
        p.setStrokeWidth(Math.max(6f, width / 130f));
        c.drawLine(px, py, px + (float)Math.sin(heading) * width / 12f,
                py - (float)Math.cos(heading) * width / 12f, p);
        return bitmap;
    }

    @Override protected synchronized void onDraw(Canvas c) {
        super.onDraw(c);
        drawScene(c, trail, heading, activityScore, activityAngle,
                getWidth(), getHeight(), replayVisibleCount < 0 ? trail.size() : replayVisibleCount,
                userScale, panX, panY, mapBackgroundVisible, mapLatitude, mapZoom,
                anchorLatitude, anchorLongitude, true,
                rideMetricsOverride, rideCurrentKmh, rideAverageKmh, rideMaxKmh,
                rideDistanceMeters, rideMovingTimeMs, rideActiveTimeMs, statsPanelHidden,
                gestureInProgress ? 1200 : 5000);
    }

    private static void drawScene(Canvas c, List<TrailPoint> allPoints, float heading,
                                  float activityScore, float activityAngle,
                                  int width, int height, int requestedVisibleCount,
                                  float userScale, float panX, float panY, boolean mapVisible,
                                  double mapLatitude, int mapZoom, double anchorLatitude, double anchorLongitude,
                                  boolean drawBackground,
                                  boolean metricsOverride, float metricsCurrentKmh, float metricsAverageKmh,
                                  float metricsMaxKmh, float metricsDistanceMeters,
                                  long metricsMovingTimeMs, long metricsActiveTimeMs,
                                  boolean statsPanelHidden, int maxDrawVertices) {
        float w = width, h = height;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        if (drawBackground) {
            p.setColor(mapVisible ? 0x22FFFFFF : 0xFFF8F9FD);
            c.drawRoundRect(new RectF(0, 0, w, h), Math.max(18, w / 40f), Math.max(18, w / 40f), p);
        }

        p.setStrokeWidth(Math.max(1.5f, w / 700f));
        p.setColor(mapVisible ? 0x66FFFFFF : 0xFFE3E7F0);
        for (int i = 1; i < 8; i++) {
            c.drawLine(w * i / 8f, 0, w * i / 8f, h, p);
            c.drawLine(0, h * i / 8f, w, h * i / 8f, p);
        }

        if (allPoints == null || allPoints.isEmpty()) allPoints = new ArrayList<>();
        if (allPoints.isEmpty()) allPoints.add(new TrailPoint(0, 0, 0));
        int count = Math.max(1, Math.min(requestedVisibleCount, allPoints.size()));
        List<TrailPoint> points = allPoints.subList(0, count);

        float minX = 0, maxX = 0, minY = 0, maxY = 0;
        if (!mapVisible) {
            // 仅无底图的“全轨迹适配”模式需要边界。在线地图定位/回放时跳过
            // 对几十万轨迹点的全量遍历，避免点击定位按钮触发主线程 ANR。
            final int boundsStride = Math.max(1, allPoints.size() / 6000);
            for (int i = 0; i < allPoints.size(); i += boundsStride) {
                TrailPoint q = allPoints.get(i);
                minX = Math.min(minX, q.x); maxX = Math.max(maxX, q.x);
                minY = Math.min(minY, q.y); maxY = Math.max(maxY, q.y);
            }
            TrailPoint q = allPoints.get(allPoints.size() - 1);
            minX = Math.min(minX, q.x); maxX = Math.max(maxX, q.x);
            minY = Math.min(minY, q.y); maxY = Math.max(maxY, q.y);
        }
        float scale;
        float cx;
        float cy;
        if (mapVisible) {
            double metersPerPixel = 156543.03392 * Math.cos(Math.toRadians(mapLatitude)) / Math.pow(2.0, mapZoom);
            scale = (float)(1.0 / Math.max(0.02, metersPerPixel));
            // 地图回放/视频以当前可见轨迹点为画面中心，而不是永远以起点为中心。
            TrailPoint focus = points.get(points.size() - 1);
            cx = w / 2f - focus.x * scale;
            cy = h / 2f - focus.y * scale;
        } else {
            float range = Math.max(4f, Math.max(maxX - minX, maxY - minY) + 2f);
            scale = Math.min(w, h) / range;
            cx = w / 2f - (minX + maxX) / 2f * scale;
            cy = h / 2f - (minY + maxY) / 2f * scale;
        }
        scale *= userScale;
        cx = w / 2f + (cx - w / 2f) * userScale + panX;
        cy = h / 2f + (cy - h / 2f) * userScale + panY;

        // 大轨迹仅对“显示路径”抽稀，原始点仍完整保存在 trail 中。
        // 限制每帧 Path 顶点数量，避免导入数万点后 UI 长时间卡顿或 ANR。
        final int vertexLimit = Math.max(200, maxDrawVertices);
        final int drawStride = Math.max(1, (points.size() + vertexLimit - 1) / vertexLimit);

        if (points.size() > 2) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x183157D5);
            Path hull = new Path();
            TrailPoint first = points.get(0);
            hull.moveTo(cx + first.x * scale, cy + first.y * scale);
            for (int i = drawStride; i < points.size(); i += drawStride) {
                TrailPoint q = points.get(i);
                hull.lineTo(cx + q.x * scale, cy + q.y * scale);
            }
            TrailPoint end = points.get(points.size() - 1);
            hull.lineTo(cx + end.x * scale, cy + end.y * scale);
            hull.close();
            c.drawPath(hull, p);
        }

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(5f, w / 150f));
        p.setColor(0xFF3157D5);
        Path path = new Path();
        TrailPoint first = points.get(0);
        path.moveTo(cx + first.x * scale, cy + first.y * scale);
        for (int i = drawStride; i < points.size(); i += drawStride) {
            TrailPoint q = points.get(i);
            path.lineTo(cx + q.x * scale, cy + q.y * scale);
        }
        TrailPoint pathEnd = points.get(points.size() - 1);
        path.lineTo(cx + pathEnd.x * scale, cy + pathEnd.y * scale);
        c.drawPath(path, p);
        p.setStyle(Paint.Style.FILL);

        TrailPoint last = points.get(points.size() - 1);
        float px = cx + last.x * scale, py = cy + last.y * scale;
        p.setColor(0xFF1C9B69);
        c.drawCircle(px, py, Math.max(13f, w / 75f), p);
        p.setStrokeWidth(Math.max(6f, w / 130f));
        c.drawLine(px, py, px + (float) Math.sin(heading) * w / 12f,
                py - (float) Math.cos(heading) * w / 12f, p);

        if (activityScore > 0.15f) {
            float len = w / 12f + w / 6f * Math.min(1f, activityScore);
            p.setStrokeWidth(Math.max(12f, w / 70f));
            p.setColor(0x99E66A3C);
            float ax = px + (float) Math.sin(activityAngle) * len;
            float ay = py - (float) Math.cos(activityAngle) * len;
            c.drawLine(px, py, ax, ay, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(4f, w / 180f));
            c.drawCircle(ax, ay, Math.max(24f, w / 35f), p);
            p.setStyle(Paint.Style.FILL);
        }

        p.setColor(Color.rgb(100, 108, 124));
        p.setTextSize(Math.max(24f, w / 32f));
        p.setTextAlign(Paint.Align.LEFT);
        c.drawText("蓝线：轨迹  双指缩放 · 单指拖动", w / 35f, h - h / 18f, p);
        String coordinateLine;
        if (!Double.isNaN(anchorLatitude) && !Double.isNaN(anchorLongitude)) {
            double[] geo = relativeMetersToLatLon(anchorLatitude, anchorLongitude, last.x, last.y);
            coordinateLine = formatDms(geo[0], true) + "  " + formatDms(geo[1], false);
        } else {
            coordinateLine = "经纬度：等待定位";
        }
        c.drawText(coordinateLine, w / 35f, h - h / 50f, p);
        p.setTextSize(Math.max(18f, w / 42f));
        String decimalLine = !Double.isNaN(anchorLatitude) && !Double.isNaN(anchorLongitude)
                ? String.format(java.util.Locale.US, "十进制度 %.6f, %.6f", relativeMetersToLatLon(anchorLatitude, anchorLongitude, last.x, last.y)[0], relativeMetersToLatLon(anchorLatitude, anchorLongitude, last.x, last.y)[1])
                : "十进制度：等待定位";
        c.drawText(decimalLine, w / 35f, h - h / 9.5f, p);
        float visibleMax = metricsOverride ? metricsMaxKmh : 0f;
        if (!metricsOverride) {
            final int metricStride = Math.max(1, points.size() / 6000);
            for (int i = 0; i < points.size(); i += metricStride)
                visibleMax = Math.max(visibleMax, points.get(i).speedKmh);
            visibleMax = Math.max(visibleMax, points.get(points.size() - 1).speedKmh);
        }
        long elapsedMs = Math.max(1L, last.timeMs - points.get(0).timeMs);
        float visibleAverage = last.distanceMeters / (elapsedMs / 1000f) * 3.6f;
        float shownCurrent = metricsOverride ? metricsCurrentKmh : last.speedKmh;
        float shownAverage = metricsOverride ? metricsAverageKmh : visibleAverage;
        float shownMax = metricsOverride ? metricsMaxKmh : visibleMax;
        float shownDistance = metricsOverride ? metricsDistanceMeters : last.distanceMeters;
        long shownMovingMs = metricsOverride ? metricsMovingTimeMs : elapsedMs;
        long shownActiveMs = metricsOverride ? metricsActiveTimeMs : elapsedMs;
        long durationSeconds = Math.max(0L, shownActiveMs / 1000L);
        long movingSeconds = Math.max(0L, shownMovingMs / 1000L);

        // 统计面板：白色 80% 透明，宽高根据文字实际范围自适应。
        float statTextSize = Math.max(16f, Math.min(23f, w / 45f));
        float statLine = Math.max(23f, statTextSize * 1.38f);
        float margin = Math.max(10f, w / 55f);
        p.setTextSize(statTextSize);
        p.setTextAlign(Paint.Align.LEFT);
        String[] statLines = new String[]{
                String.format(java.util.Locale.CHINA, "实时速度  %.2f km/h", shownCurrent),
                String.format(java.util.Locale.CHINA, "平均速度  %.2f km/h", shownAverage),
                String.format(java.util.Locale.CHINA, "最高速度  %.2f km/h", shownMax),
                String.format(java.util.Locale.CHINA, "行驶距离  %.2f km", shownDistance / 1000f),
                String.format(java.util.Locale.CHINA, "移动时长  %02d:%02d:%02d",
                        movingSeconds / 3600L, (movingSeconds % 3600L) / 60L, movingSeconds % 60L),
                String.format(java.util.Locale.CHINA, "总时长    %02d:%02d:%02d",
                        durationSeconds / 3600L, (durationSeconds % 3600L) / 60L, durationSeconds % 60L)
        };
        if (statsPanelHidden) {
            String compact = "速度";
            float compactW = p.measureText(compact) + margin * 1.5f;
            float compactH = statTextSize * 1.8f;
            RectF compactRect = new RectF(margin, margin, margin + compactW, margin + compactH);
            p.setColor(0xCCFFFFFF);
            c.drawRoundRect(compactRect, compactH * 0.28f, compactH * 0.28f, p);
            p.setColor(Color.rgb(43, 50, 66));
            c.drawText(compact, compactRect.left + margin * 0.65f,
                    compactRect.centerY() - (p.ascent() + p.descent()) / 2f, p);
        } else {
            float maxTextWidth = 0f;
            for (String line : statLines) maxTextWidth = Math.max(maxTextWidth, p.measureText(line));
            float hideTextWidth = p.measureText("隐藏");
            float panelLeft = margin;
            float panelTop = margin;
            float panelWidth = Math.min(w - margin * 2f,
                    Math.max(maxTextWidth + margin * 2f, hideTextWidth + margin * 3f));
            float panelHeight = margin * 1.15f + statLine * (statLines.length + 1);
            RectF panelRect = new RectF(panelLeft, panelTop,
                    panelLeft + panelWidth, panelTop + panelHeight);
            p.setColor(0xCCFFFFFF);
            c.drawRoundRect(panelRect, Math.max(10f, w / 60f), Math.max(10f, w / 60f), p);

            p.setColor(Color.rgb(43, 50, 66));
            float hideX = panelRect.right - margin - hideTextWidth;
            float headerBaseline = panelTop + margin * 0.45f + statLine * 0.72f;
            c.drawText("隐藏", hideX, headerBaseline, p);

            float statX = panelLeft + margin;
            float statY = panelTop + margin * 0.55f + statLine * 1.65f;
            for (String line : statLines) {
                c.drawText(line, statX, statY, p);
                statY += statLine;
            }
        }

        // 日期保留在面板外，避免覆盖统计字段。
        p.setTextSize(Math.max(16f, w / 48f));
        p.setColor(Color.rgb(100, 108, 124));
        c.drawText(new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
                .format(new java.util.Date(last.timeMs)), w / 35f, h - h / 4.15f, p);
    }

    public static double[] relativeMetersToLatLon(double anchorLat, double anchorLon, float xEastMeters, float ySouthMeters) {
        double northMeters = -ySouthMeters;
        double lat = anchorLat + northMeters / 111320.0;
        double cosLat = Math.cos(Math.toRadians(anchorLat));
        double lon = anchorLon + xEastMeters / (111320.0 * Math.max(0.01, cosLat));
        return new double[]{lat, lon};
    }

    public static String formatDms(double value, boolean latitude) {
        String positive = latitude ? "N" : "E";
        String negative = latitude ? "S" : "W";
        String hemisphere = value >= 0 ? positive : negative;
        double abs = Math.abs(value);
        int degrees = (int)Math.floor(abs);
        double minuteValue = (abs - degrees) * 60.0;
        int minutes = (int)Math.floor(minuteValue);
        double seconds = (minuteValue - minutes) * 60.0;
        if (seconds >= 59.95) {
            seconds = 0.0;
            minutes++;
            if (minutes >= 60) { minutes = 0; degrees++; }
        }
        return String.format(java.util.Locale.US, "%d°%02d'%04.1f\"%s", degrees, minutes, seconds, hemisphere);
    }

}
