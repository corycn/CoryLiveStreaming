package com.corykui.wifispeed.records;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MapTileView extends View {
    public interface StatusListener { void onMapStatus(String message, boolean error); }
    private static final int TILE = 256;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final ExecutorService pool = Executors.newFixedThreadPool(5);
    private final Map<String, Bitmap> cache = new LinkedHashMap<String, Bitmap>(256, .75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, Bitmap> e) {
            if (size() > 256) { if (e.getValue() != null) e.getValue().recycle(); return true; }
            return false;
        }
    };
    private final Set<String> loading = new HashSet<>();
    private final Map<String, Long> failedAt = new HashMap<>();
    private String provider = "none";
    private double latitude;
    private double longitude;
    private int zoom = 18;
    private float scale = 1f, panX = 0f, panY = 0f;
    private StatusListener statusListener;
    private int successCount = 0;
    private int failureCount = 0;
    private String lastError = "";
    private int mapGeneration = 0;
    private String locationCoordinateHint = "unknown";
    private String baiduCoordinateMode = "auto";
    private String baiduTileMode = "onlinelabel";
    private final ArrayDeque<String> diagnosticLines = new ArrayDeque<>();
    private static final int MAX_DIAGNOSTIC_LINES = 1200;
    private int snapshotWidthOverride = 0;
    private int snapshotHeightOverride = 0;
    private static final double[] BAIDU_LL_BANDS = {75, 60, 45, 30, 15, 0};
    private static final double[][] BAIDU_LL2MC = {
            {-0.0015702102444,111320.7020616939,1704480524535203d,-10338987376042340d,26112667856603880d,-35149669176653700d,26595700718403920d,-10725012454188240d,1800819912950474d,82.5},
            {0.0008277824516172526,111320.7020463578,647795574.6671607,-4082003173.641316,10774905663.51142,-15171875531.51559,12053065338.62167,-5124939663.577472,913311935.9512032,67.5},
            {0.00337398766765,111320.7020202162,4481351.045890365,-23393751.19931662,79682215.47186455,-115964993.2797253,97236711.15602145,-43661946.33752821,8477230.501135234,52.5},
            {0.00220636496208,111320.7020209128,51751.86112841131,3796837.749470245,992013.7397791013,-1221952.21711287,1340652.697009075,-620943.6990984312,144416.9293806241,37.5},
            {-0.0003441963504368392,111320.7020576856,278.2353980772752,2485758.690035394,6070.750963243378,54821.18345352118,9540.606633304236,-2710.55326746645,1405.483844121726,22.5},
            {-0.0003218135878613132,111320.7020701615,0.00369383431289,823725.6402795718,0.46104986909093,2351.343141331292,1.58060784298199,8.77738589078284,0.37238884252424,7.45}
    };

    private synchronized void logDiagnostic(String message) {
        String stamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
        diagnosticLines.addLast(stamp + " " + message);
        while (diagnosticLines.size() > MAX_DIAGNOSTIC_LINES) diagnosticLines.removeFirst();
    }

    public synchronized String getDiagnosticLog() {
        StringBuilder out = new StringBuilder();
        out.append("provider=").append(provider)
                .append(" center=").append(latitude).append(',').append(longitude)
                .append(" baseZoom=").append(zoom)
                .append(" scale=").append(scale)
                .append(" pan=").append(panX).append(',').append(panY)
                .append(" successes=").append(successCount)
                .append(" failures=").append(failureCount)
                .append(" lastError=").append(lastError).append(" view=").append(super.getWidth()).append('x').append(super.getHeight()).append(" snapshotOverride=").append(snapshotWidthOverride).append('x').append(snapshotHeightOverride).append('\n');
        synchronized (cache) {
            out.append("cacheSize=").append(cache.size())
                    .append(" loading=").append(loading.size())
                    .append(" failedKeys=").append(failedAt.size()).append('\n');
        }
        for (String line : diagnosticLines) out.append(line).append('\n');
        return out.toString();
    }

    public MapTileView(Context context) { super(context); setBackgroundColor(Color.WHITE); }
    public void setStatusListener(StatusListener listener) { this.statusListener = listener; }
    public synchronized void setLocationCoordinateHint(String hint) {
        this.locationCoordinateHint = hint == null ? "unknown" : hint.toLowerCase(Locale.US);
    }
    public synchronized void setBaiduCoordinateMode(String mode) {
        if (!"wgs".equals(mode) && !"gcj".equals(mode)) mode = "auto";
        this.baiduCoordinateMode = mode;
        invalidate();
    }
    public synchronized String getBaiduCoordinateMode() { return baiduCoordinateMode; }

    public synchronized void setBaiduTileMode(String mode) {
        if (!"vtile".equals(mode)) mode = "onlinelabel";
        if (!mode.equals(baiduTileMode)) {
            baiduTileMode = mode;
            logDiagnostic("baiduTileMode=" + baiduTileMode);
        }
    }

    public synchronized String getBaiduTileMode() { return baiduTileMode; }





    public synchronized void setMap(String provider, double lat, double lon, int zoom) {
        this.provider = provider == null ? "none" : provider;
        this.latitude = lat; this.longitude = lon; this.zoom = zoom;
        this.scale = 1f; this.panX = this.panY = 0f;
        successCount = 0; failureCount = 0; lastError = "";
        mapGeneration++;
        synchronized (cache) { cache.clear(); loading.clear(); failedAt.clear(); }
        logDiagnostic("setMap provider=" + this.provider + " lat=" + lat + " lon=" + lon + " zoom=" + zoom + " generation=" + mapGeneration);
        notifyStatus("正在请求地图瓦片…", false);
        invalidate();
    }
    public synchronized void clearMap() { logDiagnostic("clearMap provider=" + provider); provider = "none"; invalidate(); }

    public synchronized String getProviderName() { return provider; }
    public synchronized double getCenterLatitude() { return latitude; }
    public synchronized double getCenterLongitude() { return longitude; }
    public synchronized int getZoomLevel() { return zoom; }
    public synchronized float getViewportScale() { return scale; }
    public synchronized float getViewportPanX() { return panX; }
    public synchronized float getViewportPanY() { return panY; }
    public synchronized int getTileSuccessCount() { return successCount; }
    public synchronized int getTileFailureCount() { return failureCount; }
    public int getLoadingTileCount() { synchronized (cache) { return loading.size(); } }
    public synchronized String getLastMapError() { return lastError; }

    private int drawingWidth() { return snapshotWidthOverride > 0 ? snapshotWidthOverride : super.getWidth(); }
    private int drawingHeight() { return snapshotHeightOverride > 0 ? snapshotHeightOverride : super.getHeight(); }
    public String getCachedTileKeysJson() {
        org.json.JSONArray array = new org.json.JSONArray();
        synchronized (cache) { for (String key : cache.keySet()) array.put(key); }
        return array.toString();
    }
    public synchronized void setViewport(float scale, float panX, float panY) {
        this.scale = scale; this.panX = panX; this.panY = panY; invalidate();
    }


    public synchronized Bitmap renderSnapshot(int width, int height) {
        int w = Math.max(1, width);
        int h = Math.max(1, height);
        Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        snapshotWidthOverride = w;
        snapshotHeightOverride = h;
        try {
            // 直接调用 onDraw，避免离屏/隐藏 View 的 drawingWidth()==0 导致纯色截图。
            onDraw(canvas);
        } finally {
            snapshotWidthOverride = 0;
            snapshotHeightOverride = 0;
        }
        return bitmap;
    }

    private void notifyStatus(final String message, final boolean error) {
        if (statusListener != null) post(() -> statusListener.onMapStatus(message, error));
    }

    @Override protected synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(0xFFF3F5F8);
        if ("none".equals(provider)) return;
        // 不直接把固定 zoom 的瓦片无限缩放。将用户缩放中的 2 倍级别
        // 折算进地图 zoom，仅保留 [1, 2) 的残余比例。这样缩小时不会一次
        // 需要上百张瓦片并触发缓存抖动，放大时也能请求更清晰的瓦片。
        float safeScale = Math.max(0.125f, Math.min(scale, 16f));
        int zoomDelta = (int)Math.floor(Math.log(safeScale) / Math.log(2.0));
        int effectiveZoom = Math.max(2, Math.min(20, zoom + zoomDelta));
        float residualScale = (float)(safeScale / Math.pow(2.0, effectiveZoom - zoom));
        while (residualScale < 1f && effectiveZoom > 2) { effectiveZoom--; residualScale *= 2f; }
        while (residualScale >= 2f && effectiveZoom < 20) { effectiveZoom++; residualScale /= 2f; }

        float centerPx = drawingWidth()/2f + panX;
        float centerPy = drawingHeight()/2f + panY;
        float tileSize = TILE * residualScale;

        if ("baidu".equals(provider)) {
            // 标准百度链路：定位输入固定视为 WGS-84，只转换一次。
            // WGS-84 -> GCJ-02 -> BD-09 -> 百度墨卡托。
            double[] gcj = wgs84ToGcj02(latitude, longitude);
            double[] bd = gcj02ToBd09(gcj[0], gcj[1]);
            double[] mc = baiduLatLonToMercator(bd[0], bd[1]);
            double resolution = Math.pow(2.0, 18 - effectiveZoom); // 米/像素
            double worldX = mc[0] / (TILE * resolution);
            double worldY = mc[1] / (TILE * resolution); // 百度瓦片 Y 向北为正
            int minTileX = (int)Math.floor(worldX + (0f - centerPx) / tileSize) - 1;
            int maxTileX = (int)Math.ceil(worldX + (drawingWidth() - centerPx) / tileSize) + 1;
            int minTileY = (int)Math.floor(worldY - (drawingHeight() - centerPy) / tileSize) - 1;
            int maxTileY = (int)Math.ceil(worldY - (0f - centerPy) / tileSize) + 1;
            logDiagnostic("baiduStandard mode=" + baiduTileMode + " wgs=" + latitude + "," + longitude +
                    " gcj=" + gcj[0] + "," + gcj[1] +
                    " bd=" + bd[0] + "," + bd[1] +
                    " mc=" + mc[0] + "," + mc[1] +
                    " tileCenter=" + worldX + "," + worldY + " z=" + effectiveZoom);
            List<TileDraw> tiles = new ArrayList<>();
            for (int ty = minTileY; ty <= maxTileY; ty++) {
                for (int tx = minTileX; tx <= maxTileX; tx++) {
                    float left = centerPx + (float)(tx - worldX) * tileSize;
                    float top = centerPy - (float)(ty - worldY) * tileSize - tileSize;
                    tiles.add(new TileDraw(tx, ty, left, top,
                            Math.abs((tx + 0.5) - worldX) + Math.abs((ty + 0.5) - worldY)));
                }
            }
            Collections.sort(tiles, Comparator.comparingDouble(t -> t.distance));
            for (TileDraw tile : tiles) {
                String key = provider+":"+baiduTileMode+":"+effectiveZoom+":"+tile.x+":"+tile.y;
                Bitmap bitmap;
                synchronized (cache) { bitmap = cache.get(key); }
                if (bitmap != null && !bitmap.isRecycled()) {
                    canvas.drawBitmap(bitmap, null, new RectF(tile.left, tile.top, tile.left+tileSize, tile.top+tileSize), paint);
                } else {
                    paint.setColor(0xFFE8EBF1);
                    canvas.drawRect(tile.left, tile.top, tile.left+tileSize, tile.top+tileSize, paint);
                    requestTile(key, provider, tile.x, tile.y, effectiveZoom, mapGeneration);
                }
            }
        } else {
            // 中国大陆的谷歌道路瓦片与高德均按 GCJ-02 对齐；GPS 输入仍保持 WGS-84。
            // 绘制底图前统一转换，备份和轨迹原始数据不变。
            double projectedLat = latitude;
            double projectedLon = longitude;
            if ("amap".equals(provider) || "google".equals(provider)) {
                double[] gcj = wgs84ToGcj02(latitude, longitude);
                projectedLat = gcj[0]; projectedLon = gcj[1];
            }
            double n = Math.pow(2.0, effectiveZoom);
            double worldX = (projectedLon + 180.0) / 360.0 * n;
            double latRad = Math.toRadians(Math.max(-85.05112878, Math.min(85.05112878, projectedLat)));
            double worldY = (1.0 - Math.log(Math.tan(latRad) + 1.0 / Math.cos(latRad)) / Math.PI) / 2.0 * n;
            int minTileX = (int)Math.floor(worldX + (0f - centerPx) / tileSize) - 1;
            int maxTileX = (int)Math.ceil(worldX + (drawingWidth() - centerPx) / tileSize) + 1;
            int minTileY = (int)Math.floor(worldY + (0f - centerPy) / tileSize) - 1;
            int maxTileY = (int)Math.ceil(worldY + (drawingHeight() - centerPy) / tileSize) + 1;
            List<TileDraw> tiles = new ArrayList<>();
            for (int ty = minTileY; ty <= maxTileY; ty++) {
                for (int tx = minTileX; tx <= maxTileX; tx++) {
                    if (ty < 0 || ty >= n) continue;
                    float left = centerPx + (float)(tx - worldX) * tileSize;
                    float top = centerPy + (float)(ty - worldY) * tileSize;
                    tiles.add(new TileDraw(tx, ty, left, top,
                            Math.abs((tx + 0.5) - worldX) + Math.abs((ty + 0.5) - worldY)));
                }
            }
            Collections.sort(tiles, Comparator.comparingDouble(t -> t.distance));
            for (TileDraw tile : tiles) {
                int wrappedX = ((tile.x % (int)n) + (int)n) % (int)n;
                String key = provider+":"+effectiveZoom+":"+wrappedX+":"+tile.y;
                Bitmap bitmap;
                synchronized (cache) { bitmap = cache.get(key); }
                if (bitmap != null && !bitmap.isRecycled()) {
                    canvas.drawBitmap(bitmap, null, new RectF(tile.left, tile.top, tile.left+tileSize, tile.top+tileSize), paint);
                } else {
                    paint.setColor(0xFFE8EBF1);
                    canvas.drawRect(tile.left, tile.top, tile.left+tileSize, tile.top+tileSize, paint);
                    requestTile(key, provider, wrappedX, tile.y, effectiveZoom, mapGeneration);
                }
            }
        }
        if (successCount == 0 && failureCount > 0) {
            paint.setColor(0xCCFFFFFF);
            canvas.drawRoundRect(new RectF(24, drawingHeight()/2f-70, drawingWidth()-24, drawingHeight()/2f+70), 20, 20, paint);
            paint.setColor(0xFFB3261E);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(30f);
            canvas.drawText("地图网络请求失败", drawingWidth()/2f, drawingHeight()/2f-10, paint);
            paint.setColor(0xFF5F6368);
            paint.setTextSize(22f);
            canvas.drawText("请检查网络、VPN、私人 DNS 或广告拦截", drawingWidth()/2f, drawingHeight()/2f+35, paint);
        }
    }




    private static double webMercatorY(double lat, double n) {
        double r = Math.toRadians(Math.max(-85.05112878, Math.min(85.05112878, lat)));
        return (1.0 - Math.log(Math.tan(r) + 1.0/Math.cos(r))/Math.PI)/2.0*n;
    }

    private void requestTile(final String key, final String requestProvider, final int x, final int y, final int z, final int generation) {
        synchronized (cache) {
            if (loading.contains(key)) return;
            Long failed = failedAt.get(key);
            if (failed != null && System.currentTimeMillis() - failed < 5000L) return;
            loading.add(key);
        }
        logDiagnostic("queue key=" + key + " provider=" + requestProvider + " xyz=" + x + "," + y + "," + z);
        pool.execute(() -> {
            Bitmap bitmap = null;
            String error = "";
            String[] urls = tileUrls(requestProvider, x, y, z);
            for (String address : urls) {
                logDiagnostic("request " + address);
                HttpURLConnection conn = null;
                try {
                    conn = (HttpURLConnection)new URL(address).openConnection();
                    conn.setInstanceFollowRedirects(true);
                    conn.setConnectTimeout(7000); conn.setReadTimeout(9000);
                    conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) WiFiEnvironmentMonitor/2.9");
                    conn.setRequestProperty("Accept", "image/png,image/jpeg,image/webp,*/*");
                    conn.setRequestProperty("Referer", refererFor(requestProvider));
                    int code = conn.getResponseCode();
                    String type = conn.getContentType();
                    logDiagnostic("response code=" + code + " type=" + type + " url=" + address);
                    if (code < 200 || code >= 300) { error = "HTTP " + code; continue; }
                    try (InputStream in = new BufferedInputStream(conn.getInputStream())) {
                        bitmap = BitmapFactory.decodeStream(in);
                    }
                    if (bitmap != null) { logDiagnostic("decoded " + bitmap.getWidth() + "x" + bitmap.getHeight() + " key=" + key); break; }
                    error = "图片解码失败";
                    logDiagnostic("decode failed key=" + key + " url=" + address);
                } catch (Exception e) {
                    error = e.getClass().getSimpleName() + (e.getMessage() == null ? "" : ": " + e.getMessage());
                    logDiagnostic("exception key=" + key + " error=" + error + " url=" + address);
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }
            synchronized (cache) {
                loading.remove(key);
                if (generation != mapGeneration || !requestProvider.equals(provider)) {
                    if (bitmap != null) bitmap.recycle();
                    return;
                }
                if (bitmap != null) {
                    cache.put(key, bitmap);
                    failedAt.remove(key);
                    successCount++;
                    logDiagnostic("success key=" + key + " successCount=" + successCount);
                } else {
                    failedAt.put(key, System.currentTimeMillis());
                    failureCount++;
                    lastError = error;
                    logDiagnostic("failure key=" + key + " failureCount=" + failureCount + " error=" + error);
                }
            }
            if (bitmap != null && successCount == 1) notifyStatus("地图底图已加载", false);
            else if (bitmap == null && successCount == 0 && failureCount >= 3)
                notifyStatus("地图加载失败：" + lastError, true);
            postInvalidate();
        });
    }

    private static final class TileDraw {
        final int x, y; final float left, top; final double distance;
        TileDraw(int x, int y, float left, float top, double distance) {
            this.x=x; this.y=y; this.left=left; this.top=top; this.distance=distance;
        }
    }

    private static double[] wgs84ToGcj02(double lat, double lon) {
        if (lon < 72.004 || lon > 137.8347 || lat < 0.8293 || lat > 55.8271) return new double[]{lat, lon};
        double dLat = transformLat(lon - 105.0, lat - 35.0);
        double dLon = transformLon(lon - 105.0, lat - 35.0);
        double radLat = lat / 180.0 * Math.PI;
        double magic = Math.sin(radLat);
        magic = 1 - 0.00669342162296594323 * magic * magic;
        double sqrtMagic = Math.sqrt(magic);
        dLat = (dLat * 180.0) / ((6378245.0 * (1 - 0.00669342162296594323)) / (magic * sqrtMagic) * Math.PI);
        dLon = (dLon * 180.0) / (6378245.0 / sqrtMagic * Math.cos(radLat) * Math.PI);
        return new double[]{lat + dLat, lon + dLon};
    }
    private static double transformLat(double x, double y) {
        double ret = -100.0 + 2.0*x + 3.0*y + 0.2*y*y + 0.1*x*y + 0.2*Math.sqrt(Math.abs(x));
        ret += (20.0*Math.sin(6.0*x*Math.PI) + 20.0*Math.sin(2.0*x*Math.PI))*2.0/3.0;
        ret += (20.0*Math.sin(y*Math.PI) + 40.0*Math.sin(y/3.0*Math.PI))*2.0/3.0;
        ret += (160.0*Math.sin(y/12.0*Math.PI) + 320*Math.sin(y*Math.PI/30.0))*2.0/3.0;
        return ret;
    }
    private static double transformLon(double x, double y) {
        double ret = 300.0 + x + 2.0*y + 0.1*x*x + 0.1*x*y + 0.1*Math.sqrt(Math.abs(x));
        ret += (20.0*Math.sin(6.0*x*Math.PI) + 20.0*Math.sin(2.0*x*Math.PI))*2.0/3.0;
        ret += (20.0*Math.sin(x*Math.PI) + 40.0*Math.sin(x/3.0*Math.PI))*2.0/3.0;
        ret += (150.0*Math.sin(x/12.0*Math.PI) + 300.0*Math.sin(x/30.0*Math.PI))*2.0/3.0;
        return ret;
    }
    private static double[] gcj02ToBd09(double lat, double lon) {
        double xPi = Math.PI * 3000.0 / 180.0;
        double z = Math.sqrt(lon*lon + lat*lat) + 0.00002*Math.sin(lat*xPi);
        double theta = Math.atan2(lat, lon) + 0.000003*Math.cos(lon*xPi);
        return new double[]{z*Math.sin(theta) + 0.006, z*Math.cos(theta) + 0.0065};
    }

    private static double[] baiduLatLonToMercator(double lat, double lon) {
        lon = Math.max(-180.0, Math.min(180.0, lon));
        lat = Math.max(-74.0, Math.min(74.0, lat));
        double[] c = BAIDU_LL2MC[BAIDU_LL2MC.length - 1];
        double absLat = Math.abs(lat);
        for (int i = 0; i < BAIDU_LL_BANDS.length; i++) {
            if (absLat >= BAIDU_LL_BANDS[i]) { c = BAIDU_LL2MC[i]; break; }
        }
        double x = c[0] + c[1] * Math.abs(lon);
        double t = absLat / c[9];
        double y = c[2] + c[3]*t + c[4]*Math.pow(t,2) + c[5]*Math.pow(t,3)
                + c[6]*Math.pow(t,4) + c[7]*Math.pow(t,5) + c[8]*Math.pow(t,6);
        if (lon < 0) x = -x;
        if (lat < 0) y = -y;
        return new double[]{x, y};
    }

    private String refererFor(String p) {
        if ("amap".equals(p)) return "https://www.amap.com/";
        if ("baidu".equals(p)) return "https://map.baidu.com/";
        return "https://maps.google.com/";
    }

    private String[] tileUrls(String p, int x, int y, int z) {
        int s = Math.abs(x+y)%4 + 1;
        if ("amap".equals(p)) {
            return new String[]{
                "https://webrd0"+s+".is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=7&x="+x+"&y="+y+"&z="+z,
                "https://wprd0"+s+".is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=7&x="+x+"&y="+y+"&z="+z,
                "http://webrd0"+s+".is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=7&x="+x+"&y="+y+"&z="+z
            };
        }
        if ("baidu".equals(p)) {
            // 百度瓦片编号使用 BD-09 Mercator 的正向 Y。
            // v1.5.1 的负 Y 请求虽然返回 200 PNG，但实际是空白占位瓦片。
            int requestY = y;
            int bs = Math.floorMod(x + requestY, 4);
            logDiagnostic("baiduTileRequestPositiveY mode=" + baiduTileMode +
                    " internal=" + x + "," + y + " request=" + x + "," + requestY + " z=" + z);
            if ("onlinelabel".equals(baiduTileMode)) {
                int host = bs + 1;
                return new String[]{
                    "https://online"+host+".map.bdimg.com/onlinelabel/?qt=tile&x="+x+"&y="+requestY+"&z="+z+"&styles=pl&scaler=1&p=1",
                    "http://online"+host+".map.bdimg.com/onlinelabel/?qt=tile&x="+x+"&y="+requestY+"&z="+z+"&styles=pl&scaler=1&p=1"
                };
            }
            return new String[]{
                "https://maponline"+bs+".bdimg.com/tile/?qt=vtile&x="+x+"&y="+requestY+"&z="+z+"&styles=pl&scaler=1&p=1",
                "https://maponline"+((bs+1)%4)+".bdimg.com/tile/?qt=vtile&x="+x+"&y="+requestY+"&z="+z+"&styles=pl&scaler=1&p=1"
            };
        }
        // 谷歌标准全球 Web-Mercator 瓦片。移除 google.cn，避免中国区图层偏移。
        int gs = Math.abs(x + y) % 4;
        return new String[]{
            "https://mt"+gs+".google.com/vt/lyrs=m&hl=zh-CN&x="+x+"&y="+y+"&z="+z,
            "https://maps.google.com/maps/vt?lyrs=m&hl=zh-CN&x="+x+"&y="+y+"&z="+z
        };
    }
}
