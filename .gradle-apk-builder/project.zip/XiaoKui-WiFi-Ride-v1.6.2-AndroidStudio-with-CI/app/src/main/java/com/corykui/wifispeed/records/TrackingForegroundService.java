package com.corykui.wifispeed.records;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

public class TrackingForegroundService extends Service {
    private static final String CHANNEL_ID = "ride_tracking";
    private static final int NOTIFICATION_ID = 1401;
    private static final long WIFI_INTERVAL_MS = 30_000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private LocationManager locationManager;
    private WifiManager wifiManager;
    private boolean wifiReceiverRegistered;
    private PowerManager.WakeLock wakeLock;

    private final LocationListener locationListener = new LocationListener() {
        @Override public void onLocationChanged(Location location) {
            Intent update = new Intent(MainActivity.ACTION_BACKGROUND_LOCATION);
            update.setPackage(getPackageName());
            update.putExtra("location", location);
            sendBroadcast(update);
        }
        @Override public void onProviderEnabled(String provider) { }
        @Override public void onProviderDisabled(String provider) { }
        @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
    };

    private final BroadcastReceiver wifiReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            Intent update = new Intent(MainActivity.ACTION_BACKGROUND_WIFI);
            update.setPackage(getPackageName());
            sendBroadcast(update);
        }
    };

    private final Runnable wifiRunnable = new Runnable() {
        @Override public void run() {
            try {
                if (wifiManager != null && wifiManager.isWifiEnabled() && hasWifiPermissions()) {
                    wifiManager.startScan(); // 系统限频时静默使用最近结果，不弹提示。
                }
            } catch (Exception ignored) { }
            handler.postDelayed(this, WIFI_INTERVAL_MS);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, createNotification());
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (powerManager != null) {
            wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                    getPackageName() + ":ride-location");
            wakeLock.setReferenceCounted(false);
            try { wakeLock.acquire(); } catch (Exception ignored) { }
        }
        registerWifiReceiver();
        startLocationUpdates();
        handler.post(wifiRunnable);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startLocationUpdates();
        return START_STICKY;
    }

    private Notification createNotification() {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return builder
                .setContentTitle("小魁WiFi骑行正在记录")
                .setContentText("锁屏和后台期间持续记录轨迹与定位")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "轨迹记录", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("锁屏和后台轨迹记录通知");
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.createNotificationChannel(channel);
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasWifiPermissions() {
        return hasLocationPermission() && (Build.VERSION.SDK_INT < 33 ||
                checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED);
    }

    private void startLocationUpdates() {
        if (locationManager == null || !hasLocationPermission()) return;
        try { locationManager.removeUpdates(locationListener); } catch (Exception ignored) { }
        requestProvider(LocationManager.GPS_PROVIDER);
        requestProvider(LocationManager.NETWORK_PROVIDER);
        requestProvider(LocationManager.PASSIVE_PROVIDER);
    }

    private void requestProvider(String provider) {
        try {
            if (locationManager.isProviderEnabled(provider)) {
                locationManager.requestLocationUpdates(provider, 1000L, 0f, locationListener, Looper.getMainLooper());
            }
        } catch (Exception ignored) { }
    }

    private void registerWifiReceiver() {
        if (wifiReceiverRegistered) return;
        IntentFilter filter = new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(wifiReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(wifiReceiver, filter);
        wifiReceiverRegistered = true;
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(wifiRunnable);
        if (locationManager != null) {
            try { locationManager.removeUpdates(locationListener); } catch (Exception ignored) { }
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) { }
        }
        if (wifiReceiverRegistered) {
            try { unregisterReceiver(wifiReceiver); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
