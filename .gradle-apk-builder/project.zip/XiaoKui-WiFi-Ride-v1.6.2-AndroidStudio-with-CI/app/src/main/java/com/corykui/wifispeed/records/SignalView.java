package com.corykui.wifispeed.records;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.wifi.ScanResult;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class SignalView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<ScanResult> results = new ArrayList<>();

    public SignalView(Context context) { super(context); }
    public SignalView(Context context, AttributeSet attrs) { super(context, attrs); }

    public void setResults(List<ScanResult> scanResults) {
        results.clear();
        if (scanResults != null) {
            int limit = Math.min(10, scanResults.size());
            results.addAll(scanResults.subList(0, limit));
        }
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        paint.setColor(0xFFF8F9FD);
        canvas.drawRoundRect(new RectF(0, 0, w, h), 28, 28, paint);

        paint.setStrokeWidth(2f);
        paint.setColor(0xFFE0E4EE);
        for (int i = 1; i < 5; i++) {
            float y = h * i / 5f;
            canvas.drawLine(24, y, w - 24, y, paint);
        }

        if (results.isEmpty()) {
            paint.setColor(0xFF7A8294);
            paint.setTextSize(38f);
            paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("等待 Wi‑Fi 扫描结果", w / 2f, h / 2f, paint);
            return;
        }

        float gap = (w - 60) / results.size();
        for (int i = 0; i < results.size(); i++) {
            ScanResult r = results.get(i);
            float level = Math.max(0f, Math.min(1f, (r.level + 100f) / 70f));
            float barH = (h - 90) * level;
            float left = 30 + i * gap + gap * 0.18f;
            float right = 30 + (i + 1) * gap - gap * 0.18f;
            float top = h - 50 - barH;

            int alpha = 150 + (int)(105 * level);
            paint.setColor((alpha << 24) | 0x003157D5);
            canvas.drawRoundRect(new RectF(left, top, right, h - 50), 14, 14, paint);

            paint.setColor(0xFF3D4350);
            paint.setTextSize(22f);
            paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText(String.valueOf(r.level), (left + right) / 2f, h - 18, paint);
        }
    }
}
