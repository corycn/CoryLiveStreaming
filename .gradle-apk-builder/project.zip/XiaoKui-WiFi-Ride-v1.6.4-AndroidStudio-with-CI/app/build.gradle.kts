plugins {
    id("com.android.application")
}

android {
    namespace = "com.corykui.wifispeed.records"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.corykui.wifispeed.records"
        minSdk = 23
        targetSdk = 35
        versionCode = 48
        versionName = "1.6.4"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}
