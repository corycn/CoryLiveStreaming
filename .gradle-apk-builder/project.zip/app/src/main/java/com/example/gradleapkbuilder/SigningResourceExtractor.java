package com.example.gradleapkbuilder;

import android.content.Context;
import android.util.Base64;

import java.io.*;
import java.security.MessageDigest;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.*;

/**
 * Extracts private signing packages/keystores or public signing certificates from
 * ZIP/APK/AAB/JAR resource packages. A public certificate never contains the
 * private signing key and therefore cannot be imported as an APK signing key.
 */
final class SigningResourceExtractor {
    interface Progress {
        void onProgress(String message,long done,long total);
        boolean isCancelled();
    }

    static final class Result {
        final File workDir;
        final File privatePackage;
        final List<File> rawKeyStores;
        final File publicCertificateBundle;
        final int publicCertificateCount;
        final String sourceName;

        Result(File workDir,File privatePackage,List<File> rawKeyStores,
               File publicCertificateBundle,int publicCertificateCount,String sourceName){
            this.workDir=workDir;this.privatePackage=privatePackage;
            this.rawKeyStores=Collections.unmodifiableList(new ArrayList<>(rawKeyStores));
            this.publicCertificateBundle=publicCertificateBundle;
            this.publicCertificateCount=publicCertificateCount;this.sourceName=sourceName;
        }
        boolean hasPrivatePackage(){return privatePackage!=null&&privatePackage.isFile();}
        boolean hasRawKeyStore(){return !rawKeyStores.isEmpty();}
        boolean hasPublicCertificates(){return publicCertificateBundle!=null&&publicCertificateBundle.isFile();}
        void cleanup(){deleteRecursive(workDir);}
        String summary(){
            StringBuilder s=new StringBuilder();
            if(hasPrivatePackage())s.append("✓ 找到包含私钥的完整签名证书包，可直接导入用于 APK 签名。\n");
            if(hasRawKeyStore())s.append("✓ 找到 ").append(rawKeyStores.size()).append(" 个 keystore，需要输入密码与别名后导入。\n");
            if(hasPublicCertificates())s.append("✓ 提取到 ").append(publicCertificateCount).append(" 张公开 X.509 签名证书。\n");
            if(!hasPrivatePackage()&&!hasRawKeyStore()&&!hasPublicCertificates())s.append("没有发现可识别的签名材料。\n");
            return s.toString().trim();
        }
    }

    private static final Set<String> KEY_EXTENSIONS=new HashSet<>(Arrays.asList(
            ".jks",".keystore",".p12",".pfx",".pkcs12"));
    private static final Set<String> ARCHIVE_EXTENSIONS=new HashSet<>(Arrays.asList(
            ".zip",".apk",".aab",".jar",".apks",".xapk",".aar"));

    static Result inspect(Context context,InputStream source,String sourceName,
                          RuntimeBundleManager runtime,Progress progress)throws Exception{
        if(source==null)throw new IOException("无法打开资源包");
        File work=new File(context.getCacheDir(),"signing-resource-"+System.currentTimeMillis());
        mkdirs(work);
        File original=new File(work,"resource-package.bin");
        try{
            long copied=copy(source,new FileOutputStream(original),progress,"正在复制资源包…",-1);
            update(progress,"正在扫描资源包…",copied,Math.max(copied,1));
            File extracted=new File(work,"extracted");mkdirs(extracted);
            ScanState state=new ScanState();
            String sourceExtension=extension(sourceName==null?"":sourceName.toLowerCase(Locale.US));
            if(KEY_EXTENSIONS.contains(sourceExtension)){
                File raw=new File(extracted,"extracted"+sourceExtension);copyFile(original,raw);state.keyStores.add(raw);
            }else if(isZip(original)){
                scanZip(original,extracted,0,state,progress);
            }

            File privatePackage=createPrivatePackageIfPossible(work,state);
            LinkedHashSet<X509Certificate> certificates=new LinkedHashSet<>();
            for(File block:state.signatureBlocks)readCertificates(block,certificates);
            String lower=sourceName==null?"":sourceName.toLowerCase(Locale.US);
            if((lower.endsWith(".apk")||lower.endsWith(".aab")||lower.endsWith(".jar"))&&runtime!=null){
                try{readCertificatesWithApksigner(original,runtime,certificates);}catch(Exception ignored){}
            }
            File publicBundle=certificates.isEmpty()?null:createPublicCertificateBundle(work,certificates,sourceName);
            ArrayList<File> raw=new ArrayList<>();
            for(File f:state.keyStores)if(privatePackage==null||!sameFile(f,privatePackage))raw.add(f);
            update(progress,"签名材料扫描完成",1,1);
            return new Result(work,privatePackage,raw,publicBundle,certificates.size(),sourceName);
        }catch(Exception e){deleteRecursive(work);throw e;}
    }

    static File createPortablePackage(File output,File keyStore,String storePassword,
                                      String alias,String keyPassword,String storeType)throws Exception{
        if(keyStore==null||!keyStore.isFile())throw new IOException("keystore 文件不存在");
        Properties p=new Properties();
        String ext=extension(keyStore.getName());if(ext.isEmpty())ext=".jks";
        String storeName="extracted-keystore"+ext;
        p.setProperty("storeFile",storeName);
        p.setProperty("storePassword",storePassword==null?"":storePassword);
        p.setProperty("keyAlias",alias==null?"":alias.trim());
        p.setProperty("keyPassword",keyPassword==null||keyPassword.isEmpty()?storePassword:keyPassword);
        if(storeType!=null&&!storeType.trim().isEmpty())p.setProperty("storeType",storeType.trim());
        ByteArrayOutputStream props=new ByteArrayOutputStream();p.store(props,"Extracted by GradleApkBuilder");
        try(ZipOutputStream zip=new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(output)))){
            zip.putNextEntry(new ZipEntry("signing.properties"));zip.write(props.toByteArray());zip.closeEntry();
            zip.putNextEntry(new ZipEntry(storeName));
            try(InputStream in=new BufferedInputStream(new FileInputStream(keyStore))){byte[] b=new byte[65536];int n;while((n=in.read(b))>=0)zip.write(b,0,n);}
            zip.closeEntry();
        }
        return output;
    }

    private static final class ScanState {
        final List<File> properties=new ArrayList<>();
        final List<File> keyStores=new ArrayList<>();
        final List<File> signatureBlocks=new ArrayList<>();
        long entries;
    }

    private static void scanZip(File archive,File destination,int depth,ScanState state,Progress progress)throws Exception{
        if(depth>2)return;
        try(ZipFile zip=new ZipFile(archive)){
            Enumeration<? extends ZipEntry> entries=zip.entries();
            while(entries.hasMoreElements()){
                checkCancelled(progress);
                ZipEntry entry=entries.nextElement();state.entries++;
                if(entry.isDirectory())continue;
                String safe=safeName(entry.getName());
                String base=new File(safe).getName();String lower=base.toLowerCase(Locale.US);
                String ext=extension(lower);
                boolean interesting="signing.properties".equals(lower)||KEY_EXTENSIONS.contains(ext)
                        ||isSignatureBlock(safe)||ARCHIVE_EXTENSIONS.contains(ext);
                if(!interesting)continue;
                if(entry.getSize()>512L*1024*1024)continue;
                File out=new File(destination,"d"+depth+"-"+state.entries+"-"+base);
                mkdirs(out.getParentFile());
                try(InputStream in=zip.getInputStream(entry);OutputStream os=new BufferedOutputStream(new FileOutputStream(out))){byte[] b=new byte[65536];int n;while((n=in.read(b))>=0)os.write(b,0,n);}
                if("signing.properties".equals(lower))state.properties.add(out);
                else if(KEY_EXTENSIONS.contains(ext))state.keyStores.add(out);
                else if(isSignatureBlock(safe))state.signatureBlocks.add(out);
                if(ARCHIVE_EXTENSIONS.contains(ext)&&isZip(out))scanZip(out,destination,depth+1,state,progress);
                update(progress,"正在扫描："+base,state.entries,-1);
            }
        }
    }

    private static File createPrivatePackageIfPossible(File work,ScanState state)throws Exception{
        for(File propsFile:state.properties){
            Properties p=new Properties();try(InputStream in=new FileInputStream(propsFile)){p.load(in);}
            String requested=new File(p.getProperty("storeFile","")).getName();
            File store=null;
            for(File candidate:state.keyStores)if(candidate.getName().equals(requested)||candidate.getName().endsWith("-"+requested)){store=candidate;break;}
            if(store==null&&state.keyStores.size()==1)store=state.keyStores.get(0);
            if(store==null)continue;
            String password=p.getProperty("storePassword","");String alias=p.getProperty("keyAlias","");
            if(password.isEmpty()||alias.trim().isEmpty())continue;
            File out=new File(work,"extracted-private-signing-package.zip");
            return createPortablePackage(out,store,password,alias,p.getProperty("keyPassword",password),p.getProperty("storeType",""));
        }
        return null;
    }

    private static void readCertificates(File block,Set<X509Certificate> output){
        try(InputStream in=new BufferedInputStream(new FileInputStream(block))){
            CertificateFactory factory=CertificateFactory.getInstance("X.509");
            Collection<? extends Certificate> all=factory.generateCertificates(in);
            for(Certificate c:all)if(c instanceof X509Certificate)output.add((X509Certificate)c);
        }catch(Exception ignored){}
    }

    private static void readCertificatesWithApksigner(File packageFile,RuntimeBundleManager runtime,
                                                       Set<X509Certificate> output)throws Exception{
        File java=runtime.getJavaExecutable(),jar=runtime.getApksignerJar();
        if(java==null||jar==null)return;
        ArrayList<String> command=new ArrayList<>();Collections.addAll(command,java.getAbsolutePath(),"-jar",jar.getAbsolutePath(),"verify","--print-certs-pem",packageFile.getAbsolutePath());
        ProcessBuilder pb=new ProcessBuilder(command).redirectErrorStream(true);
        File home=runtime.getActiveJdkHome(),prefix=runtime.getActiveJdkPrefix();
        if(home!=null)pb.environment().put("JAVA_HOME",home.getAbsolutePath());
        if(prefix!=null){File tmp=new File(prefix,"tmp");tmp.mkdirs();pb.environment().put("TMPDIR",tmp.getAbsolutePath());}
        String libs=runtime.getJavaLibraryPath();if(!libs.isEmpty())pb.environment().put("LD_LIBRARY_PATH",libs);
        Process process=pb.start();ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        try(InputStream in=process.getInputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))>=0){if(bytes.size()<4_000_000)bytes.write(b,0,n);}}
        if(!process.waitFor(90,TimeUnit.SECONDS)){process.destroyForcibly();return;}
        String text=bytes.toString("UTF-8");
        Matcher matcher=Pattern.compile("-----BEGIN CERTIFICATE-----[\\s\\S]*?-----END CERTIFICATE-----").matcher(text);
        CertificateFactory factory=CertificateFactory.getInstance("X.509");
        while(matcher.find())try(InputStream in=new ByteArrayInputStream(matcher.group().getBytes("US-ASCII"))){Certificate c=factory.generateCertificate(in);if(c instanceof X509Certificate)output.add((X509Certificate)c);}
    }

    private static File createPublicCertificateBundle(File work,Collection<X509Certificate> certificates,String sourceName)throws Exception{
        File out=new File(work,"extracted-public-certificates.zip");
        try(ZipOutputStream zip=new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(out)))){
            int index=0;StringBuilder info=new StringBuilder();
            for(X509Certificate cert:certificates){
                index++;byte[] der=cert.getEncoded();String base="certificate-"+index;
                zip.putNextEntry(new ZipEntry(base+".cer"));zip.write(der);zip.closeEntry();
                String pem="-----BEGIN CERTIFICATE-----\n"+wrap(Base64.encodeToString(der,Base64.NO_WRAP),64)+"\n-----END CERTIFICATE-----\n";
                zip.putNextEntry(new ZipEntry(base+".pem"));zip.write(pem.getBytes("US-ASCII"));zip.closeEntry();
                info.append(base).append("\nSubject: ").append(cert.getSubjectX500Principal()).append("\nIssuer: ").append(cert.getIssuerX500Principal())
                        .append("\nSHA-256: ").append(hex(MessageDigest.getInstance("SHA-256").digest(der))).append("\n\n");
            }
            String note="Source: "+(sourceName==null?"resource package":sourceName)+"\n\n"
                    +"These are PUBLIC X.509 certificates only. They do not contain a private key and cannot be used to sign or update an APK.\n\n"+info;
            zip.putNextEntry(new ZipEntry("certificate-info.txt"));zip.write(note.getBytes("UTF-8"));zip.closeEntry();
        }
        return out;
    }

    private static void copyFile(File source,File destination)throws IOException{
        try(InputStream in=new BufferedInputStream(new FileInputStream(source));OutputStream out=new BufferedOutputStream(new FileOutputStream(destination))){byte[] b=new byte[65536];int n;while((n=in.read(b))>=0)out.write(b,0,n);}
    }

    private static boolean isSignatureBlock(String name){String upper=name.toUpperCase(Locale.US);return upper.startsWith("META-INF/")&&(upper.endsWith(".RSA")||upper.endsWith(".DSA")||upper.endsWith(".EC"));}
    private static boolean isZip(File file){try(ZipFile ignored=new ZipFile(file)){return true;}catch(Exception e){return false;}}
    private static String extension(String name){int dot=name.lastIndexOf('.');return dot<0?"":name.substring(dot).toLowerCase(Locale.US);}
    private static String safeName(String name)throws IOException{String n=name.replace('\\','/');if(n.startsWith("/")||n.contains("../")||n.equals(".."))throw new IOException("资源包包含不安全路径");return n;}
    private static void checkCancelled(Progress progress)throws InterruptedIOException{if(progress!=null&&progress.isCancelled())throw new InterruptedIOException("用户已取消提取");}
    private static void update(Progress progress,String message,long done,long total)throws InterruptedIOException{checkCancelled(progress);if(progress!=null)progress.onProgress(message,done,total);}
    private static long copy(InputStream in,OutputStream out,Progress progress,String message,long total)throws IOException{
        try(InputStream source=in;OutputStream destination=out){byte[] b=new byte[65536];int n;long done=0,last=0;while((n=source.read(b))>=0){checkCancelled(progress);destination.write(b,0,n);done+=n;if(done-last>=1024*1024){update(progress,message,done,total);last=done;}}update(progress,message,done,total);return done;}
    }
    private static void mkdirs(File file)throws IOException{if(file!=null&&!file.exists()&&!file.mkdirs())throw new IOException("无法创建目录："+file);}
    private static String wrap(String text,int width){StringBuilder out=new StringBuilder();for(int i=0;i<text.length();i+=width){if(out.length()>0)out.append('\n');out.append(text, i, Math.min(text.length(),i+width));}return out.toString();}
    private static String hex(byte[] bytes){StringBuilder out=new StringBuilder();for(byte b:bytes){if(out.length()>0)out.append(':');out.append(String.format(Locale.US,"%02X",b));}return out.toString();}
    private static boolean sameFile(File a,File b){try{return a.getCanonicalFile().equals(b.getCanonicalFile());}catch(Exception e){return a.equals(b);}}
    private static void deleteRecursive(File file){if(file==null||!file.exists())return;if(file.isDirectory()){File[] children=file.listFiles();if(children!=null)for(File child:children)deleteRecursive(child);}file.delete();}
}
