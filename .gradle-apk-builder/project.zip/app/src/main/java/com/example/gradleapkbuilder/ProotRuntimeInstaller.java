package com.example.gradleapkbuilder;

import android.os.Build;
import org.apache.commons.compress.archivers.ar.ArArchiveEntry;
import org.apache.commons.compress.archivers.ar.ArArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream;

import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.regex.*;

/** Installs an Android-native Termux PRoot plus an official Alpine mini rootfs. */
final class ProotRuntimeInstaller {
    interface Progress { void onProgress(String message,long done,long total); }

    private static final String TERMUX_PACKAGES =
            "https://packages.termux.dev/apt/termux-main/dists/stable/main/binary-aarch64/Packages.xz";
    private static final String TERMUX_BASE = "https://packages.termux.dev/apt/termux-main/";
    private static final String ALPINE_INDEX =
            "https://dl-cdn.alpinelinux.org/alpine/latest-stable/releases/aarch64/";

    static void install(File bundleDir, File downloadsDir, Progress progress) throws Exception {
        if (!Arrays.asList(Build.SUPPORTED_ABIS).contains("arm64-v8a")) {
            throw new IOException("PRoot 自动安装首版仅支持 arm64-v8a 设备");
        }
        mkdirs(downloadsDir);
        File staging = new File(bundleDir.getParentFile(), "proot-staging-" + System.currentTimeMillis());
        deleteTree(staging); mkdirs(staging);
        File prefix = new File(staging, "termux-prefix"); mkdirs(prefix);
        File rootfs = new File(staging, "rootfs"); mkdirs(rootfs);
        try {
            if (progress != null) progress.onProgress("正在查询 Termux 官方 PRoot 软件包…",0,-1);
            byte[] packagesXz = getBytes(TERMUX_PACKAGES, "application/octet-stream", 20_000_000);
            String packages = decompressXzText(packagesXz);
            Map<String,Pkg> all = parsePackages(packages);
            LinkedHashSet<String> wanted = new LinkedHashSet<>();
            resolve("proot", all, wanted);
            int index=0;
            for (String name : wanted) {
                Pkg pkg=all.get(name); if(pkg==null) continue;
                index++;
                File deb=new File(downloadsDir,name+"_"+pkg.version+".deb.part");
                download(new URL(TERMUX_BASE + pkg.filename), deb, progress,
                        "["+index+"/"+wanted.size()+"] 下载 Termux "+name+"…");
                verifySha256(deb,pkg.sha256);
                extractDeb(deb,prefix,progress,name);
                deb.delete();
            }
            File proot=findNamed(prefix,"proot");
            if(proot==null||!proot.isFile()) throw new IOException("Termux 软件包已解压，但未找到 proot");
            File actualPrefix=proot.getParentFile()==null?null:proot.getParentFile().getParentFile();
            if(actualPrefix==null)throw new IOException("无法识别 Termux PREFIX 目录");
            if(!actualPrefix.getCanonicalFile().equals(prefix.getCanonicalFile())){
                File normalized=new File(staging,"termux-prefix-normalized");deleteTree(normalized);copyTree(actualPrefix,normalized);
                deleteTree(prefix);if(!normalized.renameTo(prefix)){copyTree(normalized,prefix);deleteTree(normalized);}
                proot=findNamed(prefix,"proot");
            }

            if(progress!=null)progress.onProgress("正在查询 Alpine 官方 ARM64 mini rootfs…",0,-1);
            String html=new String(getBytes(ALPINE_INDEX,"text/html",2_000_000),"UTF-8");
            String rootName=findLatestMiniRootfs(html);
            String rootUrl=ALPINE_INDEX+rootName;
            String checksumText=new String(getBytes(rootUrl+".sha256","text/plain",4096),"UTF-8");
            String rootSha=checksumText.trim().split("\\s+")[0];
            File rootArchive=new File(downloadsDir,rootName+".part");
            download(new URL(rootUrl),rootArchive,progress,"正在下载 Alpine Linux rootfs…");
            verifySha256(rootArchive,rootSha);
            extractTarGz(rootArchive,rootfs,progress); rootArchive.delete();
            if(!new File(rootfs,"bin/sh").isFile()) throw new IOException("rootfs 解压完成但缺少 /bin/sh");

            Properties p=new Properties();
            p.setProperty("version","Termux-proot + "+rootName.replace(".tar.gz",""));
            p.setProperty("abi","arm64-v8a");
            p.setProperty("prootPackage",all.get("proot").version);
            p.setProperty("rootfs",rootName);
            p.setProperty("source","packages.termux.dev + dl-cdn.alpinelinux.org");
            p.setProperty("jdk","使用 components/jdk 或 rootfs 内自备 JDK");
            p.setProperty("androidSdk","使用 components/android-sdk");
            try(OutputStream out=new FileOutputStream(new File(staging,"bundle.properties"))){p.store(out,"GradleApkBuilder PRoot runtime");}

            markExecutables(prefix);
            deleteTree(bundleDir);
            if(!staging.renameTo(bundleDir)){copyTree(staging,bundleDir);deleteTree(staging);}
            if(progress!=null)progress.onProgress("PRoot Linux 兼容环境安装完成",1,1);
        } catch(Exception e) { deleteTree(staging); throw e; }
    }

    private static final class Pkg {String name,version,filename,sha256,depends;}
    private static Map<String,Pkg> parsePackages(String text){
        LinkedHashMap<String,Pkg> map=new LinkedHashMap<>();
        for(String block:text.split("\\n\\n+")){
            Pkg p=new Pkg();
            for(String line:block.split("\\n")){
                int c=line.indexOf(':'); if(c<1)continue;
                String k=line.substring(0,c),v=line.substring(c+1).trim();
                if(k.equals("Package"))p.name=v; else if(k.equals("Version"))p.version=v;
                else if(k.equals("Filename"))p.filename=v; else if(k.equals("SHA256"))p.sha256=v;
                else if(k.equals("Depends"))p.depends=v;
            }
            if(p.name!=null&&p.filename!=null&&p.sha256!=null)map.put(p.name,p);
        }
        return map;
    }
    private static void resolve(String name,Map<String,Pkg> all,LinkedHashSet<String> out)throws IOException{
        name=name.trim().replaceAll("\\s*\\(.*?\\)","");
        if(name.contains("|"))name=name.substring(0,name.indexOf('|')).trim();
        if(name.isEmpty()||out.contains(name)||name.startsWith("libc"))return;
        Pkg p=all.get(name); if(p==null)throw new IOException("Termux 软件源缺少依赖："+name);
        if(p.depends!=null)for(String d:p.depends.split(","))resolve(d,all,out);
        out.add(name);
    }
    private static String findLatestMiniRootfs(String html)throws IOException{
        Matcher m=Pattern.compile("alpine-minirootfs-([0-9]+\\.[0-9]+\\.[0-9]+)-aarch64\\.tar\\.gz").matcher(html);
        String best=null,bestVer=null;
        while(m.find()){String file=m.group(),ver=m.group(1);if(best==null||compare(ver,bestVer)>0){best=file;bestVer=ver;}}
        if(best==null)throw new IOException("Alpine 官方目录中未找到 ARM64 mini rootfs");
        return best;
    }
    private static int compare(String a,String b){String[]x=a.split("\\."),y=b.split("\\.");for(int i=0;i<Math.max(x.length,y.length);i++){int p=i<x.length?Integer.parseInt(x[i]):0,q=i<y.length?Integer.parseInt(y[i]):0;if(p!=q)return Integer.compare(p,q);}return 0;}

    private static void extractDeb(File deb,File prefix,Progress progress,String name)throws Exception{
        try(ArArchiveInputStream ar=new ArArchiveInputStream(new BufferedInputStream(new FileInputStream(deb)))){
            ArArchiveEntry e;boolean found=false;
            while((e=ar.getNextArEntry())!=null){String n=e.getName();if(n.startsWith("data.tar")){found=true;InputStream data=ar;if(n.endsWith(".xz"))data=new XZCompressorInputStream(ar,true);else if(n.endsWith(".gz"))data=new GzipCompressorInputStream(ar,true);extractTar(data,prefix,progress,"解压 "+name);break;}}
            if(!found)throw new IOException(name+" DEB 中没有 data.tar");
        }
    }
    private static void extractTarGz(File archive,File root,Progress p)throws Exception{try(InputStream in=new GzipCompressorInputStream(new BufferedInputStream(new FileInputStream(archive)),true)){extractTar(in,root,p,"解压 Linux rootfs");}}
    private static void extractTar(InputStream in,File root,Progress p,String message)throws Exception{
        try(TarArchiveInputStream tar=new TarArchiveInputStream(in)){TarArchiveEntry e;byte[]b=new byte[65536];long count=0;while((e=tar.getNextTarEntry())!=null){String name=safe(e.getName());if(name.isEmpty())continue;File dst=new File(root,name);inside(root,dst);if(e.isDirectory())mkdirs(dst);else if(e.isSymbolicLink()){mkdirs(dst.getParentFile());try{android.system.Os.symlink(e.getLinkName(),dst.getAbsolutePath());}catch(Exception ignored){}}else{mkdirs(dst.getParentFile());try(OutputStream out=new FileOutputStream(dst)){int n;while((n=tar.read(b))>=0)out.write(b,0,n);}if((e.getMode()&0111)!=0)chmod(dst);}count++;if(p!=null&&count%50==0)p.onProgress(message+"…",count,-1);}}}
    private static String decompressXzText(byte[] bytes)throws Exception{try(InputStream in=new XZCompressorInputStream(new ByteArrayInputStream(bytes),true);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[]b=new byte[16384];int n;while((n=in.read(b))>=0)out.write(b,0,n);return out.toString("UTF-8");}}
    private static byte[] getBytes(String u,String accept,int max)throws Exception{URL cur=new URL(u);for(int r=0;r<8;r++){HttpURLConnection c=(HttpURLConnection)cur.openConnection();c.setConnectTimeout(25000);c.setReadTimeout(90000);c.setInstanceFollowRedirects(false);c.setRequestProperty("User-Agent","GradleApkBuilder/1.6.0");c.setRequestProperty("Accept",accept);int code=c.getResponseCode();if(code>=300&&code<400){String l=c.getHeaderField("Location");c.disconnect();if(l==null)throw new IOException("重定向缺少地址");cur=new URL(cur,l);continue;}if(code<200||code>=300)throw new IOException("HTTP "+code+"："+cur);try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[]b=new byte[16384];int n;while((n=in.read(b))>=0){out.write(b,0,n);if(out.size()>max)throw new IOException("下载内容过大");}return out.toByteArray();}finally{c.disconnect();}}throw new IOException("重定向次数过多");}
    private static void download(URL url,File dst,Progress p,String msg)throws Exception{URL cur=url;for(int r=0;r<8;r++){HttpURLConnection c=(HttpURLConnection)cur.openConnection();c.setConnectTimeout(25000);c.setReadTimeout(120000);c.setInstanceFollowRedirects(false);c.setRequestProperty("User-Agent","GradleApkBuilder/1.6.0");int code=c.getResponseCode();if(code>=300&&code<400){String l=c.getHeaderField("Location");c.disconnect();if(l==null)throw new IOException("重定向缺少地址");cur=new URL(cur,l);continue;}if(code<200||code>=300)throw new IOException("下载失败 HTTP "+code+"："+cur);long total=c.getContentLengthLong(),done=0;try(InputStream in=c.getInputStream();OutputStream out=new FileOutputStream(dst)){byte[]b=new byte[65536];int n;while((n=in.read(b))>=0){out.write(b,0,n);done+=n;if(p!=null)p.onProgress(msg,done,total);}}finally{c.disconnect();}return;}throw new IOException("下载重定向次数过多");}
    private static void verifySha256(File f,String expected)throws Exception{String actual=sha256(f);if(!actual.equalsIgnoreCase(expected))throw new SecurityException("下载文件 SHA-256 校验失败\n期望："+expected+"\n实际："+actual);}
    private static String sha256(File f)throws Exception{MessageDigest d=MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(f)){byte[]b=new byte[65536];int n;while((n=in.read(b))>=0)d.update(b,0,n);}StringBuilder s=new StringBuilder();for(byte x:d.digest())s.append(String.format(Locale.US,"%02x",x));return s.toString();}
    private static File findNamed(File f,String name){if(f==null||!f.exists())return null;if(f.isFile()&&f.getName().equals(name))return f;File[]a=f.listFiles();if(a!=null)for(File x:a){File r=findNamed(x,name);if(r!=null)return r;}return null;}
    private static void markExecutables(File f){if(f==null||!f.exists())return;if(f.isDirectory()){File[]a=f.listFiles();if(a!=null)for(File x:a)markExecutables(x);}else{File p=f.getParentFile();if((p!=null&&p.getName().equals("bin"))||f.getName().equals("proot"))chmod(f);}}
    private static void chmod(File f){try{android.system.Os.chmod(f.getAbsolutePath(),0755);}catch(Throwable ignored){f.setExecutable(true,false);}}
    private static String safe(String n)throws IOException{n=n.replace('\\','/');while(n.startsWith("./"))n=n.substring(2);if(n.startsWith("/")||n.contains("../")||n.equals(".."))throw new IOException("压缩包包含不安全路径");return n;}
    private static void inside(File root,File child)throws IOException{String r=root.getCanonicalPath()+File.separator,c=child.getCanonicalPath();if(!c.startsWith(r))throw new IOException("压缩包路径越界");}
    private static void mkdirs(File f)throws IOException{if(f!=null&&!f.exists()&&!f.mkdirs())throw new IOException("无法创建目录："+f);}
    private static void deleteTree(File f)throws IOException{if(f==null||!f.exists())return;if(f.isDirectory()){File[]a=f.listFiles();if(a!=null)for(File x:a)deleteTree(x);}if(!f.delete())throw new IOException("无法删除："+f);}
    private static void copyTree(File s,File d)throws IOException{if(s.isDirectory()){mkdirs(d);File[]a=s.listFiles();if(a!=null)for(File x:a)copyTree(x,new File(d,x.getName()));}else{mkdirs(d.getParentFile());try(InputStream in=new FileInputStream(s);OutputStream out=new FileOutputStream(d)){byte[]b=new byte[65536];int n;while((n=in.read(b))>=0)out.write(b,0,n);}}}
}
