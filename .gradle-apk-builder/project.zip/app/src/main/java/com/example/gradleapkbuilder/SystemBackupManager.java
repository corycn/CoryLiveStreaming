package com.example.gradleapkbuilder;

import android.content.Context;
import android.os.Build;
import android.system.Os;
import android.system.OsConstants;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;
import java.util.zip.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

final class SystemBackupManager {
    interface Progress { void onProgress(String message); }
    interface ExportProgress {
        void onProgress(String message, long done, long total);
        boolean isCancelled();
    }
    private static final class Counter {
        long done;
        final long sourceTotal;
        long lastReportAt;
        long lastReportBytes;
        Counter(long total){sourceTotal=Math.max(1,total);}
        void report(ExportProgress progress,String message,boolean force){
            if(progress==null)return;
            long now=System.currentTimeMillis();
            if(force||done-lastReportBytes>=2L*1024*1024||now-lastReportAt>=250){
                lastReportAt=now;lastReportBytes=done;
                progress.onProgress(message,Math.min(done,sourceTotal),sourceTotal);
            }
        }
    }
    private static final class ScanCounter {
        long files,bytes,lastReportAt;
        void report(ExportProgress progress,String path)throws InterruptedIOException{
            checkCancelled(progress);
            long now=System.currentTimeMillis();
            if(progress!=null&&(files%250==0||now-lastReportAt>=300)){
                lastReportAt=now;
                progress.onProgress("正在统计备份内容："+path,bytes,0);
            }
        }
    }
    private static final byte[] MAGIC = new byte[]{'G','A','P','B','A','K','1','\n'};
    private final Context context;
    private final SecureSettings settings;

    SystemBackupManager(Context context, SecureSettings settings) {
        this.context = context.getApplicationContext();
        this.settings = settings;
    }

    void exportAll(OutputStream destination, char[] password, ExportProgress progress) throws Exception {
        if (destination == null) throw new IOException("无法打开备份输出文件");
        if (password == null || password.length < 6) throw new IOException("备份密码至少需要 6 位");
        ScanCounter scan=new ScanCounter();
        long sourceTotal=sizeOfNoFollow(context.getFilesDir(),progress,scan);
        File project=new File(context.getCacheDir(),"imported-project.zip");
        if(project.isFile()){scan.files++;scan.bytes+=project.length();scan.report(progress,"current-project.zip");sourceTotal+=project.length();}
        Counter counter=new Counter(sourceTotal);
        try {
            checkCancelled(progress);
            if(progress!=null)progress.onProgress("正在准备流式加密备份…",0,counter.sourceTotal);
            byte[] salt=new byte[16],iv=new byte[12];
            SecureRandom random=new SecureRandom();random.nextBytes(salt);random.nextBytes(iv);
            SecretKeySpec key=derive(password,salt);
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE,key,new GCMParameterSpec(128,iv));
            BufferedOutputStream buffered=new BufferedOutputStream(destination,256*1024);
            buffered.write(MAGIC);buffered.write(salt);buffered.write(iv);buffered.flush();
            try(CipherOutputStream encrypted=new CipherOutputStream(buffered,cipher);
                ZipOutputStream zip=new ZipOutputStream(new BufferedOutputStream(encrypted,256*1024))){
                zip.setLevel(Deflater.BEST_SPEED);
                writeBackupZip(zip,progress,counter);
                checkCancelled(progress);
                zip.finish();
            }
            counter.done=counter.sourceTotal;
            counter.report(progress,"备份完成",true);
        } finally { Arrays.fill(password, '\0'); }
    }

    void importAll(InputStream source, char[] password, Progress progress) throws Exception {
        if (password == null || password.length < 6) throw new IOException("请输入正确的备份密码");
        File encrypted = File.createTempFile("gap-system-restore-", ".gapbackup", context.getCacheDir());
        File plain = File.createTempFile("gap-system-restore-", ".zip", context.getCacheDir());
        File stage = new File(context.getCacheDir(), "system-restore-stage-" + System.currentTimeMillis());
        try {
            copy(source, new FileOutputStream(encrypted));
            progress.onProgress("正在解密并校验备份…");
            decryptFile(encrypted, plain, password);
            if (!stage.mkdirs()) throw new IOException("无法创建恢复临时目录");
            unzipSecure(plain, stage);
            Properties meta = loadProperties(new File(stage, "backup.properties"));
            int schema;
            try { schema = Integer.parseInt(meta.getProperty("schema", "0")); }
            catch (NumberFormatException e) { throw new IOException("系统备份格式版本无效", e); }
            if (schema < 1 || schema > 2) throw new IOException("不支持的系统备份格式");
            String abi = meta.getProperty("abi", "");
            if (!abi.isEmpty() && !Arrays.asList(Build.SUPPORTED_ABIS).contains(abi)) throw new IOException("备份 ABI 与当前设备不兼容：" + abi);
            progress.onProgress("正在恢复全部程序目录…");
            Properties fileLinks = schema >= 2
                    ? loadProperties(new File(stage, "files-symlinks.properties"))
                    : new Properties();
            restoreFiles(new File(stage, "files"), context.getFilesDir(), fileLinks);
            restoreCacheProject(new File(stage, "current-project.zip"));
            Properties cloud = loadProperties(new File(stage, "cloud.properties"));
            settings.restoreCloud(new SecureSettings.Cloud(cloud.getProperty("owner", ""), cloud.getProperty("repo", ""), cloud.getProperty("branch", "main"), cloud.getProperty("task", "assembleDebug"), cloud.getProperty("token", "")));
            progress.onProgress("恢复完成，正在执行环境自检…");
        } finally {
            encrypted.delete(); plain.delete(); deleteRecursive(stage); Arrays.fill(password, '\0');
        }
    }

    private void writeBackupZip(ZipOutputStream zip, ExportProgress progress, Counter counter) throws Exception {
        Properties meta = new Properties();
        meta.setProperty("schema", "2");
        meta.setProperty("appVersion", BuildConfig.VERSION_NAME);
        meta.setProperty("createdAt", Long.toString(System.currentTimeMillis()));
        meta.setProperty("abi", Build.SUPPORTED_ABIS.length == 0 ? "" : Build.SUPPORTED_ABIS[0]);
        putProperties(zip, "backup.properties", meta);
        SecureSettings.Cloud c = settings.loadCloud();
        Properties cp = new Properties();
        cp.setProperty("owner", c.owner); cp.setProperty("repo", c.repo); cp.setProperty("branch", c.branch); cp.setProperty("task", c.task); cp.setProperty("token", c.token);
        putProperties(zip, "cloud.properties", cp);
        Properties symlinks = new Properties();
        addTree(zip, context.getFilesDir(), "files/", progress, symlinks, counter);
        if (!symlinks.isEmpty()) putProperties(zip, "files-symlinks.properties", symlinks);
        File project = new File(context.getCacheDir(), "imported-project.zip");
        if (project.isFile()) addFile(zip, project, "current-project.zip", progress, counter);
    }

    private void restoreFiles(File source, File destination, Properties symlinks) throws IOException {
        if (!source.exists()) return;
        File backup = new File(context.getCacheDir(), "files-before-restore-" + System.currentTimeMillis());
        if (destination.exists() && !destination.renameTo(backup)) copyTree(destination, backup);
        try {
            if (!destination.exists() && !destination.mkdirs()) throw new IOException("无法创建应用文件目录");
            copyTree(source, destination);
            restoreBackupSymlinks(destination, symlinks);
            restoreExecutableHints(destination);
            deleteRecursive(backup);
        } catch (IOException e) {
            deleteRecursive(destination);
            if (backup.exists() && !backup.renameTo(destination)) copyTree(backup, destination);
            throw e;
        }
    }

    private void restoreCacheProject(File source) throws IOException {
        if (!source.isFile()) return;
        copy(new FileInputStream(source), new FileOutputStream(new File(context.getCacheDir(), "imported-project.zip")));
    }

    private static void restoreExecutableHints(File root) {
        if (root == null || !existsNoFollow(root) || isSymlink(root)) return;
        if (root.isDirectory()) { File[] children = root.listFiles(); if (children != null) for (File c : children) restoreExecutableHints(c); return; }
        String n = root.getName();
        if (n.equals("java") || n.equals("javac") || n.equals("aapt2") || n.equals("aapt") || n.equals("adb") || n.equals("zipalign") || n.equals("proot") || n.equals("gradle") || n.equals("gradlew") || root.getParentFile().getName().equals("bin")) root.setExecutable(true, false);
    }

    private static void addTree(ZipOutputStream zip, File root, String prefix,
                                ExportProgress progress, Properties symlinks,
                                Counter counter) throws IOException {
        checkCancelled(progress);
        if (root == null || !existsNoFollow(root)) return;
        File[] files = root.listFiles(); if (files == null) return;
        for (File f : files) {
            checkCancelled(progress);
            String name = prefix + f.getName();
            if (isSymlink(f)) {
                try { symlinks.setProperty(name, Os.readlink(f.getAbsolutePath())); }
                catch (Exception e) { throw new IOException("无法读取备份符号链接：" + f, e); }
                counter.report(progress,"正在记录符号链接：" + name,false);
            } else if (f.isDirectory()) {
                addTree(zip, f, name + "/", progress, symlinks, counter);
            } else if (f.isFile()) {
                addFile(zip, f, name, progress, counter);
            }
        }
    }

    private static void addFile(ZipOutputStream zip, File file, String name,
                                ExportProgress progress, Counter counter) throws IOException {
        checkCancelled(progress);
        ZipEntry e = new ZipEntry(name); e.setTime(file.lastModified()); zip.putNextEntry(e);
        try (InputStream in = new BufferedInputStream(new FileInputStream(file))) {
            byte[] b = new byte[65536]; int n;
            while ((n=in.read(b))>0) {
                checkCancelled(progress);
                zip.write(b,0,n); counter.done+=n;
                counter.report(progress,"正在压缩并加密："+name,false);
            }
        }
        zip.closeEntry();
        counter.report(progress,"正在压缩并加密："+name,true);
    }

    private static void putProperties(ZipOutputStream zip, String name, Properties p) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream(); p.store(b, "Gradle APK Builder backup");
        zip.putNextEntry(new ZipEntry(name)); zip.write(b.toByteArray()); zip.closeEntry();
    }

    private static Properties loadProperties(File f) throws IOException {
        Properties p = new Properties(); if (!f.isFile()) return p;
        try (InputStream in = new FileInputStream(f)) { p.load(in); } return p;
    }

    private static void unzipSecure(File zipFile, File destination) throws IOException {
        String root = destination.getCanonicalPath() + File.separator;
        try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(new FileInputStream(zipFile)))) {
            ZipEntry e; byte[] b = new byte[65536];
            while ((e=zin.getNextEntry()) != null) {
                File out = new File(destination, e.getName());
                if (!out.getCanonicalPath().startsWith(root)) throw new IOException("备份包含不安全路径");
                if (e.isDirectory()) { if (!out.exists() && !out.mkdirs()) throw new IOException("无法创建目录"); }
                else { File parent=out.getParentFile(); if (!parent.exists() && !parent.mkdirs()) throw new IOException("无法创建目录"); try(OutputStream os=new FileOutputStream(out)){int n;while((n=zin.read(b))>0)os.write(b,0,n);} }
                zin.closeEntry();
            }
        }
    }

    private static void checkCancelled(ExportProgress progress) throws InterruptedIOException {
        if(progress!=null&&progress.isCancelled())throw new InterruptedIOException("用户已取消备份");
    }

    private static long sizeOfNoFollow(File file,ExportProgress progress,ScanCounter scan)throws InterruptedIOException{
        checkCancelled(progress);
        if(file==null||!existsNoFollow(file)||isSymlink(file))return 0;
        scan.files++;
        if(file.isFile()){
            long length=Math.max(0,file.length());scan.bytes+=length;scan.report(progress,file.getName());return length;
        }
        scan.report(progress,file.getName());
        long total=0;File[] children=file.listFiles();if(children!=null)for(File child:children)total+=sizeOfNoFollow(child,progress,scan);return total;
    }

    private static void decryptFile(File encrypted, File plain, char[] password) throws Exception {
        try (InputStream in = new BufferedInputStream(new FileInputStream(encrypted))) {
            byte[] magic=new byte[MAGIC.length]; if(in.read(magic)!=magic.length || !Arrays.equals(magic,MAGIC)) throw new IOException("不是有效的系统备份文件");
            byte[] salt=new byte[16],iv=new byte[12]; if(in.read(salt)!=16||in.read(iv)!=12)throw new IOException("备份文件损坏");
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,derive(password,salt),new GCMParameterSpec(128,iv));
            try(CipherInputStream cis=new CipherInputStream(in,c);OutputStream out=new FileOutputStream(plain)){byte[]b=new byte[65536];int n;while((n=cis.read(b))>0)out.write(b,0,n);} catch(IOException e){throw new IOException("备份密码错误或文件已损坏",e);}
        }
    }

    private static SecretKeySpec derive(char[] password, byte[] salt) throws Exception {
        PBEKeySpec spec=new PBEKeySpec(password,salt,150000,256);
        SecretKeyFactory f;
        try{f=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");}
        catch(Exception unavailable){f=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");}
        return new SecretKeySpec(f.generateSecret(spec).getEncoded(),"AES");
    }

    private static void restoreBackupSymlinks(File filesRoot, Properties links) throws IOException {
        if (links == null || links.isEmpty()) return;
        ArrayList<String> names = new ArrayList<>();
        for (Object key : links.keySet()) names.add(String.valueOf(key));
        Collections.sort(names, (a,b) -> Integer.compare(pathDepth(a), pathDepth(b)));
        String rootPath = filesRoot.getAbsolutePath();
        for (String name : names) {
            String normalized = name.replace('\\','/');
            if (!normalized.startsWith("files/") || normalized.contains("../") || normalized.startsWith("/")) {
                throw new IOException("备份符号链接路径无效：" + name);
            }
            String child = normalized.substring("files/".length());
            if (child.isEmpty()) throw new IOException("备份符号链接路径为空");
            File destination = new File(filesRoot, child);
            String absolute = destination.getAbsolutePath();
            if (!absolute.startsWith(rootPath + File.separator)) throw new IOException("备份符号链接路径越界：" + name);
            File parent = destination.getParentFile();
            ensureNoSymlinkParents(filesRoot, parent);
            if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("无法创建符号链接目录：" + parent);
            deleteNoFollow(destination);
            String target = links.getProperty(name);
            if (target == null || target.indexOf('\0') >= 0) throw new IOException("备份符号链接目标无效：" + name);
            try { Os.symlink(target, destination.getAbsolutePath()); }
            catch (Exception e) { throw new IOException("无法恢复备份符号链接：" + name + " -> " + target, e); }
        }
    }

    private static void ensureNoSymlinkParents(File root, File parent) throws IOException {
        if (parent == null) return;
        String rootPath = root.getAbsolutePath();
        String parentPath = parent.getAbsolutePath();
        if (!parentPath.equals(rootPath) && !parentPath.startsWith(rootPath + File.separator)) {
            throw new IOException("备份符号链接路径越界：" + parent);
        }
        ArrayList<File> chain = new ArrayList<>();
        File current = parent;
        while (current != null && !current.equals(root)) {
            chain.add(current);
            current = current.getParentFile();
        }
        if (current == null) throw new IOException("备份符号链接路径越界：" + parent);
        Collections.reverse(chain);
        for (File item : chain) {
            if (isSymlink(item)) throw new IOException("备份符号链接父目录不安全：" + item);
        }
    }

    private static int pathDepth(String path) {
        int n = 0; for (int i=0;i<path.length();i++) if (path.charAt(i)=='/') n++; return n;
    }

    private static void copyTree(File source, File destination) throws IOException {
        if (isSymlink(source)) {
            File parent = destination.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("无法创建目录："+parent);
            deleteNoFollow(destination);
            try { Os.symlink(Os.readlink(source.getAbsolutePath()), destination.getAbsolutePath()); }
            catch (Exception e) { throw new IOException("无法复制符号链接："+source, e); }
        } else if (source.isDirectory()) {
            if (!destination.exists() && !destination.mkdirs()) throw new IOException("无法创建目录："+destination);
            File[] cs=source.listFiles(); if(cs!=null)for(File c:cs)copyTree(c,new File(destination,c.getName()));
        } else if (source.isFile()) {
            copy(new FileInputStream(source),new FileOutputStream(destination));
        }
    }
    private static void copy(InputStream in, OutputStream out) throws IOException { try(InputStream i=in;OutputStream o=out){byte[]b=new byte[65536];int n;while((n=i.read(b))>0)o.write(b,0,n);} }

    private static boolean existsNoFollow(File file) {
        if (file == null) return false;
        try { Os.lstat(file.getAbsolutePath()); return true; } catch (Throwable ignored) { return false; }
    }
    private static boolean isSymlink(File file) {
        if (file == null) return false;
        try { return OsConstants.S_ISLNK(Os.lstat(file.getAbsolutePath()).st_mode); }
        catch (Throwable ignored) { return false; }
    }
    private static void deleteNoFollow(File file) {
        if (!existsNoFollow(file)) return;
        if (isSymlink(file)) {
            // Deleting a File that represents a symlink removes the link itself,
            // not its target. This also compiles against Android SDK stubs that omit the
            // low-level unlink symbol.
            file.delete();
        } else {
            deleteRecursive(file);
        }
    }
    private static void deleteRecursive(File f){
        if(f==null||!existsNoFollow(f))return;
        if(isSymlink(f)){deleteNoFollow(f);return;}
        if(f.isDirectory()){File[]c=f.listFiles();if(c!=null)for(File x:c)deleteRecursive(x);}
        f.delete();
    }
}
