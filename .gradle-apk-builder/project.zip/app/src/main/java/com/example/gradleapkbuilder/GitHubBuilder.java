package com.example.gradleapkbuilder;

import android.util.Base64;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

final class GitHubBuilder {
    interface Listener { void onStatus(String text); }
    static final String API = "https://api.github.com";

    private final String token, owner, repo, branch;
    private final Listener listener;
    private volatile boolean cancelled;
    private volatile HttpURLConnection activeConnection;
    private volatile Thread workerThread;

    GitHubBuilder(String token, String owner, String repo, String branch, Listener listener) {
        this.token = token.trim(); this.owner = owner.trim(); this.repo = repo.trim();
        this.branch = branch.trim().isEmpty() ? "main" : branch.trim(); this.listener = listener;
    }

    File build(File projectZip, File outputDir) throws Exception {
        workerThread=Thread.currentThread();
        try {
        checkCancelled();
        status("正在检查 GitHub 仓库…");
        request("GET", "/repos/" + enc(owner) + "/" + enc(repo), null, false);

        status("正在写入安全构建工作流…");
        putContent(".github/workflows/gradle-apk-builder.yml", workflow().getBytes(StandardCharsets.UTF_8), "Configure Android APK build");
        status("正在上传工程 ZIP，并通过 push 自动触发 Actions…");
        putContent(".gradle-apk-builder/project.zip", readBytes(projectZip), "Upload Android project for build");
        // 每次写入唯一触发文件，即使工程 ZIP 内容不变也会产生新的 push。
        String trigger = "{\"requestedAt\":" + System.currentTimeMillis() + ",\"nonce\":\"" + UUID.randomUUID() + "\"}";
        String commitSha = putContent(".gradle-apk-builder/trigger.json", trigger.getBytes(StandardCharsets.UTF_8), "Trigger Android project build");

        long runId = waitForRun(commitSha);
        waitForCompletion(runId);
        status("构建成功，正在下载 APK 产物…");
        JSONObject arts = json(request("GET", "/repos/" + enc(owner) + "/" + enc(repo) + "/actions/runs/" + runId + "/artifacts", null, false));
        JSONArray arr = arts.getJSONArray("artifacts");
        if (arr.length() == 0) throw new IOException("构建完成，但没有找到任何 Artifact");
        if (!outputDir.exists() && !outputDir.mkdirs()) throw new IOException("无法创建输出目录");

        // GitHub 不保证 Artifact 数组顺序；gradle-build-log 可能排在 compiled-apks 前面。
        // 先精确选择 compiled-apks，再逐个扫描其他未过期 Artifact 作为兼容兜底。
        ArrayList<JSONObject> candidates = new ArrayList<>();
        ArrayList<String> artifactNames = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject artifact = arr.getJSONObject(i);
            String name = artifact.optString("name", "artifact-" + i);
            artifactNames.add(name);
            if (artifact.optBoolean("expired", false)) continue;
            if ("compiled-apks".equalsIgnoreCase(name)) candidates.add(0, artifact);
            else candidates.add(artifact);
        }

        IOException lastError = null;
        for (JSONObject artifact : candidates) {
            checkCancelled();
            String artifactName = artifact.optString("name", "artifact");
            long artifactId = artifact.getLong("id");
            status("正在检查 Artifact：" + artifactName);
            try {
                byte[] artifactZip = request("GET", "/repos/" + enc(owner) + "/" + enc(repo) + "/actions/artifacts/" + artifactId + "/zip", null, true);
                File zip = new File(outputDir, safeFileName(artifactName) + ".zip");
                write(zip, artifactZip);
                File apk = extractFirstApk(zip, outputDir);
                status("APK 已下载：" + apk.getName());
                return apk;
            } catch (IOException e) {
                checkCancelled();
                lastError = e;
                status("Artifact " + artifactName + " 中没有 APK，继续检查…");
            }
        }
        throw new IOException("所有 Artifact 中均未找到 APK。可用 Artifact：" + artifactNames
                + (lastError == null ? "" : "。最后错误：" + lastError.getMessage()));
        } finally { workerThread=null; activeConnection=null; }
    }

    void cancel() {
        cancelled=true;
        HttpURLConnection connection=activeConnection;
        if(connection!=null)try{connection.disconnect();}catch(Throwable ignored){}
        Thread thread=workerThread;
        if(thread!=null)thread.interrupt();
    }

    private void checkCancelled() throws InterruptedIOException {
        if(cancelled||Thread.currentThread().isInterrupted())throw new InterruptedIOException("用户已取消云端构建");
    }

    private void pause(long millis) throws Exception {
        checkCancelled();
        try{Thread.sleep(millis);}catch(InterruptedException e){Thread.currentThread().interrupt();checkCancelled();throw e;}
        checkCancelled();
    }

    private String putContent(String path, byte[] content, String message) throws Exception {
        String endpoint = "/repos/" + enc(owner) + "/" + enc(repo) + "/contents/" + path;
        String sha = null;
        try { sha = json(request("GET", endpoint + "?ref=" + enc(branch), null, false)).optString("sha", null); }
        catch (HttpError e) { if (e.code != 404) throw e; }
        JSONObject body = new JSONObject()
                .put("message", message)
                .put("branch", branch)
                .put("content", Base64.encodeToString(content, Base64.NO_WRAP));
        if (sha != null && !sha.isEmpty()) body.put("sha", sha);
        JSONObject result = json(request("PUT", endpoint, body.toString().getBytes(StandardCharsets.UTF_8), false));
        JSONObject commit = result.optJSONObject("commit");
        return commit == null ? "" : commit.optString("sha", "");
    }

    private long waitForRun(String commitSha) throws Exception {
        for (int i = 0; i < 40; i++) {
            checkCancelled();
            pause(3000);
            String endpoint = "/repos/" + enc(owner) + "/" + enc(repo) + "/actions/runs?branch=" + enc(branch) + "&event=push&per_page=20";
            JSONObject o = json(request("GET", endpoint, null, false));
            JSONArray runs = o.getJSONArray("workflow_runs");
            for (int j = 0; j < runs.length(); j++) {
                JSONObject run = runs.getJSONObject(j);
                String sha = run.optString("head_sha");
                String name = run.optString("name");
                if ((!commitSha.isEmpty() && commitSha.equals(sha)) ||
                        (commitSha.isEmpty() && "Gradle APK Builder".equals(name))) {
                    return run.getLong("id");
                }
            }
            status("等待 GitHub 接收 push 并创建构建任务… " + (i + 1));
        }
        throw new IOException("未找到由工程上传提交触发的 GitHub Actions 任务。请确认仓库已启用 Actions，令牌具备 Contents 写入和 Actions 读取权限。 ");
    }

    private void waitForCompletion(long runId) throws Exception {
        for (int i = 0; i < 120; i++) {
            checkCancelled();
            JSONObject run = json(request("GET", "/repos/" + enc(owner) + "/" + enc(repo) + "/actions/runs/" + runId, null, false));
            String state = run.optString("status");
            String conclusion = run.optString("conclusion");
            status("云端构建状态：" + state + (conclusion.isEmpty() ? "" : " / " + conclusion));
            if ("completed".equals(state)) {
                if (!"success".equals(conclusion)) {
                    String logs=downloadRunLogTail(runId);
                    throw new IOException("GitHub Actions 构建失败："+conclusion+"\n\nActions 日志末尾：\n"+logs);
                }
                return;
            }
            pause(5000);
        }
        throw new IOException("等待构建超时");
    }


    private String downloadRunLogTail(long runId){
        try{
            byte[] zip=request("GET","/repos/"+enc(owner)+"/"+enc(repo)+"/actions/runs/"+runId+"/logs",null,true);
            ArrayDeque<String> lines=new ArrayDeque<>();
            try(java.util.zip.ZipInputStream zin=new java.util.zip.ZipInputStream(new ByteArrayInputStream(zip))){
                java.util.zip.ZipEntry e;
                while((e=zin.getNextEntry())!=null){
                    if(e.isDirectory())continue;
                    BufferedReader r=new BufferedReader(new InputStreamReader(zin,StandardCharsets.UTF_8));
                    String line;while((line=r.readLine())!=null){lines.addLast(line);while(lines.size()>120)lines.removeFirst();}
                }
            }
            StringBuilder out=new StringBuilder();for(String line:lines)out.append(line).append('\n');
            return out.length()==0?"未能从日志 ZIP 中读取文本。":out.toString();
        }catch(Exception e){return "自动下载日志失败："+e.getMessage()+"。请在仓库 Actions 页面展开失败步骤。";}
    }
    private byte[] request(String method, String path, byte[] body, boolean binary) throws Exception {
        Exception last = null;
        for (int attempt = 1; attempt <= 6; attempt++) {
            checkCancelled();
            try { return requestOnce(method, path, body, binary); }
            catch (UnknownHostException | SocketTimeoutException | ConnectException e) {
                last = e;
                status("网络暂时不可用，正在重试… " + attempt + "/6");
                pause(Math.min(30000L, attempt * 5000L));
            }
        }
        throw new IOException("网络连接多次重试仍失败：" + (last == null ? "未知错误" : last.getMessage()), last);
    }

    private byte[] requestOnce(String method, String path, byte[] body, boolean binary) throws Exception {
        URL url = new URL(path.startsWith("http") ? path : API + path);
        for (int redirects = 0; redirects < 6; redirects++) {
            checkCancelled();
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            activeConnection=c;
            c.setInstanceFollowRedirects(false); c.setConnectTimeout(20000); c.setReadTimeout(120000);
            c.setRequestMethod(method);
            boolean githubApi = "api.github.com".equalsIgnoreCase(url.getHost());
            c.setRequestProperty("Accept", githubApi ? "application/vnd.github+json" : (binary ? "application/octet-stream" : "*/*"));
            if (githubApi) {
                c.setRequestProperty("Authorization", "Bearer " + token);
                c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
            }
            c.setRequestProperty("User-Agent", "GradleApkBuilder-Android");
            if (body != null) { c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json; charset=utf-8"); try (OutputStream out = c.getOutputStream()) { out.write(body); } }
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) { String loc = c.getHeaderField("Location"); c.disconnect(); activeConnection=null; if (loc == null) throw new IOException("重定向缺少地址"); url = new URL(loc); method = "GET"; body = null; continue; }
            InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            byte[] data = in == null ? new byte[0] : readAllCancellable(in);
            c.disconnect(); activeConnection=null;
            checkCancelled();
            if (code < 200 || code >= 300) throw new HttpError(code, new String(data, StandardCharsets.UTF_8));
            return data;
        }
        throw new IOException("重定向次数过多");
    }


    private static String safeFileName(String name) {
        if (name == null || name.trim().isEmpty()) return "artifact";
        return name.replaceAll("[^A-Za-z0-9._-]", "_");
    }

    private static JSONObject json(byte[] bytes) throws JSONException { return new JSONObject(new String(bytes, StandardCharsets.UTF_8)); }
    private static String enc(String s) throws UnsupportedEncodingException { return URLEncoder.encode(s, "UTF-8").replace("+", "%20"); }
    private void status(String s) { if (listener != null) listener.onStatus(s); }
    private byte[] readAllCancellable(InputStream in) throws IOException {
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[32768];int n;
        while((n=in.read(b))>=0){try{checkCancelled();}catch(InterruptedIOException e){throw e;}out.write(b,0,n);}return out.toByteArray();
    }
    private static byte[] readBytes(File f) throws IOException { try (InputStream in = new FileInputStream(f)) { return readAll(in); } }
    private static byte[] readAll(InputStream in) throws IOException { ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] b = new byte[32768]; int n; while ((n = in.read(b)) >= 0) out.write(b, 0, n); return out.toByteArray(); }
    private static void write(File f, byte[] b) throws IOException { try (OutputStream out = new FileOutputStream(f)) { out.write(b); } }

    private static File extractFirstApk(File zip, File dir) throws IOException {
        try (java.util.zip.ZipInputStream in = new java.util.zip.ZipInputStream(new FileInputStream(zip))) {
            java.util.zip.ZipEntry e;
            while ((e = in.getNextEntry()) != null) {
                String name = new File(e.getName()).getName();
                if (!e.isDirectory() && name.toLowerCase(Locale.US).endsWith(".apk")) {
                    File out = new File(dir, name);
                    try (OutputStream os = new FileOutputStream(out)) { byte[] b = new byte[32768]; int n; while ((n = in.read(b)) >= 0) os.write(b, 0, n); }
                    return out;
                }
            }
        }
        throw new IOException("Artifact 中未找到 APK");
    }

    private static String workflow() {
        return "name: Gradle APK Builder\n" +
                "on:\n" +
                "  push:\n" +
                "    paths:\n" +
                "      - '.gradle-apk-builder/project.zip'\n" +
                "      - '.gradle-apk-builder/trigger.json'\n" +
                "      - '.github/workflows/gradle-apk-builder.yml'\n" +
                "  workflow_dispatch:\n" +
                "permissions:\n" +
                "  contents: read\n" +
                "jobs:\n" +
                "  build:\n" +
                "    runs-on: ubuntu-latest\n" +
                "    timeout-minutes: 45\n" +
                "    steps:\n" +
                "      - uses: actions/checkout@v5\n" +
                "      - uses: actions/setup-java@v5\n" +
                "        with:\n" +
                "          distribution: temurin\n" +
                "          java-version: '17'\n" +
                "      - name: Extract and inspect imported project\n" +
                "        run: |\n" +
                "          set -euxo pipefail\n" +
                "          rm -rf imported-project /tmp/imported-gradle\n" +
                "          mkdir imported-project\n" +
                "          unzip -q .gradle-apk-builder/project.zip -d imported-project\n" +
                "          ROOT=$(find imported-project -maxdepth 5 \\( -name settings.gradle -o -name settings.gradle.kts \\) -printf '%h\\n' | head -1)\n" +
                "          test -n \"$ROOT\"\n" +
                "          echo \"PROJECT_ROOT=$ROOT\" >> $GITHUB_ENV\n" +
                "          find \"$ROOT\" -maxdepth 3 -type f | sort | head -200\n" +
                "      - name: Install the project's official Gradle distribution\n" +
                "        run: |\n" +
                "          set -euxo pipefail\n" +
                "          PROP=\"$PROJECT_ROOT/gradle/wrapper/gradle-wrapper.properties\"\n" +
                "          if [ -f \"$PROP\" ]; then\n" +
                "            URL=$(grep '^distributionUrl=' \"$PROP\" | cut -d= -f2- | sed 's#\\\\:#:#g')\n" +
                "          else\n" +
                "            URL=https://services.gradle.org/distributions/gradle-8.9-bin.zip\n" +
                "          fi\n" +
                "          case \"$URL\" in https://services.gradle.org/distributions/*|https://downloads.gradle.org/distributions/*) ;; *) echo '不允许的 Gradle 下载域名'; exit 2;; esac\n" +
                "          curl --fail --location --retry 3 \"$URL\" -o /tmp/gradle.zip\n" +
                "          mkdir -p /tmp/imported-gradle && unzip -q /tmp/gradle.zip -d /tmp/imported-gradle\n" +
                "          GRADLE_BIN=$(find /tmp/imported-gradle -type f -path '*/bin/gradle' -print -quit)\n" +
                "          chmod +x \"$GRADLE_BIN\"\n" +
                "          echo \"GRADLE_BIN=$GRADLE_BIN\" >> $GITHUB_ENV\n" +
                "          \"$GRADLE_BIN\" --version\n" +
                "      - name: Build debug APK\n" +
                "        run: |\n" +
                "          set -o pipefail\n" +
                "          cd \"$PROJECT_ROOT\"\n" +
                "          \"$GRADLE_BIN\" --no-daemon --stacktrace --warning-mode all assembleDebug 2>&1 | tee \"$GITHUB_WORKSPACE/gradle-build.log\"\n" +
                "      - name: Collect APK files\n" +
                "        if: success()\n" +
                "        run: |\n" +
                "          mkdir -p collected-apks\n" +
                "          find \"$PROJECT_ROOT\" -type f -path '*/build/outputs/apk/*.apk' -exec cp {} collected-apks/ \\;\n" +
                "          test -n \"$(find collected-apks -name '*.apk' -print -quit)\"\n" +
                "      - uses: actions/upload-artifact@v6\n" +
                "        if: success()\n" +
                "        with:\n" +
                "          name: compiled-apks\n" +
                "          path: collected-apks/*.apk\n" +
                "          if-no-files-found: error\n" +
                "      - uses: actions/upload-artifact@v6\n" +
                "        if: always()\n" +
                "        with:\n" +
                "          name: gradle-build-log\n" +
                "          path: gradle-build.log\n" +
                "          if-no-files-found: warn\n";
    }

    static final class HttpError extends IOException { final int code; HttpError(int code, String body) { super("GitHub API " + code + ": " + body); this.code = code; } }
}
