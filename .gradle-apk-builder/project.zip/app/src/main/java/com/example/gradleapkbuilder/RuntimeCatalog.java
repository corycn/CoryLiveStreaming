package com.example.gradleapkbuilder;

import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.util.*;

/** Discovers trusted AndroidIDE SDK component archives. */
final class RuntimeCatalog {
    static final String[] DEFAULT_INDEXES = {
            "https://raw.githubusercontent.com/AndroidIDEOfficial/androidide-tools/main/manifest.json",
            "https://cdn.jsdelivr.net/gh/AndroidIDEOfficial/androidide-tools@main/manifest.json"
    };

    static final class ComponentSet {
        final String source, abi, version;
        final LinkedHashMap<String,String> urls = new LinkedHashMap<>();
        ComponentSet(String source, String abi, String version) {
            this.source=source; this.abi=abi; this.version=version;
        }
        String summary(){ return "AndroidIDE SDK 组件 · "+abi+" · Build Tools "+version; }
    }

    interface Status { void onStatus(String message); }

    static ComponentSet discoverComponents(String abi, Status status) throws Exception {
        ArrayList<String> failures=new ArrayList<>();
        for(String index:DEFAULT_INDEXES){
            try{
                if(status!=null)status.onStatus("正在查询可信工具链目录…\n"+host(index));
                JSONObject root=new JSONObject(get(index));
                ComponentSet set=parseAndroidIdeManifest(root,abi,index);
                if(set!=null)return set;
                failures.add(host(index)+"：没有适合 "+abi+" 的组件");
            }catch(Exception e){failures.add(host(index)+"："+clean(e.getMessage()));}
        }
        throw new IOException("无法获取 SDK 组件目录。\n• "+join(failures,"\n• "));
    }

    private static ComponentSet parseAndroidIdeManifest(JSONObject root,String abi,String source)throws Exception{
        if(!root.has("android_sdk")||!root.has("build_tools"))throw new IOException("不支持的目录格式");
        String key;
        if("arm64-v8a".equals(abi))key="aarch64";
        else if(abi.startsWith("armeabi"))key="arm";
        else if("x86_64".equals(abi))key="x86_64";
        else return null;

        JSONObject btAll=root.getJSONObject("build_tools");
        JSONObject bt=btAll.optJSONObject(key);
        JSONObject ptAll=root.optJSONObject("platform_tools");
        JSONObject pt=ptAll==null?null:ptAll.optJSONObject(key);
        if(bt==null||bt.length()==0||pt==null||pt.length()==0)return null;
        String best=bestVersionKey(bt);
        String version=best.replaceFirst("^_","").replace('_','.');
        ComponentSet set=new ComponentSet(source,abi,version);
        putHttps(set.urls,"android-sdk",root.optString("android_sdk"));
        putHttps(set.urls,"cmdline-tools",root.optString("cmdline_tools"));
        putHttps(set.urls,"build-tools",bt.optString(best));
        String ptKey=pt.has(best)?best:bestVersionKey(pt);
        putHttps(set.urls,"platform-tools",pt.optString(ptKey));
        // The public manifest only carries the old AndroidIDE JDK 11 archive.
        // It is downloaded when present, but the UI warns that modern AGP may require JDK 17.
        JSONObject jdk=root.optJSONObject("jdk_11");
        if(jdk!=null){String u=jdk.optString(key,"");if(u.startsWith("https://"))set.urls.put("jdk-11",u);}
        return set;
    }

    private static void putHttps(Map<String,String> m,String name,String u)throws IOException{
        if(u==null||!u.startsWith("https://"))throw new IOException(name+" 下载地址无效");
        m.put(name,u);
    }
    private static String bestVersionKey(JSONObject o){
        String best=null;Iterator<String> it=o.keys();while(it.hasNext()){String k=it.next();if(best==null||compareVersions(k,best)>0)best=k;}return best;
    }
    private static int compareVersions(String a,String b){
        String[]x=a.replaceAll("[^0-9.]",".").split("\\.+"),y=b.replaceAll("[^0-9.]",".").split("\\.+");
        for(int i=0;i<Math.max(x.length,y.length);i++){int p=i<x.length&&!x[i].isEmpty()?num(x[i]):0,q=i<y.length&&!y[i].isEmpty()?num(y[i]):0;if(p!=q)return Integer.compare(p,q);}return a.compareTo(b);
    }
    private static int num(String s){try{return Integer.parseInt(s);}catch(Exception e){return 0;}}

    private static String get(String u)throws Exception{
        URL current=new URL(u);
        for(int redirects=0;redirects<8;redirects++){
            HttpURLConnection c=(HttpURLConnection)current.openConnection();
            c.setConnectTimeout(20000);c.setReadTimeout(45000);c.setInstanceFollowRedirects(false);
            c.setRequestProperty("Accept","application/json,text/plain,*/*");
            c.setRequestProperty("User-Agent","GradleApkBuilder/1.9.7");
            int code=c.getResponseCode();
            if(code>=300&&code<400){String loc=c.getHeaderField("Location");c.disconnect();if(loc==null)throw new IOException("重定向缺少地址");current=new URL(current,loc);continue;}
            if(code<200||code>=300){c.disconnect();throw new IOException("HTTP "+code);}
            try(InputStream in=new BufferedInputStream(c.getInputStream());ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[]b=new byte[16384];int n;while((n=in.read(b))>=0){out.write(b,0,n);if(out.size()>2_000_000)throw new IOException("目录文件过大");}return out.toString("UTF-8");
            }finally{c.disconnect();}
        }
        throw new IOException("重定向次数过多");
    }
    private static String host(String u){try{return new URL(u).getHost();}catch(Exception e){return u;}}
    private static String clean(String s){return s==null||s.trim().isEmpty()?"未知错误":s.trim();}
    private static String join(List<String>a,String sep){StringBuilder s=new StringBuilder();for(String x:a){if(s.length()>0)s.append(sep);s.append(x);}return s.toString();}
}
