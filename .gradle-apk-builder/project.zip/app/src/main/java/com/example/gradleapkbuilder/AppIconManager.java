package com.example.gradleapkbuilder;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

/** Stores a user-selected icon, extracts icons from packages, and prepares a temporary project ZIP with replaced launcher icons. */
final class AppIconManager {
    interface Progress { void onProgress(String message,long done,long total); boolean isCancelled(); }

    private final Context context;
    private final File baseDir;
    private final File currentIcon;

    AppIconManager(Context context) {
        this.context=context.getApplicationContext();
        this.baseDir=new File(this.context.getFilesDir(),"app-icon");
        this.currentIcon=new File(baseDir,"current.png");
        if(!baseDir.exists())baseDir.mkdirs();
    }

    boolean hasCustomIcon(){return currentIcon.isFile()&&currentIcon.length()>0;}
    File getCurrentIcon(){return hasCustomIcon()?currentIcon:null;}
    String status(){return hasCustomIcon()?"已选择编译图标："+currentIcon.getName()+"（"+human(currentIcon.length())+"）":"未设置编译前替换图标";}
    void remove(){if(currentIcon.exists())currentIcon.delete();}

    void importImage(InputStream source)throws IOException{
        if(source==null)throw new IOException("无法打开图标文件");
        Bitmap bitmap=BitmapFactory.decodeStream(source);
        if(bitmap==null)throw new IOException("无法识别图像，请选择 PNG、JPEG 或 WebP");
        saveBitmap(bitmap,currentIcon,1024);
        bitmap.recycle();
    }

    File extractIcon(InputStream source,String name)throws Exception{
        if(source==null)throw new IOException("无法打开资源包");
        String lower=name==null?"":name.toLowerCase(Locale.US);
        File input=File.createTempFile("corykui-icon-source-",suffix(lower),context.getCacheDir());
        try(OutputStream out=new FileOutputStream(input)){copy(source,out);}
        Bitmap bitmap=null;
        try{
            if(lower.endsWith(".apk"))bitmap=extractApkIcon(input);
            if(bitmap==null&&(lower.endsWith(".zip")||lower.endsWith(".aab")||lower.endsWith(".apks")||lower.endsWith(".xapk")||lower.endsWith(".aar")||lower.endsWith(".jar")))bitmap=extractZipIcon(input);
            if(bitmap==null)bitmap=BitmapFactory.decodeFile(input.getAbsolutePath());
            if(bitmap==null)throw new IOException("资源包中未找到可识别的应用图标");
            File output=new File(baseDir,"extracted-"+System.currentTimeMillis()+".png");
            saveBitmap(bitmap,output,1024);
            return output;
        }finally{
            if(bitmap!=null)bitmap.recycle();
            input.delete();
        }
    }

    void useExtracted(File file)throws IOException{
        if(file==null||!file.isFile())throw new IOException("提取的图标不存在");
        try(InputStream in=new FileInputStream(file)){importImage(in);}
    }

    File prepareProjectZip(File sourceZip,Progress progress)throws Exception{
        if(!hasCustomIcon())return sourceZip;
        if(sourceZip==null||!sourceZip.isFile())throw new IOException("工程 ZIP 不存在");
        File work=new File(context.getCacheDir(),"icon-project-"+System.currentTimeMillis());
        File outZip=new File(context.getCacheDir(),"CoryKui-icon-project-"+System.currentTimeMillis()+".zip");
        deleteRecursive(work);if(!work.mkdirs())throw new IOException("无法创建图标替换临时目录");
        try{
            unzip(sourceZip,work,progress);
            List<File> manifests=new ArrayList<>();findManifests(work,manifests);
            if(manifests.isEmpty())throw new IOException("工程中没有找到 src/main/AndroidManifest.xml");
            Bitmap source=BitmapFactory.decodeFile(currentIcon.getAbsolutePath());
            if(source==null)throw new IOException("当前图标文件损坏");
            int patched=0;
            try{
                for(File manifest:manifests){
                    if(patchManifestAndResources(manifest,source))patched++;
                }
            }finally{source.recycle();}
            if(patched==0)throw new IOException("没有找到可替换图标的 Android 应用模块");
            zipDirectory(work,outZip,progress);
            return outZip;
        }finally{deleteRecursive(work);}
    }

    private boolean patchManifestAndResources(File manifest,Bitmap source)throws IOException{
        String text=readText(manifest);
        int app=text.indexOf("<application");
        if(app<0)return false;
        int end=text.indexOf('>',app);if(end<0)return false;
        String tag=text.substring(app,end+1);
        tag=replaceOrAddAttribute(tag,"android:icon","@mipmap/corykui_compile_icon");
        tag=replaceOrAddAttribute(tag,"android:roundIcon","@mipmap/corykui_compile_icon_round");
        text=text.substring(0,app)+tag+text.substring(end+1);
        writeText(manifest,text);
        File main=manifest.getParentFile(); // src/main
        File res=new File(main,"res");
        writeDensity(source,new File(res,"mipmap-mdpi"),48);
        writeDensity(source,new File(res,"mipmap-hdpi"),72);
        writeDensity(source,new File(res,"mipmap-xhdpi"),96);
        writeDensity(source,new File(res,"mipmap-xxhdpi"),144);
        writeDensity(source,new File(res,"mipmap-xxxhdpi"),192);
        return true;
    }

    private static String replaceOrAddAttribute(String tag,String name,String value){
        String pattern=name+"=\"";int start=tag.indexOf(pattern);
        if(start>=0){int valueStart=start+pattern.length();int valueEnd=tag.indexOf('"',valueStart);if(valueEnd>valueStart)return tag.substring(0,valueStart)+value+tag.substring(valueEnd);}
        int pos=tag.lastIndexOf('>');return tag.substring(0,pos)+"\n        "+name+"=\""+value+"\""+tag.substring(pos);
    }

    private static void writeDensity(Bitmap source,File dir,int size)throws IOException{
        if(!dir.exists()&&!dir.mkdirs())throw new IOException("无法创建图标资源目录："+dir);
        Bitmap scaled=Bitmap.createScaledBitmap(source,size,size,true);
        File a=new File(dir,"corykui_compile_icon.png"),b=new File(dir,"corykui_compile_icon_round.png");
        try(FileOutputStream out=new FileOutputStream(a)){if(!scaled.compress(Bitmap.CompressFormat.PNG,100,out))throw new IOException("无法写入图标："+a);}
        try(FileOutputStream out=new FileOutputStream(b)){if(!scaled.compress(Bitmap.CompressFormat.PNG,100,out))throw new IOException("无法写入圆形图标："+b);}
        if(scaled!=source)scaled.recycle();
    }

    private Bitmap extractApkIcon(File apk){
        try{
            PackageManager pm=context.getPackageManager();
            PackageInfo info=pm.getPackageArchiveInfo(apk.getAbsolutePath(),PackageManager.GET_META_DATA);
            if(info==null||info.applicationInfo==null)return null;
            ApplicationInfo ai=info.applicationInfo;ai.sourceDir=apk.getAbsolutePath();ai.publicSourceDir=apk.getAbsolutePath();
            return drawableToBitmap(pm.getApplicationIcon(ai));
        }catch(Exception ignored){return null;}
    }

    private static Bitmap extractZipIcon(File file)throws IOException{
        try(ZipFile zip=new ZipFile(file)){
            ZipEntry best=null;long score=Long.MIN_VALUE;
            Enumeration<? extends ZipEntry> entries=zip.entries();
            while(entries.hasMoreElements()){
                ZipEntry e=entries.nextElement();if(e.isDirectory())continue;
                String n=e.getName().toLowerCase(Locale.US);
                if(!(n.endsWith(".png")||n.endsWith(".webp")||n.endsWith(".jpg")||n.endsWith(".jpeg")))continue;
                long s=Math.max(0,e.getSize());
                if(n.contains("ic_launcher"))s+=1_000_000_000L;
                else if(n.contains("launcher"))s+=800_000_000L;
                else if(n.contains("app_icon")||n.contains("appicon"))s+=600_000_000L;
                else if(n.contains("icon"))s+=300_000_000L;
                if(n.contains("xxxhdpi"))s+=50_000_000L;else if(n.contains("xxhdpi"))s+=40_000_000L;
                if(s>score){score=s;best=e;}
            }
            if(best==null)return null;
            try(InputStream in=zip.getInputStream(best)){return BitmapFactory.decodeStream(in);}
        }
    }

    private static Bitmap drawableToBitmap(Drawable drawable){
        if(drawable instanceof BitmapDrawable){Bitmap b=((BitmapDrawable)drawable).getBitmap();return b.copy(Bitmap.Config.ARGB_8888,false);}
        int w=Math.max(1,drawable.getIntrinsicWidth()),h=Math.max(1,drawable.getIntrinsicHeight());
        Bitmap bitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(bitmap);drawable.setBounds(0,0,w,h);drawable.draw(canvas);return bitmap;
    }

    private static void saveBitmap(Bitmap bitmap,File file,int max)throws IOException{
        int w=bitmap.getWidth(),h=bitmap.getHeight();float scale=Math.min(1f,max/(float)Math.max(w,h));
        Bitmap out=scale<1f?Bitmap.createScaledBitmap(bitmap,Math.max(1,Math.round(w*scale)),Math.max(1,Math.round(h*scale)),true):bitmap;
        File parent=file.getParentFile();if(parent!=null&&!parent.exists()&&!parent.mkdirs())throw new IOException("无法创建图标目录");
        try(FileOutputStream stream=new FileOutputStream(file)){if(!out.compress(Bitmap.CompressFormat.PNG,100,stream))throw new IOException("无法保存 PNG 图标");}
        if(out!=bitmap)out.recycle();
    }

    private static void findManifests(File root,List<File> out){
        if(root==null||!root.exists())return;
        if(root.isFile()){String p=root.getPath().replace('\\','/');if(p.endsWith("/src/main/AndroidManifest.xml"))out.add(root);return;}
        File[] files=root.listFiles();if(files!=null)for(File f:files)findManifests(f,out);
    }

    private static void unzip(File zipFile,File destination,Progress progress)throws Exception{
        String root=destination.getCanonicalPath()+File.separator;long total=Math.max(1,zipFile.length()),done=0;
        try(ZipInputStream zip=new ZipInputStream(new BufferedInputStream(new FileInputStream(zipFile)))){
            ZipEntry e;byte[] buffer=new byte[65536];
            while((e=zip.getNextEntry())!=null){check(progress);File out=new File(destination,e.getName());if(!out.getCanonicalPath().startsWith(root))throw new IOException("工程 ZIP 包含不安全路径");
                if(e.isDirectory()){if(!out.exists()&&!out.mkdirs())throw new IOException("无法创建目录："+out);}else{File parent=out.getParentFile();if(parent!=null&&!parent.exists()&&!parent.mkdirs())throw new IOException("无法创建目录："+parent);try(OutputStream target=new BufferedOutputStream(new FileOutputStream(out))){int n;while((n=zip.read(buffer))>=0){check(progress);target.write(buffer,0,n);done+=n;if(progress!=null)progress.onProgress("正在准备图标替换工程…",Math.min(done,total),total);}}}zip.closeEntry();}
        }
    }

    private static void zipDirectory(File root,File output,Progress progress)throws Exception{
        List<File> files=new ArrayList<>();collectFiles(root,files);long total=0;for(File f:files)total+=f.length();long done=0;
        try(ZipOutputStream zip=new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(output)))){
            byte[] buffer=new byte[65536];String base=root.getCanonicalPath()+File.separator;
            for(File f:files){check(progress);String name=f.getCanonicalPath().substring(base.length()).replace(File.separatorChar,'/');zip.putNextEntry(new ZipEntry(name));try(InputStream in=new BufferedInputStream(new FileInputStream(f))){int n;while((n=in.read(buffer))>=0){check(progress);zip.write(buffer,0,n);done+=n;if(progress!=null)progress.onProgress("正在生成替换图标后的工程 ZIP…",done,Math.max(1,total));}}zip.closeEntry();}
        }
    }

    private static void collectFiles(File root,List<File> out){File[] files=root.listFiles();if(files!=null)for(File f:files){if(f.isDirectory())collectFiles(f,out);else out.add(f);}}
    private static void check(Progress progress)throws InterruptedIOException{if(progress!=null&&progress.isCancelled())throw new InterruptedIOException("用户已取消图标处理");}
    private static String readText(File f)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=new FileInputStream(f)){copy(in,out);}return out.toString("UTF-8");}
    private static void writeText(File f,String text)throws IOException{try(OutputStream out=new FileOutputStream(f)){out.write(text.getBytes(StandardCharsets.UTF_8));}}
    private static void copy(InputStream in,OutputStream out)throws IOException{byte[] b=new byte[65536];int n;while((n=in.read(b))>=0)out.write(b,0,n);}
    private static String suffix(String name){int i=name.lastIndexOf('.');return i>=0?name.substring(i):".bin";}
    private static String human(long n){if(n<1024)return n+" B";double v=n;String[] u={"B","KB","MB","GB"};int i=0;while(v>=1024&&i<u.length-1){v/=1024;i++;}return String.format(Locale.US,"%.1f %s",v,u[i]);}
    private static void deleteRecursive(File f){if(f==null||!f.exists())return;if(f.isDirectory()){File[] c=f.listFiles();if(c!=null)for(File x:c)deleteRecursive(x);}f.delete();}
}
