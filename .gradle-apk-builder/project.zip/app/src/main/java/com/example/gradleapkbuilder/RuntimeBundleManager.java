package com.example.gradleapkbuilder;

import android.content.Context;
import android.os.Build;
import android.system.Os;
import android.system.OsConstants;
import org.apache.commons.compress.archivers.tar.*;
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;
import java.text.SimpleDateFormat;

/** Manages downloaded SDK components and an optional complete PRoot runtime. */
final class RuntimeBundleManager {
    interface Progress {
        void onProgress(String message,long done,long total);
        default boolean isCancelled(){return false;}
    }
    private static final class ExportCounter {
        final Progress progress; final long total; long done,lastBytes,lastTime;
        ExportCounter(Progress progress,long total){this.progress=progress;this.total=Math.max(1,total);}
        void add(long n,String message)throws InterruptedIOException{done+=Math.max(0,n);report(message,false);}
        void report(String message,boolean force)throws InterruptedIOException{
            if(progress==null)return;
            if(progress.isCancelled())throw new InterruptedIOException("用户已取消导出");
            long now=System.currentTimeMillis();
            if(force||done-lastBytes>=2L*1024*1024||now-lastTime>=250){lastBytes=done;lastTime=now;progress.onProgress(message,Math.min(done,total),total);}
        }
    }

    private final File baseDir,bundleDir,downloadsDir,componentsDir;
    RuntimeBundleManager(Context context){
        Context app=context.getApplicationContext();
        baseDir=new File(app.getFilesDir(),"linux-runtime");
        bundleDir=new File(baseDir,"current");
        downloadsDir=new File(baseDir,"downloads");
        componentsDir=new File(baseDir,"sdk-components");
    }

    File getBundleDir(){return bundleDir;}
    File getRootfsDir(){return new File(bundleDir,"rootfs");}
    File getProotFile(){File old=new File(bundleDir,"bin/proot");if(old.isFile())return old;return findNamed(new File(bundleDir,"termux-prefix"),"proot");}
    File getProotLoaderFile(){
        File direct=new File(bundleDir,"termux-prefix/libexec/proot/loader");
        if(direct.isFile())return direct;
        return findBySuffix(new File(bundleDir,"termux-prefix"),"/libexec/proot/loader");
    }
    File getMetadataFile(){return new File(bundleDir,"bundle.properties");}
    File getComponentsDir(){return componentsDir;}
    private File getJdkSelectionFile(){return new File(componentsDir,"jdk-selection.properties");}
    int getActiveJdkMajor(){
        Properties p=loadPropertiesQuietly(getJdkSelectionFile());
        try{return Integer.parseInt(p.getProperty("activeMajor","0"));}catch(Exception ignored){return 0;}
    }
    File getActiveJdkPrefix(){
        Properties p=loadPropertiesQuietly(getJdkSelectionFile());
        String relative=p.getProperty("activePrefix","").trim();
        if(relative.isEmpty())return null;
        File prefix=new File(componentsDir,relative);
        return prefix.isDirectory()?prefix:null;
    }
    File getActiveJdkHome(){
        int major=getActiveJdkMajor();File prefix=getActiveJdkPrefix();
        if(prefix==null||major<=0)return null;
        File direct=new File(prefix,"lib/jvm/java-"+major+"-openjdk");
        if(direct.isDirectory())return direct;
        File java=findJava(prefix);return java==null?null:java.getParentFile().getParentFile();
    }
    File getJavaExecutable(){
        File home=getActiveJdkHome();File active=home==null?null:new File(home,"bin/java");
        if(active!=null&&active.isFile())return active;
        File legacy=new File(componentsDir,"jdk/bin/java");
        if(legacy.isFile())return legacy;
        File f=findJava(new File(componentsDir,"jdk"));
        return f!=null?f:findJava(getRootfsDir());
    }
    String getJavaLibraryPath(){
        File prefix=getActiveJdkPrefix(),home=getActiveJdkHome();
        if(prefix==null||home==null)return "";
        return TermuxJdkInstaller.libraryPath(prefix,home);
    }
    File getAndroidSdkDir(){ File direct=new File(componentsDir,"android-sdk"); if(direct.isDirectory())return direct; File inRoot=new File(getRootfsDir(),"opt/android-sdk"); return inRoot.isDirectory()?inRoot:null; }

    /** Prefer the newest AndroidIDE ARM build-tools aapt2 instead of an arbitrary recursive match. */
    File getAapt2Executable(){
        List<File> candidates=getAapt2Candidates();
        return candidates.isEmpty()?null:candidates.get(0);
    }

    List<File> getAapt2Candidates(){
        ArrayList<File> result=new ArrayList<>();
        File sdk=getAndroidSdkDir();
        if(sdk==null)return result;
        File buildTools=new File(sdk,"build-tools");
        File[] versions=buildTools.listFiles(File::isDirectory);
        if(versions!=null){
            Arrays.sort(versions,(a,b)->compareVersionNames(b.getName(),a.getName()));
            for(File version:versions){
                File direct=new File(version,"aapt2");
                if(direct.isFile())result.add(direct);
            }
        }
        File fallback=findNamed(sdk,"aapt2");
        if(fallback!=null&&!result.contains(fallback))result.add(fallback);
        return result;
    }

    File getAndroidJar(){
        int highest=getHighestInstalledPlatformApi();
        return highest>0?getAndroidJar(highest):null;
    }

    File getApksignerJar(){
        File sdk=getAndroidSdkDir();
        return sdk==null?null:findNamed(sdk,"apksigner.jar");
    }

    File getAndroidJar(int api){
        File sdk=getAndroidSdkDir();
        if(sdk==null)return null;
        File exact=new File(sdk,"platforms/android-"+api+"/android.jar");
        return exact.isFile()?exact:null;
    }

    int getHighestInstalledPlatformApi(){
        File sdk=getAndroidSdkDir();
        File platforms=sdk==null?null:new File(sdk,"platforms");
        File[] dirs=platforms==null?null:platforms.listFiles(File::isDirectory);
        int best=0;
        if(dirs!=null)for(File dir:dirs){
            String name=dir.getName();
            if(name.startsWith("android-"))try{
                int api=Integer.parseInt(name.substring(8).replaceAll("[^0-9].*$",""));
                if(new File(dir,"android.jar").isFile())best=Math.max(best,api);
            }catch(Exception ignored){}
        }
        return best;
    }

    private static int compareVersionNames(String a,String b){
        String[] aa=a.split("[^0-9]+"),bb=b.split("[^0-9]+");
        for(int i=0;i<Math.max(aa.length,bb.length);i++){
            int x=i<aa.length&&!aa[i].isEmpty()?parseInt(aa[i]):0;
            int y=i<bb.length&&!bb[i].isEmpty()?parseInt(bb[i]):0;
            if(x!=y)return Integer.compare(x,y);
        }
        return a.compareTo(b);
    }
    private static int parseInt(String value){try{return Integer.parseInt(value);}catch(Exception ignored){return 0;}}
    boolean isDirectBuildReady(){
        if(!isSdkComponentsInstalled()||getJavaExecutable()==null||getAndroidSdkDir()==null||getAapt2Executable()==null||getAndroidJar()==null)return false;
        // Android 10+ removes exec permission from writable app home for apps targeting API 29+.
        // This project ships as a sideload compiler variant targeting 28. Also require chmod to succeed.
        return chmodExecutable(getJavaExecutable())&&chmodExecutable(getAapt2Executable());
    }
    boolean isBuildReady(){ return isDirectBuildReady()||isInstalled(); }
    boolean isArm64(){return Arrays.asList(Build.SUPPORTED_ABIS).contains("arm64-v8a");}
    boolean isSdkComponentsInstalled(){return new File(componentsDir,"components.properties").isFile()&&new File(componentsDir,"android-sdk").isDirectory();}
    boolean isInstalled(){
        File proot=getProotFile();
        File loader=getProotLoaderFile();
        File shell=new File(getRootfsDir(),"bin/sh");
        return proot!=null&&proot.isFile()&&loader!=null&&loader.isFile()
                &&existsNoFollow(shell)&&getMetadataFile().isFile();
    }

    String status(){
        StringBuilder s=new StringBuilder();
        s.append("设备 ABI：").append(Arrays.toString(Build.SUPPORTED_ABIS)).append('\n');
        s.append("SDK 组件缓存：").append(isSdkComponentsInstalled()?"已安装":"未安装").append('\n');
        s.append("Android 原生本地构建：").append(isDirectBuildReady()?"可用":"不可用").append('\n');
        s.append("PRoot Linux 兼容环境：").append(isInstalled()?"已安装":"未安装（可选）").append('\n');
        s.append("已安装 JDK：").append(installedJdkSummary()).append('\n');
        int activeMajor=getActiveJdkMajor();
        s.append("当前启用 JDK：").append(activeMajor>0?("JDK "+activeMajor):"内置/旧版 JDK").append('\n');
        File meta=isSdkComponentsInstalled()?new File(componentsDir,"components.properties"):getMetadataFile();
        if(meta.isFile()){
            Properties p=new Properties();try(InputStream in=new FileInputStream(meta)){p.load(in);}catch(Exception ignored){}
            s.append("环境版本：").append(p.getProperty("version","未知")).append('\n');
            s.append("JDK：").append(p.getProperty("jdk","未知")).append('\n');
            s.append("Android SDK：").append(p.getProperty("androidSdk","未知")).append('\n');
        }
        s.append("占用空间：").append(human(sizeOf(baseDir)));
        if(isDirectBuildReady())s.append("\n✓ 已具备 Android 原生 JDK/SDK/Build Tools，本地 Gradle 编译可直接使用，不再强制要求 rootfs。");
        else if(isSdkComponentsInstalled())s.append("\n组件已安装但自检未通过。请在‘更多操作’中运行环境自检，查看缺少的 java、android.jar 或 aapt2。");
        if(!isArm64())s.append("\n警告：自动组件源主要面向 arm64-v8a。");
        return s.toString();
    }

    String selfTestDirect() throws Exception {
        StringBuilder out=new StringBuilder();
        File java=getJavaExecutable(),sdk=getAndroidSdkDir(),aapt2=getAapt2Executable(),androidJar=getAndroidJar();
        out.append("Java：").append(java==null?"未找到":java.getAbsolutePath()).append('\n');
        out.append("Android SDK：").append(sdk==null?"未找到":sdk.getAbsolutePath()).append('\n');
        out.append("aapt2：").append(aapt2==null?"未找到":aapt2.getAbsolutePath()).append('\n');
        out.append("android.jar：").append(androidJar==null?"未找到":androidJar.getAbsolutePath()).append('\n');
        if(java==null||sdk==null||aapt2==null||androidJar==null)throw new IOException(out+"\n环境不完整，请重新执行自动下载安装。");
        if(!chmodExecutable(java)||!chmodExecutable(aapt2))throw new IOException("无法恢复 Java/aapt2 执行权限。请确认安装的是旁加载本地编译版（targetSdk 28），然后重新导入工具链。");
        Map<String,String> javaEnv=new HashMap<>();
        String javaLibraries=getJavaLibraryPath();
        if(!javaLibraries.isEmpty())javaEnv.put("LD_LIBRARY_PATH",javaLibraries);
        File activePrefix=getActiveJdkPrefix(),activeHome=getActiveJdkHome();
        if(activePrefix!=null){File tmp=new File(activePrefix,"tmp");mkdirs(tmp);javaEnv.put("TMPDIR",tmp.getAbsolutePath());}
        if(activeHome!=null)javaEnv.put("JAVA_HOME",activeHome.getAbsolutePath());
        out.append(runCommand(new String[]{java.getAbsolutePath(),"-version"},null,javaEnv,25)).append('\n');
        out.append(runCommand(new String[]{aapt2.getAbsolutePath(),"version"},null,25));
        return out.toString();
    }

    String selfTest() throws Exception {
        StringBuilder out=new StringBuilder(selfTestDirect());
        if(isInstalled())out.append("\n").append(selfTestProot());
        return out.toString();
    }



    boolean isJdkInstalled(int major){
        if(major!=17&&major!=21)return false;
        File prefix=new File(componentsDir,"jdks/jdk-"+major+"-prefix");
        File direct=new File(prefix,"lib/jvm/java-"+major+"-openjdk/bin/java");
        return direct.isFile()||findJava(prefix)!=null;
    }

    String activateJdk(int major)throws Exception{
        if(!isJdkInstalled(major))throw new IOException("JDK "+major+" 尚未安装");
        File prefix=new File(componentsDir,"jdks/jdk-"+major+"-prefix");
        Properties selection=new Properties();
        selection.setProperty("activeMajor",String.valueOf(major));
        selection.setProperty("activePrefix","jdks/jdk-"+major+"-prefix");
        Properties old=loadPropertiesQuietly(getJdkSelectionFile());
        selection.setProperty("packageVersion",old.getProperty("jdk"+major+"Version",old.getProperty("packageVersion","installed")));
        try(OutputStream out=new FileOutputStream(getJdkSelectionFile())){selection.store(out,"GradleApkBuilder active JDK");}
        File components=new File(componentsDir,"components.properties");
        Properties metadata=loadPropertiesQuietly(components);
        metadata.setProperty("jdk","Termux OpenJDK "+major+" (active)");
        metadata.setProperty("activeJdk",String.valueOf(major));
        try(OutputStream out=new FileOutputStream(components)){metadata.store(out,"GradleApkBuilder SDK components");}
        File java=getJavaExecutable();
        if(java==null)throw new IOException("JDK "+major+" 已存在，但未找到 java 可执行文件");
        markToolExecutables(prefix);
        String result=selfTestDirect();
        return "JDK "+major+" 已设为当前版本并通过自检。\n\n"+result;
    }

    String installJdkAutomatically(int major,Progress progress)throws Exception{
        TermuxJdkInstaller.Result result=TermuxJdkInstaller.install(componentsDir,downloadsDir,major,
                (m,d,t)->{if(progress!=null)progress.onProgress(m,d,t);});
        markToolExecutables(result.prefix);
        if(progress!=null)progress.onProgress("JDK "+major+" 已安装并启用："+result.packageVersion,1,1);
        return result.selfTestOutput;
    }

    private String installedJdkSummary(){
        ArrayList<String> versions=new ArrayList<>();
        File jdks=new File(componentsDir,"jdks");
        if(new File(jdks,"jdk-17-prefix/lib/jvm/java-17-openjdk/bin/java").isFile())versions.add("17");
        if(new File(jdks,"jdk-21-prefix/lib/jvm/java-21-openjdk/bin/java").isFile())versions.add("21");
        File legacy=new File(componentsDir,"jdk/bin/java");
        if(legacy.isFile())versions.add("11（AndroidIDE）");
        if(versions.isEmpty())return "未安装";
        StringBuilder out=new StringBuilder();for(String v:versions){if(out.length()>0)out.append("、");out.append(v);}return out.toString();
    }

    private static Properties loadPropertiesQuietly(File file){
        Properties p=new Properties();if(file!=null&&file.isFile())try(InputStream in=new FileInputStream(file)){p.load(in);}catch(Exception ignored){}return p;
    }

    void installProotAutomatically(Progress progress)throws Exception{
        ProotRuntimeInstaller.install(bundleDir,downloadsDir,(m,d,t)->{if(progress!=null)progress.onProgress(m,d,t);});
        String test=selfTestProot();
        if(progress!=null)progress.onProgress("PRoot 自检通过："+test,1,1);
    }

    String selfTestProot()throws Exception{
        if(!isInstalled())throw new IOException("PRoot 或 Linux rootfs 未完整安装");
        repairProotRuntimePermissions();
        File proot=getProotFile();chmodExecutable(proot);
        File loader=getProotLoaderFile();
        if(loader==null||!loader.isFile())throw new IOException("缺少 Termux PRoot loader：libexec/proot/loader");
        if(!chmodExecutable(loader))throw new IOException("无法恢复 PRoot loader 执行权限："+loader);
        File prefix=new File(bundleDir,"termux-prefix");
        File tmp=new File(prefix,"tmp");
        mkdirs(tmp);
        chmodMode(tmp,0700);
        Map<String,String> environment=new HashMap<>();
        environment.put("LD_LIBRARY_PATH",new File(prefix,"lib").getAbsolutePath());
        environment.put("PROOT_TMP_DIR",tmp.getAbsolutePath());
        environment.put("TMPDIR",tmp.getAbsolutePath());
        environment.put("PROOT_NO_SECCOMP","1");
        environment.put("PROOT_LOADER",loader.getAbsolutePath());
        environment.put("LD_PRELOAD","");

        String version=runProcess(new String[]{proot.getAbsolutePath(),"-V"},environment,30);
        String shellTest=runProcess(new String[]{
                proot.getAbsolutePath(),"--link2symlink","-0","-r",getRootfsDir().getAbsolutePath(),
                "-b","/dev","-b","/proc","-w","/","/bin/busybox","sh","-c",
                "printf GradleApkBuilder-rootfs-ok"
        },environment,30);
        if(!shellTest.contains("GradleApkBuilder-rootfs-ok")){
            throw new IOException("PRoot 可执行，但 rootfs BusyBox shell 自检没有返回预期结果："+shellTest);
        }
        return version.trim()+"\nrootfs BusyBox shell：OK";
    }

    /**
     * ZIP and encrypted backup formats do not preserve Unix mode bits.  On Alpine,
     * /bin/busybox and the musl dynamic loader must both remain executable; otherwise
     * PRoot reports execve("/bin/busybox"): Permission denied even though the file exists.
     */
    private void repairProotRuntimePermissions()throws IOException{
        File rootfs=getRootfsDir();
        if(!rootfs.isDirectory())return;

        String[] directories={"bin","sbin","lib","usr","usr/bin","usr/sbin","usr/lib","tmp","var","var/tmp"};
        for(String relative:directories){
            File directory=new File(rootfs,relative);
            if(directory.isDirectory())chmodMode(directory,(relative.endsWith("tmp")?0777:0755));
        }

        chmodRegularChildren(new File(rootfs,"bin"));
        chmodRegularChildren(new File(rootfs,"sbin"));
        chmodRegularChildren(new File(rootfs,"usr/bin"));
        chmodRegularChildren(new File(rootfs,"usr/sbin"));

        File busybox=new File(rootfs,"bin/busybox");
        requireExecutable(busybox,"rootfs BusyBox");
        chmodGuestLinkTarget(rootfs,new File(rootfs,"bin/sh"));
        chmodGuestLinkTarget(rootfs,new File(rootfs,"lib/ld-musl-aarch64.so.1"));
        chmodGuestLinkTarget(rootfs,new File(rootfs,"lib/libc.musl-aarch64.so.1"));
        chmodGuestLinkTarget(rootfs,new File(rootfs,"usr/lib/libc.musl-aarch64.so.1"));

        File proot=getProotFile();
        if(proot!=null)requireExecutable(proot,"PRoot");
        File loader=getProotLoaderFile();
        if(loader!=null)requireExecutable(loader,"PRoot loader");

        File prefix=new File(bundleDir,"termux-prefix");
        File tmp=new File(prefix,"tmp");
        mkdirs(tmp);
        chmodMode(tmp,0700);
    }

    private static void chmodRegularChildren(File directory){
        File[] children=directory==null?null:directory.listFiles();
        if(children==null)return;
        for(File child:children){
            if(child.isDirectory())chmodMode(child,0755);
            else if(!isSymlink(child))chmodMode(child,0755);
        }
    }

    private static void chmodGuestLinkTarget(File rootfs,File path){
        if(!existsNoFollow(path))return;
        if(!isSymlink(path)){chmodMode(path,0755);return;}
        try{
            String target=Os.readlink(path.getAbsolutePath());
            File resolved=target.startsWith("/")?new File(rootfs,target.substring(1)):new File(path.getParentFile(),target);
            ensureInside(rootfs,resolved);
            // Follow a short link chain such as ld-musl -> libc.musl.
            for(int i=0;i<8&&isSymlink(resolved);i++){
                String next=Os.readlink(resolved.getAbsolutePath());
                resolved=next.startsWith("/")?new File(rootfs,next.substring(1)):new File(resolved.getParentFile(),next);
                ensureInside(rootfs,resolved);
            }
            if(existsNoFollow(resolved)&&!isSymlink(resolved))chmodMode(resolved,0755);
        }catch(Exception ignored){}
    }

    private static void requireExecutable(File file,String label)throws IOException{
        if(file==null||!existsNoFollow(file)||isSymlink(file)||!file.isFile())throw new IOException(label+" 文件缺失："+file);
        chmodMode(file,0755);
        if(!file.canExecute())throw new IOException(label+" 无法恢复执行权限："+file);
    }

    private static void chmodMode(File file,int mode){
        if(file==null||!existsNoFollow(file)||isSymlink(file))return;
        try{Os.chmod(file.getAbsolutePath(),mode);}
        catch(Throwable ignored){
            file.setReadable(true,false);
            file.setWritable((mode&0200)!=0,true);
            file.setExecutable((mode&0111)!=0,false);
        }
    }

    private static String runProcess(String[] command,Map<String,String> environment,int timeoutSeconds)throws Exception{
        ProcessBuilder builder=new ProcessBuilder(command);
        builder.environment().remove("LD_PRELOAD");
        if(environment!=null)builder.environment().putAll(environment);
        if(builder.environment().get("LD_PRELOAD")!=null
                && builder.environment().get("LD_PRELOAD").isEmpty()) {
            builder.environment().remove("LD_PRELOAD");
        }
        builder.redirectErrorStream(true);
        Process process=builder.start();
        ByteArrayOutputStream output=new ByteArrayOutputStream();
        InputStream input=process.getInputStream();
        byte[] buffer=new byte[4096];
        long deadline=System.currentTimeMillis()+timeoutSeconds*1000L;
        while(System.currentTimeMillis()<deadline){
            while(input.available()>0){int count=input.read(buffer);if(count>0)output.write(buffer,0,count);}
            try{
                int code=process.exitValue();
                while(input.available()>0){int count=input.read(buffer);if(count>0)output.write(buffer,0,count);}
                String text=output.toString("UTF-8").trim();
                if(code!=0)throw new IOException("命令失败，退出代码 "+code+"："+text);
                return text;
            }catch(IllegalThreadStateException ignored){Thread.sleep(50);}
        }
        process.destroy();
        throw new IOException("PRoot 环境自检超时");
    }

    void installAutomatically(Progress progress)throws Exception{
        String abi=isArm64()?"arm64-v8a":(Build.SUPPORTED_ABIS.length>0?Build.SUPPORTED_ABIS[0]:"unknown");
        RuntimeCatalog.ComponentSet set=RuntimeCatalog.discoverComponents(abi,m->{if(progress!=null)progress.onProgress(m,0,-1);});
        if(progress!=null)progress.onProgress("已找到："+set.summary(),0,-1);
        installComponentSet(set,progress);
        // AndroidIDE's archived manifest currently exposes older ARM64 aapt2 builds.
        // Overlay the newer ARM64 build-tools release so API 35 framework resources can
        // be parsed on-device. The release asset digest from GitHub is mandatory.
        if(isArm64())installArm64BuildToolsCompatibility(progress);
    }

    private void installArm64BuildToolsCompatibility(Progress progress)throws Exception{
        final String assetName="android-sdk-tools-static-aarch64.zip";
        JSONObject release=null;Exception last=null;
        String[] releaseApis={
                "https://api.github.com/repos/lzhiyong/android-sdk-tools/releases/tags/v35.0.2",
                "https://api.github.com/repos/lzhiyong/android-sdk-tools/releases/tags/35.0.2"
        };
        for(String api:releaseApis){
            try{release=new JSONObject(downloadText(api));break;}catch(Exception e){last=e;}
        }
        if(release==null)throw new IOException("无法查询 ARM64 Build Tools 35.0.2 发布信息："+(last==null?"未知错误":last.getMessage()),last);
        JSONArray assets=release.optJSONArray("assets");JSONObject selected=null;
        if(assets!=null)for(int i=0;i<assets.length();i++){JSONObject item=assets.optJSONObject(i);if(item!=null&&assetName.equals(item.optString("name"))){selected=item;break;}}
        if(selected==null)throw new IOException("ARM64 Build Tools Release 中没有找到 "+assetName);

        // GitHub added a cryptographic digest field to release assets. Older API
        // versions and some cached release responses can omit it, so refresh the
        // individual asset with the newest REST API before deciding it is absent.
        String assetApi=selected.optString("url","");
        if(!assetApi.isEmpty()){
            try{
                JSONObject refreshed=new JSONObject(downloadText(assetApi));
                if(refreshed.has("digest"))selected.put("digest",refreshed.optString("digest",""));
                if(refreshed.has("browser_download_url"))selected.put("browser_download_url",refreshed.optString("browser_download_url",""));
                if(refreshed.has("size"))selected.put("size",refreshed.optLong("size",selected.optLong("size",-1)));
            }catch(Exception ignored){}
        }
        String url=selected.optString("browser_download_url","");
        String digest=selected.optString("digest","");
        String expected="";
        if(digest.toLowerCase(Locale.US).startsWith("sha256:"))expected=digest.substring(7).trim();
        if(url.isEmpty()||!url.startsWith("https://github.com/lzhiyong/android-sdk-tools/releases/download/35.0.2/"))
            throw new SecurityException("ARM64 Build Tools 下载地址不属于固定的 GitHub Release");
        if(!expected.isEmpty()&&expected.length()!=64)throw new SecurityException("ARM64 Build Tools SHA-256 摘要格式无效");

        mkdirs(downloadsDir);File archive=new File(downloadsDir,"arm64-build-tools-35.0.2.zip.part");
        if(progress!=null)progress.onProgress("正在下载 ARM64 Build Tools 35.0.2…",0,selected.optLong("size",-1));
        download(url,archive,progress);
        String actual=sha256(archive);
        if(!expected.isEmpty()&&!expected.equalsIgnoreCase(actual)){archive.delete();throw new SecurityException("ARM64 Build Tools SHA-256 校验失败\n期望："+expected+"\n实际："+actual);}
        if(expected.isEmpty()&&progress!=null)progress.onProgress("Release 未返回 digest，正在执行固定来源与工具内容自检…",archive.length(),archive.length());

        File stage=new File(baseDir,"arm64-build-tools-stage-"+System.currentTimeMillis());deleteTree(stage);mkdirs(stage);
        try{
            unzipAll(archive,stage,progress,"正在解压 ARM64 Build Tools 35.0.2…");
            File stagedAapt2=findNamed(stage,"aapt2");
            if(stagedAapt2==null||!stagedAapt2.isFile())throw new IOException("ARM64 Build Tools ZIP 缺少 aapt2");
            File source=stagedAapt2.getParentFile();
            File sdk=getAndroidSdkDir();if(sdk==null)throw new IOException("Android SDK 尚未安装");
            File target=new File(sdk,"build-tools/35.0.2-arm64");deleteTree(target);mkdirs(target);
            File[] children=source.listFiles();if(children!=null)for(File child:children)copyTreePreserveLinks(child,new File(target,child.getName()));
            markToolExecutables(target);
            File aapt2=new File(target,"aapt2");
            if(!aapt2.isFile()||!chmodExecutable(aapt2))throw new IOException("ARM64 Build Tools 解压后缺少可执行 aapt2");

            // The decisive compatibility check is parsing the newest installed
            // framework resources. This catches old aapt2 builds that report
            // errors such as "illegal map type string (22)" with API 35.
            File androidJar=getAndroidJar();
            if(androidJar==null)throw new IOException("没有可用于验证 ARM64 aapt2 的 android.jar");
            try{runCommand(new String[]{aapt2.getAbsolutePath(),"dump","resources",androidJar.getAbsolutePath()},target,90);}
            catch(Exception incompatible){deleteTree(target);throw new IOException("ARM64 aapt2 35.0.2 无法解析 "+androidJar.getAbsolutePath()+"："+incompatible.getMessage(),incompatible);}

            Properties metadata=loadPropertiesQuietly(new File(componentsDir,"components.properties"));
            metadata.setProperty("arm64BuildTools","35.0.2");
            metadata.setProperty("arm64BuildToolsSource",release.optString("html_url","https://github.com/lzhiyong/android-sdk-tools/releases/tag/v35.0.2"));
            metadata.setProperty("arm64BuildToolsSha256",actual);
            metadata.setProperty("arm64BuildToolsVerification",expected.isEmpty()?"pinned-github-url+sha256-recorded+android-platform-self-test":"github-release-digest+android-platform-self-test");
            try(OutputStream out=new FileOutputStream(new File(componentsDir,"components.properties"))){metadata.store(out,"GradleApkBuilder SDK components");}
            if(progress!=null)progress.onProgress("ARM64 Build Tools 35.0.2 已安装并通过 API 平台自检",1,1);
        }finally{archive.delete();deleteTree(stage);}
    }

    private static String downloadText(String source)throws Exception{
        URL current=new URL(source);
        for(int redirects=0;redirects<8;redirects++){
            HttpURLConnection c=(HttpURLConnection)current.openConnection();c.setConnectTimeout(25000);c.setReadTimeout(45000);c.setInstanceFollowRedirects(false);c.setRequestProperty("User-Agent","GradleApkBuilder/1.9.0");c.setRequestProperty("Accept","application/vnd.github+json,application/json");c.setRequestProperty("X-GitHub-Api-Version","2026-03-10");
            int code=c.getResponseCode();if(code>=300&&code<400){String loc=c.getHeaderField("Location");c.disconnect();if(loc==null)throw new IOException("查询重定向缺少地址");current=new URL(current,loc);continue;}if(code<200||code>=300){String host=current.getHost();c.disconnect();throw new IOException("查询失败，HTTP "+code+"："+host);}
            try(InputStream in=new BufferedInputStream(c.getInputStream());ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[16384];int n;while((n=in.read(b))>=0){out.write(b,0,n);if(out.size()>4_000_000)throw new IOException("发布信息过大");}return out.toString("UTF-8");}finally{c.disconnect();}
        }
        throw new IOException("查询重定向次数过多");
    }

    private void installComponentSet(RuntimeCatalog.ComponentSet set,Progress progress)throws Exception{
        mkdirs(downloadsDir);
        File staging=new File(baseDir,"components-staging-"+System.currentTimeMillis());
        deleteTree(staging);mkdirs(staging);
        File sdkStage=new File(staging,"sdk-home");mkdirs(sdkStage);
        File jdkStage=new File(staging,"jdk-home");mkdirs(jdkStage);
        try{
            int index=0,total=set.urls.size();
            for(Map.Entry<String,String> c:set.urls.entrySet()){
                index++;
                String name=c.getKey();
                File archive=new File(downloadsDir,name+".tar.xz.part");
                final int current=index;
                download(c.getValue(),archive,(m,d,t)->{if(progress!=null)progress.onProgress("["+current+"/"+total+"] 下载 "+name+"…",d,t);});
                File destination=name.startsWith("jdk")?jdkStage:("android-sdk".equals(name)?sdkStage:new File(sdkStage,"android-sdk"));
                mkdirs(destination);
                extractTarXz(archive,destination,name,progress);
                archive.delete();
            }

            File foundSdk=findDirectoryNamed(sdkStage,"android-sdk");
            if(foundSdk==null)throw new IOException("组件解压完成，但没有找到 android-sdk 目录");
            File finalSdk=new File(staging,"android-sdk");
            if(!foundSdk.renameTo(finalSdk)){copyTree(foundSdk,finalSdk);}
            File java=findJava(jdkStage);
            if(java!=null){File jdkRoot=findJdkRoot(java,jdkStage);copyTree(jdkRoot,new File(staging,"jdk"));}

            // Preserve separately installed JDK 17/21 and the active-version selection
            // when Android SDK components are refreshed.
            File existingJdks=new File(componentsDir,"jdks");
            if(existingJdks.isDirectory())copyTreePreserveLinks(existingJdks,new File(staging,"jdks"));
            File existingSelection=getJdkSelectionFile();
            if(existingSelection.isFile())copyTree(existingSelection,new File(staging,"jdk-selection.properties"));

            Properties p=new Properties();
            p.setProperty("version","AndroidIDE-tools-"+set.version);
            p.setProperty("abi",set.abi);
            p.setProperty("androidSdk",set.version);
            int selectedMajor=0;
            Properties selected=loadPropertiesQuietly(new File(staging,"jdk-selection.properties"));
            try{selectedMajor=Integer.parseInt(selected.getProperty("activeMajor","0"));}catch(Exception ignored){}
            p.setProperty("jdk",selectedMajor>0?("Termux OpenJDK "+selectedMajor+" (active)"):(java==null?"未包含（现代 AGP 建议 JDK 17）":"AndroidIDE JDK 11"));
            if(selectedMajor>0)p.setProperty("activeJdk",String.valueOf(selectedMajor));
            p.setProperty("source",set.source);
            try(OutputStream out=new FileOutputStream(new File(staging,"components.properties"))){p.store(out,"GradleApkBuilder SDK components");}

            deleteTree(componentsDir);
            if(!staging.renameTo(componentsDir)){copyTree(staging,componentsDir);deleteTree(staging);}
            markToolExecutables(componentsDir);
            if(progress!=null)progress.onProgress("SDK/JDK 组件安装完成，正在准备本地构建…",1,1);
        }catch(Exception e){deleteTree(staging);throw e;}
    }

    void installFromUrl(String url,String expectedSha256,Progress progress)throws Exception{
        if(!isArm64())throw new IOException("当前设备不是 ARM64，无法安装首版 Linux 工具链");
        mkdirs(downloadsDir);File tmp=new File(downloadsDir,"runtime.bundle.part");download(url,tmp,progress);
        String actual=sha256(tmp);if(expectedSha256!=null&&!expectedSha256.trim().isEmpty()&&!actual.equalsIgnoreCase(expectedSha256.trim())){tmp.delete();throw new SecurityException("工具链校验失败\n期望："+expectedSha256+"\n实际："+actual);}installZip(tmp,progress);tmp.delete();
    }
    void importBundle(InputStream input,Progress progress)throws Exception{
        mkdirs(downloadsDir);
        File tmp=new File(downloadsDir,"imported-toolchain.zip");
        try(OutputStream out=new FileOutputStream(tmp)){copy(input,out,progress,-1,"正在导入工具链程序包…");}
        try{
            if(isPortablePackage(tmp)) installPortablePackage(tmp,progress);
            else installZip(tmp,progress); // 兼容旧版完整 PRoot ZIP
        }finally{tmp.delete();}
    }

    /** 导出所有已下载组件、可选 Linux 运行时、元数据和逐文件 SHA-256。 */
    void exportBundle(OutputStream out,Progress progress)throws Exception{
        if(out==null)throw new IOException("无法打开工具链导出文件");
        if(!isSdkComponentsInstalled()&&!isInstalled())throw new IOException("尚未安装任何环境组件");
        long sourceBytes=(isSdkComponentsInstalled()?sizeOf(componentsDir):0)+(isInstalled()?sizeOf(bundleDir):0);
        ExportCounter counter=new ExportCounter(progress,Math.max(1,sourceBytes*3));
        File stage=new File(baseDir,"export-stage-"+System.currentTimeMillis());deleteTree(stage);mkdirs(stage);
        try{
            counter.report("正在准备工具链导出…",true);
            Properties meta=new Properties();
            meta.setProperty("format","GradleApkBuilder.ToolchainPackage");
            meta.setProperty("schema","3");
            meta.setProperty("appVersion",BuildConfig.VERSION_NAME);
            meta.setProperty("createdAt",new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ",Locale.US).format(new Date()));
            meta.setProperty("abis",Arrays.toString(Build.SUPPORTED_ABIS));
            meta.setProperty("hasComponents",String.valueOf(isSdkComponentsInstalled()));
            meta.setProperty("hasRuntime",String.valueOf(isInstalled()));
            Properties symlinks=new Properties();
            if(isSdkComponentsInstalled())copyTreeForPackage(componentsDir,new File(stage,"components"),stage,symlinks,counter);
            if(isInstalled())copyTreeForPackage(bundleDir,new File(stage,"runtime"),stage,symlinks,counter);
            if(!symlinks.isEmpty()){
                try(OutputStream linkOut=new FileOutputStream(new File(stage,"symlinks.properties"))){symlinks.store(linkOut,"Symbolic links: package-relative path -> original link target");}
            }
            try(OutputStream m=new FileOutputStream(new File(stage,"toolchain-package.properties"))){meta.store(m,"GradleApkBuilder portable toolchain package");}
            writeChecksumManifest(stage,new File(stage,"checksums.sha256"),counter);
            try(ZipOutputStream zout=new ZipOutputStream(new BufferedOutputStream(out,256*1024))){zout.setLevel(Deflater.BEST_SPEED);zipTree(stage,stage,zout,counter);zout.finish();}
            counter.done=counter.total;counter.report("工具链导出完成",true);
        }finally{deleteTree(stage);}
    }
    void remove()throws IOException{deleteTree(baseDir);}


    private static boolean isPortablePackage(File zip)throws IOException{
        try(ZipFile z=new ZipFile(zip)){return z.getEntry("toolchain-package.properties")!=null;}
    }

    private void installPortablePackage(File zip,Progress progress)throws Exception{
        File stage=new File(baseDir,"import-stage-"+System.currentTimeMillis());deleteTree(stage);mkdirs(stage);
        try{
            unzipAll(zip,stage,progress,"正在解压工具链程序包…");
            File metaFile=new File(stage,"toolchain-package.properties");
            Properties meta=new Properties();try(InputStream in=new FileInputStream(metaFile)){meta.load(in);}
            if(!"GradleApkBuilder.ToolchainPackage".equals(meta.getProperty("format")))throw new IOException("不是有效的 GradleApkBuilder 工具链程序包");
            int schema=Integer.parseInt(meta.getProperty("schema","0"));if(schema<2)throw new IOException("工具链包格式版本过旧");
            verifyChecksumManifest(stage,new File(stage,"checksums.sha256"),progress);
            Properties importedSymlinks=loadPropertiesIfPresent(new File(stage,"symlinks.properties"));
            File importedComponents=new File(stage,"components"), importedRuntime=new File(stage,"runtime");
            if(!importedComponents.isDirectory()&&!importedRuntime.isDirectory())throw new IOException("工具链包不包含任何可安装组件");

            File backupComponents=new File(baseDir,"components-backup"),backupRuntime=new File(baseDir,"runtime-backup");
            deleteTree(backupComponents);deleteTree(backupRuntime);
            if(componentsDir.exists()&&!componentsDir.renameTo(backupComponents))copyTree(componentsDir,backupComponents);
            if(bundleDir.exists()&&!bundleDir.renameTo(backupRuntime))copyTree(bundleDir,backupRuntime);
            try{
                if(importedComponents.isDirectory()){deleteTree(componentsDir);copyTree(importedComponents,componentsDir);}
                if(importedRuntime.isDirectory()){deleteTree(bundleDir);copyTree(importedRuntime,bundleDir);}
                if(!importedSymlinks.isEmpty()){
                    if(progress!=null)progress.onProgress("正在恢复工具链符号链接…",0,importedSymlinks.size());
                    restorePackageSymlinks(importedSymlinks,progress);
                }
                markToolExecutables(componentsDir);markToolExecutables(bundleDir);
                if(importedRuntime.isDirectory())repairProotRuntimePermissions();
                if(progress!=null)progress.onProgress("正在运行导入后的环境自检…",0,-1);
                if(isSdkComponentsInstalled())selfTest();
                else if(isInstalled())selfTestProot();
                else throw new IOException("导入后未检测到可用环境");
                deleteTree(backupComponents);deleteTree(backupRuntime);
            }catch(Exception e){
                deleteTree(componentsDir);deleteTree(bundleDir);
                if(backupComponents.exists()&&!backupComponents.renameTo(componentsDir))copyTree(backupComponents,componentsDir);
                if(backupRuntime.exists()&&!backupRuntime.renameTo(bundleDir))copyTree(backupRuntime,bundleDir);
                throw new IOException("导入安装或自检失败，已恢复原环境："+e.getMessage(),e);
            }
        }finally{deleteTree(stage);}
    }

    private static void unzipAll(File zip,File root,Progress progress,String message)throws Exception{
        long done=0,total=zip.length();
        try(ZipInputStream zin=new ZipInputStream(new BufferedInputStream(new FileInputStream(zip)))){
            ZipEntry e;byte[]b=new byte[65536];
            while((e=zin.getNextEntry())!=null){String name=safeName(e.getName());if(name.isEmpty())continue;File dst=new File(root,name);ensureInside(root,dst);
                if(e.isDirectory())mkdirs(dst);else{mkdirs(dst.getParentFile());try(OutputStream out=new BufferedOutputStream(new FileOutputStream(dst))){int n;while((n=zin.read(b))>=0){out.write(b,0,n);done+=n;if(progress!=null)progress.onProgress(message,done,total);}}}
            }
        }
    }


    /**
     * Copies regular files into a portable ZIP staging tree while recording symbolic
     * links separately. java.util.zip does not preserve Unix link metadata and trying
     * to open an absolute rootfs link (for example /usr/bin/yes -> /bin/busybox) from
     * the Android host returns ENOENT.
     */
    private static void copyTreeForPackage(File source,File destination,File packageRoot,
                                           Properties symlinks,ExportCounter counter)throws IOException{
        counter.report("正在收集工具链文件…",false);
        if(isSymlink(source)){
            mkdirs(destination.getParentFile());
            String relative=packageRoot.toURI().relativize(destination.toURI()).getPath();
            if(relative==null||relative.isEmpty())throw new IOException("无法记录工具链符号链接："+source);
            try{symlinks.setProperty(relative,Os.readlink(source.getAbsolutePath()));}
            catch(Exception e){throw new IOException("无法读取工具链符号链接："+source,e);}
            counter.report("正在记录符号链接："+relative,true);return;
        }
        if(source.isDirectory()){
            mkdirs(destination);File[] children=source.listFiles();
            if(children!=null)for(File child:children)copyTreeForPackage(child,new File(destination,child.getName()),packageRoot,symlinks,counter);
            return;
        }
        if(!source.isFile())return;
        mkdirs(destination.getParentFile());
        String relative=packageRoot.toURI().relativize(destination.toURI()).getPath();
        try(InputStream in=new BufferedInputStream(new FileInputStream(source));OutputStream out=new BufferedOutputStream(new FileOutputStream(destination))){
            byte[] buffer=new byte[65536];int count;while((count=in.read(buffer))>=0){out.write(buffer,0,count);counter.add(count,"正在收集工具链："+relative);}
        }
        destination.setLastModified(source.lastModified());counter.report("已收集："+relative,true);
    }

    private static Properties loadPropertiesIfPresent(File file)throws IOException{
        Properties result=new Properties();
        if(file!=null&&file.isFile()){
            try(InputStream in=new BufferedInputStream(new FileInputStream(file))){
                result.load(in);
            }
        }
        return result;
    }

    private void restorePackageSymlinks(Properties links,Progress progress)throws IOException{
        ArrayList<String> names=new ArrayList<>();
        for(Object key:links.keySet())names.add(String.valueOf(key));
        Collections.sort(names,(a,b)->{
            int da=pathDepth(a),db=pathDepth(b);
            return da!=db?Integer.compare(da,db):a.compareTo(b);
        });
        int index=0;
        for(String rawName:names){
            String name=safeName(rawName);
            File root;
            String child;
            if(name.startsWith("components/")){
                root=componentsDir;child=name.substring("components/".length());
            }else if(name.startsWith("runtime/")){
                root=bundleDir;child=name.substring("runtime/".length());
            }else{
                throw new IOException("工具链符号链接路径无效："+name);
            }
            if(child.isEmpty())throw new IOException("工具链符号链接路径为空："+name);
            File destination=new File(root,child);
            ensureNoSymlinkParents(root,destination.getParentFile());
            mkdirs(destination.getParentFile());
            deleteNoFollow(destination);
            String target=links.getProperty(rawName);
            if(target==null||target.indexOf('\0')>=0)throw new IOException("工具链符号链接目标无效："+name);
            try{
                Os.symlink(target,destination.getAbsolutePath());
            }catch(Exception e){
                throw new IOException("无法恢复工具链符号链接："+name+" -> "+target,e);
            }
            index++;
            if(progress!=null)progress.onProgress("正在恢复符号链接："+name,index,names.size());
        }
    }

    private static int pathDepth(String path){
        int depth=0;
        for(int i=0;i<path.length();i++)if(path.charAt(i)=='/')depth++;
        return depth;
    }

    private static void ensureNoSymlinkParents(File root,File parent)throws IOException{
        if(parent==null)return;
        String rootPath=root.getAbsolutePath();
        String parentPath=parent.getAbsolutePath();
        if(!parentPath.equals(rootPath)&&!parentPath.startsWith(rootPath+File.separator)){
            throw new IOException("符号链接路径越界："+parent);
        }
        ArrayList<File> chain=new ArrayList<>();
        File current=parent;
        while(current!=null&&!current.equals(root)){
            chain.add(current);
            current=current.getParentFile();
        }
        if(current==null)throw new IOException("符号链接路径越界："+parent);
        Collections.reverse(chain);
        for(File item:chain){
            if(isSymlink(item))throw new IOException("符号链接父目录不安全："+item);
        }
    }

    private static void writeChecksumManifest(File root,File manifest,ExportCounter counter)throws Exception{
        ArrayList<File> files=new ArrayList<>();collectFiles(root,files,manifest);Collections.sort(files,Comparator.comparing(File::getAbsolutePath));
        try(Writer w=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(manifest),"UTF-8"))){
            for(File f:files){String rel=root.toURI().relativize(f.toURI()).getPath();w.write(sha256Tracked(f,counter,"正在计算校验："+rel)+"  "+rel+"\n");counter.report("已校验："+rel,true);}
        }
    }

    private static String sha256Tracked(File file,ExportCounter counter,String message)throws Exception{
        MessageDigest digest=MessageDigest.getInstance("SHA-256");byte[] buffer=new byte[65536];int count;
        try(InputStream in=new BufferedInputStream(new FileInputStream(file))){while((count=in.read(buffer))>=0){digest.update(buffer,0,count);counter.add(count,message);}}
        StringBuilder result=new StringBuilder();for(byte value:digest.digest())result.append(String.format(Locale.US,"%02x",value));return result.toString();
    }

    private static void verifyChecksumManifest(File root,File manifest,Progress progress)throws Exception{
        if(!manifest.isFile())throw new IOException("工具链包缺少 checksums.sha256");
        List<String> lines=new ArrayList<>();try(BufferedReader r=new BufferedReader(new InputStreamReader(new FileInputStream(manifest),"UTF-8"))){String line;while((line=r.readLine())!=null)if(!line.trim().isEmpty())lines.add(line);}
        int i=0;for(String line:lines){int sep=line.indexOf("  ");if(sep!=64)throw new IOException("无效的校验清单行");String expected=line.substring(0,64),name=safeName(line.substring(sep+2));File f=new File(root,name);ensureInside(root,f);if(!f.isFile())throw new IOException("工具链包缺少文件："+name);String actual=sha256(f);if(!expected.equalsIgnoreCase(actual))throw new SecurityException("工具链文件校验失败："+name);i++;if(progress!=null)progress.onProgress("正在校验："+name,i,lines.size());}
    }

    private static void collectFiles(File root,List<File> out,File excluded){
        if(root.equals(excluded))return;if(root.isFile()){out.add(root);return;}File[]a=root.listFiles();if(a!=null)for(File f:a)collectFiles(f,out,excluded);
    }

    private void installZip(File zip,Progress progress)throws Exception{
        File staging=new File(baseDir,"staging-"+System.currentTimeMillis());deleteTree(staging);mkdirs(staging);long count=0;
        try(ZipInputStream zin=new ZipInputStream(new BufferedInputStream(new FileInputStream(zip)))){ZipEntry e;while((e=zin.getNextEntry())!=null){String name=safeName(e.getName());if(name.isEmpty())continue;File dst=new File(staging,name);ensureInside(staging,dst);if(e.isDirectory())mkdirs(dst);else{mkdirs(dst.getParentFile());try(OutputStream out=new BufferedOutputStream(new FileOutputStream(dst))){byte[]b=new byte[65536];int n;while((n=zin.read(b))>=0){out.write(b,0,n);count+=n;if(progress!=null)progress.onProgress("正在解压完整 Linux 工具链…",count,zip.length());}}}}}
        File p=new File(staging,"bin/proot"),sh=new File(staging,"rootfs/bin/sh"),meta=new File(staging,"bundle.properties");if(!p.isFile()||!existsNoFollow(sh)||!meta.isFile()){deleteTree(staging);throw new IOException("工具链包格式无效：必须包含 bin/proot、rootfs/bin/sh、bundle.properties");}p.setExecutable(true,true);deleteTree(bundleDir);if(!staging.renameTo(bundleDir)){copyTree(staging,bundleDir);deleteTree(staging);}
        repairProotRuntimePermissions();
    }

    private static void extractTarXz(File archive,File destination,String component,Progress progress)throws Exception{
        long entries=0;
        ArrayList<String[]> links=new ArrayList<>();
        try(InputStream fin=new BufferedInputStream(new FileInputStream(archive));XZCompressorInputStream xz=new XZCompressorInputStream(fin,true);TarArchiveInputStream tin=new TarArchiveInputStream(xz)){
            TarArchiveEntry e;byte[]buf=new byte[65536];
            while((e=tin.getNextTarEntry())!=null){String name=safeName(e.getName());if(name.isEmpty())continue;File dst=new File(destination,name);ensureInside(destination,dst);
                if(e.isDirectory()){mkdirs(dst);}else if(e.isSymbolicLink()||e.isLink()){
                    mkdirs(dst.getParentFile());links.add(new String[]{dst.getAbsolutePath(),e.getLinkName()});
                }else{mkdirs(dst.getParentFile());try(OutputStream out=new BufferedOutputStream(new FileOutputStream(dst))){int n;while((n=tin.read(buf))>=0)out.write(buf,0,n);}if((e.getMode()&0111)!=0)dst.setExecutable(true,true);}
                entries++;if(progress!=null&&entries%25==0)progress.onProgress("正在解压 "+component+"…",entries,-1);
            }
        }catch(NoClassDefFoundError err){throw new IOException("缺少 XZ 解压库，请确认 Gradle 已下载 commons-compress 与 xz 依赖",err);}
        for(String[] link:links){try{File dst=new File(link[0]);if(dst.exists())dst.delete();Os.symlink(link[1],dst.getAbsolutePath());}catch(Exception ignored){}}
        if(entries==0)throw new IOException(component+" 压缩包为空或格式不受支持");
    }

    private static void download(String source,File dst,Progress progress)throws Exception{
        URL current=new URL(source);
        for(int redirects=0;redirects<8;redirects++){
            HttpURLConnection c=(HttpURLConnection)current.openConnection();c.setConnectTimeout(25000);c.setReadTimeout(90000);c.setInstanceFollowRedirects(false);c.setRequestProperty("User-Agent","GradleApkBuilder/1.9.0");
            int code=c.getResponseCode();if(code>=300&&code<400){String loc=c.getHeaderField("Location");c.disconnect();if(loc==null)throw new IOException("下载重定向缺少地址");current=new URL(current,loc);continue;}if(code<200||code>=300){c.disconnect();throw new IOException("下载失败，HTTP "+code+"："+current.getHost());}
            long total=c.getContentLengthLong();try(InputStream in=new BufferedInputStream(c.getInputStream());OutputStream out=new BufferedOutputStream(new FileOutputStream(dst))){copy(in,out,progress,total,"正在下载工具链组件…");}finally{c.disconnect();}return;
        }throw new IOException("下载重定向次数过多");
    }

    private static void copy(InputStream in,OutputStream out,Progress p,long total,String message)throws IOException{byte[]b=new byte[65536];int n;long done=0;while((n=in.read(b))>=0){if(p!=null&&p.isCancelled())throw new InterruptedIOException("用户已取消操作");out.write(b,0,n);done+=n;if(p!=null)p.onProgress(message,done,total);}}
    private static File findDirectoryNamed(File root,String name){if(root.isDirectory()&&root.getName().equals(name))return root;File[]a=root.listFiles();if(a!=null)for(File f:a)if(f.isDirectory()){File r=findDirectoryNamed(f,name);if(r!=null)return r;}return null;}
    private static File findJava(File root){File direct=new File(root,"usr/bin/java");if(direct.isFile())return direct;File[]a=root.listFiles();if(a!=null)for(File f:a){if(f.isDirectory()){File r=findJava(f);if(r!=null)return r;}else if("java".equals(f.getName())&&f.getParentFile()!=null&&"bin".equals(f.getParentFile().getName()))return f;}return null;}
    private static File findJdkRoot(File java,File fallback){File p=java.getParentFile();return p!=null&&p.getParentFile()!=null?p.getParentFile():fallback;}
    private static File findNamed(File root,String name){if(root==null||!root.exists())return null;if(root.isFile()&&name.equals(root.getName()))return root;File[]a=root.listFiles();if(a!=null)for(File f:a){File r=findNamed(f,name);if(r!=null)return r;}return null;}
    private static File findBySuffix(File file,String suffix){
        if(file==null||!file.exists())return null;
        if(file.isFile()&&file.getAbsolutePath().replace('\\','/').endsWith(suffix))return file;
        File[] children=file.listFiles();
        if(children!=null)for(File child:children){File found=findBySuffix(child,suffix);if(found!=null)return found;}
        return null;
    }
    private static void markToolExecutables(File root){if(root==null||!root.exists())return;if(root.isDirectory()){File[]a=root.listFiles();if(a!=null)for(File f:a)markToolExecutables(f);}else{String n=root.getName();File p=root.getParentFile();String pn=p==null?"":p.getName();if("bin".equals(pn)||n.equals("aapt")||n.equals("aapt2")||n.equals("zipalign")||n.equals("adb")||n.equals("java"))chmodExecutable(root);}}

    private static boolean isSymlink(File file){
        if(file==null)return false;
        try{return OsConstants.S_ISLNK(Os.lstat(file.getAbsolutePath()).st_mode);}
        catch(Throwable ignored){return false;}
    }

    private static boolean existsNoFollow(File file){
        if(file==null)return false;
        try{Os.lstat(file.getAbsolutePath());return true;}catch(Throwable ignored){return false;}
    }

    private static boolean chmodExecutable(File file){
        if(file==null||!file.isFile())return false;
        try{Os.chmod(file.getAbsolutePath(),0755);}catch(Throwable ignored){file.setReadable(true,false);file.setWritable(true,true);file.setExecutable(true,false);}
        return file.canExecute();
    }
    private static String runCommand(String[] cmd,File dir,int seconds)throws Exception{return runCommand(cmd,dir,null,seconds);}
    private static String runCommand(String[] cmd,File dir,Map<String,String> environment,int seconds)throws Exception{ProcessBuilder pb=new ProcessBuilder(cmd);if(dir!=null)pb.directory(dir);if(environment!=null)pb.environment().putAll(environment);pb.redirectErrorStream(true);Process p=pb.start();ByteArrayOutputStream out=new ByteArrayOutputStream();InputStream in=p.getInputStream();byte[]b=new byte[4096];long end=System.currentTimeMillis()+seconds*1000L;while(System.currentTimeMillis()<end){while(in.available()>0){int n=in.read(b);if(n>0)out.write(b,0,n);}try{if(p.exitValue()!=0)throw new IOException("命令执行失败："+new String(out.toByteArray(),"UTF-8"));return new String(out.toByteArray(),"UTF-8").trim();}catch(IllegalThreadStateException ignored){Thread.sleep(50);}}p.destroy();throw new IOException("环境自检超时");}
    private static String safeName(String n)throws IOException{if(n==null)return"";n=n.replace('\\','/');while(n.startsWith("./"))n=n.substring(2);if(n.startsWith("/")||n.contains("../")||n.equals(".."))throw new IOException("压缩包包含不安全路径");return n;}
    private static void ensureInside(File root,File child)throws IOException{String r=root.getCanonicalPath()+File.separator,c=child.getCanonicalPath();if(!c.startsWith(r))throw new IOException("压缩包路径越界");}
    private static String sha256(File f)throws Exception{MessageDigest d=MessageDigest.getInstance("SHA-256");byte[]b=new byte[65536];int n;try(InputStream in=new FileInputStream(f)){while((n=in.read(b))>=0)d.update(b,0,n);}StringBuilder s=new StringBuilder();for(byte x:d.digest())s.append(String.format(Locale.US,"%02x",x));return s.toString();}
    private static void zipTree(File root,File file,ZipOutputStream out,ExportCounter counter)throws IOException{
        counter.report("正在写入工具链压缩包…",false);
        if(file.isDirectory()){File[]children=file.listFiles();if(children!=null)for(File c:children)zipTree(root,c,out,counter);return;}
        String name=root.toURI().relativize(file.toURI()).getPath();out.putNextEntry(new ZipEntry(name));
        try(InputStream in=new BufferedInputStream(new FileInputStream(file))){byte[]b=new byte[65536];int n;while((n=in.read(b))>=0){out.write(b,0,n);counter.add(n,"正在导出工具链："+name);}}
        out.closeEntry();counter.report("已写入："+name,true);
    }
    private static void copyTreePreserveLinks(File src,File dst)throws IOException{
        if(isSymlink(src)){
            mkdirs(dst.getParentFile());
            try{Os.symlink(Os.readlink(src.getAbsolutePath()),dst.getAbsolutePath());}
            catch(Exception e){throw new IOException("无法复制符号链接："+src,e);}
            return;
        }
        if(src.isDirectory()){
            mkdirs(dst);File[] children=src.listFiles();
            if(children!=null)for(File child:children)copyTreePreserveLinks(child,new File(dst,child.getName()));
            return;
        }
        if(src.isFile()){
            mkdirs(dst.getParentFile());
            try(InputStream in=new BufferedInputStream(new FileInputStream(src));OutputStream out=new BufferedOutputStream(new FileOutputStream(dst))){
                byte[] buffer=new byte[65536];int count;while((count=in.read(buffer))>=0)out.write(buffer,0,count);
            }
            dst.setLastModified(src.lastModified());if(src.canExecute())dst.setExecutable(true,false);
        }
    }

    private static void copyTree(File src,File dst)throws IOException{
        if(isSymlink(src)){
            mkdirs(dst.getParentFile());
            deleteNoFollow(dst);
            try{Os.symlink(Os.readlink(src.getAbsolutePath()),dst.getAbsolutePath());}
            catch(Exception e){throw new IOException("无法复制符号链接："+src,e);}
            return;
        }
        if(src.isDirectory()){
            mkdirs(dst);
            File[] a=src.listFiles();
            if(a!=null)for(File f:a)copyTree(f,new File(dst,f.getName()));
        }else if(src.isFile()){
            mkdirs(dst.getParentFile());
            try(InputStream i=new FileInputStream(src);OutputStream o=new FileOutputStream(dst)){
                byte[] b=new byte[65536];int n;while((n=i.read(b))>=0)o.write(b,0,n);
            }
        }
    }
    private static void deleteNoFollow(File file)throws IOException{
        if(file==null||!existsNoFollow(file))return;
        if(isSymlink(file)){
            // File.delete() removes the directory entry itself on Android/Linux.
            // Avoid a low-level unlink call because some Android SDK stubs used
            // by imported projects omit that symbol during javac compilation.
            if(file.delete())return;
            throw new IOException("无法删除符号链接："+file);
        }
        deleteTree(file);
    }
    private static void deleteTree(File f)throws IOException{
        if(f==null||!existsNoFollow(f))return;
        if(isSymlink(f)){deleteNoFollow(f);return;}
        if(f.isDirectory()){File[]a=f.listFiles();if(a!=null)for(File c:a)deleteTree(c);}
        if(!f.delete())throw new IOException("无法删除："+f);
    }
    private static void mkdirs(File f)throws IOException{if(f!=null&&!f.exists()&&!f.mkdirs())throw new IOException("无法创建目录："+f);}
    private static long sizeOf(File f){if(f==null||!existsNoFollow(f)||isSymlink(f))return 0;if(f.isFile())return f.length();long n=0;File[]a=f.listFiles();if(a!=null)for(File c:a)n+=sizeOf(c);return n;}
    private static String human(long n){if(n<1024)return n+" B";if(n<1048576)return String.format(Locale.US,"%.1f KB",n/1024.0);if(n<1073741824)return String.format(Locale.US,"%.1f MB",n/1048576.0);return String.format(Locale.US,"%.2f GB",n/1073741824.0);}
}
