package com.example.gradleapkbuilder;

import android.content.Context;
import android.os.Build;
import android.system.Os;
import org.apache.commons.compress.archivers.tar.*;
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream;
import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;
import java.text.SimpleDateFormat;

/** Manages downloaded SDK components and an optional complete PRoot runtime. */
final class RuntimeBundleManager {
    interface Progress { void onProgress(String message,long done,long total); }

    private final File baseDir,bundleDir,downloadsDir,componentsDir;
    RuntimeBundleManager(Context context){
        Context app=context.getApplicationContext();
        baseDir=new File(app.getFilesDir(),"linux-runtime");
        bundleDir=new File(baseDir,"current");
        downloadsDir=new File(baseDir,"downloads");
        componentsDir=new File(baseDir,"sdk-components");
    }

    File getBundleDir(){return bundleDir;}
    File getRootfsDir(){return new File(bundleDir,"rootfs");}
    File getProotFile(){File old=new File(bundleDir,"bin/proot");if(old.isFile())return old;return findNamed(new File(bundleDir,"termux-prefix"),"proot");}
    File getMetadataFile(){return new File(bundleDir,"bundle.properties");}
    File getComponentsDir(){return componentsDir;}
    File getJavaExecutable(){ File f=findJava(componentsDir); return f!=null?f:findJava(getRootfsDir()); }
    File getAndroidSdkDir(){ File direct=new File(componentsDir,"android-sdk"); if(direct.isDirectory())return direct; File inRoot=new File(getRootfsDir(),"opt/android-sdk"); return inRoot.isDirectory()?inRoot:null; }
    File getAapt2Executable(){ File sdk=getAndroidSdkDir(); return sdk==null?null:findNamed(sdk,"aapt2"); }
    File getAndroidJar(){ File sdk=getAndroidSdkDir(); return sdk==null?null:findNamed(sdk,"android.jar"); }
    boolean isDirectBuildReady(){
        if(!isSdkComponentsInstalled()||getJavaExecutable()==null||getAndroidSdkDir()==null||getAapt2Executable()==null||getAndroidJar()==null)return false;
        // Android 10+ removes exec permission from writable app home for apps targeting API 29+.
        // This project ships as a sideload compiler variant targeting 28. Also require chmod to succeed.
        return chmodExecutable(getJavaExecutable())&&chmodExecutable(getAapt2Executable());
    }
    boolean isBuildReady(){ return isDirectBuildReady()||isInstalled(); }
    boolean isArm64(){return Arrays.asList(Build.SUPPORTED_ABIS).contains("arm64-v8a");}
    boolean isSdkComponentsInstalled(){return new File(componentsDir,"components.properties").isFile()&&new File(componentsDir,"android-sdk").isDirectory();}
    boolean isInstalled(){return getProotFile()!=null&&getProotFile().isFile()&&new File(getRootfsDir(),"bin/sh").isFile()&&getMetadataFile().isFile();}

    String status(){
        StringBuilder s=new StringBuilder();
        s.append("设备 ABI：").append(Arrays.toString(Build.SUPPORTED_ABIS)).append('\n');
        s.append("SDK 组件缓存：").append(isSdkComponentsInstalled()?"已安装":"未安装").append('\n');
        s.append("Android 原生本地构建：").append(isDirectBuildReady()?"可用":"不可用").append('\n');
        s.append("PRoot Linux 兼容环境：").append(isInstalled()?"已安装":"未安装（可选）").append('\n');
        File meta=isSdkComponentsInstalled()?new File(componentsDir,"components.properties"):getMetadataFile();
        if(meta.isFile()){
            Properties p=new Properties();try(InputStream in=new FileInputStream(meta)){p.load(in);}catch(Exception ignored){}
            s.append("环境版本：").append(p.getProperty("version","未知")).append('\n');
            s.append("JDK：").append(p.getProperty("jdk","未知")).append('\n');
            s.append("Android SDK：").append(p.getProperty("androidSdk","未知")).append('\n');
        }
        s.append("占用空间：").append(human(sizeOf(baseDir)));
        if(isDirectBuildReady())s.append("\n✓ 已具备 Android 原生 JDK/SDK/Build Tools，本地 Gradle 编译可直接使用，不再强制要求 rootfs。");
        else if(isSdkComponentsInstalled())s.append("\n组件已安装但自检未通过。请在‘更多操作’中运行环境自检，查看缺少的 java、android.jar 或 aapt2。");
        if(!isArm64())s.append("\n警告：自动组件源主要面向 arm64-v8a。");
        return s.toString();
    }

    String selfTest() throws Exception {
        StringBuilder out=new StringBuilder();
        File java=getJavaExecutable(),sdk=getAndroidSdkDir(),aapt2=getAapt2Executable(),androidJar=getAndroidJar();
        out.append("Java：").append(java==null?"未找到":java.getAbsolutePath()).append('\n');
        out.append("Android SDK：").append(sdk==null?"未找到":sdk.getAbsolutePath()).append('\n');
        out.append("aapt2：").append(aapt2==null?"未找到":aapt2.getAbsolutePath()).append('\n');
        out.append("android.jar：").append(androidJar==null?"未找到":androidJar.getAbsolutePath()).append('\n');
        if(java==null||sdk==null||aapt2==null||androidJar==null)throw new IOException(out+"\n环境不完整，请重新执行自动下载安装。");
        if(!chmodExecutable(java)||!chmodExecutable(aapt2))throw new IOException("无法恢复 Java/aapt2 执行权限。请确认安装的是旁加载本地编译版（targetSdk 28），然后重新导入工具链。");
        out.append(runCommand(new String[]{java.getAbsolutePath(),"-version"},null,25)).append('\n');
        out.append(runCommand(new String[]{aapt2.getAbsolutePath(),"version"},null,25));
        if(isInstalled())out.append("\n").append(selfTestProot());
        return out.toString();
    }


    void installProotAutomatically(Progress progress)throws Exception{
        ProotRuntimeInstaller.install(bundleDir,downloadsDir,(m,d,t)->{if(progress!=null)progress.onProgress(m,d,t);});
        String test=selfTestProot();
        if(progress!=null)progress.onProgress("PRoot 自检通过："+test,1,1);
    }

    String selfTestProot()throws Exception{
        if(!isInstalled())throw new IOException("PRoot 或 Linux rootfs 未完整安装");
        File proot=getProotFile();chmodExecutable(proot);
        File prefix=new File(bundleDir,"termux-prefix");
        ProcessBuilder pb=new ProcessBuilder(proot.getAbsolutePath(),"-V");
        pb.environment().put("LD_LIBRARY_PATH",new File(prefix,"lib").getAbsolutePath());
        pb.environment().put("PROOT_TMP_DIR",new File(baseDir,"proot-tmp").getAbsolutePath());
        mkdirs(new File(baseDir,"proot-tmp"));pb.redirectErrorStream(true);
        Process p=pb.start();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[]b=new byte[4096];int n;try(InputStream in=p.getInputStream()){while((n=in.read(b))>=0)out.write(b,0,n);}
        int code=p.waitFor();if(code!=0)throw new IOException("proot --version 失败，退出代码 "+code+"："+out.toString("UTF-8"));
        return out.toString("UTF-8").trim();
    }
    void installAutomatically(Progress progress)throws Exception{
        String abi=isArm64()?"arm64-v8a":(Build.SUPPORTED_ABIS.length>0?Build.SUPPORTED_ABIS[0]:"unknown");
        RuntimeCatalog.ComponentSet set=RuntimeCatalog.discoverComponents(abi,m->{if(progress!=null)progress.onProgress(m,0,-1);});
        if(progress!=null)progress.onProgress("已找到："+set.summary(),0,-1);
        installComponentSet(set,progress);
    }

    private void installComponentSet(RuntimeCatalog.ComponentSet set,Progress progress)throws Exception{
        mkdirs(downloadsDir);
        File staging=new File(baseDir,"components-staging-"+System.currentTimeMillis());
        deleteTree(staging);mkdirs(staging);
        File sdkStage=new File(staging,"sdk-home");mkdirs(sdkStage);
        File jdkStage=new File(staging,"jdk-home");mkdirs(jdkStage);
        try{
            int index=0,total=set.urls.size();
            for(Map.Entry<String,String> c:set.urls.entrySet()){
                index++;
                String name=c.getKey();
                File archive=new File(downloadsDir,name+".tar.xz.part");
                final int current=index;
                download(c.getValue(),archive,(m,d,t)->{if(progress!=null)progress.onProgress("["+current+"/"+total+"] 下载 "+name+"…",d,t);});
                File destination=name.startsWith("jdk")?jdkStage:("android-sdk".equals(name)?sdkStage:new File(sdkStage,"android-sdk"));
                mkdirs(destination);
                extractTarXz(archive,destination,name,progress);
                archive.delete();
            }

            File foundSdk=findDirectoryNamed(sdkStage,"android-sdk");
            if(foundSdk==null)throw new IOException("组件解压完成，但没有找到 android-sdk 目录");
            File finalSdk=new File(staging,"android-sdk");
            if(!foundSdk.renameTo(finalSdk)){copyTree(foundSdk,finalSdk);}
            File java=findJava(jdkStage);
            if(java!=null){File jdkRoot=findJdkRoot(java,jdkStage);copyTree(jdkRoot,new File(staging,"jdk"));}

            Properties p=new Properties();
            p.setProperty("version","AndroidIDE-tools-"+set.version);
            p.setProperty("abi",set.abi);
            p.setProperty("androidSdk",set.version);
            p.setProperty("jdk",java==null?"未包含（现代 AGP 建议 JDK 17）":"AndroidIDE JDK 11");
            p.setProperty("source",set.source);
            try(OutputStream out=new FileOutputStream(new File(staging,"components.properties"))){p.store(out,"GradleApkBuilder SDK components");}

            deleteTree(componentsDir);
            if(!staging.renameTo(componentsDir)){copyTree(staging,componentsDir);deleteTree(staging);}
            markToolExecutables(componentsDir);
            if(progress!=null)progress.onProgress("SDK/JDK 组件安装完成，正在准备本地构建…",1,1);
        }catch(Exception e){deleteTree(staging);throw e;}
    }

    void installFromUrl(String url,String expectedSha256,Progress progress)throws Exception{
        if(!isArm64())throw new IOException("当前设备不是 ARM64，无法安装首版 Linux 工具链");
        mkdirs(downloadsDir);File tmp=new File(downloadsDir,"runtime.bundle.part");download(url,tmp,progress);
        String actual=sha256(tmp);if(expectedSha256!=null&&!expectedSha256.trim().isEmpty()&&!actual.equalsIgnoreCase(expectedSha256.trim())){tmp.delete();throw new SecurityException("工具链校验失败\n期望："+expectedSha256+"\n实际："+actual);}installZip(tmp,progress);tmp.delete();
    }
    void importBundle(InputStream input,Progress progress)throws Exception{
        mkdirs(downloadsDir);
        File tmp=new File(downloadsDir,"imported-toolchain.zip");
        try(OutputStream out=new FileOutputStream(tmp)){copy(input,out,progress,-1,"正在导入工具链程序包…");}
        try{
            if(isPortablePackage(tmp)) installPortablePackage(tmp,progress);
            else installZip(tmp,progress); // 兼容旧版完整 PRoot ZIP
        }finally{tmp.delete();}
    }

    /** 导出所有已下载组件、可选 Linux 运行时、元数据和逐文件 SHA-256。 */
    void exportBundle(OutputStream out,Progress progress)throws Exception{
        if(!isSdkComponentsInstalled()&&!isInstalled())throw new IOException("尚未安装任何环境组件");
        File stage=new File(baseDir,"export-stage-"+System.currentTimeMillis());deleteTree(stage);mkdirs(stage);
        try{
            Properties meta=new Properties();
            meta.setProperty("format","GradleApkBuilder.ToolchainPackage");
            meta.setProperty("schema","2");
            meta.setProperty("appVersion","1.5.2");
            meta.setProperty("createdAt",new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ",Locale.US).format(new Date()));
            meta.setProperty("abis",Arrays.toString(Build.SUPPORTED_ABIS));
            meta.setProperty("hasComponents",String.valueOf(isSdkComponentsInstalled()));
            meta.setProperty("hasRuntime",String.valueOf(isInstalled()));
            if(isSdkComponentsInstalled())copyTree(componentsDir,new File(stage,"components"));
            if(isInstalled())copyTree(bundleDir,new File(stage,"runtime"));
            try(OutputStream m=new FileOutputStream(new File(stage,"toolchain-package.properties"))){meta.store(m,"GradleApkBuilder portable toolchain package");}
            writeChecksumManifest(stage,new File(stage,"checksums.sha256"),progress);
            try(ZipOutputStream zout=new ZipOutputStream(new BufferedOutputStream(out))){zipTree(stage,stage,zout,progress);}
        }finally{deleteTree(stage);}
    }
    void remove()throws IOException{deleteTree(baseDir);}


    private static boolean isPortablePackage(File zip)throws IOException{
        try(ZipFile z=new ZipFile(zip)){return z.getEntry("toolchain-package.properties")!=null;}
    }

    private void installPortablePackage(File zip,Progress progress)throws Exception{
        File stage=new File(baseDir,"import-stage-"+System.currentTimeMillis());deleteTree(stage);mkdirs(stage);
        try{
            unzipAll(zip,stage,progress,"正在解压工具链程序包…");
            File metaFile=new File(stage,"toolchain-package.properties");
            Properties meta=new Properties();try(InputStream in=new FileInputStream(metaFile)){meta.load(in);}
            if(!"GradleApkBuilder.ToolchainPackage".equals(meta.getProperty("format")))throw new IOException("不是有效的 GradleApkBuilder 工具链程序包");
            int schema=Integer.parseInt(meta.getProperty("schema","0"));if(schema<2)throw new IOException("工具链包格式版本过旧");
            verifyChecksumManifest(stage,new File(stage,"checksums.sha256"),progress);
            File importedComponents=new File(stage,"components"), importedRuntime=new File(stage,"runtime");
            if(!importedComponents.isDirectory()&&!importedRuntime.isDirectory())throw new IOException("工具链包不包含任何可安装组件");

            File backupComponents=new File(baseDir,"components-backup"),backupRuntime=new File(baseDir,"runtime-backup");
            deleteTree(backupComponents);deleteTree(backupRuntime);
            if(componentsDir.exists()&&!componentsDir.renameTo(backupComponents))copyTree(componentsDir,backupComponents);
            if(bundleDir.exists()&&!bundleDir.renameTo(backupRuntime))copyTree(bundleDir,backupRuntime);
            try{
                if(importedComponents.isDirectory()){deleteTree(componentsDir);copyTree(importedComponents,componentsDir);}
                if(importedRuntime.isDirectory()){deleteTree(bundleDir);copyTree(importedRuntime,bundleDir);}
                markToolExecutables(componentsDir);markToolExecutables(bundleDir);
                if(progress!=null)progress.onProgress("正在运行导入后的环境自检…",0,-1);
                if(isSdkComponentsInstalled())selfTest();
                else if(isInstalled())selfTestProot();
                else throw new IOException("导入后未检测到可用环境");
                deleteTree(backupComponents);deleteTree(backupRuntime);
            }catch(Exception e){
                deleteTree(componentsDir);deleteTree(bundleDir);
                if(backupComponents.exists()&&!backupComponents.renameTo(componentsDir))copyTree(backupComponents,componentsDir);
                if(backupRuntime.exists()&&!backupRuntime.renameTo(bundleDir))copyTree(backupRuntime,bundleDir);
                throw new IOException("导入安装或自检失败，已恢复原环境："+e.getMessage(),e);
            }
        }finally{deleteTree(stage);}
    }

    private static void unzipAll(File zip,File root,Progress progress,String message)throws Exception{
        long done=0,total=zip.length();
        try(ZipInputStream zin=new ZipInputStream(new BufferedInputStream(new FileInputStream(zip)))){
            ZipEntry e;byte[]b=new byte[65536];
            while((e=zin.getNextEntry())!=null){String name=safeName(e.getName());if(name.isEmpty())continue;File dst=new File(root,name);ensureInside(root,dst);
                if(e.isDirectory())mkdirs(dst);else{mkdirs(dst.getParentFile());try(OutputStream out=new BufferedOutputStream(new FileOutputStream(dst))){int n;while((n=zin.read(b))>=0){out.write(b,0,n);done+=n;if(progress!=null)progress.onProgress(message,done,total);}}}
            }
        }
    }

    private static void writeChecksumManifest(File root,File manifest,Progress progress)throws Exception{
        ArrayList<File> files=new ArrayList<>();collectFiles(root,files,manifest);
        Collections.sort(files,Comparator.comparing(File::getAbsolutePath));
        try(Writer w=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(manifest),"UTF-8"))){
            int i=0;for(File f:files){String rel=root.toURI().relativize(f.toURI()).getPath();w.write(sha256(f)+"  "+rel+"\n");i++;if(progress!=null)progress.onProgress("正在生成完整性清单："+rel,i,files.size());}
        }
    }

    private static void verifyChecksumManifest(File root,File manifest,Progress progress)throws Exception{
        if(!manifest.isFile())throw new IOException("工具链包缺少 checksums.sha256");
        List<String> lines=new ArrayList<>();try(BufferedReader r=new BufferedReader(new InputStreamReader(new FileInputStream(manifest),"UTF-8"))){String line;while((line=r.readLine())!=null)if(!line.trim().isEmpty())lines.add(line);}
        int i=0;for(String line:lines){int sep=line.indexOf("  ");if(sep!=64)throw new IOException("无效的校验清单行");String expected=line.substring(0,64),name=safeName(line.substring(sep+2));File f=new File(root,name);ensureInside(root,f);if(!f.isFile())throw new IOException("工具链包缺少文件："+name);String actual=sha256(f);if(!expected.equalsIgnoreCase(actual))throw new SecurityException("工具链文件校验失败："+name);i++;if(progress!=null)progress.onProgress("正在校验："+name,i,lines.size());}
    }

    private static void collectFiles(File root,List<File> out,File excluded){
        if(root.equals(excluded))return;if(root.isFile()){out.add(root);return;}File[]a=root.listFiles();if(a!=null)for(File f:a)collectFiles(f,out,excluded);
    }

    private void installZip(File zip,Progress progress)throws Exception{
        File staging=new File(baseDir,"staging-"+System.currentTimeMillis());deleteTree(staging);mkdirs(staging);long count=0;
        try(ZipInputStream zin=new ZipInputStream(new BufferedInputStream(new FileInputStream(zip)))){ZipEntry e;while((e=zin.getNextEntry())!=null){String name=safeName(e.getName());if(name.isEmpty())continue;File dst=new File(staging,name);ensureInside(staging,dst);if(e.isDirectory())mkdirs(dst);else{mkdirs(dst.getParentFile());try(OutputStream out=new BufferedOutputStream(new FileOutputStream(dst))){byte[]b=new byte[65536];int n;while((n=zin.read(b))>=0){out.write(b,0,n);count+=n;if(progress!=null)progress.onProgress("正在解压完整 Linux 工具链…",count,zip.length());}}}}}
        File p=new File(staging,"bin/proot"),sh=new File(staging,"rootfs/bin/sh"),meta=new File(staging,"bundle.properties");if(!p.isFile()||!sh.isFile()||!meta.isFile()){deleteTree(staging);throw new IOException("工具链包格式无效：必须包含 bin/proot、rootfs/bin/sh、bundle.properties");}p.setExecutable(true,true);deleteTree(bundleDir);if(!staging.renameTo(bundleDir)){copyTree(staging,bundleDir);deleteTree(staging);}
    }

    private static void extractTarXz(File archive,File destination,String component,Progress progress)throws Exception{
        long entries=0;
        ArrayList<String[]> links=new ArrayList<>();
        try(InputStream fin=new BufferedInputStream(new FileInputStream(archive));XZCompressorInputStream xz=new XZCompressorInputStream(fin,true);TarArchiveInputStream tin=new TarArchiveInputStream(xz)){
            TarArchiveEntry e;byte[]buf=new byte[65536];
            while((e=tin.getNextTarEntry())!=null){String name=safeName(e.getName());if(name.isEmpty())continue;File dst=new File(destination,name);ensureInside(destination,dst);
                if(e.isDirectory()){mkdirs(dst);}else if(e.isSymbolicLink()||e.isLink()){
                    mkdirs(dst.getParentFile());links.add(new String[]{dst.getAbsolutePath(),e.getLinkName()});
                }else{mkdirs(dst.getParentFile());try(OutputStream out=new BufferedOutputStream(new FileOutputStream(dst))){int n;while((n=tin.read(buf))>=0)out.write(buf,0,n);}if((e.getMode()&0111)!=0)dst.setExecutable(true,true);}
                entries++;if(progress!=null&&entries%25==0)progress.onProgress("正在解压 "+component+"…",entries,-1);
            }
        }catch(NoClassDefFoundError err){throw new IOException("缺少 XZ 解压库，请确认 Gradle 已下载 commons-compress 与 xz 依赖",err);}
        for(String[] link:links){try{File dst=new File(link[0]);if(dst.exists())dst.delete();Os.symlink(link[1],dst.getAbsolutePath());}catch(Exception ignored){}}
        if(entries==0)throw new IOException(component+" 压缩包为空或格式不受支持");
    }

    private static void download(String source,File dst,Progress progress)throws Exception{
        URL current=new URL(source);
        for(int redirects=0;redirects<8;redirects++){
            HttpURLConnection c=(HttpURLConnection)current.openConnection();c.setConnectTimeout(25000);c.setReadTimeout(90000);c.setInstanceFollowRedirects(false);c.setRequestProperty("User-Agent","GradleApkBuilder/1.4.0");
            int code=c.getResponseCode();if(code>=300&&code<400){String loc=c.getHeaderField("Location");c.disconnect();if(loc==null)throw new IOException("下载重定向缺少地址");current=new URL(current,loc);continue;}if(code<200||code>=300){c.disconnect();throw new IOException("下载失败，HTTP "+code+"："+current.getHost());}
            long total=c.getContentLengthLong();try(InputStream in=new BufferedInputStream(c.getInputStream());OutputStream out=new BufferedOutputStream(new FileOutputStream(dst))){copy(in,out,progress,total,"正在下载工具链组件…");}finally{c.disconnect();}return;
        }throw new IOException("下载重定向次数过多");
    }

    private static void copy(InputStream in,OutputStream out,Progress p,long total,String message)throws IOException{byte[]b=new byte[65536];int n;long done=0;while((n=in.read(b))>=0){out.write(b,0,n);done+=n;if(p!=null)p.onProgress(message,done,total);}}
    private static File findDirectoryNamed(File root,String name){if(root.isDirectory()&&root.getName().equals(name))return root;File[]a=root.listFiles();if(a!=null)for(File f:a)if(f.isDirectory()){File r=findDirectoryNamed(f,name);if(r!=null)return r;}return null;}
    private static File findJava(File root){File direct=new File(root,"usr/bin/java");if(direct.isFile())return direct;File[]a=root.listFiles();if(a!=null)for(File f:a){if(f.isDirectory()){File r=findJava(f);if(r!=null)return r;}else if("java".equals(f.getName())&&f.getParentFile()!=null&&"bin".equals(f.getParentFile().getName()))return f;}return null;}
    private static File findJdkRoot(File java,File fallback){File p=java.getParentFile();return p!=null&&p.getParentFile()!=null?p.getParentFile():fallback;}
    private static File findNamed(File root,String name){if(root==null||!root.exists())return null;if(root.isFile()&&name.equals(root.getName()))return root;File[]a=root.listFiles();if(a!=null)for(File f:a){File r=findNamed(f,name);if(r!=null)return r;}return null;}
    private static void markToolExecutables(File root){if(root==null||!root.exists())return;if(root.isDirectory()){File[]a=root.listFiles();if(a!=null)for(File f:a)markToolExecutables(f);}else{String n=root.getName();File p=root.getParentFile();String pn=p==null?"":p.getName();if("bin".equals(pn)||n.equals("aapt")||n.equals("aapt2")||n.equals("zipalign")||n.equals("adb")||n.equals("java"))chmodExecutable(root);}}
    private static boolean chmodExecutable(File file){
        if(file==null||!file.isFile())return false;
        try{Os.chmod(file.getAbsolutePath(),0755);}catch(Throwable ignored){file.setReadable(true,false);file.setWritable(true,true);file.setExecutable(true,false);}
        return file.canExecute();
    }
    private static String runCommand(String[] cmd,File dir,int seconds)throws Exception{ProcessBuilder pb=new ProcessBuilder(cmd);if(dir!=null)pb.directory(dir);pb.redirectErrorStream(true);Process p=pb.start();ByteArrayOutputStream out=new ByteArrayOutputStream();InputStream in=p.getInputStream();byte[]b=new byte[4096];long end=System.currentTimeMillis()+seconds*1000L;while(System.currentTimeMillis()<end){while(in.available()>0){int n=in.read(b);if(n>0)out.write(b,0,n);}try{if(p.exitValue()!=0)throw new IOException("命令执行失败："+new String(out.toByteArray(),"UTF-8"));return new String(out.toByteArray(),"UTF-8").trim();}catch(IllegalThreadStateException ignored){Thread.sleep(50);}}p.destroy();throw new IOException("环境自检超时");}
    private static String safeName(String n)throws IOException{if(n==null)return"";n=n.replace('\\','/');while(n.startsWith("./"))n=n.substring(2);if(n.startsWith("/")||n.contains("../")||n.equals(".."))throw new IOException("压缩包包含不安全路径");return n;}
    private static void ensureInside(File root,File child)throws IOException{String r=root.getCanonicalPath()+File.separator,c=child.getCanonicalPath();if(!c.startsWith(r))throw new IOException("压缩包路径越界");}
    private static String sha256(File f)throws Exception{MessageDigest d=MessageDigest.getInstance("SHA-256");byte[]b=new byte[65536];int n;try(InputStream in=new FileInputStream(f)){while((n=in.read(b))>=0)d.update(b,0,n);}StringBuilder s=new StringBuilder();for(byte x:d.digest())s.append(String.format(Locale.US,"%02x",x));return s.toString();}
    private static void zipTree(File root,File file,ZipOutputStream out,Progress p)throws IOException{if(file.isDirectory()){File[]children=file.listFiles();if(children!=null)for(File c:children)zipTree(root,c,out,p);return;}String name=root.toURI().relativize(file.toURI()).getPath();out.putNextEntry(new ZipEntry(name));try(InputStream in=new FileInputStream(file)){byte[]b=new byte[65536];int n;while((n=in.read(b))>=0)out.write(b,0,n);}out.closeEntry();if(p!=null)p.onProgress("正在导出工具链："+name,0,-1);}
    private static void copyTree(File src,File dst)throws IOException{if(src.isDirectory()){mkdirs(dst);File[]a=src.listFiles();if(a!=null)for(File f:a)copyTree(f,new File(dst,f.getName()));}else{mkdirs(dst.getParentFile());try(InputStream i=new FileInputStream(src);OutputStream o=new FileOutputStream(dst)){byte[]b=new byte[65536];int n;while((n=i.read(b))>=0)o.write(b,0,n);}}}
    private static void deleteTree(File f)throws IOException{if(!f.exists())return;if(f.isDirectory()){File[]a=f.listFiles();if(a!=null)for(File c:a)deleteTree(c);}if(!f.delete())throw new IOException("无法删除："+f);}
    private static void mkdirs(File f)throws IOException{if(f!=null&&!f.exists()&&!f.mkdirs())throw new IOException("无法创建目录："+f);}
    private static long sizeOf(File f){if(!f.exists())return 0;if(f.isFile())return f.length();long n=0;File[]a=f.listFiles();if(a!=null)for(File c:a)n+=sizeOf(c);return n;}
    private static String human(long n){if(n<1024)return n+" B";if(n<1048576)return String.format(Locale.US,"%.1f KB",n/1024.0);if(n<1073741824)return String.format(Locale.US,"%.1f MB",n/1048576.0);return String.format(Locale.US,"%.2f GB",n/1073741824.0);}
}
