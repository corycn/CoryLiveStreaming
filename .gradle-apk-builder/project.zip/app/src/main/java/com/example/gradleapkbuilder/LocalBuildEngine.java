package com.example.gradleapkbuilder;

import java.io.*;
import android.system.Os;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.zip.*;

/** Runs Gradle directly with Android-native AndroidIDE tools, with PRoot as a fallback. */
final class LocalBuildEngine {
    interface Listener { void onLine(String line); }
    private final RuntimeBundleManager runtime;
    private final Listener listener;
    private volatile Process process;

    LocalBuildEngine(RuntimeBundleManager runtime, Listener listener) { this.runtime=runtime; this.listener=listener; }

    File build(File projectZip, File workBase, String task) throws Exception {
        if (!runtime.isBuildReady()) throw new IOException("本地构建环境尚未通过自检，请打开 SDK 管理器重新安装或运行环境自检");
        File work = new File(workBase, "local-build-" + System.currentTimeMillis());
        File project = new File(work, "project"), out = new File(work, "outputs");
        mkdirs(project); mkdirs(out); unzip(projectZip, project);
        File projectRoot = findProjectRoot(project);
        if(runtime.isDirectBuildReady()) runDirect(projectRoot,task);
        else runProot(projectRoot,out,task);
        File apk=findFirstApk(projectRoot); if(apk==null)throw new IOException("构建完成但未找到 APK");
        File result=new File(out,apk.getName()); copy(apk,result); return result;
    }

    private void runDirect(File projectRoot,String task)throws Exception{
        int preferredJdk=detectPreferredJdk(projectRoot);
        File java=preferredJdk>0?runtime.getJavaExecutable(preferredJdk):runtime.getJavaExecutable();
        File selectedPrefix=preferredJdk>0?runtime.getJdkPrefix(preferredJdk):runtime.getActiveJdkPrefix();
        File selectedHome=preferredJdk>0?runtime.getJdkHome(preferredJdk):runtime.getActiveJdkHome();
        String selectedLibraries=preferredJdk>0?runtime.getJavaLibraryPath(preferredJdk):runtime.getJavaLibraryPath();
        if(java==null){java=runtime.getJavaExecutable();selectedPrefix=runtime.getActiveJdkPrefix();selectedHome=runtime.getActiveJdkHome();selectedLibraries=runtime.getJavaLibraryPath();}
        File sdk=runtime.getAndroidSdkDir();
        if(java==null||sdk==null)throw new IOException("没有找到本地 Java 或 Android SDK");
        restoreExecutable(java);
        File jdk=selectedHome!=null?selectedHome:java.getParentFile().getParentFile();
        restoreBinPermissions(java.getParentFile());
        File gradlew=new File(projectRoot,"gradlew");
        if(gradlew.isFile())restoreExecutable(gradlew);
        String javaVersion=verifyJavaTool(java,selectedPrefix,jdk,selectedLibraries);
        int javaMajor=parseJavaMajor(javaVersion);
        notifyLine("本次构建使用 JDK "+javaMajor+"："+java.getAbsolutePath()+(preferredJdk>0?"（根据工程兼容性自动选择）":""));

        int requestedApi=detectCompileSdk(projectRoot);
        if(requestedApi<=0)requestedApi=runtime.getHighestInstalledPlatformApi();
        PlatformTools platform=preparePlatformTools(requestedApi);
        // If the cached Android platform or ARM64 aapt2 is damaged/incompatible,
        // repair the AndroidIDE SDK component set once and repeat the preflight.
        if(platform==null){
            notifyLine("Android Platform/aapt2 预检失败，正在自动修复 API "+requestedApi+" 构建环境…");
            final String[] lastProgress={""};
            runtime.repairForCompileSdk(requestedApi,(message,done,total)->{
                String line=progressText(message,done,total);
                if(!line.equals(lastProgress[0])){lastProgress[0]=line;notifyLine(line);}
            });
            sdk=runtime.getAndroidSdkDir();
            platform=preparePlatformTools(requestedApi);
        }
        if(platform==null){
            int highest=runtime.getHighestInstalledPlatformApi();
            throw new IOException("自动修复后仍没有找到可读取 Android Platform "+requestedApi+" 的 ARM64 aapt2/android.jar。当前最高 API："+highest+"。请导出 Bug 日志。 ");
        }
        File androidJar=platform.androidJar;
        File aapt2=platform.aapt2;
        writeLocalProperties(projectRoot,sdk);
        File gradleHome=prepareOfficialGradle(projectRoot, runtime.getGradleDistributionsDir());
        File launcher=findGradleLauncher(gradleHome);
        if(launcher==null)throw new IOException("Gradle 发行包缺少 lib/gradle-launcher-*.jar："+gradleHome);
        if(javaMajor>0&&javaMajor<17)notifyLine("警告：当前 Java "+javaMajor+"。AGP 8.x 通常要求 JDK 17；若后续报 Java 版本不足，请在 SDK 管理器安装 JDK 17/21。");
        String cleanTask=cleanTask(task);
        File javaTmp=new File(projectRoot,".java-tmp");mkdirs(javaTmp);
        File gradleUserHome=runtime.getGradleUserHomeDir();mkdirs(gradleUserHome);
        migrateLegacyGradleUserHomes(projectRoot,gradleUserHome);
        cleanupSharedGradleLocks(gradleUserHome);
        File homeDir=new File(projectRoot,".home");mkdirs(homeDir);
        File androidUserHome=new File(homeDir,".android");mkdirs(androidUserHome);
        File analyticsSettings=new File(androidUserHome,"analytics.settings");
        try{if(!analyticsSettings.exists())analyticsSettings.createNewFile();}catch(IOException ignored){}
        try{Os.chmod(javaTmp.getAbsolutePath(),0700);}catch(Throwable ignored){}
        try{Os.chmod(homeDir.getAbsolutePath(),0700);}catch(Throwable ignored){}
        try{Os.chmod(androidUserHome.getAbsolutePath(),0700);}catch(Throwable ignored){}
        try{Os.chmod(analyticsSettings.getAbsolutePath(),0600);}catch(Throwable ignored){}
        String tmpProperty="-Djava.io.tmpdir="+javaTmp.getAbsolutePath();
        String userHomeProperty="-Duser.home="+homeDir.getAbsolutePath();
        String androidUserHomeProperty="-Dandroid.user.home="+androidUserHome.getAbsolutePath();
        String launchMechanism="-Djdk.lang.Process.launchMechanism=VFORK";
        String gradleJvmArgs="-Xms64m -Xmx512m -Dfile.encoding=UTF-8 "+tmpProperty+" "+userHomeProperty+" "+androidUserHomeProperty+" -Dorg.gradle.vfs.watch=false "+launchMechanism;
        writeGradleRuntimeProperties(new File(gradleUserHome,"gradle.properties"),gradleJvmArgs);
        List<String> command=new ArrayList<>();
        command.add(java.getAbsolutePath());
        command.add("-Xms64m");
        command.add("-Xmx512m");
        command.add("-Dfile.encoding=UTF-8");
        command.add(tmpProperty);
        command.add(userHomeProperty);
        command.add(androidUserHomeProperty);
        command.add(launchMechanism);
        // If Gradle still needs a single-use daemon, make that JVM use VFORK too.
        command.add("-Dorg.gradle.jvmargs="+gradleJvmArgs);
        command.add("-Dorg.gradle.vfs.watch=false");
        command.add("-classpath");
        command.add(launcher.getAbsolutePath());
        command.add("org.gradle.launcher.GradleMain");
        command.add("--no-daemon");
        command.add("--no-watch-fs");
        command.add("--no-build-cache");
        command.add("--max-workers=1");
        command.add("--stacktrace");
        command.add("--console=plain");
        command.add("-Dorg.gradle.parallel=false");
        command.add("-Dorg.gradle.workers.max=1");
        command.add("-Dorg.gradle.caching=false");
        command.add("-Dkotlin.compiler.execution.strategy=in-process");
        command.add("-Dkotlin.daemon.enabled=false");
        command.add("-Pandroid.aapt2FromMavenOverride="+aapt2.getAbsolutePath());
        command.add(cleanTask);
        ProcessBuilder pb=new ProcessBuilder(command);
        pb.directory(projectRoot);pb.redirectErrorStream(true);
        Map<String,String> env=pb.environment();
        env.put("HOME",homeDir.getAbsolutePath());
        // AGP 8.x rejects builds when old and new Android preference variables
        // resolve to different folders. Remove inherited/deprecated variables and
        // use only the currently recommended ANDROID_USER_HOME.
        env.remove("ANDROID_PREFS_ROOT");
        env.remove("ANDROID_SDK_HOME");
        env.remove("ANDROID_USER_HOME");
        env.put("ANDROID_USER_HOME",androidUserHome.getAbsolutePath());
        env.put("JAVA_HOME",jdk.getAbsolutePath());
        env.put("ANDROID_HOME",sdk.getAbsolutePath());env.put("ANDROID_SDK_ROOT",sdk.getAbsolutePath());
        env.put("GRADLE_USER_HOME",gradleUserHome.getAbsolutePath());
        env.put("PATH",java.getParentFile().getAbsolutePath()+":"+System.getenv("PATH"));
        env.put("TMPDIR",javaTmp.getAbsolutePath());
        env.put("TMP",javaTmp.getAbsolutePath());
        env.put("TEMP",javaTmp.getAbsolutePath());
        env.put("JAVA_TOOL_OPTIONS",tmpProperty+" "+userHomeProperty+" "+androidUserHomeProperty+" -Dorg.gradle.vfs.watch=false "+launchMechanism);
        env.put("GRADLE_OPTS",tmpProperty+" "+userHomeProperty+" "+androidUserHomeProperty+" -Dorg.gradle.vfs.watch=false "+launchMechanism);
        env.remove("_JAVA_OPTIONS");
        env.remove("JDK_JAVA_OPTIONS");
        if(!selectedLibraries.isEmpty())env.put("LD_LIBRARY_PATH",selectedLibraries);
        if(selectedPrefix!=null){File tmp=new File(selectedPrefix,"tmp");mkdirs(tmp);}
        notifyLine("临时目录："+javaTmp.getAbsolutePath());
        notifyLine("Gradle/Maven 共享依赖缓存："+gradleUserHome.getAbsolutePath());
        notifyLine("进程启动模式：VFORK（兼容 Android/Termux JDK spawn helper）");
        notifyLine("使用 Android 原生工具链构建（无需 PRoot/rootfs）");
        File onlineLog=new File(projectRoot,"gradle-build-full.log");
        try{
            execute(pb,onlineLog);
        }catch(IOException onlineFailure){
            if(isNetworkResolutionFailure(onlineLog)&&runtime.hasGradleDependencyCache()){
                notifyLine("检测到网络/DNS不可用，正在使用已备份的 Gradle/Maven 缓存离线重试…");
                ArrayList<String> offlineCommand=new ArrayList<>(command);
                offlineCommand.add(offlineCommand.size()-1,"--offline");
                ProcessBuilder offline=new ProcessBuilder(offlineCommand);
                offline.directory(projectRoot);offline.redirectErrorStream(true);
                offline.environment().clear();
                offline.environment().putAll(pb.environment());
                execute(offline,new File(projectRoot,"gradle-build-offline.log"));
            }else{
                throw onlineFailure;
            }
        }
        notifyLine("已保存本次成功下载的 AGP/Kotlin/AndroidX/Maven 依赖到共享工具链缓存（"+humanBytes(runtime.gradleDependencyCacheBytes())+"）");
    }

    private static final class PlatformTools {
        final File androidJar;
        final File aapt2;
        PlatformTools(File androidJar,File aapt2){this.androidJar=androidJar;this.aapt2=aapt2;}
    }

    private PlatformTools preparePlatformTools(int requestedApi)throws Exception{
        File androidJar=runtime.getAndroidJar(requestedApi);
        if(androidJar==null){
            notifyLine("未安装工程需要的 Android Platform "+requestedApi);
            return null;
        }
        try{
            normalizeAndroidJar(androidJar);
        }catch(Exception e){
            notifyLine("Android Platform 文件预检失败："+shortMessage(e));
            return null;
        }
        File aapt2=selectCompatibleAapt2(runtime.getAapt2Candidates(),androidJar);
        if(aapt2==null)return null;
        restoreExecutable(aapt2);
        verifyTool(aapt2,new String[]{"version"},"aapt2");
        notifyLine("Android Platform 预检通过：API "+requestedApi+" / "+androidJar.getAbsolutePath());
        return new PlatformTools(androidJar,aapt2);
    }

    private static String progressText(String message,long done,long total){
        if(total<=0)return message;
        long percent=Math.max(0,Math.min(100,done*100/Math.max(1,total)));
        return message+"（"+percent+"%）";
    }


    private File selectCompatibleAapt2(List<File> candidates,File androidJar)throws Exception{
        ArrayList<String> failures=new ArrayList<>();
        for(File candidate:candidates){
            if(candidate==null||!candidate.isFile())continue;
            try{
                restoreExecutable(candidate);
                String result=runToolLimited(Arrays.asList(candidate.getAbsolutePath(),"dump","resources",androidJar.getAbsolutePath()),45);
                notifyLine("aapt2 平台兼容性预检通过："+candidate.getAbsolutePath());
                return candidate;
            }catch(Exception e){
                failures.add(candidate.getAbsolutePath()+"："+shortMessage(e));
            }
        }
        if(!failures.isEmpty())notifyLine("aapt2 平台预检失败：\n"+joinLines(failures));
        return null;
    }

    private static void normalizeAndroidJar(File jar)throws Exception{
        if(jar==null||!jar.isFile())throw new IOException("Android Platform 缺少 android.jar："+jar);
        if(jar.length()<1024*1024)throw new IOException("android.jar 文件异常小，可能下载或解压损坏："+jar+"（"+jar.length()+" B）");
        validateAndroidJar(jar);
        try{Os.chmod(jar.getAbsolutePath(),0644);}catch(Throwable ignored){jar.setReadable(true,false);}
        // Replace symlinks or unusual files with a regular, readable copy. Native aapt2
        // is less tolerant of broken/absolute links than Java's File API.
        boolean symlink=false;
        try{symlink=android.system.OsConstants.S_ISLNK(Os.lstat(jar.getAbsolutePath()).st_mode);}catch(Throwable ignored){}
        if(symlink||!jar.canRead()){
            File copy=new File(jar.getParentFile(),"android.jar.gab-normalized");
            copyFile(jar,copy);validateAndroidJar(copy);
            if(!jar.delete())throw new IOException("无法替换异常 android.jar："+jar);
            if(!copy.renameTo(jar)){copyFile(copy,jar);copy.delete();}
            try{Os.chmod(jar.getAbsolutePath(),0644);}catch(Throwable ignored){jar.setReadable(true,false);}
        }
    }

    private static void validateAndroidJar(File jar)throws Exception{
        try(ZipFile zip=new ZipFile(jar)){
            if(zip.getEntry("resources.arsc")==null)throw new IOException("android.jar 缺少 resources.arsc");
            if(zip.getEntry("android/R.class")==null&&zip.getEntry("android/Manifest.class")==null)
                throw new IOException("android.jar 缺少 Android framework class");
        }catch(ZipException e){throw new IOException("android.jar 不是有效的 ZIP/JAR，可能下载损坏："+jar,e);}
    }

    private static String runToolLimited(List<String> command,int timeoutSeconds)throws Exception{
        Process p=new ProcessBuilder(command).redirectErrorStream(true).start();
        ByteArrayOutputStream sample=new ByteArrayOutputStream();
        Thread reader=new Thread(()->{
            try(InputStream in=p.getInputStream()){
                byte[] buffer=new byte[8192];int count;
                while((count=in.read(buffer))>=0){
                    int keep=Math.min(count,Math.max(0,32768-sample.size()));
                    if(keep>0)sample.write(buffer,0,keep);
                }
            }catch(IOException ignored){}
        },"aapt2-preflight-reader");
        reader.start();
        if(!p.waitFor(timeoutSeconds,TimeUnit.SECONDS)){p.destroyForcibly();reader.join(2000);throw new IOException("命令超时");}
        reader.join(2000);
        String text=new String(sample.toByteArray(),"UTF-8").trim();
        if(p.exitValue()!=0)throw new IOException("退出代码 "+p.exitValue()+(text.isEmpty()?"":"："+text));
        return text;
    }

    private int detectPreferredJdk(File root){
        boolean requires21=false;int agpMajor=0;
        ArrayDeque<File> queue=new ArrayDeque<>();queue.add(root);int visited=0;
        java.util.regex.Pattern agp=java.util.regex.Pattern.compile("com\\.android\\.(?:application|library)[^\\n]{0,160}?version\\s*[\"']?([0-9]+)");
        java.util.regex.Pattern java21=java.util.regex.Pattern.compile("VERSION_21|JavaLanguageVersion\\.of\\(\\s*21\\s*\\)|jvmToolchain\\s*\\(\\s*21\\s*\\)");
        while(!queue.isEmpty()&&visited<3000){
            File file=queue.removeFirst();visited++;
            if(file.isDirectory()){String name=file.getName();if(".gradle".equals(name)||"build".equals(name)||".git".equals(name))continue;File[] children=file.listFiles();if(children!=null)Collections.addAll(queue,children);}
            else if(file.getName().equals("build.gradle")||file.getName().equals("build.gradle.kts")||file.getName().equals("libs.versions.toml")){
                try{String text=readSmallText(file,2_000_000);if(java21.matcher(text).find())requires21=true;java.util.regex.Matcher m=agp.matcher(text);while(m.find())agpMajor=Math.max(agpMajor,Integer.parseInt(m.group(1)));}catch(Exception ignored){}
            }
        }
        if(requires21&&runtime.isJdkInstalled(21))return 21;
        if(agpMajor>=8&&runtime.isJdkInstalled(17))return 17;
        return 0;
    }

    private static int detectCompileSdk(File root){
        java.util.regex.Pattern pattern=java.util.regex.Pattern.compile("(?:compileSdk(?:Version)?\\s*(?:=)?\\s*|compileSdkVersion\\s+)([0-9]{2,3})");
        ArrayDeque<File> queue=new ArrayDeque<>();queue.add(root);int best=0,visited=0;
        while(!queue.isEmpty()&&visited<3000){
            File file=queue.removeFirst();visited++;
            if(file.isDirectory()){
                String name=file.getName();if(".gradle".equals(name)||"build".equals(name)||".git".equals(name))continue;
                File[] children=file.listFiles();if(children!=null)Collections.addAll(queue,children);
            }else if(file.getName().equals("build.gradle")||file.getName().equals("build.gradle.kts")){
                try{String text=readSmallText(file,2_000_000);java.util.regex.Matcher m=pattern.matcher(text);while(m.find())best=Math.max(best,Integer.parseInt(m.group(1)));}catch(Exception ignored){}
            }
        }
        return best;
    }

    private static void writeLocalProperties(File projectRoot,File sdk)throws IOException{
        File file=new File(projectRoot,"local.properties");
        Properties p=new Properties();
        if(file.isFile())try(InputStream in=new FileInputStream(file)){p.load(in);}
        p.setProperty("sdk.dir",sdk.getAbsolutePath());
        try(OutputStream out=new FileOutputStream(file)){p.store(out,"Generated by GradleApkBuilder for local Android build");}
    }

    private static String readSmallText(File file,int max)throws IOException{
        try(InputStream in=new FileInputStream(file);ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[8192];int n;while((n=in.read(b))>=0){if(out.size()+n>max)break;out.write(b,0,n);}return out.toString("UTF-8");
        }
    }
    private static void copyFile(File source,File target)throws IOException{
        File parent=target.getParentFile();if(parent!=null&&!parent.exists()&&!parent.mkdirs())throw new IOException("无法创建目录："+parent);
        try(InputStream in=new BufferedInputStream(new FileInputStream(source));OutputStream out=new BufferedOutputStream(new FileOutputStream(target))){byte[] b=new byte[65536];int n;while((n=in.read(b))>=0)out.write(b,0,n);}
    }
    private static String shortMessage(Exception e){String s=e.getMessage();if(s==null)s=e.toString();return s.length()>500?s.substring(0,500):s;}
    private static String joinLines(List<String> lines){StringBuilder out=new StringBuilder();for(String line:lines)out.append("• ").append(line).append('\n');return out.toString();}

    private void runProot(File projectRoot,File out,String task)throws Exception{
        File proot=runtime.getProotFile(),rootfs=runtime.getRootfsDir();
        restoreExecutable(proot);
        String script="export HOME=/root; "
                +"export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin; "
                +"export ANDROID_HOME=/opt/android-sdk; "
                +"export ANDROID_SDK_ROOT=/opt/android-sdk; "
                +"export GRADLE_USER_HOME=/root/.gradle; "
                +buildScript(task);
        List<String> cmd=new ArrayList<>();
        Collections.addAll(cmd,proot.getAbsolutePath(),"--link2symlink","-0",
                "-r",rootfs.getAbsolutePath(),"-b","/dev","-b","/proc","-b","/sys",
                "-b",projectRoot.getCanonicalPath()+":/workspace",
                "-b",out.getCanonicalPath()+":/outputs","-w","/workspace",
                "/bin/busybox","sh","-lc",script);
        ProcessBuilder builder=new ProcessBuilder(cmd).redirectErrorStream(true);
        Map<String,String> env=builder.environment();
        env.remove("LD_PRELOAD");
        env.put("PROOT_NO_SECCOMP","1");
        File loader=runtime.getProotLoaderFile();
        if(loader==null||!loader.isFile())throw new IOException("缺少 PRoot loader：libexec/proot/loader");
        restoreExecutable(loader);
        env.put("PROOT_LOADER",loader.getAbsolutePath());
        File prefix=new File(runtime.getBundleDir(),"termux-prefix");
        File prootTmp=new File(prefix,"tmp");
        mkdirs(prootTmp);
        try{android.system.Os.chmod(prootTmp.getAbsolutePath(),0700);}catch(Throwable ignored){}
        env.put("PROOT_TMP_DIR",prootTmp.getAbsolutePath());
        env.put("TMPDIR",prootTmp.getAbsolutePath());
        env.put("LD_LIBRARY_PATH",new File(prefix,"lib").getAbsolutePath());
        notifyLine("使用 PRoot Linux 兼容环境构建（固定 loader，PROOT_NO_SECCOMP=1）");
        execute(builder,new File(projectRoot,"gradle-build-full.log"));
    }

    private void execute(ProcessBuilder pb,File fullLog)throws Exception{
        ArrayDeque<String> tail=new ArrayDeque<>();
        ArrayList<String> diagnostics=new ArrayList<>();
        int diagnosticContext=0;
        File parent=fullLog==null?null:fullLog.getParentFile();
        if(parent!=null)mkdirs(parent);
        try{
            process=pb.start();
        }catch(IOException e){throw new IOException("无法启动构建命令："+e.getMessage(),e);}
        try(BufferedReader r=new BufferedReader(new InputStreamReader(process.getInputStream()));
            Writer log=fullLog==null?new StringWriter():new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fullLog),"UTF-8"))){
            String line;
            while((line=r.readLine())!=null){
                String clean=stripAnsi(line);
                notifyLine(clean);
                log.write(clean);log.write('\n');
                tail.addLast(clean);
                while(tail.size()>80)tail.removeFirst();
                if(isImportantBuildLine(clean)){
                    appendDiagnostic(diagnostics,clean);
                    diagnosticContext=16;
                }else if(diagnosticContext>0){
                    appendDiagnostic(diagnostics,clean);
                    diagnosticContext--;
                }
            }
            log.flush();
        }
        if(!process.waitFor(90,TimeUnit.MINUTES)){process.destroyForcibly();throw new IOException("本地构建超时");}
        int code=process.exitValue();
        if(code!=0){
            String rootCause=extractFailureSummary(fullLog);
            StringBuilder details=new StringBuilder();
            if(rootCause!=null&&!rootCause.trim().isEmpty()){
                details.append("根因摘要：\n").append(rootCause.trim()).append("\n\n");
            }else if(!diagnostics.isEmpty()){
                details.append("关键错误：\n");
                for(String line:diagnostics)details.append(line).append('\n');
                details.append("\n");
            }
            details.append("日志末尾：\n");
            for(String line:tail)details.append(line).append('\n');
            if(fullLog!=null)details.append("\n完整日志已保存：\n").append(fullLog.getAbsolutePath());
            String hint=code==126?"\n退出代码 126 表示命令存在但不可执行。请在环境自检中确认 Java 与 aapt2 均能运行；若提示 Permission denied 或 cannot execute，需重新安装兼容当前 Android/ABI 的工具组件。":"";
            throw new IOException("Gradle 构建失败，退出代码 "+code+hint+"\n\n"+details);
        }
    }

    private static String extractFailureSummary(File logFile){
        if(logFile==null||!logFile.isFile())return "";
        ArrayList<String> lines=new ArrayList<>();
        try(BufferedReader reader=new BufferedReader(new InputStreamReader(new FileInputStream(logFile),"UTF-8"))){
            String line;int count=0;
            while((line=reader.readLine())!=null&&count<25000){lines.add(stripAnsi(line));count++;}
        }catch(Exception ignored){return "";}
        LinkedHashSet<String> picked=new LinkedHashSet<>();
        int failure=-1,what=-1;
        for(int i=0;i<lines.size();i++){
            String lower=lines.get(i).toLowerCase(Locale.US);
            if(failure<0&&lower.contains("failure: build failed"))failure=i;
            if(what<0&&lower.contains("what went wrong"))what=i;
        }
        int start=what>=0?what:failure;
        if(start>=0){
            for(int i=start;i<lines.size()&&picked.size()<90;i++){
                String line=lines.get(i);
                String lower=line.toLowerCase(Locale.US);
                if(i>start&&(lower.startsWith("* try:")||lower.startsWith("* get more help")||lower.startsWith("build failed in")))break;
                if(!line.trim().isEmpty())picked.add(line);
            }
        }
        String[] needles={"execution failed for task","caused by:","could not resolve","could not create","could not initialize","aapt","error:","exception","unsupportedclassversionerror","nosuchfileexception","permission denied","outofmemoryerror","failed to exec","unable to start","no space left","classnotfoundexception","linkageerror"};
        for(int i=0;i<lines.size()&&picked.size()<140;i++){
            String line=lines.get(i),lower=line.toLowerCase(Locale.US);
            boolean hit=false;
            for(String needle:needles)if(lower.contains(needle)){hit=true;break;}
            if(hit){
                for(int j=Math.max(0,i-2);j<Math.min(lines.size(),i+8)&&picked.size()<140;j++){
                    String candidate=lines.get(j);
                    if(!candidate.trim().isEmpty())picked.add(candidate);
                }
            }
        }
        // Put the deepest Android preferences conflict first. Without this,
        // long Gradle stack traces can hide the actionable paths below the fold.
        for(int i=0;i<lines.size();i++){
            String lower=lines.get(i).toLowerCase(Locale.US);
            if(lower.contains("androidlocationsexception")&&lower.contains("different paths")){
                StringBuilder conflict=new StringBuilder();
                for(int j=i;j<Math.min(lines.size(),i+12);j++){
                    String candidate=lines.get(j);
                    if(!candidate.trim().isEmpty())conflict.append(candidate).append('\n');
                }
                conflict.append("修复建议：仅设置 ANDROID_USER_HOME，并移除 ANDROID_PREFS_ROOT 与 ANDROID_SDK_HOME。\n");
                return conflict.toString();
            }
        }
        if(picked.isEmpty())return "";
        StringBuilder out=new StringBuilder();
        for(String line:picked){out.append(line).append('\n');if(out.length()>12000)break;}
        return out.toString();
    }

    private static String stripAnsi(String line){
        if(line==null)return "";
        return line.replaceAll("\\u001B\\[[;\\d]*[ -/]*[@-~]","");
    }

    private static boolean isImportantBuildLine(String line){
        if(line==null)return false;
        String lower=line.toLowerCase(Locale.US);
        return lower.contains("failure: build failed")||lower.contains("what went wrong")
                ||lower.contains("execution failed for task")||lower.contains("could not resolve")
                ||lower.contains("caused by:")||lower.contains("exception")||lower.contains(" error:")
                ||lower.startsWith("error:")||lower.contains("aapt")||lower.contains("outofmemory")
                ||lower.contains("process 'command")||lower.contains("permission denied")
                ||lower.contains("failed to exec")||lower.contains("unable to start");
    }

    private static void appendDiagnostic(List<String> diagnostics,String line){
        if(diagnostics.size()>=140)return;
        if(diagnostics.isEmpty()||!diagnostics.get(diagnostics.size()-1).equals(line))diagnostics.add(line);
    }

    private static void restoreExecutable(File f)throws IOException{
        if(f==null||!f.isFile())return;
        try{Os.chmod(f.getAbsolutePath(),0755);}catch(Throwable e){f.setExecutable(true,false);}
        if(!f.canExecute())throw new IOException("无法赋予执行权限："+f+"。Android 10+ 的 W^X 策略会阻止 targetSdk 29+ 应用执行私有目录中的下载程序；请安装旁加载本地编译版并重新导入组件。");
    }
    private static void restoreBinPermissions(File dir) throws IOException {File[] files=dir==null?null:dir.listFiles();if(files!=null)for(File f:files)if(f.isFile())restoreExecutable(f);}
    private String verifyJavaTool(File executable,File prefix,File home,String libraries)throws Exception{
        List<String> cmd=new ArrayList<>();cmd.add(executable.getAbsolutePath());cmd.add("-version");
        ProcessBuilder pb=new ProcessBuilder(cmd).redirectErrorStream(true);
        if(libraries!=null&&!libraries.isEmpty())pb.environment().put("LD_LIBRARY_PATH",libraries);
        if(prefix!=null){File tmp=new File(prefix,"tmp");mkdirs(tmp);pb.environment().put("TMPDIR",tmp.getAbsolutePath());}
        if(home!=null)pb.environment().put("JAVA_HOME",home.getAbsolutePath());
        pb.environment().put("JAVA_TOOL_OPTIONS","-Djdk.lang.Process.launchMechanism=VFORK");
        Process p;try{p=pb.start();}catch(IOException e){throw new IOException("Java 无法执行："+executable+"\n"+e.getMessage(),e);}
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        try(InputStream in=p.getInputStream()){byte[]b=new byte[4096];int n;while((n=in.read(b))>=0)out.write(b,0,n);}
        if(!p.waitFor(30,TimeUnit.SECONDS)){p.destroyForcibly();throw new IOException("Java 自检超时："+executable);}
        String text=new String(out.toByteArray(),"UTF-8").trim();notifyLine("Java 自检："+(text.isEmpty()?"退出代码 "+p.exitValue():text));
        if(p.exitValue()!=0)throw new IOException("Java 自检失败，退出代码 "+p.exitValue()+"：\n"+text);
        return text;
    }

    private String verifyTool(File executable,String[] args,String label)throws Exception{
        List<String> cmd=new ArrayList<>();cmd.add(executable.getAbsolutePath());Collections.addAll(cmd,args);
        ProcessBuilder pb=new ProcessBuilder(cmd).redirectErrorStream(true);
        if("Java".equals(label)){
            String javaLibraries=runtime.getJavaLibraryPath();
            if(!javaLibraries.isEmpty())pb.environment().put("LD_LIBRARY_PATH",javaLibraries);
            File activePrefix=runtime.getActiveJdkPrefix(),activeHome=runtime.getActiveJdkHome();
            if(activePrefix!=null){File tmp=new File(activePrefix,"tmp");mkdirs(tmp);pb.environment().put("TMPDIR",tmp.getAbsolutePath());}
            if(activeHome!=null)pb.environment().put("JAVA_HOME",activeHome.getAbsolutePath());
            pb.environment().put("JAVA_TOOL_OPTIONS","-Djdk.lang.Process.launchMechanism=VFORK");
        }
        Process p;
        try{p=pb.start();}catch(IOException e){throw new IOException(label+" 无法执行："+executable+"\n"+e.getMessage(),e);}
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        try(InputStream in=p.getInputStream()){byte[]b=new byte[4096];int n;while((n=in.read(b))>=0)out.write(b,0,n);}
        if(!p.waitFor(30,TimeUnit.SECONDS)){p.destroyForcibly();throw new IOException(label+" 自检超时："+executable);}
        String text=new String(out.toByteArray(),"UTF-8").trim();
        notifyLine(label+" 自检："+(text.isEmpty()?"退出代码 "+p.exitValue():text));
        if(p.exitValue()!=0)throw new IOException(label+" 自检失败，退出代码 "+p.exitValue()+"：\n"+text);
        return text;
    }
    private void migrateLegacyGradleUserHomes(File projectRoot,File sharedHome){
        File marker=new File(sharedHome,".legacy-cache-migrated-v1.9.7");
        if(marker.isFile())return;
        int migrated=0;
        try{
            File projectWorkspace=projectRoot;
            while(projectWorkspace!=null&&!"project".equals(projectWorkspace.getName()))projectWorkspace=projectWorkspace.getParentFile();
            File currentWork=projectWorkspace==null?null:projectWorkspace.getParentFile();
            File localBuilds=currentWork==null?null:currentWork.getParentFile();
            File[] builds=localBuilds==null?null:localBuilds.listFiles(File::isDirectory);
            if(builds!=null){
                Arrays.sort(builds,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
                for(File build:builds){
                    File legacy=new File(build,"project/.gradle-user-home");
                    if(!legacy.isDirectory()||legacy.equals(sharedHome))continue;
                    mergeGradleCacheTree(legacy,sharedHome);
                    migrated++;
                }
            }
            mkdirs(marker.getParentFile());
            try(OutputStream out=new FileOutputStream(marker)){
                out.write(("migrated="+migrated+"\n").getBytes("UTF-8"));
            }
            if(migrated>0)notifyLine("已从 "+migrated+" 个旧版本地构建目录合并 Gradle/Maven 依赖缓存");
        }catch(Exception e){
            notifyLine("旧依赖缓存迁移失败，将使用当前共享缓存："+e.getMessage());
        }
    }

    private static void mergeGradleCacheTree(File source,File destination)throws IOException{
        if(source==null||!source.exists())return;
        String name=source.getName();
        if(name.endsWith(".lock")||name.equals("registry.bin.lock")||name.equals("daemon")||name.equals(".tmp")||name.equals("notifications"))return;
        if(source.isDirectory()){
            mkdirs(destination);
            File[] children=source.listFiles();
            if(children!=null)for(File child:children)mergeGradleCacheTree(child,new File(destination,child.getName()));
            return;
        }
        if(source.isFile()&&!destination.exists())copy(source,destination);
    }

    private static void cleanupSharedGradleLocks(File root){
        if(root==null||!root.exists())return;
        if(root.isDirectory()){
            String name=root.getName();
            if(name.equals("daemon")||name.equals(".tmp")||name.equals("notifications")){
                try{deleteTreeQuietly(root);}catch(Exception ignored){}
                return;
            }
            File[] children=root.listFiles();
            if(children!=null)for(File child:children)cleanupSharedGradleLocks(child);
            return;
        }
        String name=root.getName();
        if(name.endsWith(".lock")||name.equals("registry.bin.lock"))root.delete();
    }

    private static void deleteTreeQuietly(File file){
        if(file==null||!file.exists())return;
        if(file.isDirectory()){
            File[] children=file.listFiles();
            if(children!=null)for(File child:children)deleteTreeQuietly(child);
        }
        file.delete();
    }

    private static boolean isNetworkResolutionFailure(File log){
        if(log==null||!log.isFile())return false;
        try(BufferedReader reader=new BufferedReader(new InputStreamReader(new FileInputStream(log),"UTF-8"))){
            String line;
            while((line=reader.readLine())!=null){
                String lower=line.toLowerCase(Locale.US);
                if(lower.contains("unknownhostexception")
                        ||lower.contains("no address associated with hostname")
                        ||lower.contains("name or service not known")
                        ||lower.contains("could not get resource")
                        ||lower.contains("could not get 'https://")
                        ||lower.contains("could not download")){
                    return true;
                }
            }
        }catch(Exception ignored){}
        return false;
    }

    private static String humanBytes(long bytes){
        if(bytes<1024)return bytes+" B";
        double value=bytes;String[] units={"KB","MB","GB","TB"};int index=-1;
        do{value/=1024d;index++;}while(value>=1024d&&index<units.length-1);
        return String.format(Locale.US,"%.2f %s",value,units[index]);
    }

    private File prepareOfficialGradle(File projectRoot,File sharedCacheRoot)throws Exception{
        File props=new File(projectRoot,"gradle/wrapper/gradle-wrapper.properties");
        if(!props.isFile())throw new IOException("工程没有 gradle/wrapper/gradle-wrapper.properties，无法确定 Gradle 版本");
        Properties p=new Properties();try(InputStream in=new FileInputStream(props)){p.load(in);}
        String raw=p.getProperty("distributionUrl","").replace("\\:",":").trim();
        if(raw.isEmpty())throw new IOException("gradle-wrapper.properties 缺少 distributionUrl");
        java.net.URL u=new java.net.URL(raw);String host=u.getHost().toLowerCase(Locale.US);
        if(!("services.gradle.org".equals(host)||"downloads.gradle.org".equals(host)))throw new IOException("为安全起见，本地构建只允许 Gradle 官方发行地址："+raw);
        String name=new File(u.getPath()).getName();if(!name.endsWith(".zip"))throw new IOException("Gradle distributionUrl 不是 ZIP："+raw);

        // Use a shared, version-specific Gradle cache inside sdk-components. This directory is
        // included in portable toolchain exports and full system backups, unlike the old
        // per-build project/.gradle-distributions directory.
        mkdirs(sharedCacheRoot);
        String cacheKey=name.substring(0,name.length()-4).replaceAll("[^A-Za-z0-9._-]","_");
        File cache=new File(sharedCacheRoot,cacheKey);mkdirs(cache);
        File zip=new File(cache,name);
        migrateLegacyGradleCache(projectRoot,cache,zip,name);
        File home=findUsableGradleHome(cache);
        if(home!=null){
            notifyLine("使用已缓存的官方 Gradle："+home.getName()+"（无需下载）");
            return home;
        }

        // A restored toolchain may contain the distribution ZIP but not the extracted tree.
        // Re-extract it locally before attempting any network request.
        if(zip.isFile()&&zip.length()>0){
            try{
                validateZip(zip);
                notifyLine("正在从工具链备份恢复 Gradle："+name);
                deleteExtractedGradleTrees(cache,zip);
                unzip(zip,cache);
                home=findUsableGradleHome(cache);
                if(home!=null){
                    notifyLine("Gradle 已从备份缓存恢复："+home.getName());
                    return home;
                }
            }catch(Exception damaged){
                notifyLine("备份中的 Gradle 缓存无效，将重新下载："+damaged.getMessage());
                deleteExtractedGradleTrees(cache,zip);
                if(!zip.delete())zip.deleteOnExit();
            }
        }

        notifyLine("正在下载官方 Gradle："+raw);
        File part=new File(cache,name+".part");
        if(part.exists()&&!part.delete())part.deleteOnExit();
        download(u,part);
        validateZip(part);
        if(zip.exists()&&!zip.delete())throw new IOException("无法替换旧 Gradle 缓存："+zip);
        if(!part.renameTo(zip)){copy(part,zip);if(!part.delete())part.deleteOnExit();}
        unzip(zip,cache);
        home=findUsableGradleHome(cache);
        if(home==null)throw new IOException("Gradle ZIP 解压后没有找到可用的 gradle-launcher");
        notifyLine("Gradle 已保存到共享工具链缓存，后续备份/导入可离线恢复");
        return home;
    }

    private void migrateLegacyGradleCache(File projectRoot,File sharedCache,File sharedZip,String archiveName){
        if(findUsableGradleHome(sharedCache)!=null||sharedZip.isFile())return;
        try{
            File projectWorkspace=projectRoot;
            while(projectWorkspace!=null&&!"project".equals(projectWorkspace.getName()))projectWorkspace=projectWorkspace.getParentFile();
            File currentWork=projectWorkspace==null?null:projectWorkspace.getParentFile();
            File localBuilds=currentWork==null?null:currentWork.getParentFile();
            File[] builds=localBuilds==null?null:localBuilds.listFiles(File::isDirectory);
            if(builds==null)return;
            Arrays.sort(builds,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
            for(File build:builds){
                if(build.equals(currentWork))continue;
                File legacy=new File(build,"project/.gradle-distributions");
                if(!legacy.isDirectory())continue;
                File legacyZip=new File(legacy,archiveName);
                if(legacyZip.isFile()&&legacyZip.length()>0){
                    try{
                        validateZip(legacyZip);
                        copy(legacyZip,sharedZip);
                        notifyLine("已从旧版全量备份迁移 Gradle 压缩包："+archiveName);
                        return;
                    }catch(Exception ignored){}
                }
                File legacyHome=findUsableGradleHome(legacy);
                if(legacyHome!=null){
                    File target=new File(sharedCache,legacyHome.getName());
                    copyTree(legacyHome,target);
                    notifyLine("已从旧版本地构建目录迁移 Gradle："+legacyHome.getName());
                    return;
                }
            }
        }catch(Exception e){
            notifyLine("旧 Gradle 缓存迁移失败，将按正常流程处理："+e.getMessage());
        }
    }

    private static void copyTree(File source,File destination)throws IOException{
        if(source.isDirectory()){
            mkdirs(destination);
            File[] children=source.listFiles();
            if(children!=null)for(File child:children)copyTree(child,new File(destination,child.getName()));
            return;
        }
        if(source.isFile())copy(source,destination);
    }

    private static File findUsableGradleHome(File dir){
        File home=findGradleHome(dir);
        return home!=null&&findGradleLauncher(home)!=null?home:null;
    }

    private static void validateZip(File zip)throws IOException{
        try(ZipFile file=new ZipFile(zip)){
            if(file.size()==0)throw new IOException("ZIP 为空");
        }catch(ZipException e){
            throw new IOException("Gradle ZIP 已损坏",e);
        }
    }

    private static void deleteExtractedGradleTrees(File cache,File preservedZip)throws IOException{
        File[] children=cache.listFiles();
        if(children==null)return;
        for(File child:children){
            if(child.equals(preservedZip)||child.getName().endsWith(".part"))continue;
            deleteTree(child);
        }
    }

    private static void deleteTree(File file)throws IOException{
        if(file==null||!file.exists())return;
        if(file.isDirectory()){
            File[] children=file.listFiles();
            if(children!=null)for(File child:children)deleteTree(child);
        }
        if(!file.delete()&&file.exists())throw new IOException("无法清理旧 Gradle 缓存："+file);
    }
    private static void download(java.net.URL url,File out)throws Exception{
        java.net.URL current=url;
        for(int i=0;i<8;i++){
            java.net.HttpURLConnection c=(java.net.HttpURLConnection)current.openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(20000);c.setReadTimeout(120000);c.setRequestProperty("User-Agent","GradleApkBuilder-Android");
            int code=c.getResponseCode();if(code>=300&&code<400){String loc=c.getHeaderField("Location");c.disconnect();if(loc==null)throw new IOException("Gradle 下载重定向缺少地址");current=new java.net.URL(current,loc);continue;}
            if(code<200||code>=300)throw new IOException("Gradle 下载失败，HTTP "+code);
            try(InputStream in=c.getInputStream();OutputStream os=new FileOutputStream(out)){byte[]b=new byte[65536];int n;while((n=in.read(b))>=0)os.write(b,0,n);}return;
        }throw new IOException("Gradle 下载重定向次数过多");
    }
    private static File findGradleLauncher(File gradleHome){
        File lib=new File(gradleHome,"lib");
        File[] jars=lib.listFiles((d,n)->n.startsWith("gradle-launcher-")&&n.endsWith(".jar"));
        if(jars==null||jars.length==0)return null;
        Arrays.sort(jars,Comparator.comparing(File::getName));
        return jars[jars.length-1];
    }
    private static File findGradleHome(File dir){File[]a=dir.listFiles(File::isDirectory);if(a!=null)for(File f:a)if(new File(f,"bin/gradle").isFile())return f;return null;}
    private static int parseJavaMajor(String text){java.util.regex.Matcher m=java.util.regex.Pattern.compile("version \"(\\d+)(?:\\.(\\d+))?").matcher(text);if(!m.find())return -1;int first=Integer.parseInt(m.group(1));return first==1&&m.group(2)!=null?Integer.parseInt(m.group(2)):first;}
    private static String shellQuote(String s){return "'"+s.replace("'","'\"'\"'")+"'";}

    private static void writeGradleRuntimeProperties(File file,String jvmArgs)throws IOException{
        mkdirs(file.getParentFile());
        try(Writer writer=new OutputStreamWriter(new FileOutputStream(file),"UTF-8")){
            writer.write("org.gradle.daemon=false\n");
            writer.write("org.gradle.console=plain\n");
            writer.write("org.gradle.vfs.watch=false\n");
            writer.write("org.gradle.parallel=false\n");
            writer.write("org.gradle.workers.max=1\n");
            writer.write("org.gradle.caching=false\n");
            writer.write("org.gradle.configuration-cache=false\n");
            writer.write("kotlin.compiler.execution.strategy=in-process\n");
            writer.write("kotlin.daemon.enabled=false\n");
            writer.write("org.gradle.jvmargs="+jvmArgs+"\n");
        }
    }

    private void notifyLine(String s){if(listener!=null)listener.onLine(s);}
    void cancel(){Process p=process;if(p!=null)p.destroyForcibly();}
    private static String cleanTask(String task){return(task==null||task.trim().isEmpty())?"assembleDebug":task.trim().replaceAll("[^A-Za-z0-9:_-]","");}
    private static String buildScript(String task){String t=cleanTask(task);return "set -e; chmod +x ./gradlew 2>/dev/null || true; if [ -x ./gradlew ]; then ./gradlew --no-daemon --stacktrace "+t+"; else gradle --no-daemon --stacktrace "+t+"; fi";}
    private static File findProjectRoot(File dir){if(new File(dir,"settings.gradle").isFile()||new File(dir,"settings.gradle.kts").isFile())return dir;File[]a=dir.listFiles(File::isDirectory);if(a!=null&&a.length==1)return findProjectRoot(a[0]);return dir;}
    private static File findFirstApk(File f){if(f.isFile()&&f.getName().endsWith(".apk")&&f.getPath().contains("build"+File.separator+"outputs"+File.separator+"apk"))return f;if(f.isDirectory()){File[]a=f.listFiles();if(a!=null)for(File c:a){File r=findFirstApk(c);if(r!=null)return r;}}return null;}
    private static void unzip(File zip,File dst)throws IOException{try(ZipInputStream in=new ZipInputStream(new FileInputStream(zip))){ZipEntry e;while((e=in.getNextEntry())!=null){String n=e.getName().replace('\\','/');if(n.startsWith("/")||n.contains("../"))throw new IOException("工程 ZIP 路径不安全");File x=new File(dst,n);if(e.isDirectory())mkdirs(x);else{mkdirs(x.getParentFile());try(OutputStream o=new FileOutputStream(x)){byte[]b=new byte[65536];int k;while((k=in.read(b))>=0)o.write(b,0,k);}}}}}
    private static void copy(File a,File b)throws IOException{mkdirs(b.getParentFile());try(InputStream i=new FileInputStream(a);OutputStream o=new FileOutputStream(b)){byte[]x=new byte[65536];int n;while((n=i.read(x))>=0)o.write(x,0,n);}}
    private static void mkdirs(File f)throws IOException{if(f!=null&&!f.exists()&&!f.mkdirs())throw new IOException("无法创建目录："+f);}
}
