package com.example.gradleapkbuilder;

import java.io.*;
import android.system.Os;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.zip.*;

/** Runs Gradle directly with Android-native AndroidIDE tools, with PRoot as a fallback. */
final class LocalBuildEngine {
    interface Listener { void onLine(String line); }
    private final RuntimeBundleManager runtime;
    private final Listener listener;
    private volatile Process process;

    LocalBuildEngine(RuntimeBundleManager runtime, Listener listener) { this.runtime=runtime; this.listener=listener; }

    File build(File projectZip, File workBase, String task) throws Exception {
        if (!runtime.isBuildReady()) throw new IOException("本地构建环境尚未通过自检，请打开 SDK 管理器重新安装或运行环境自检");
        File work = new File(workBase, "local-build-" + System.currentTimeMillis());
        File project = new File(work, "project"), out = new File(work, "outputs");
        mkdirs(project); mkdirs(out); unzip(projectZip, project);
        File projectRoot = findProjectRoot(project);
        if(runtime.isDirectBuildReady()) runDirect(projectRoot,task);
        else runProot(projectRoot,out,task);
        File apk=findFirstApk(projectRoot); if(apk==null)throw new IOException("构建完成但未找到 APK");
        File result=new File(out,apk.getName()); copy(apk,result); return result;
    }

    private void runDirect(File projectRoot,String task)throws Exception{
        File java=runtime.getJavaExecutable(),sdk=runtime.getAndroidSdkDir(),aapt2=runtime.getAapt2Executable();
        if(java==null||sdk==null||aapt2==null)throw new IOException("没有找到本地 Java、Android SDK 或 ARM64 aapt2");
        restoreExecutable(java);
        restoreExecutable(aapt2);
        File jdk=java.getParentFile().getParentFile();
        restoreBinPermissions(java.getParentFile());
        File gradlew=new File(projectRoot,"gradlew");
        if(gradlew.isFile())restoreExecutable(gradlew);
        String javaVersion=verifyTool(java, new String[]{"-version"}, "Java");
        verifyTool(aapt2, new String[]{"version"}, "aapt2");
        int javaMajor=parseJavaMajor(javaVersion);
        File gradleHome=prepareOfficialGradle(projectRoot, new File(projectRoot,".gradle-distributions"));
        File launcher=findGradleLauncher(gradleHome);
        if(launcher==null)throw new IOException("Gradle 发行包缺少 lib/gradle-launcher-*.jar："+gradleHome);
        if(javaMajor>0&&javaMajor<17)notifyLine("警告：当前 Java "+javaMajor+"。AGP 8.x 通常要求 JDK 17；若后续报 Java 版本不足，请在 SDK 管理器安装 JDK 17/21。");
        String cleanTask=cleanTask(task);
        File javaTmp=new File(projectRoot,".java-tmp");mkdirs(javaTmp);
        File gradleUserHome=new File(projectRoot,".gradle-user-home");mkdirs(gradleUserHome);
        File homeDir=new File(projectRoot,".home");mkdirs(homeDir);
        try{Os.chmod(javaTmp.getAbsolutePath(),0700);}catch(Throwable ignored){}
        String tmpProperty="-Djava.io.tmpdir="+javaTmp.getAbsolutePath();
        String gradleJvmArgs="-Xms64m -Xmx512m -Dfile.encoding=UTF-8 "+tmpProperty+" -Dorg.gradle.vfs.watch=false";
        writeGradleRuntimeProperties(new File(gradleUserHome,"gradle.properties"),gradleJvmArgs);
        List<String> command=new ArrayList<>();
        command.add(java.getAbsolutePath());
        command.add("-Xms64m");
        command.add("-Xmx512m");
        command.add("-Dfile.encoding=UTF-8");
        command.add(tmpProperty);
        command.add("-Dorg.gradle.jvmargs="+gradleJvmArgs);
        command.add("-Dorg.gradle.vfs.watch=false");
        command.add("-classpath");
        command.add(launcher.getAbsolutePath());
        command.add("org.gradle.launcher.GradleMain");
        command.add("--no-daemon");
        command.add("--no-watch-fs");
        command.add("--stacktrace");
        command.add("-Pandroid.aapt2FromMavenOverride="+aapt2.getAbsolutePath());
        command.add(cleanTask);
        ProcessBuilder pb=new ProcessBuilder(command);
        pb.directory(projectRoot);pb.redirectErrorStream(true);
        Map<String,String> env=pb.environment();
        env.put("HOME",homeDir.getAbsolutePath());
        env.put("JAVA_HOME",jdk.getAbsolutePath());
        env.put("ANDROID_HOME",sdk.getAbsolutePath());env.put("ANDROID_SDK_ROOT",sdk.getAbsolutePath());
        env.put("GRADLE_USER_HOME",gradleUserHome.getAbsolutePath());
        env.put("PATH",java.getParentFile().getAbsolutePath()+":"+System.getenv("PATH"));
        env.put("TMPDIR",javaTmp.getAbsolutePath());
        env.put("TMP",javaTmp.getAbsolutePath());
        env.put("TEMP",javaTmp.getAbsolutePath());
        env.put("JAVA_TOOL_OPTIONS",tmpProperty+" -Dorg.gradle.vfs.watch=false");
        env.put("GRADLE_OPTS",tmpProperty+" -Dorg.gradle.vfs.watch=false");
        env.remove("_JAVA_OPTIONS");
        env.remove("JDK_JAVA_OPTIONS");
        String javaLibraries=runtime.getJavaLibraryPath();
        if(!javaLibraries.isEmpty())env.put("LD_LIBRARY_PATH",javaLibraries);
        File activePrefix=runtime.getActiveJdkPrefix();
        if(activePrefix!=null){File tmp=new File(activePrefix,"tmp");mkdirs(tmp);}
        notifyLine("临时目录："+javaTmp.getAbsolutePath());
        notifyLine("使用 Android 原生工具链构建（无需 PRoot/rootfs）");
        execute(pb);
    }

    private void runProot(File projectRoot,File out,String task)throws Exception{
        File proot=runtime.getProotFile(),rootfs=runtime.getRootfsDir();
        restoreExecutable(proot);
        String script="export HOME=/root; "
                +"export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin; "
                +"export ANDROID_HOME=/opt/android-sdk; "
                +"export ANDROID_SDK_ROOT=/opt/android-sdk; "
                +"export GRADLE_USER_HOME=/root/.gradle; "
                +buildScript(task);
        List<String> cmd=new ArrayList<>();
        Collections.addAll(cmd,proot.getAbsolutePath(),"--link2symlink","-0",
                "-r",rootfs.getAbsolutePath(),"-b","/dev","-b","/proc","-b","/sys",
                "-b",projectRoot.getCanonicalPath()+":/workspace",
                "-b",out.getCanonicalPath()+":/outputs","-w","/workspace",
                "/bin/busybox","sh","-lc",script);
        ProcessBuilder builder=new ProcessBuilder(cmd).redirectErrorStream(true);
        Map<String,String> env=builder.environment();
        env.remove("LD_PRELOAD");
        env.put("PROOT_NO_SECCOMP","1");
        File loader=runtime.getProotLoaderFile();
        if(loader==null||!loader.isFile())throw new IOException("缺少 PRoot loader：libexec/proot/loader");
        restoreExecutable(loader);
        env.put("PROOT_LOADER",loader.getAbsolutePath());
        File prefix=new File(runtime.getBundleDir(),"termux-prefix");
        File prootTmp=new File(prefix,"tmp");
        mkdirs(prootTmp);
        try{android.system.Os.chmod(prootTmp.getAbsolutePath(),0700);}catch(Throwable ignored){}
        env.put("PROOT_TMP_DIR",prootTmp.getAbsolutePath());
        env.put("TMPDIR",prootTmp.getAbsolutePath());
        env.put("LD_LIBRARY_PATH",new File(prefix,"lib").getAbsolutePath());
        notifyLine("使用 PRoot Linux 兼容环境构建（固定 loader，PROOT_NO_SECCOMP=1）");
        execute(builder);
    }

    private void execute(ProcessBuilder pb)throws Exception{
        ArrayDeque<String> tail=new ArrayDeque<>();
        try{
            process=pb.start();
        }catch(IOException e){throw new IOException("无法启动构建命令："+e.getMessage(),e);}
        try(BufferedReader r=new BufferedReader(new InputStreamReader(process.getInputStream()))){
            String line;
            while((line=r.readLine())!=null){
                notifyLine(line);
                tail.addLast(line);
                while(tail.size()>80)tail.removeFirst();
            }
        }
        if(!process.waitFor(90,TimeUnit.MINUTES)){process.destroyForcibly();throw new IOException("本地构建超时");}
        int code=process.exitValue();
        if(code!=0){
            StringBuilder details=new StringBuilder();
            for(String line:tail)details.append(line).append('\n');
            String hint=code==126?"\n退出代码 126 表示命令存在但不可执行。请在环境自检中确认 Java 与 aapt2 均能运行；若提示 Permission denied 或 cannot execute，需重新安装兼容当前 Android/ABI 的工具组件。":"";
            throw new IOException("Gradle 构建失败，退出代码 "+code+hint+"\n\n最后构建日志：\n"+details);
        }
    }

    private static void restoreExecutable(File f)throws IOException{
        if(f==null||!f.isFile())return;
        try{Os.chmod(f.getAbsolutePath(),0755);}catch(Throwable e){f.setExecutable(true,false);}
        if(!f.canExecute())throw new IOException("无法赋予执行权限："+f+"。Android 10+ 的 W^X 策略会阻止 targetSdk 29+ 应用执行私有目录中的下载程序；请安装旁加载本地编译版并重新导入组件。");
    }
    private static void restoreBinPermissions(File dir) throws IOException {File[] files=dir==null?null:dir.listFiles();if(files!=null)for(File f:files)if(f.isFile())restoreExecutable(f);}
    private String verifyTool(File executable,String[] args,String label)throws Exception{
        List<String> cmd=new ArrayList<>();cmd.add(executable.getAbsolutePath());Collections.addAll(cmd,args);
        ProcessBuilder pb=new ProcessBuilder(cmd).redirectErrorStream(true);
        if("Java".equals(label)){
            String javaLibraries=runtime.getJavaLibraryPath();
            if(!javaLibraries.isEmpty())pb.environment().put("LD_LIBRARY_PATH",javaLibraries);
            File activePrefix=runtime.getActiveJdkPrefix(),activeHome=runtime.getActiveJdkHome();
            if(activePrefix!=null){File tmp=new File(activePrefix,"tmp");mkdirs(tmp);pb.environment().put("TMPDIR",tmp.getAbsolutePath());}
            if(activeHome!=null)pb.environment().put("JAVA_HOME",activeHome.getAbsolutePath());
        }
        Process p;
        try{p=pb.start();}catch(IOException e){throw new IOException(label+" 无法执行："+executable+"\n"+e.getMessage(),e);}
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        try(InputStream in=p.getInputStream()){byte[]b=new byte[4096];int n;while((n=in.read(b))>=0)out.write(b,0,n);}
        if(!p.waitFor(30,TimeUnit.SECONDS)){p.destroyForcibly();throw new IOException(label+" 自检超时："+executable);}
        String text=new String(out.toByteArray(),"UTF-8").trim();
        notifyLine(label+" 自检："+(text.isEmpty()?"退出代码 "+p.exitValue():text));
        if(p.exitValue()!=0)throw new IOException(label+" 自检失败，退出代码 "+p.exitValue()+"：\n"+text);
        return text;
    }
    private File prepareOfficialGradle(File projectRoot,File cache)throws Exception{
        File props=new File(projectRoot,"gradle/wrapper/gradle-wrapper.properties");
        if(!props.isFile())throw new IOException("工程没有 gradle/wrapper/gradle-wrapper.properties，无法确定 Gradle 版本");
        Properties p=new Properties();try(InputStream in=new FileInputStream(props)){p.load(in);}
        String raw=p.getProperty("distributionUrl","").replace("\\:",":").trim();
        if(raw.isEmpty())throw new IOException("gradle-wrapper.properties 缺少 distributionUrl");
        java.net.URL u=new java.net.URL(raw);String host=u.getHost().toLowerCase(Locale.US);
        if(!("services.gradle.org".equals(host)||"downloads.gradle.org".equals(host)))throw new IOException("为安全起见，本地构建只允许 Gradle 官方发行地址："+raw);
        String name=new File(u.getPath()).getName();if(!name.endsWith(".zip"))throw new IOException("Gradle distributionUrl 不是 ZIP："+raw);
        mkdirs(cache);File zip=new File(cache,name);File home=findGradleHome(cache);
        if(home!=null)return home;
        notifyLine("正在下载官方 Gradle："+raw);download(u,zip);unzip(zip,cache);home=findGradleHome(cache);
        if(home==null)throw new IOException("Gradle ZIP 解压后没有找到 bin/gradle");return home;
    }
    private static void download(java.net.URL url,File out)throws Exception{
        java.net.URL current=url;
        for(int i=0;i<8;i++){
            java.net.HttpURLConnection c=(java.net.HttpURLConnection)current.openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(20000);c.setReadTimeout(120000);c.setRequestProperty("User-Agent","GradleApkBuilder-Android");
            int code=c.getResponseCode();if(code>=300&&code<400){String loc=c.getHeaderField("Location");c.disconnect();if(loc==null)throw new IOException("Gradle 下载重定向缺少地址");current=new java.net.URL(current,loc);continue;}
            if(code<200||code>=300)throw new IOException("Gradle 下载失败，HTTP "+code);
            try(InputStream in=c.getInputStream();OutputStream os=new FileOutputStream(out)){byte[]b=new byte[65536];int n;while((n=in.read(b))>=0)os.write(b,0,n);}return;
        }throw new IOException("Gradle 下载重定向次数过多");
    }
    private static File findGradleLauncher(File gradleHome){
        File lib=new File(gradleHome,"lib");
        File[] jars=lib.listFiles((d,n)->n.startsWith("gradle-launcher-")&&n.endsWith(".jar"));
        if(jars==null||jars.length==0)return null;
        Arrays.sort(jars,Comparator.comparing(File::getName));
        return jars[jars.length-1];
    }
    private static File findGradleHome(File dir){File[]a=dir.listFiles(File::isDirectory);if(a!=null)for(File f:a)if(new File(f,"bin/gradle").isFile())return f;return null;}
    private static int parseJavaMajor(String text){java.util.regex.Matcher m=java.util.regex.Pattern.compile("version \"(\\d+)(?:\\.(\\d+))?").matcher(text);if(!m.find())return -1;int first=Integer.parseInt(m.group(1));return first==1&&m.group(2)!=null?Integer.parseInt(m.group(2)):first;}
    private static String shellQuote(String s){return "'"+s.replace("'","'\"'\"'")+"'";}

    private static void writeGradleRuntimeProperties(File file,String jvmArgs)throws IOException{
        mkdirs(file.getParentFile());
        try(Writer writer=new OutputStreamWriter(new FileOutputStream(file),"UTF-8")){
            writer.write("org.gradle.daemon=false\n");
            writer.write("org.gradle.vfs.watch=false\n");
            writer.write("org.gradle.jvmargs="+jvmArgs+"\n");
        }
    }

    private void notifyLine(String s){if(listener!=null)listener.onLine(s);}
    void cancel(){Process p=process;if(p!=null)p.destroyForcibly();}
    private static String cleanTask(String task){return(task==null||task.trim().isEmpty())?"assembleDebug":task.trim().replaceAll("[^A-Za-z0-9:_-]","");}
    private static String buildScript(String task){String t=cleanTask(task);return "set -e; chmod +x ./gradlew 2>/dev/null || true; if [ -x ./gradlew ]; then ./gradlew --no-daemon --stacktrace "+t+"; else gradle --no-daemon --stacktrace "+t+"; fi";}
    private static File findProjectRoot(File dir){if(new File(dir,"settings.gradle").isFile()||new File(dir,"settings.gradle.kts").isFile())return dir;File[]a=dir.listFiles(File::isDirectory);if(a!=null&&a.length==1)return findProjectRoot(a[0]);return dir;}
    private static File findFirstApk(File f){if(f.isFile()&&f.getName().endsWith(".apk")&&f.getPath().contains("build"+File.separator+"outputs"+File.separator+"apk"))return f;if(f.isDirectory()){File[]a=f.listFiles();if(a!=null)for(File c:a){File r=findFirstApk(c);if(r!=null)return r;}}return null;}
    private static void unzip(File zip,File dst)throws IOException{try(ZipInputStream in=new ZipInputStream(new FileInputStream(zip))){ZipEntry e;while((e=in.getNextEntry())!=null){String n=e.getName().replace('\\','/');if(n.startsWith("/")||n.contains("../"))throw new IOException("工程 ZIP 路径不安全");File x=new File(dst,n);if(e.isDirectory())mkdirs(x);else{mkdirs(x.getParentFile());try(OutputStream o=new FileOutputStream(x)){byte[]b=new byte[65536];int k;while((k=in.read(b))>=0)o.write(b,0,k);}}}}}
    private static void copy(File a,File b)throws IOException{mkdirs(b.getParentFile());try(InputStream i=new FileInputStream(a);OutputStream o=new FileOutputStream(b)){byte[]x=new byte[65536];int n;while((n=i.read(x))>=0)o.write(x,0,n);}}
    private static void mkdirs(File f)throws IOException{if(f!=null&&!f.exists()&&!f.mkdirs())throw new IOException("无法创建目录："+f);}
}
