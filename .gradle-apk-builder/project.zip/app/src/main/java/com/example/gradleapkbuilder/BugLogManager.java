package com.example.gradleapkbuilder;

import android.content.Context;
import android.os.Build;
import android.content.pm.PackageInfo;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

final class BugLogManager {
    interface ExportProgress {
        void onProgress(String message,long done,long total);
        boolean isCancelled();
    }
    private final Context context;
    private final File logFile;
    BugLogManager(Context context){this.context=context.getApplicationContext();this.logFile=new File(context.getFilesDir(),"logs/app.log");}

    synchronized void log(String level,String message){
        try{
            File parent=logFile.getParentFile();if(!parent.exists())parent.mkdirs();
            String time=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS",Locale.US).format(new Date());
            String clean=sanitize(message==null?"":message);
            try(Writer w=new OutputStreamWriter(new FileOutputStream(logFile,true),"UTF-8")){w.write(time+" ["+level+"] "+clean+"\n");}
            trimIfNeeded();
        }catch(Exception ignored){}
    }

    void exportReport(OutputStream target,RuntimeBundleManager runtime,File projectZip,File builtApk)throws Exception{exportReport(target,runtime,projectZip,builtApk,null);}

    void exportReport(OutputStream target,RuntimeBundleManager runtime,File projectZip,File builtApk,ExportProgress progress)throws Exception{
        String report=buildReport(runtime,projectZip,builtApk);
        ArrayList<File> files=new ArrayList<>();if(logFile.isFile())files.add(logFile);
        collectRecent(new File(context.getFilesDir(),"local-builds"),files,3);collectRecent(new File(context.getFilesDir(),"outputs"),files,3);
        long total=report.getBytes("UTF-8").length;for(File f:files)total+=f.length();total=Math.max(1,total);long done=0;
        try(ZipOutputStream zip=new ZipOutputStream(new BufferedOutputStream(target))){
            checkCancelled(progress);byte[] text=report.getBytes("UTF-8");zip.putNextEntry(new ZipEntry("report.txt"));zip.write(text);zip.closeEntry();done+=text.length;if(progress!=null)progress.onProgress("正在写入诊断信息…",done,total);
            for(File file:files){checkCancelled(progress);String name=file.equals(logFile)?"logs/app.log":(file.getAbsolutePath().contains(File.separator+"outputs"+File.separator)?"outputs/":"local-builds/")+file.getName();zip.putNextEntry(new ZipEntry(name));
                try(InputStream in=new BufferedInputStream(new FileInputStream(file))){byte[]buf=new byte[65536];int n;while((n=in.read(buf))>=0){checkCancelled(progress);zip.write(buf,0,n);done+=n;if(progress!=null)progress.onProgress("正在导出日志："+name,done,total);}}
                zip.closeEntry();
            }
            zip.finish();
        }
        if(progress!=null)progress.onProgress("Bug 日志导出完成",total,total);
    }

    private static void checkCancelled(ExportProgress progress)throws InterruptedIOException{if(progress!=null&&progress.isCancelled())throw new InterruptedIOException("用户已取消导出");}

    private void collectRecent(File root,List<File> result,int max){if(root==null||!root.exists())return;ArrayList<File> files=new ArrayList<>();collectTextFiles(root,files);files.sort((a,b)->Long.compare(b.lastModified(),a.lastModified()));for(int i=0;i<Math.min(max,files.size());i++)result.add(files.get(i));}

    private String buildReport(RuntimeBundleManager runtime,File projectZip,File builtApk){
        StringBuilder b=new StringBuilder();
        b.append("Gradle APK Builder Bug Report\n");
        b.append("Generated: ").append(new Date()).append("\n");
        b.append("App version: ").append(appVersion()).append("\n");
        b.append("Android: ").append(Build.VERSION.RELEASE).append(" / API ").append(Build.VERSION.SDK_INT).append("\n");
        b.append("Device: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append("\n");
        b.append("ABIs: ").append(Arrays.toString(Build.SUPPORTED_ABIS)).append("\n");
        b.append("Free app storage: ").append(context.getFilesDir().getUsableSpace()).append(" bytes\n\n");
        b.append("=== Runtime status ===\n").append(sanitize(runtime.status())).append("\n");
        b.append("Project ZIP: ").append(projectZip==null?"none":projectZip.getAbsolutePath()+" ("+projectZip.length()+" bytes)").append("\n");
        b.append("Built APK: ").append(builtApk==null?"none":builtApk.getAbsolutePath()+" ("+builtApk.length()+" bytes)").append("\n");
        return b.toString();
    }


    private String appVersion(){
        try{
            PackageInfo info=context.getPackageManager().getPackageInfo(context.getPackageName(),0);
            long code=Build.VERSION.SDK_INT>=28?info.getLongVersionCode():info.versionCode;
            return info.versionName+" ("+code+")";
        }catch(Exception ignored){return "unknown";}
    }

    private void addRecentLogs(ZipOutputStream zip,File root,String prefix,int max)throws IOException{
        if(root==null||!root.exists())return;
        ArrayList<File> files=new ArrayList<>();collectTextFiles(root,files);
        files.sort((a,b)->Long.compare(b.lastModified(),a.lastModified()));
        int count=0;for(File f:files){if(count++>=max)break;addFile(zip,prefix+"/"+f.getName(),f);}
    }
    private void collectTextFiles(File f,List<File> out){
        if(f.isDirectory()){File[] a=f.listFiles();if(a!=null)for(File x:a)collectTextFiles(x,out);}
        else if(f.length()<2_000_000&&(f.getName().endsWith(".log")||f.getName().endsWith(".txt")))out.add(f);
    }
    private static void addText(ZipOutputStream zip,String name,String text)throws IOException{zip.putNextEntry(new ZipEntry(name));zip.write(text.getBytes("UTF-8"));zip.closeEntry();}
    private static void addFile(ZipOutputStream zip,String name,File file)throws IOException{zip.putNextEntry(new ZipEntry(name));try(InputStream in=new FileInputStream(file)){byte[]buf=new byte[65536];int n;while((n=in.read(buf))>=0)zip.write(buf,0,n);}zip.closeEntry();}
    private void trimIfNeeded()throws IOException{if(logFile.length()<2_000_000)return;byte[] all=new byte[(int)Math.min(logFile.length(),1_000_000)];try(RandomAccessFile r=new RandomAccessFile(logFile,"r")){r.seek(Math.max(0,r.length()-all.length));r.readFully(all);}try(OutputStream out=new FileOutputStream(logFile)){out.write(all);}}
    static String sanitize(String s){if(s==null)return"";return s.replaceAll("gh[pousr]_[A-Za-z0-9_]+","[TOKEN HIDDEN]").replaceAll("Bearer\\s+[A-Za-z0-9._-]+","Bearer [TOKEN HIDDEN]");}
}
