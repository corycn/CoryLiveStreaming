package com.example.gradleapkbuilder;

import android.content.Context;

import java.io.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.zip.*;

/** Imports, exports and applies a portable APK signing-certificate package. */
final class SigningCertificateManager {
    static final class GenerateOptions {
        String alias; String storePassword; String keyPassword; String commonName;
        String organizationUnit; String organization; String locality; String state; String country;
        int validityDays=9125;
    }

    interface Listener { void onMessage(String message); }
    interface ExportProgress {
        void onProgress(String message,long done,long total);
        boolean isCancelled();
    }

    private final File baseDir;
    private final File currentDir;
    private final File propertiesFile;
    private final File keyStoreFile;

    SigningCertificateManager(Context context) {
        baseDir = new File(context.getApplicationContext().getFilesDir(), "signing-certificates");
        currentDir = new File(baseDir, "current");
        propertiesFile = new File(currentDir, "signing.properties");
        keyStoreFile = new File(currentDir, "keystore.bin");
    }

    boolean isConfigured() {
        return propertiesFile.isFile() && keyStoreFile.isFile();
    }

    String status() {
        if (!isConfigured()) return "未导入 APK 签名证书包";
        try {
            Properties p = load(propertiesFile);
            return "已导入\n别名：" + p.getProperty("keyAlias", "未知")
                    + "\n类型：" + p.getProperty("storeType", "自动识别")
                    + "\n文件：" + keyStoreFile.getName();
        } catch (Exception e) {
            return "签名配置存在，但无法读取：" + e.getMessage();
        }
    }

    void importPackage(InputStream source, RuntimeBundleManager runtime) throws Exception {
        if (source == null) throw new IOException("无法打开签名证书包");
        File stage = new File(baseDir, "stage-" + System.currentTimeMillis());
        File zip = File.createTempFile("gap-signing-", ".zip", baseDir.getParentFile());
        deleteRecursive(stage);
        if (!stage.mkdirs()) throw new IOException("无法创建签名证书临时目录");
        try {
            try (OutputStream out = new FileOutputStream(zip)) { copy(source, out); }
            unzipSecure(zip, stage);
            File props = findNamed(stage, "signing.properties");
            if (props == null) throw new IOException("签名证书包缺少 signing.properties");
            Properties input = load(props);
            String storeName = input.getProperty("storeFile", "").trim();
            String storePassword = input.getProperty("storePassword", "");
            String alias = input.getProperty("keyAlias", "").trim();
            String keyPassword = input.getProperty("keyPassword", storePassword);
            if (storeName.isEmpty() || storePassword.isEmpty() || alias.isEmpty()) {
                throw new IOException("signing.properties 必须包含 storeFile、storePassword 和 keyAlias");
            }
            File store = new File(props.getParentFile(), storeName);
            String parent = props.getParentFile().getCanonicalPath() + File.separator;
            if (!store.getCanonicalPath().startsWith(parent) || !store.isFile()) {
                store = findByName(stage, new File(storeName).getName());
            }
            if (store == null || !store.isFile()) throw new IOException("签名证书包中未找到 keystore：" + storeName);
            String type = validateWithJdk(store, storePassword, alias, keyPassword,
                    input.getProperty("storeType", "").trim(), runtime, null);

            File replacement = new File(baseDir, "current-new");
            deleteRecursive(replacement);
            if (!replacement.mkdirs()) throw new IOException("无法创建签名证书安装目录");
            File newStore = new File(replacement, "keystore.bin");
            copy(new FileInputStream(store), new FileOutputStream(newStore));
            Properties normalized = new Properties();
            normalized.setProperty("storeFile", "keystore.bin");
            normalized.setProperty("storePassword", storePassword);
            normalized.setProperty("keyAlias", alias);
            normalized.setProperty("keyPassword", keyPassword);
            normalized.setProperty("storeType", type);
            copyOptional(input,normalized,"commonName");
            copyOptional(input,normalized,"organizationUnit");
            copyOptional(input,normalized,"organization");
            copyOptional(input,normalized,"locality");
            copyOptional(input,normalized,"state");
            copyOptional(input,normalized,"country");
            copyOptional(input,normalized,"validityDays");
            try (OutputStream out = new FileOutputStream(new File(replacement, "signing.properties"))) {
                normalized.store(out, "GradleApkBuilder APK signing certificate");
            }
            replaceCurrent(replacement);
        } finally {
            zip.delete();
            deleteRecursive(stage);
        }
    }


    Properties currentProperties() {
        try { return isConfigured() ? load(propertiesFile) : new Properties(); }
        catch (Exception e) { return new Properties(); }
    }

    void updateCurrentConfiguration(Properties edited, RuntimeBundleManager runtime) throws Exception {
        if(!isConfigured())throw new IOException("尚未导入签名证书");
        Properties current=load(propertiesFile);
        Properties merged=new Properties();merged.putAll(current);
        if(edited!=null)for(String name:edited.stringPropertyNames())merged.setProperty(name,edited.getProperty(name,""));
        String storePassword=merged.getProperty("storePassword","");
        String alias=merged.getProperty("keyAlias","").trim();
        String keyPassword=merged.getProperty("keyPassword",storePassword);if(keyPassword.isEmpty())keyPassword=storePassword;merged.setProperty("keyPassword",keyPassword);
        if(storePassword.isEmpty()||alias.isEmpty())throw new IOException("证书库密码和私钥别名不能为空");
        String type=validateWithJdk(keyStoreFile,storePassword,alias,keyPassword,merged.getProperty("storeType",""),runtime,null);
        merged.setProperty("storeFile","keystore.bin");merged.setProperty("storeType",type);
        File temp=new File(currentDir,"signing.properties.new");
        try(OutputStream out=new FileOutputStream(temp)){merged.store(out,"CoryKui APKbuild signing configuration");}
        if(propertiesFile.exists()&&!propertiesFile.delete()){temp.delete();throw new IOException("无法更新签名配置");}
        if(!temp.renameTo(propertiesFile)){try(InputStream in=new FileInputStream(temp);OutputStream out=new FileOutputStream(propertiesFile)){copy(in,out);}temp.delete();}
    }

    void generateRandomCertificate(RuntimeBundleManager runtime, GenerateOptions options, Listener listener) throws Exception {
        if (runtime == null) throw new IOException("运行时环境不可用");
        if (options == null) throw new IOException("签名证书参数为空");
        String alias = clean(options.alias, "corykui");
        String storePassword = requirePassword(options.storePassword, "证书库密码");
        String keyPassword = options.keyPassword == null || options.keyPassword.isEmpty() ? storePassword : options.keyPassword;
        File keytool = findKeytool(runtime);
        if (keytool == null) throw new IOException("当前 JDK 中未找到 keytool，请安装或启用 JDK 17/21");
        File stage = new File(baseDir, "generated-" + System.currentTimeMillis());
        deleteRecursive(stage);
        if (!stage.mkdirs()) throw new IOException("无法创建签名证书生成目录");
        File store = new File(stage, "CoryKui-APKbuild-signing.jks");
        String dname = "CN=" + escapeDn(clean(options.commonName, "CoryKui APKbuild"))
                + ", OU=" + escapeDn(clean(options.organizationUnit, "Android Build"))
                + ", O=" + escapeDn(clean(options.organization, "CoryKui"))
                + ", L=" + escapeDn(clean(options.locality, "Unknown"))
                + ", ST=" + escapeDn(clean(options.state, "Unknown"))
                + ", C=" + normalizeCountry(options.country);
        ArrayList<String> command = new ArrayList<>();
        Collections.addAll(command, keytool.getAbsolutePath(), "-genkeypair", "-noprompt",
                "-keystore", store.getAbsolutePath(), "-storetype", "JKS",
                "-storepass", storePassword, "-keypass", keyPassword,
                "-alias", alias, "-keyalg", "RSA", "-keysize", "2048",
                "-sigalg", "SHA256withRSA", "-validity", String.valueOf(Math.max(365, options.validityDays)),
                "-dname", dname);
        if (listener != null) listener.onMessage("正在使用 JDK keytool 生成 RSA 2048 签名证书…");
        runTool(command, runtime, listener);
        validateWithJdk(store, storePassword, alias, keyPassword, "JKS", runtime, listener);

        File replacement = new File(baseDir, "current-new");
        deleteRecursive(replacement);
        if (!replacement.mkdirs()) throw new IOException("无法创建签名证书安装目录");
        copy(new FileInputStream(store), new FileOutputStream(new File(replacement, "keystore.bin")));
        Properties normalized = new Properties();
        normalized.setProperty("storeFile", "keystore.bin");
        normalized.setProperty("storePassword", storePassword);
        normalized.setProperty("keyAlias", alias);
        normalized.setProperty("keyPassword", keyPassword);
        normalized.setProperty("storeType", "JKS");
        normalized.setProperty("commonName", clean(options.commonName, "CoryKui APKbuild"));
        normalized.setProperty("organizationUnit", clean(options.organizationUnit, "Android Build"));
        normalized.setProperty("organization", clean(options.organization, "CoryKui"));
        normalized.setProperty("locality", clean(options.locality, "Unknown"));
        normalized.setProperty("state", clean(options.state, "Unknown"));
        normalized.setProperty("country", normalizeCountry(options.country));
        normalized.setProperty("validityDays", String.valueOf(Math.max(365, options.validityDays)));
        try (OutputStream out = new FileOutputStream(new File(replacement, "signing.properties"))) {
            normalized.store(out, "CoryKui APKbuild generated APK signing certificate");
        }
        replaceCurrent(replacement);
        deleteRecursive(stage);
        if (listener != null) listener.onMessage("随机签名证书已生成并启用");
    }

    private void replaceCurrent(File replacement) throws IOException {
        File old = new File(baseDir, "current-old");
        deleteRecursive(old);
        if (currentDir.exists() && !currentDir.renameTo(old)) throw new IOException("无法备份原签名证书");
        if (!replacement.renameTo(currentDir)) {
            if (old.exists()) old.renameTo(currentDir);
            throw new IOException("无法安装新签名证书");
        }
        deleteRecursive(old);
    }

    private static File findKeytool(RuntimeBundleManager runtime) {
        File home = runtime.getActiveJdkHome();
        if (home != null) {
            File tool = new File(home, "bin/keytool");
            if (tool.isFile()) return tool;
        }
        File prefix = runtime.getActiveJdkPrefix();
        if (prefix != null) {
            File tool = new File(prefix, "bin/keytool");
            if (tool.isFile()) return tool;
        }
        return null;
    }

    private static void runTool(List<String> command, RuntimeBundleManager runtime, Listener listener) throws Exception {
        runTool(command, runtime, listener, "生成签名证书");
    }

    private static void runTool(List<String> command, RuntimeBundleManager runtime, Listener listener, String action) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(command).redirectErrorStream(true);
        File home = runtime.getActiveJdkHome();
        File prefix = runtime.getActiveJdkPrefix();
        if (home != null) pb.environment().put("JAVA_HOME", home.getAbsolutePath());
        if (prefix != null) { File tmp = new File(prefix, "tmp"); tmp.mkdirs(); pb.environment().put("TMPDIR", tmp.getAbsolutePath()); }
        String libs = runtime.getJavaLibraryPath();
        if (!libs.isEmpty()) pb.environment().put("LD_LIBRARY_PATH", libs);
        Process process = pb.start();
        StringBuilder output = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line; while ((line = reader.readLine()) != null) { output.append(line).append('\n'); if (listener != null) listener.onMessage(line); }
        }
        if (!process.waitFor(5, TimeUnit.MINUTES)) { process.destroyForcibly(); throw new IOException("keytool " + action + "超时"); }
        if (process.exitValue() != 0) throw new IOException("keytool " + action + "失败，退出代码 " + process.exitValue() + "：\n" + output);
    }

    private static void copyOptional(Properties source,Properties target,String key){String value=source.getProperty(key);if(value!=null&&!value.trim().isEmpty())target.setProperty(key,value.trim());}

    private static String clean(String value, String fallback) { String s=value==null?"":value.trim(); return s.isEmpty()?fallback:s; }
    private static String requirePassword(String value,String label)throws IOException { if(value==null||value.length()<6)throw new IOException(label+"至少需要 6 位"); return value; }
    private static String normalizeCountry(String value) { String s=clean(value,"CN").toUpperCase(Locale.US); return s.length()>=2?s.substring(0,2):"CN"; }
    private static String escapeDn(String value) { return value.replace("\\","\\\\").replace(",","\\,").replace("=","\\="); }

    void exportPackage(OutputStream destination) throws Exception { exportPackage(destination,null); }

    void exportPackage(OutputStream destination,ExportProgress progress) throws Exception {
        if (!isConfigured()) throw new IOException("尚未导入签名证书包");
        if (destination == null) throw new IOException("无法打开签名证书导出文件");
        Properties p = load(propertiesFile);Properties exported = new Properties();exported.putAll(p);
        exported.setProperty("storeFile", "GradleApkBuilder-signing-keystore.jks");
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();exported.store(buffer, "Sensitive APK signing package - keep private");
        byte[] metadata=buffer.toByteArray();long total=Math.max(1,metadata.length+keyStoreFile.length()),done=0;
        try (ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(destination))) {
            checkCancelled(progress);zip.putNextEntry(new ZipEntry("signing.properties"));zip.write(metadata);zip.closeEntry();done+=metadata.length;
            if(progress!=null)progress.onProgress("正在导出签名配置…",done,total);
            zip.putNextEntry(new ZipEntry("GradleApkBuilder-signing-keystore.jks"));
            try (InputStream in = new BufferedInputStream(new FileInputStream(keyStoreFile))) {
                byte[] bytes = new byte[65536]; int count;
                while ((count = in.read(bytes)) >= 0) {checkCancelled(progress);zip.write(bytes, 0, count);done+=count;if(progress!=null)progress.onProgress("正在导出签名私钥…",done,total);}
            }
            zip.closeEntry();zip.finish();
        }
        if(progress!=null)progress.onProgress("签名证书导出完成",total,total);
    }

    private static void checkCancelled(ExportProgress progress)throws InterruptedIOException{
        if(progress!=null&&progress.isCancelled())throw new InterruptedIOException("用户已取消导出");
    }

    File signIfConfigured(File inputApk, RuntimeBundleManager runtime, Listener listener) throws Exception {
        if (!isConfigured()) return inputApk;
        File java = runtime.getJavaExecutable();
        File sdk = runtime.getAndroidSdkDir();
        if (java == null || sdk == null) throw new IOException("已导入签名证书，但缺少 Java 或 Android SDK，无法签名 APK");
        File jar = findNamed(sdk, "apksigner.jar");
        if (jar == null) throw new IOException("Android SDK 中未找到 apksigner.jar，请安装 Build Tools");
        Properties p = load(propertiesFile);
        File output = new File(inputApk.getParentFile(), stripApk(inputApk.getName()) + "-signed.apk");
        if (output.exists() && !output.delete()) throw new IOException("无法覆盖旧签名 APK：" + output);
        ArrayList<String> command = new ArrayList<>();
        Collections.addAll(command,
                java.getAbsolutePath(), "-jar", jar.getAbsolutePath(), "sign",
                "--ks", keyStoreFile.getAbsolutePath(),
                "--ks-type", p.getProperty("storeType", "JKS"),
                "--ks-key-alias", p.getProperty("keyAlias"),
                "--ks-pass", "pass:" + p.getProperty("storePassword"),
                "--key-pass", "pass:" + p.getProperty("keyPassword"),
                "--out", output.getAbsolutePath(), inputApk.getAbsolutePath());
        if (listener != null) listener.onMessage("正在使用导入的签名证书签名 APK…");
        run(command, runtime, listener);
        run(Arrays.asList(java.getAbsolutePath(), "-jar", jar.getAbsolutePath(), "verify", "--verbose", output.getAbsolutePath()), runtime, listener);
        if (!output.isFile() || output.length() == 0) throw new IOException("APK 签名命令完成，但没有生成输出文件");
        return output;
    }

    void remove() { deleteRecursive(currentDir); }

    private static void run(List<String> command, RuntimeBundleManager runtime, Listener listener) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(command).redirectErrorStream(true);
        File home = runtime.getActiveJdkHome();
        File prefix = runtime.getActiveJdkPrefix();
        if (home != null) pb.environment().put("JAVA_HOME", home.getAbsolutePath());
        if (prefix != null) {
            File tmp = new File(prefix, "tmp"); tmp.mkdirs();
            pb.environment().put("TMPDIR", tmp.getAbsolutePath());
        }
        String libs = runtime.getJavaLibraryPath();
        if (!libs.isEmpty()) pb.environment().put("LD_LIBRARY_PATH", libs);
        Process process = pb.start();
        StringBuilder text = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line; while ((line = reader.readLine()) != null) {
                text.append(line).append('\n');
                if (listener != null) listener.onMessage(line);
            }
        }
        if (!process.waitFor(10, TimeUnit.MINUTES)) {
            process.destroyForcibly(); throw new IOException("APK 签名命令超时");
        }
        if (process.exitValue() != 0) throw new IOException("APK 签名失败，退出代码 " + process.exitValue() + "：\n" + text);
    }

    private static String validateWithJdk(File store, String storePassword, String alias,
                                          String keyPassword, String requestedType,
                                          RuntimeBundleManager runtime, Listener listener) throws Exception {
        if (store == null || !store.isFile() || store.length() < 32) {
            throw new IOException("签名证书文件不存在或内容为空");
        }
        String type = detectStoreType(store, requestedType);
        File keytool = runtime == null ? null : findKeytool(runtime);
        if (keytool == null) {
            throw new IOException("无法验证签名证书：当前 JDK 中未找到 keytool，请安装或启用 JDK 17/21");
        }

        // Do not use Android's in-process KeyStore provider for JKS validation.
        // Some Android builds expose PKCS12 only, which caused a valid JKS file
        // to be retried as PKCS12 and reported as an invalid PKCS12 stream.
        ArrayList<String> listCommand = new ArrayList<>();
        Collections.addAll(listCommand, keytool.getAbsolutePath(), "-list", "-v",
                "-keystore", store.getAbsolutePath(),
                "-storetype", type,
                "-storepass", storePassword,
                "-alias", alias);
        runTool(listCommand, runtime, listener, "验证签名证书库和别名");

        // Verify that the private-key password can actually unlock the selected alias.
        // Importing the key into a disposable PKCS12 store exercises both storePassword
        // and keyPassword without modifying the source keystore.
        File verifyStore = new File(store.getParentFile(), ".verify-" + System.nanoTime() + ".p12");
        String verifyPassword = "CoryKuiVerify" + Long.toHexString(System.nanoTime());
        try {
            ArrayList<String> verifyCommand = new ArrayList<>();
            Collections.addAll(verifyCommand, keytool.getAbsolutePath(), "-importkeystore", "-noprompt",
                    "-srckeystore", store.getAbsolutePath(),
                    "-srcstoretype", type,
                    "-srcstorepass", storePassword,
                    "-srcalias", alias,
                    "-srckeypass", keyPassword,
                    "-destkeystore", verifyStore.getAbsolutePath(),
                    "-deststoretype", "PKCS12",
                    "-deststorepass", verifyPassword,
                    "-destkeypass", verifyPassword);
            runTool(verifyCommand, runtime, listener, "验证签名私钥密码");
            if (!verifyStore.isFile() || verifyStore.length() < 32) {
                throw new IOException("签名私钥验证没有生成有效的临时证书库");
            }
        } finally {
            if (verifyStore.exists() && !verifyStore.delete()) verifyStore.deleteOnExit();
        }
        return type;
    }

    private static String detectStoreType(File store, String requestedType) throws IOException {
        String requested = requestedType == null ? "" : requestedType.trim().toUpperCase(Locale.US);
        if ("JKS".equals(requested) || "PKCS12".equals(requested) || "PKCS#12".equals(requested)) {
            return requested.startsWith("PKCS") ? "PKCS12" : "JKS";
        }
        try (DataInputStream input = new DataInputStream(new BufferedInputStream(new FileInputStream(store)))) {
            int magic = input.readInt();
            if (magic == 0xFEEDFEED || magic == 0xCECECECE) return "JKS";
        }
        return "PKCS12";
    }

    private static String stripApk(String name) {
        return name.toLowerCase(Locale.US).endsWith(".apk") ? name.substring(0, name.length() - 4) : name;
    }
    private static File findNamed(File root, String name) {
        if (root == null || !root.exists()) return null;
        if (root.isFile()) return name.equals(root.getName()) ? root : null;
        File[] files = root.listFiles();
        if (files != null) for (File file : files) { File found = findNamed(file, name); if (found != null) return found; }
        return null;
    }
    private static File findByName(File root, String name) { return findNamed(root, name); }
    private static Properties load(File file) throws IOException {
        Properties p = new Properties();
        try (InputStream in = new FileInputStream(file)) { p.load(in); }
        return p;
    }
    private static void unzipSecure(File zipFile, File destination) throws IOException {
        String root = destination.getCanonicalPath() + File.separator;
        try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(new FileInputStream(zipFile)))) {
            ZipEntry entry; byte[] bytes = new byte[65536];
            while ((entry = zip.getNextEntry()) != null) {
                File output = new File(destination, entry.getName());
                if (!output.getCanonicalPath().startsWith(root)) throw new IOException("签名证书包包含不安全路径");
                if (entry.isDirectory()) {
                    if (!output.exists() && !output.mkdirs()) throw new IOException("无法创建目录：" + output);
                } else {
                    File parent = output.getParentFile();
                    if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("无法创建目录：" + parent);
                    try (OutputStream out = new FileOutputStream(output)) {
                        int count; while ((count = zip.read(bytes)) >= 0) out.write(bytes, 0, count);
                    }
                }
                zip.closeEntry();
            }
        }
    }
    private static void copy(InputStream in, OutputStream out) throws IOException {
        try (InputStream source = in; OutputStream destination = out) {
            byte[] bytes = new byte[65536]; int count;
            while ((count = source.read(bytes)) >= 0) destination.write(bytes, 0, count);
        }
    }
    private static void deleteRecursive(File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory()) { File[] files = file.listFiles(); if (files != null) for (File child : files) deleteRecursive(child); }
        file.delete();
    }
}
