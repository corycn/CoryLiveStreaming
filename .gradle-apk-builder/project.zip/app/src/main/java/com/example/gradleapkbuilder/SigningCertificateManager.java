package com.example.gradleapkbuilder;

import android.content.Context;

import java.io.*;
import java.security.Key;
import java.security.KeyStore;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.zip.*;

/** Imports, exports and applies a portable APK signing-certificate package. */
final class SigningCertificateManager {
    interface Listener { void onMessage(String message); }
    interface ExportProgress {
        void onProgress(String message,long done,long total);
        boolean isCancelled();
    }

    private final File baseDir;
    private final File currentDir;
    private final File propertiesFile;
    private final File keyStoreFile;

    SigningCertificateManager(Context context) {
        baseDir = new File(context.getApplicationContext().getFilesDir(), "signing-certificates");
        currentDir = new File(baseDir, "current");
        propertiesFile = new File(currentDir, "signing.properties");
        keyStoreFile = new File(currentDir, "keystore.bin");
    }

    boolean isConfigured() {
        return propertiesFile.isFile() && keyStoreFile.isFile();
    }

    String status() {
        if (!isConfigured()) return "未导入 APK 签名证书包";
        try {
            Properties p = load(propertiesFile);
            return "已导入\n别名：" + p.getProperty("keyAlias", "未知")
                    + "\n类型：" + p.getProperty("storeType", "自动识别")
                    + "\n文件：" + keyStoreFile.getName();
        } catch (Exception e) {
            return "签名配置存在，但无法读取：" + e.getMessage();
        }
    }

    void importPackage(InputStream source) throws Exception {
        if (source == null) throw new IOException("无法打开签名证书包");
        File stage = new File(baseDir, "stage-" + System.currentTimeMillis());
        File zip = File.createTempFile("gap-signing-", ".zip", baseDir.getParentFile());
        deleteRecursive(stage);
        if (!stage.mkdirs()) throw new IOException("无法创建签名证书临时目录");
        try {
            try (OutputStream out = new FileOutputStream(zip)) { copy(source, out); }
            unzipSecure(zip, stage);
            File props = findNamed(stage, "signing.properties");
            if (props == null) throw new IOException("签名证书包缺少 signing.properties");
            Properties input = load(props);
            String storeName = input.getProperty("storeFile", "").trim();
            String storePassword = input.getProperty("storePassword", "");
            String alias = input.getProperty("keyAlias", "").trim();
            String keyPassword = input.getProperty("keyPassword", storePassword);
            if (storeName.isEmpty() || storePassword.isEmpty() || alias.isEmpty()) {
                throw new IOException("signing.properties 必须包含 storeFile、storePassword 和 keyAlias");
            }
            File store = new File(props.getParentFile(), storeName);
            String parent = props.getParentFile().getCanonicalPath() + File.separator;
            if (!store.getCanonicalPath().startsWith(parent) || !store.isFile()) {
                store = findByName(stage, new File(storeName).getName());
            }
            if (store == null || !store.isFile()) throw new IOException("签名证书包中未找到 keystore：" + storeName);
            String type = validate(store, storePassword, alias, keyPassword,
                    input.getProperty("storeType", "").trim());

            File replacement = new File(baseDir, "current-new");
            deleteRecursive(replacement);
            if (!replacement.mkdirs()) throw new IOException("无法创建签名证书安装目录");
            File newStore = new File(replacement, "keystore.bin");
            copy(new FileInputStream(store), new FileOutputStream(newStore));
            Properties normalized = new Properties();
            normalized.setProperty("storeFile", "keystore.bin");
            normalized.setProperty("storePassword", storePassword);
            normalized.setProperty("keyAlias", alias);
            normalized.setProperty("keyPassword", keyPassword);
            normalized.setProperty("storeType", type);
            try (OutputStream out = new FileOutputStream(new File(replacement, "signing.properties"))) {
                normalized.store(out, "GradleApkBuilder APK signing certificate");
            }
            File old = new File(baseDir, "current-old");
            deleteRecursive(old);
            if (currentDir.exists() && !currentDir.renameTo(old)) throw new IOException("无法备份原签名证书");
            if (!replacement.renameTo(currentDir)) {
                if (old.exists()) old.renameTo(currentDir);
                throw new IOException("无法安装签名证书包");
            }
            deleteRecursive(old);
        } finally {
            zip.delete();
            deleteRecursive(stage);
        }
    }

    void exportPackage(OutputStream destination) throws Exception { exportPackage(destination,null); }

    void exportPackage(OutputStream destination,ExportProgress progress) throws Exception {
        if (!isConfigured()) throw new IOException("尚未导入签名证书包");
        if (destination == null) throw new IOException("无法打开签名证书导出文件");
        Properties p = load(propertiesFile);Properties exported = new Properties();exported.putAll(p);
        exported.setProperty("storeFile", "GradleApkBuilder-signing-keystore.jks");
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();exported.store(buffer, "Sensitive APK signing package - keep private");
        byte[] metadata=buffer.toByteArray();long total=Math.max(1,metadata.length+keyStoreFile.length()),done=0;
        try (ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(destination))) {
            checkCancelled(progress);zip.putNextEntry(new ZipEntry("signing.properties"));zip.write(metadata);zip.closeEntry();done+=metadata.length;
            if(progress!=null)progress.onProgress("正在导出签名配置…",done,total);
            zip.putNextEntry(new ZipEntry("GradleApkBuilder-signing-keystore.jks"));
            try (InputStream in = new BufferedInputStream(new FileInputStream(keyStoreFile))) {
                byte[] bytes = new byte[65536]; int count;
                while ((count = in.read(bytes)) >= 0) {checkCancelled(progress);zip.write(bytes, 0, count);done+=count;if(progress!=null)progress.onProgress("正在导出签名私钥…",done,total);}
            }
            zip.closeEntry();zip.finish();
        }
        if(progress!=null)progress.onProgress("签名证书导出完成",total,total);
    }

    private static void checkCancelled(ExportProgress progress)throws InterruptedIOException{
        if(progress!=null&&progress.isCancelled())throw new InterruptedIOException("用户已取消导出");
    }

    File signIfConfigured(File inputApk, RuntimeBundleManager runtime, Listener listener) throws Exception {
        if (!isConfigured()) return inputApk;
        File java = runtime.getJavaExecutable();
        File sdk = runtime.getAndroidSdkDir();
        if (java == null || sdk == null) throw new IOException("已导入签名证书，但缺少 Java 或 Android SDK，无法签名 APK");
        File jar = findNamed(sdk, "apksigner.jar");
        if (jar == null) throw new IOException("Android SDK 中未找到 apksigner.jar，请安装 Build Tools");
        Properties p = load(propertiesFile);
        File output = new File(inputApk.getParentFile(), stripApk(inputApk.getName()) + "-signed.apk");
        if (output.exists() && !output.delete()) throw new IOException("无法覆盖旧签名 APK：" + output);
        ArrayList<String> command = new ArrayList<>();
        Collections.addAll(command,
                java.getAbsolutePath(), "-jar", jar.getAbsolutePath(), "sign",
                "--ks", keyStoreFile.getAbsolutePath(),
                "--ks-type", p.getProperty("storeType", "JKS"),
                "--ks-key-alias", p.getProperty("keyAlias"),
                "--ks-pass", "pass:" + p.getProperty("storePassword"),
                "--key-pass", "pass:" + p.getProperty("keyPassword"),
                "--out", output.getAbsolutePath(), inputApk.getAbsolutePath());
        if (listener != null) listener.onMessage("正在使用导入的签名证书签名 APK…");
        run(command, runtime, listener);
        run(Arrays.asList(java.getAbsolutePath(), "-jar", jar.getAbsolutePath(), "verify", "--verbose", output.getAbsolutePath()), runtime, listener);
        if (!output.isFile() || output.length() == 0) throw new IOException("APK 签名命令完成，但没有生成输出文件");
        return output;
    }

    void remove() { deleteRecursive(currentDir); }

    private static void run(List<String> command, RuntimeBundleManager runtime, Listener listener) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(command).redirectErrorStream(true);
        File home = runtime.getActiveJdkHome();
        File prefix = runtime.getActiveJdkPrefix();
        if (home != null) pb.environment().put("JAVA_HOME", home.getAbsolutePath());
        if (prefix != null) {
            File tmp = new File(prefix, "tmp"); tmp.mkdirs();
            pb.environment().put("TMPDIR", tmp.getAbsolutePath());
        }
        String libs = runtime.getJavaLibraryPath();
        if (!libs.isEmpty()) pb.environment().put("LD_LIBRARY_PATH", libs);
        Process process = pb.start();
        StringBuilder text = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line; while ((line = reader.readLine()) != null) {
                text.append(line).append('\n');
                if (listener != null) listener.onMessage(line);
            }
        }
        if (!process.waitFor(10, TimeUnit.MINUTES)) {
            process.destroyForcibly(); throw new IOException("APK 签名命令超时");
        }
        if (process.exitValue() != 0) throw new IOException("APK 签名失败，退出代码 " + process.exitValue() + "：\n" + text);
    }

    private static String validate(File store, String storePassword, String alias,
                                   String keyPassword, String requestedType) throws Exception {
        LinkedHashSet<String> types = new LinkedHashSet<>();
        if (!requestedType.isEmpty()) types.add(requestedType);
        types.add("JKS"); types.add("PKCS12");
        Exception last = null;
        for (String type : types) {
            try (InputStream in = new FileInputStream(store)) {
                KeyStore ks = KeyStore.getInstance(type);
                ks.load(in, storePassword.toCharArray());
                if (!ks.containsAlias(alias)) throw new IOException("keystore 中不存在别名：" + alias);
                Key key = ks.getKey(alias, keyPassword.toCharArray());
                if (key == null) throw new IOException("无法读取签名私钥，请检查 keyPassword");
                return type;
            } catch (Exception e) { last = e; }
        }
        throw new IOException("签名证书或密码无效：" + (last == null ? "未知错误" : last.getMessage()), last);
    }

    private static String stripApk(String name) {
        return name.toLowerCase(Locale.US).endsWith(".apk") ? name.substring(0, name.length() - 4) : name;
    }
    private static File findNamed(File root, String name) {
        if (root == null || !root.exists()) return null;
        if (root.isFile()) return name.equals(root.getName()) ? root : null;
        File[] files = root.listFiles();
        if (files != null) for (File file : files) { File found = findNamed(file, name); if (found != null) return found; }
        return null;
    }
    private static File findByName(File root, String name) { return findNamed(root, name); }
    private static Properties load(File file) throws IOException {
        Properties p = new Properties();
        try (InputStream in = new FileInputStream(file)) { p.load(in); }
        return p;
    }
    private static void unzipSecure(File zipFile, File destination) throws IOException {
        String root = destination.getCanonicalPath() + File.separator;
        try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(new FileInputStream(zipFile)))) {
            ZipEntry entry; byte[] bytes = new byte[65536];
            while ((entry = zip.getNextEntry()) != null) {
                File output = new File(destination, entry.getName());
                if (!output.getCanonicalPath().startsWith(root)) throw new IOException("签名证书包包含不安全路径");
                if (entry.isDirectory()) {
                    if (!output.exists() && !output.mkdirs()) throw new IOException("无法创建目录：" + output);
                } else {
                    File parent = output.getParentFile();
                    if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("无法创建目录：" + parent);
                    try (OutputStream out = new FileOutputStream(output)) {
                        int count; while ((count = zip.read(bytes)) >= 0) out.write(bytes, 0, count);
                    }
                }
                zip.closeEntry();
            }
        }
    }
    private static void copy(InputStream in, OutputStream out) throws IOException {
        try (InputStream source = in; OutputStream destination = out) {
            byte[] bytes = new byte[65536]; int count;
            while ((count = source.read(bytes)) >= 0) destination.write(bytes, 0, count);
        }
    }
    private static void deleteRecursive(File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory()) { File[] files = file.listFiles(); if (files != null) for (File child : files) deleteRecursive(child); }
        file.delete();
    }
}
