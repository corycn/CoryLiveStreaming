package com.example.gradleapkbuilder;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.*;
import android.provider.OpenableColumns;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.text.*;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PICK_PROJECT=10, EXPORT_APK=11, IMPORT_RUNTIME=12, EXPORT_RUNTIME=13, EXPORT_SYSTEM_BACKUP=14, IMPORT_SYSTEM_BACKUP=15, EXPORT_BUG_LOG=16, IMPORT_SIGNING=17, EXPORT_SIGNING=18, EXTRACT_SIGNING_RESOURCE=19, EXPORT_SETTINGS=20, IMPORT_SETTINGS=21, PICK_APP_ICON=22, EXTRACT_APP_ICON=23;
    private TextView projectText,statusText,runtimeText;
    private ScrollView statusScroll;
    private EditText ownerInput,repoInput,branchInput,tokenInput,taskInput;
    private Button cloudButton,localButton,exportButton;
    private File projectZip,builtApk;
    private RuntimeBundleManager runtime;
    private SecureSettings secureSettings;
    private SystemBackupManager backupManager;
    private char[] pendingBackupPassword;
    private char[] pendingSettingsPassword;
    private LocalBuildEngine activeLocalBuild;
    private GitHubBuilder activeGitHubBuild;
    private BugLogManager bugLog;
    private SigningCertificateManager signingManager;
    private SigningResourceExtractor.Result pendingSigningExtraction;
    private AppIconManager iconManager;
    private final Handler settingsHandler=new Handler(Looper.getMainLooper());
    private final Runnable saveCloudRunnable=()->saveCloudInputsSilently();
    private final ArrayDeque<String> statusHistory=new ArrayDeque<>();
    private final ArrayList<String> statusProgressLines=new ArrayList<>();

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        runtime=new RuntimeBundleManager(this);
        secureSettings=new SecureSettings(this);
        backupManager=new SystemBackupManager(this,secureSettings);
        bugLog=new BugLogManager(this);
        signingManager=new SigningCertificateManager(this);
        iconManager=new AppIconManager(this);
        bugLog.log("INFO","App started");
        setContentView(buildUi());
        restoreSavedCloudSettings();
        attachCloudAutoSave();
        restoreCurrentProjectReference();
        refreshRuntime();
    }

    private View buildUi(){
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setBackgroundColor(Color.rgb(245,247,252));
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(18),0,dp(8),0);bar.setBackgroundColor(Color.rgb(51,92,255));
        TextView title=new TextView(this);title.setText("小魁安卓编译");title.setTextSize(20);title.setTextColor(Color.WHITE);bar.addView(title,new LinearLayout.LayoutParams(0,-1,1));
        Button menu=new Button(this);menu.setText("⋮");menu.setTextSize(24);menu.setTextColor(Color.WHITE);menu.setBackgroundColor(Color.TRANSPARENT);menu.setOnClickListener(v->showTopMenu(menu));bar.addView(menu,new LinearLayout.LayoutParams(dp(56),-1));page.addView(bar,new LinearLayout.LayoutParams(-1,dp(58)));
        ScrollView scroll=new ScrollView(this);LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(16),dp(14),dp(16),dp(30));scroll.addView(body);page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        body.addView(section("1. 导入 Android Studio / Gradle 工程"));
        Button pick=button("选择工程 ZIP");pick.setOnClickListener(v->pickProject());body.addView(pick);
        projectText=text("尚未选择工程。请将完整 Android Studio 项目压缩为 ZIP。 ");body.addView(projectText);

        body.addView(section("2. 手机本地构建"));
        runtimeText=text("");runtimeText.setTextIsSelectable(true);body.addView(runtimeText);
        LinearLayout tools=new LinearLayout(this);tools.setOrientation(LinearLayout.HORIZONTAL);
        Button manage=button("SDK / Linux 环境管理");manage.setOnClickListener(v->showRuntimeManager());tools.addView(manage,new LinearLayout.LayoutParams(0,-2,1));
        body.addView(tools);
        taskInput=input("Gradle 任务，默认 assembleDebug",false);taskInput.setText("assembleDebug");body.addView(taskInput);
        localButton=button("在手机本地编译 APK");localButton.setEnabled(false);localButton.setOnClickListener(v->startLocalBuild());body.addView(localButton);
        body.addView(text("本地构建优先直接使用 AndroidIDE 的 Android 原生 JDK、SDK 和 ARM64 aapt2，不再强制要求 Linux rootfs。部分现代工程需要 JDK 17；环境自检会显示实际 Java 版本。"));

        body.addView(section("3. GitHub Actions 云端备用引擎"));
        ownerInput=input("GitHub 用户名或组织名",false);body.addView(ownerInput);
        repoInput=input("仓库名称",false);body.addView(repoInput);
        branchInput=input("分支（默认 main）",false);branchInput.setText("main");body.addView(branchInput);
        tokenInput=input("GitHub Token（使用 Android Keystore 加密保存）",true);body.addView(tokenInput);
        cloudButton=button("上传并云端编译 APK");cloudButton.setEnabled(false);cloudButton.setOnClickListener(v->startCloudBuild());body.addView(cloudButton);

        body.addView(section("4. 构建状态与导出"));
        FrameLayout statusPanel=new FrameLayout(this);
        statusPanel.setBackgroundColor(Color.argb(22,40,55,95));
        statusScroll=new ScrollView(this);statusScroll.setFillViewport(true);
        if(Build.VERSION.SDK_INT>=21)statusScroll.setNestedScrollingEnabled(true);
        statusText=text("");statusText.setTextIsSelectable(true);statusText.setPadding(dp(10),dp(8),dp(48),dp(12));
        statusScroll.addView(statusText,new ScrollView.LayoutParams(-1,-2));
        statusScroll.setOnTouchListener((v,event)->{ViewParent parent=v.getParent();if(parent!=null)parent.requestDisallowInterceptTouchEvent(event.getAction()!=MotionEvent.ACTION_UP&&event.getAction()!=MotionEvent.ACTION_CANCEL);return false;});
        statusPanel.addView(statusScroll,new FrameLayout.LayoutParams(-1,-1));
        Button jumpTop=statusJumpButton("⇧","跳转到首条（最新）记录");
        Button jumpBottom=statusJumpButton("⇩","跳转到最后一条（最旧）记录");
        FrameLayout.LayoutParams topParams=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.TOP|Gravity.END);topParams.topMargin=dp(2);topParams.rightMargin=dp(2);
        FrameLayout.LayoutParams bottomParams=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.BOTTOM|Gravity.END);bottomParams.bottomMargin=dp(2);bottomParams.rightMargin=dp(2);
        statusPanel.addView(jumpTop,topParams);statusPanel.addView(jumpBottom,bottomParams);
        jumpTop.setOnClickListener(v->scrollStatusTop());jumpBottom.setOnClickListener(v->scrollStatusBottom());
        body.addView(statusPanel,new LinearLayout.LayoutParams(-1,dp(320)));setStatus("等待导入工程。");
        exportButton=button("导出已编译 APK");exportButton.setEnabled(false);exportButton.setOnClickListener(v->exportApk());body.addView(exportButton);
        return page;
    }

    private void showTopMenu(View anchor){
        PopupMenu m=new PopupMenu(this,anchor);
        m.getMenu().add("SDK / Linux 环境管理");
        m.getMenu().add("系统备份与恢复");
        m.getMenu().add("APK 签名证书管理");
        m.getMenu().add("应用图标管理");
        m.getMenu().add("导出 Bug 日志");
        m.getMenu().add("关于我们 / 版本信息");
        m.getMenu().add("使用说明");
        m.setOnMenuItemClickListener(item->{
            String t=item.getTitle().toString();
            if(t.startsWith("SDK"))showRuntimeManager();
            else if(t.startsWith("系统备份"))showBackupActions();
            else if(t.startsWith("APK 签名"))showSigningActions();
            else if(t.startsWith("应用图标"))showIconActions();
            else if(t.startsWith("导出 Bug"))exportBugLog();
            else if(t.startsWith("关于"))showAbout();
            else showHelp();
            return true;
        });
        m.show();
    }

    private void showRuntimeManager(){
        String message=runtime.status()+"\n\n可分别自动安装 Android 构建组件、JDK 17、JDK 21 和 PRoot Linux 兼容环境。所有已下载版本都会纳入‘导出全部组件程序包’与全量系统备份，导入恢复后自动选择原来的活动 JDK 并自检。";

        LinearLayout content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22),dp(8),dp(22),dp(16));

        TextView details=text(message);
        details.setTextIsSelectable(true);
        details.setPadding(0,0,0,dp(14));
        content.addView(details,new LinearLayout.LayoutParams(-1,-2));

        Button install=button("安装构建组件");
        Button installJdk17=button("自动安装 JDK 17");
        Button installJdk21=button("自动安装 JDK 21");
        Button more=button("更多操作");
        Button close=button("关闭");
        LinearLayout.LayoutParams buttonParams=new LinearLayout.LayoutParams(-1,dp(52));
        buttonParams.topMargin=dp(8);
        content.addView(install,buttonParams);
        LinearLayout.LayoutParams jdk17Params=new LinearLayout.LayoutParams(-1,dp(52));
        jdk17Params.topMargin=dp(8);
        content.addView(installJdk17,jdk17Params);
        LinearLayout.LayoutParams jdk21Params=new LinearLayout.LayoutParams(-1,dp(52));
        jdk21Params.topMargin=dp(8);
        content.addView(installJdk21,jdk21Params);
        LinearLayout.LayoutParams moreParams=new LinearLayout.LayoutParams(-1,dp(52));
        moreParams.topMargin=dp(8);
        content.addView(more,moreParams);
        LinearLayout.LayoutParams closeParams=new LinearLayout.LayoutParams(-1,dp(52));
        closeParams.topMargin=dp(8);
        content.addView(close,closeParams);

        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.addView(content,new ScrollView.LayoutParams(-1,-2));

        AlertDialog dialog=new AlertDialog.Builder(this)
                .setTitle("SDK / Linux 环境管理")
                .setView(scroll)
                .create();

        install.setOnClickListener(v->{dialog.dismiss();downloadRuntimeAutomatically();});
        installJdk17.setOnClickListener(v->{dialog.dismiss();requestJdkAction(17);});
        installJdk21.setOnClickListener(v->{dialog.dismiss();requestJdkAction(21);});
        more.setOnClickListener(v->{dialog.dismiss();showRuntimeActions();});
        close.setOnClickListener(v->dialog.dismiss());

        dialog.setOnShowListener(ignored->{
            Window window=dialog.getWindow();
            if(window!=null){
                int width=(int)(getResources().getDisplayMetrics().widthPixels*0.92f);
                int maxHeight=(int)(getResources().getDisplayMetrics().heightPixels*0.86f);
                window.setLayout(width,WindowManager.LayoutParams.WRAP_CONTENT);
                window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
                scroll.post(()->{
                    View decor=window.getDecorView();
                    if(decor.getHeight()>maxHeight)window.setLayout(width,maxHeight);
                });
            }
        });
        dialog.show();
    }

    private void downloadRuntimeAutomatically(){
        setBusy("正在自动搜索兼容工具链…");
        new Thread(()->{
            try{
                runtime.installAutomatically((m,d,t)->runOnUiThread(()->setProgressStatus(progress(m,d,t))));
                runOnUiThread(()->{setStatus(runtime.isBuildReady()?"✓ 本地 JDK/SDK/Build Tools 已安装并可用于编译":"✓ 组件已下载，但环境自检尚未通过。请进入更多操作运行环境自检。");refreshRuntime();setIdle();});
            }catch(Exception e){runOnUiThread(()->{setIdle();error("自动安装失败",e);setStatus("自动安装失败：\n"+safe(e.getMessage()));});}
        }).start();
    }

    private void showRuntimeActions(){String[] items={"安装 / 更新 Android 构建组件","安装或启用 JDK 17","安装或启用 JDK 21","自动安装 PRoot Linux 兼容环境","运行完整环境自检","导入全部工具链程序包","导出全部组件程序包","删除本地工具链","刷新环境状态"};new AlertDialog.Builder(this).setTitle("SDK / Linux 工具链操作").setItems(items,(d,w)->{if(w==0)downloadRuntimeAutomatically();else if(w==1)requestJdkAction(17);else if(w==2)requestJdkAction(21);else if(w==3)downloadProotAutomatically();else if(w==4)runRuntimeSelfTest();else if(w==5)pickRuntime();else if(w==6)exportRuntime();else if(w==7)confirmRemoveRuntime();else refreshRuntime();}).show();}

    private void requestJdkAction(int major){
        if(!runtime.isJdkInstalled(major)){downloadJdkAutomatically(major);return;}

        LinearLayout content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22),dp(8),dp(22),dp(16));

        TextView message=text("请选择下一步操作。仅启用不会重复下载；重新安装会保留其他 JDK 版本。");
        message.setPadding(0,0,0,dp(12));
        content.addView(message,new LinearLayout.LayoutParams(-1,-2));

        Button activate=button("仅启用 JDK "+major);
        Button reinstall=button("重新下载安装 JDK "+major);
        Button cancel=button("取消");
        LinearLayout.LayoutParams buttonParams=new LinearLayout.LayoutParams(-1,dp(54));
        buttonParams.topMargin=dp(8);
        content.addView(activate,buttonParams);
        LinearLayout.LayoutParams reinstallParams=new LinearLayout.LayoutParams(-1,dp(54));
        reinstallParams.topMargin=dp(8);
        content.addView(reinstall,reinstallParams);
        LinearLayout.LayoutParams cancelParams=new LinearLayout.LayoutParams(-1,dp(54));
        cancelParams.topMargin=dp(8);
        content.addView(cancel,cancelParams);

        AlertDialog dialog=new AlertDialog.Builder(this)
                .setTitle("JDK "+major+" 已安装")
                .setView(content)
                .create();

        activate.setOnClickListener(v->{dialog.dismiss();activateInstalledJdk(major);});
        reinstall.setOnClickListener(v->{dialog.dismiss();downloadJdkAutomatically(major);});
        cancel.setOnClickListener(v->dialog.dismiss());

        dialog.setOnShowListener(ignored->{
            Window window=dialog.getWindow();
            if(window!=null){
                int width=(int)(getResources().getDisplayMetrics().widthPixels*0.92f);
                window.setLayout(width,WindowManager.LayoutParams.WRAP_CONTENT);
            }
        });
        dialog.show();
    }

    private void activateInstalledJdk(int major){
        setBusy("正在启用 JDK "+major+"…");
        new Thread(()->{try{
            String result=runtime.activateJdk(major);
            runOnUiThread(()->{setIdle();refreshRuntime();setStatus("✓ 已切换到 JDK "+major+"\n\n"+result);});
        }catch(Exception e){runOnUiThread(()->{setIdle();refreshRuntime();error("JDK "+major+" 启用失败",e);});}}).start();
    }

    private void downloadJdkAutomatically(int major){
        setBusy("正在自动搜索并安装 JDK "+major+"…");
        new Thread(()->{try{
            String result=runtime.installJdkAutomatically(major,(m,d,t)->runOnUiThread(()->setProgressStatus(progress(m,d,t))));
            runOnUiThread(()->{setIdle();refreshRuntime();setStatus("✓ JDK "+major+" 已安装、设为当前版本并通过自检\n\n"+result);});
        }catch(Exception e){runOnUiThread(()->{setIdle();refreshRuntime();bugLog.log("ERROR","JDK "+major+" install failed: "+safe(e.getMessage()));error("JDK "+major+" 自动安装失败",e);});}}).start();
    }

    private void downloadProotAutomatically(){
        setBusy("正在自动搜索 PRoot 与 Linux rootfs…");
        new Thread(()->{try{runtime.installProotAutomatically((m,d,t)->runOnUiThread(()->setProgressStatus(progress(m,d,t))));runOnUiThread(()->{setIdle();refreshRuntime();setStatus("✓ PRoot Linux 兼容环境已安装并通过自检，可随全部组件一起导出。 ");});}catch(Exception e){runOnUiThread(()->{setIdle();refreshRuntime();bugLog.log("ERROR","PRoot install failed: "+safe(e.getMessage()));error("PRoot Linux 自动安装失败",e);});}}).start();
    }

    private void runRuntimeSelfTest(){setBusy("正在检查 Java、Android SDK 与 aapt2…");new Thread(()->{try{String result=runtime.selfTest();runOnUiThread(()->{setIdle();refreshRuntime();new AlertDialog.Builder(this).setTitle("环境自检通过").setMessage(result).setPositiveButton("确定",null).show();});}catch(Exception e){runOnUiThread(()->{setIdle();refreshRuntime();error("环境自检失败",e);});}}).start();}

    private void downloadRuntime(String url,String sha){setBusy("准备下载 Linux 工具链…");new Thread(()->{try{runtime.installFromUrl(url,sha,(m,d,t)->runOnUiThread(()->setProgressStatus(progress(m,d,t))));runOnUiThread(()->{setStatus("✓ Linux 工具链安装完成");refreshRuntime();setIdle();});}catch(Exception e){runOnUiThread(()->{setIdle();error("工具链安装失败",e);});}}).start();}
    private void pickRuntime(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");startActivityForResult(i,IMPORT_RUNTIME);}
    private void exportRuntime(){if(!runtime.isBuildReady()&&!runtime.isSdkComponentsInstalled()){Toast.makeText(this,"尚未安装工具链",Toast.LENGTH_LONG).show();return;}Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");i.putExtra(Intent.EXTRA_TITLE,"GradleApkBuilder-toolchain-all-components.gaptoolchain.zip");startActivityForResult(i,EXPORT_RUNTIME);}
    private void confirmRemoveRuntime(){new AlertDialog.Builder(this).setTitle("删除本地工具链？").setMessage("将删除 Linux rootfs、JDK、Gradle、Android SDK 和缓存。工程与已导出的 APK 不受影响。 ").setPositiveButton("删除",(d,w)->{try{runtime.remove();refreshRuntime();setStatus("本地工具链已删除。 ");}catch(Exception e){error("删除失败",e);}}).setNegativeButton("取消",null).show();}
    private void refreshRuntime(){runtimeText.setText(runtime.status()+"\nAPK 签名证书："+signingManager.status()+"\n编译前应用图标："+iconManager.status());updateBuildButtons();}

    private void showSigningActions(){
        String[] items={"随机生成签名证书","编辑当前签名证书配置","导入签名证书封包","从资源包提取签名材料","导出当前签名证书封包","查看签名证书状态","删除当前签名证书"};
        new AlertDialog.Builder(this).setTitle("APK 签名证书管理").setItems(items,(d,w)->{
            if(w==0)showGenerateSigningDialog(false);
            else if(w==1){if(signingManager.isConfigured())showSigningConfigurationEditor("编辑当前签名证书",null);else Toast.makeText(this,"尚未导入签名证书",Toast.LENGTH_LONG).show();}
            else if(w==2)pickSigningPackage();
            else if(w==3)pickSigningResource();
            else if(w==4)exportSigningPackage();
            else if(w==5)new AlertDialog.Builder(this).setTitle("签名证书状态").setMessage(signingManager.status()+"\n\n本地构建和云端下载完成后的 APK 会自动使用当前私钥证书重新签名。\n\n从 APK/AAB 提取出的公开证书不包含私钥，只能用于核对签名，不能用于签名 APK。").setPositiveButton("确定",null).show();
            else if(w==6)new AlertDialog.Builder(this).setTitle("删除签名证书？").setMessage("删除后新构建的 APK 将不再自动使用该证书签名。").setPositiveButton("删除",(x,y)->{signingManager.remove();refreshRuntime();}).setNegativeButton("取消",null).show();
        }).show();
    }

    private void showGenerateSigningDialog(boolean editCurrent){
        Properties current=editCurrent?signingManager.currentProperties():new Properties();
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(4),dp(20),0);
        EditText alias=input("别名",false),storePass=input("证书库密码（至少 6 位）",true),keyPass=input("私钥密码（可与证书库密码相同）",true);
        EditText cn=input("证书名称 CN",false),ou=input("组织单位 OU",false),org=input("组织 O",false),city=input("城市 L",false),state=input("省/州 ST",false),country=input("国家代码 C（如 CN）",false),validity=input("有效期天数",false);
        String random=randomPassword(18);alias.setText(current.getProperty("keyAlias","corykui"));storePass.setText(current.getProperty("storePassword",random));keyPass.setText(current.getProperty("keyPassword",storePass.getText().toString()));cn.setText(current.getProperty("commonName","CoryKui APKbuild"));ou.setText(current.getProperty("organizationUnit","Android Build"));org.setText(current.getProperty("organization","CoryKui"));city.setText(current.getProperty("locality","Unknown"));state.setText(current.getProperty("state","Unknown"));country.setText(current.getProperty("country","CN"));validity.setText(current.getProperty("validityDays","9125"));
        for(EditText v:new EditText[]{alias,storePass,keyPass,cn,ou,org,city,state,country,validity})box.addView(v);
        ScrollView scroll=new ScrollView(this);scroll.addView(box);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(editCurrent?"编辑并重新生成签名证书":"随机生成签名证书").setView(scroll).setPositiveButton("生成并启用",null).setNegativeButton("取消",null).create();
        dialog.setOnShowListener(ignored->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            SigningCertificateManager.GenerateOptions o=new SigningCertificateManager.GenerateOptions();o.alias=alias.getText().toString().trim();o.storePassword=storePass.getText().toString();o.keyPassword=keyPass.getText().toString();o.commonName=cn.getText().toString().trim();o.organizationUnit=ou.getText().toString().trim();o.organization=org.getText().toString().trim();o.locality=city.getText().toString().trim();o.state=state.getText().toString().trim();o.country=country.getText().toString().trim();try{o.validityDays=Integer.parseInt(validity.getText().toString().trim());}catch(Exception e){o.validityDays=9125;}
            dialog.dismiss();setBusy("正在生成随机签名证书…");new Thread(()->{try{signingManager.generateRandomCertificate(runtime,o,line->runOnUiThread(()->setProgressStatus(line)));runOnUiThread(()->{setIdle();refreshRuntime();new AlertDialog.Builder(this).setTitle("签名证书已生成").setMessage(signingManager.status()+"\n\n请立即通过‘导出当前签名证书封包’备份私钥。").setPositiveButton("确定",null).show();});}catch(Exception e){runOnUiThread(()->{setIdle();error("随机签名证书生成失败",e);});}}).start();
        }));dialog.show();
    }

    private static String randomPassword(int length){String chars="ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#_-";java.security.SecureRandom r=new java.security.SecureRandom();StringBuilder s=new StringBuilder();for(int i=0;i<length;i++)s.append(chars.charAt(r.nextInt(chars.length())));return s.toString();}

    private void showSigningConfigurationEditor(String title,Runnable afterClose){
        Properties current=signingManager.currentProperties();
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(20),dp(6),dp(20),dp(14));
        TextView note=text("可编辑证书库密码、私钥别名、私钥密码和证书资料。‘验证并保存’只在输入信息与现有私钥匹配时生效；修改证书主体需要选择‘按当前资料重新生成证书’。");
        content.addView(note);
        EditText alias=input("私钥别名",false),storePass=input("证书库密码",true),keyPass=input("私钥密码",true),type=input("证书库类型：JKS 或 PKCS12",false);
        EditText cn=input("证书名称 CN",false),ou=input("组织单位 OU",false),org=input("组织 O",false),city=input("城市 L",false),state=input("省/州 ST",false),country=input("国家代码 C",false),validity=input("有效期天数",false);
        alias.setText(current.getProperty("keyAlias",""));storePass.setText(current.getProperty("storePassword",""));keyPass.setText(current.getProperty("keyPassword",current.getProperty("storePassword","")));type.setText(current.getProperty("storeType",""));
        cn.setText(current.getProperty("commonName","CoryKui APKbuild"));ou.setText(current.getProperty("organizationUnit","Android Build"));org.setText(current.getProperty("organization","CoryKui"));city.setText(current.getProperty("locality","Unknown"));state.setText(current.getProperty("state","Unknown"));country.setText(current.getProperty("country","CN"));validity.setText(current.getProperty("validityDays","9125"));
        for(EditText field:new EditText[]{alias,storePass,keyPass,type,cn,ou,org,city,state,country,validity})content.addView(field,new LinearLayout.LayoutParams(-1,-2));
        Button save=button("验证并保存当前配置"),saveExport=button("验证、保存并导出到 Download"),regenerate=button("按当前资料重新生成证书并启用"),close=button("关闭");
        for(Button b:new Button[]{save,saveExport,regenerate,close}){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.topMargin=dp(8);content.addView(b,lp);}
        ScrollView scroll=new ScrollView(this);scroll.addView(content);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(title).setView(scroll).create();
        final boolean[] closed={false};
        Runnable closeCleanup=()->{if(!closed[0]){closed[0]=true;if(afterClose!=null)afterClose.run();}};
        close.setOnClickListener(v->{dialog.dismiss();closeCleanup.run();});
        dialog.setOnCancelListener(d->closeCleanup.run());
        save.setOnClickListener(v->{dialog.dismiss();saveEditedSigningConfiguration(editorProperties(alias,storePass,keyPass,type,cn,ou,org,city,state,country,validity),false,closeCleanup);});
        saveExport.setOnClickListener(v->{dialog.dismiss();saveEditedSigningConfiguration(editorProperties(alias,storePass,keyPass,type,cn,ou,org,city,state,country,validity),true,closeCleanup);});
        regenerate.setOnClickListener(v->{
            SigningCertificateManager.GenerateOptions options=editorGenerateOptions(alias,storePass,keyPass,cn,ou,org,city,state,country,validity);
            dialog.dismiss();closeCleanup.run();
            OperationProgressDialog pd=new OperationProgressDialog(this,"重新生成签名证书",true);pd.show();setBusy("正在按编辑资料重新生成签名证书…");
            new Thread(()->{try{signingManager.generateRandomCertificate(runtime,options,line->runOnUiThread(()->{pd.update(line,0,-1);setProgressStatus(line);}));runOnUiThread(()->{pd.dismiss();setIdle();refreshRuntime();setStatus("✓ 签名证书已按编辑资料重新生成并启用");});}catch(Exception e){runOnUiThread(()->{pd.dismiss();setIdle();error("重新生成签名证书失败",e);});}}).start();
        });
        dialog.setOnShowListener(ignored->{Window w=dialog.getWindow();if(w!=null)w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.94f),(int)(getResources().getDisplayMetrics().heightPixels*0.88f));});
        dialog.show();
    }

    private Properties editorProperties(EditText alias,EditText storePass,EditText keyPass,EditText type,EditText cn,EditText ou,EditText org,EditText city,EditText state,EditText country,EditText validity){
        Properties p=new Properties();p.setProperty("keyAlias",alias.getText().toString().trim());p.setProperty("storePassword",storePass.getText().toString());p.setProperty("keyPassword",keyPass.getText().toString());p.setProperty("storeType",type.getText().toString().trim());p.setProperty("commonName",cn.getText().toString().trim());p.setProperty("organizationUnit",ou.getText().toString().trim());p.setProperty("organization",org.getText().toString().trim());p.setProperty("locality",city.getText().toString().trim());p.setProperty("state",state.getText().toString().trim());p.setProperty("country",country.getText().toString().trim());p.setProperty("validityDays",validity.getText().toString().trim());return p;
    }

    private SigningCertificateManager.GenerateOptions editorGenerateOptions(EditText alias,EditText storePass,EditText keyPass,EditText cn,EditText ou,EditText org,EditText city,EditText state,EditText country,EditText validity){
        SigningCertificateManager.GenerateOptions o=new SigningCertificateManager.GenerateOptions();o.alias=alias.getText().toString().trim();o.storePassword=storePass.getText().toString();o.keyPassword=keyPass.getText().toString();o.commonName=cn.getText().toString().trim();o.organizationUnit=ou.getText().toString().trim();o.organization=org.getText().toString().trim();o.locality=city.getText().toString().trim();o.state=state.getText().toString().trim();o.country=country.getText().toString().trim();try{o.validityDays=Integer.parseInt(validity.getText().toString().trim());}catch(Exception e){o.validityDays=9125;}return o;
    }

    private void saveEditedSigningConfiguration(Properties edited,boolean exportToDownloads,Runnable cleanup){
        OperationProgressDialog pd=new OperationProgressDialog(this,exportToDownloads?"保存并导出签名证书":"保存签名证书配置",true);pd.show();setBusy("正在验证签名证书配置…");
        new Thread(()->{File temp=null;try{
            signingManager.updateCurrentConfiguration(edited,runtime);runOnUiThread(()->pd.updatePercent("配置验证通过",55,""));
            if(exportToDownloads){temp=File.createTempFile("corykui-signing-",".zip",getCacheDir());try(OutputStream out=new FileOutputStream(temp)){signingManager.exportPackage(out,new SigningCertificateManager.ExportProgress(){public void onProgress(String m,long d,long t){runOnUiThread(()->pd.update(m,d,t));}public boolean isCancelled(){return pd.isCancelled();}});}if(pd.isCancelled())throw new InterruptedIOException("用户已取消导出");saveFileToDownloads(temp,"CoryKui-APKbuild-signing-certificate.zip","application/zip");}
            File finalTemp=temp;runOnUiThread(()->{pd.dismiss();setIdle();refreshRuntime();setStatus(exportToDownloads?"✓ 签名配置已保存并导出到 Download/GradleApkBuilder":"✓ 签名配置已验证并保存");if(finalTemp!=null)finalTemp.delete();if(cleanup!=null)cleanup.run();});
        }catch(Exception e){File failed=temp;runOnUiThread(()->{pd.dismiss();setIdle();if(failed!=null)failed.delete();if(pd.isCancelled())Toast.makeText(this,"签名配置操作已取消",Toast.LENGTH_LONG).show();else error("签名配置保存失败",e);if(cleanup!=null)cleanup.run();});}}).start();
    }

    private void showIconActions(){
        String[] items={"从手机选择编译图标","从 APK / 资源包提取应用图标","保存当前编译图标到 Download","查看图标状态","清除编译前图标替换"};
        new AlertDialog.Builder(this).setTitle("应用图标管理").setItems(items,(d,w)->{if(w==0)pickCustomIcon();else if(w==1)pickIconResource();else if(w==2)saveCurrentIcon();else if(w==3)new AlertDialog.Builder(this).setTitle("应用图标状态").setMessage(iconManager.status()+"\n\n设置后，本地和云端构建前都会在临时工程中替换 application 图标，不修改原始工程 ZIP。").setPositiveButton("确定",null).show();else if(w==4){iconManager.remove();refreshRuntime();setStatus("已清除编译前应用图标替换。 ");}}).show();
    }

    private void pickCustomIcon(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");startActivityForResult(i,PICK_APP_ICON);}
    private void pickIconResource(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/vnd.android.package-archive","application/zip","application/octet-stream","image/png","image/jpeg","image/webp"});startActivityForResult(i,EXTRACT_APP_ICON);}
    private void importCustomIcon(Uri uri){setBusy("正在导入应用图标…");new Thread(()->{try(InputStream in=getContentResolver().openInputStream(uri)){iconManager.importImage(in);runOnUiThread(()->{setIdle();refreshRuntime();setStatus("✓ 已设置编译前应用图标替换");});}catch(Exception e){runOnUiThread(()->{setIdle();error("图标导入失败",e);});}}).start();}
    private void extractAppIcon(Uri uri){String name=displayName(uri);setBusy("正在从资源包提取应用图标…");new Thread(()->{try(InputStream in=getContentResolver().openInputStream(uri)){File icon=iconManager.extractIcon(in,name);runOnUiThread(()->showExtractedIconActions(icon));}catch(Exception e){runOnUiThread(()->{setIdle();error("应用图标提取失败",e);});}}).start();}
    private void showExtractedIconActions(File icon){setIdle();String[] actions={"设为编译图标并保存到 Download","仅设为编译图标","仅保存到 Download","取消"};new AlertDialog.Builder(this).setTitle("已提取应用图标").setMessage("已成功提取 PNG 图标，可用于后续编译替换或保存到手机。").setItems(actions,(d,w)->{try{if(w==0){iconManager.useExtracted(icon);saveFileToDownloads(icon,"CoryKui-extracted-app-icon.png","image/png");refreshRuntime();Toast.makeText(this,"已设置并保存到 Download/GradleApkBuilder",Toast.LENGTH_LONG).show();}else if(w==1){iconManager.useExtracted(icon);refreshRuntime();setStatus("✓ 已使用提取图标作为编译图标");}else if(w==2){saveFileToDownloads(icon,"CoryKui-extracted-app-icon.png","image/png");Toast.makeText(this,"已保存到 Download/GradleApkBuilder",Toast.LENGTH_LONG).show();}}catch(Exception e){error("图标处理失败",e);}finally{icon.delete();}}).show();}
    private void saveCurrentIcon(){File icon=iconManager.getCurrentIcon();if(icon==null){Toast.makeText(this,"尚未设置编译图标",Toast.LENGTH_LONG).show();return;}setBusy("正在保存应用图标…");new Thread(()->{try{saveFileToDownloads(icon,"CoryKui-APKbuild-icon.png","image/png");runOnUiThread(()->{setIdle();Toast.makeText(this,"已保存到 Download/GradleApkBuilder",Toast.LENGTH_LONG).show();});}catch(Exception e){runOnUiThread(()->{setIdle();error("保存应用图标失败",e);});}}).start();}

    private void pickSigningResource(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/zip","application/vnd.android.package-archive","application/java-archive","application/octet-stream"});
        startActivityForResult(i,EXTRACT_SIGNING_RESOURCE);
    }

    private void inspectSigningResource(Uri uri){
        String name=displayName(uri);long total=contentLength(uri);
        OperationProgressDialog pd=new OperationProgressDialog(this,"提取签名材料",true);pd.show();setBusy("正在扫描资源包中的签名材料…");
        new Thread(()->{try(InputStream in=getContentResolver().openInputStream(uri)){
            SigningResourceExtractor.Result result=SigningResourceExtractor.inspect(this,in,name,runtime,new SigningResourceExtractor.Progress(){
                public void onProgress(String m,long d,long t){runOnUiThread(()->{long effective=t>0?t:total;pd.update(m,d,effective);setProgressStatus(progress(m,d,effective));});}
                public boolean isCancelled(){return pd.isCancelled();}
            });
            pendingSigningExtraction=result;
            runOnUiThread(()->{pd.dismiss();setIdle();showSigningExtractionResult(result);});
        }catch(Exception e){runOnUiThread(()->{pd.dismiss();setIdle();if(pd.isCancelled())Toast.makeText(this,"签名材料提取已取消",Toast.LENGTH_LONG).show();else error("签名材料提取失败",e);});}}).start();
    }

    private void showSigningExtractionResult(SigningResourceExtractor.Result result){
        if(result==null)return;
        if(result.hasPrivatePackage()){
            String[] actions={"立即导入并编辑","直接导入并保存到 Download","仅导入到本应用","仅保存提取证书包到 Download","取消"};
            new AlertDialog.Builder(this).setTitle("已提取完整签名证书包").setMessage(result.summary()+"\n\n选择‘立即导入并编辑’后，会先导入可识别的密码、别名、类型和证书资料，再自动进入编辑界面。")
                    .setItems(actions,(d,w)->{if(w==0)importExtractedPrivatePackage(result,false,true);else if(w==1)importExtractedPrivatePackage(result,true,false);else if(w==2)importExtractedPrivatePackage(result,false,false);else if(w==3)saveExtractedFile(result.privatePackage,"GradleApkBuilder-extracted-signing-package.zip","application/zip",result);else result.cleanup();}).show();
            return;
        }
        if(result.hasRawKeyStore()){
            showRawKeystoreCredentials(result,result.rawKeyStores.get(0));return;
        }
        if(result.hasPublicCertificates()){
            new AlertDialog.Builder(this).setTitle("已提取公开签名证书")
                    .setMessage(result.summary()+"\n\n公开证书不包含私钥，不能直接导入为 APK 签名密钥；可以保存到 Download 用于核对证书指纹或 API 平台登记。")
                    .setPositiveButton("保存到 Download",(d,w)->saveExtractedFile(result.publicCertificateBundle,"GradleApkBuilder-public-signing-certificates.zip","application/zip",result))
                    .setNegativeButton("关闭",(d,w)->result.cleanup()).show();return;
        }
        new AlertDialog.Builder(this).setTitle("未发现签名材料").setMessage(result.summary()).setPositiveButton("确定",(d,w)->result.cleanup()).show();
    }

    private void showRawKeystoreCredentials(SigningResourceExtractor.Result result,File keyStore){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(6),dp(20),dp(14));
        TextView note=text("输入资源包中 keystore 的有效信息。导入后可立即进入编辑界面，继续保存、重新生成或导出。");box.addView(note);
        EditText storePass=input("证书库密码",true),alias=input("私钥别名",false),keyPass=input("私钥密码（留空则与证书库密码相同）",true),type=input("类型：JKS 或 PKCS12（可留空自动识别）",false);
        box.addView(storePass);box.addView(alias);box.addView(keyPass);box.addView(type);
        Button importEdit=button("立即导入并编辑"),importSave=button("导入并保存到 Download"),onlyImport=button("仅导入"),cancel=button("取消");
        for(Button b:new Button[]{importEdit,importSave,onlyImport,cancel}){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.topMargin=dp(8);box.addView(b,lp);}
        ScrollView scroll=new ScrollView(this);scroll.addView(box);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("导入提取出的 keystore\n"+keyStore.getName()).setView(scroll).create();
        importEdit.setOnClickListener(v->importRawKeystore(result,keyStore,storePass.getText().toString(),alias.getText().toString(),keyPass.getText().toString(),type.getText().toString(),false,true,dialog));
        importSave.setOnClickListener(v->importRawKeystore(result,keyStore,storePass.getText().toString(),alias.getText().toString(),keyPass.getText().toString(),type.getText().toString(),true,false,dialog));
        onlyImport.setOnClickListener(v->importRawKeystore(result,keyStore,storePass.getText().toString(),alias.getText().toString(),keyPass.getText().toString(),type.getText().toString(),false,false,dialog));
        cancel.setOnClickListener(v->{dialog.dismiss();result.cleanup();});
        dialog.setOnCancelListener(d->result.cleanup());
        dialog.show();
    }

    private void importRawKeystore(SigningResourceExtractor.Result result,File keyStore,String storePassword,String alias,String keyPassword,String type,boolean save,boolean editAfter,AlertDialog dialog){
        if(storePassword.isEmpty()||alias.trim().isEmpty()){Toast.makeText(this,"请输入证书库密码和私钥别名",Toast.LENGTH_LONG).show();return;}
        dialog.dismiss();setBusy("正在验证并导入提取出的 keystore…");
        new Thread(()->{try{File portable=new File(result.workDir,"normalized-extracted-signing.zip");SigningResourceExtractor.createPortablePackage(portable,keyStore,storePassword,alias,keyPassword,type);try(InputStream in=new FileInputStream(portable)){signingManager.importPackage(in,runtime);}if(save)saveFileToDownloads(portable,"GradleApkBuilder-extracted-signing-package.zip","application/zip");runOnUiThread(()->{setIdle();refreshRuntime();if(editAfter){result.cleanup();showSigningConfigurationEditor("编辑刚导入的签名证书",null);}else{new AlertDialog.Builder(this).setTitle("签名证书导入成功").setMessage(signingManager.status()+(save?"\n\n已同时保存到 Download/GradleApkBuilder。":"")).setPositiveButton("确定",null).show();result.cleanup();}});}catch(Exception e){runOnUiThread(()->{setIdle();error("提取证书导入失败",e);result.cleanup();});}}).start();
    }

    private void importExtractedPrivatePackage(SigningResourceExtractor.Result result,boolean save,boolean editAfter){
        setBusy("正在导入提取出的签名证书包…");
        new Thread(()->{try(InputStream in=new FileInputStream(result.privatePackage)){signingManager.importPackage(in,runtime);if(save)saveFileToDownloads(result.privatePackage,"GradleApkBuilder-extracted-signing-package.zip","application/zip");runOnUiThread(()->{setIdle();refreshRuntime();result.cleanup();if(editAfter)showSigningConfigurationEditor("编辑刚导入的签名证书",null);else new AlertDialog.Builder(this).setTitle("签名证书导入成功").setMessage(signingManager.status()+(save?"\n\n已同时保存到 Download/GradleApkBuilder。":"")).setPositiveButton("确定",null).show();});}catch(Exception e){runOnUiThread(()->{setIdle();error("签名证书导入失败",e);result.cleanup();});}}).start();
    }

    private void saveExtractedFile(File file,String name,String mime,SigningResourceExtractor.Result result){
        setBusy("正在保存提取文件到 Download…");new Thread(()->{try{saveFileToDownloads(file,name,mime);runOnUiThread(()->{setIdle();Toast.makeText(this,"已保存到 Download/GradleApkBuilder/"+name,Toast.LENGTH_LONG).show();});}catch(Exception e){runOnUiThread(()->{setIdle();error("保存到 Download 失败",e);});}finally{result.cleanup();}}).start();
    }

    private Uri saveFileToDownloads(File source,String name,String mime)throws Exception{
        if(source==null||!source.isFile())throw new IOException("待保存文件不存在");
        if(Build.VERSION.SDK_INT>=29){
            ContentValues values=new ContentValues();values.put(MediaStore.MediaColumns.DISPLAY_NAME,name);values.put(MediaStore.MediaColumns.MIME_TYPE,mime);values.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/GradleApkBuilder");values.put(MediaStore.MediaColumns.IS_PENDING,1);
            Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new IOException("无法在 Download 创建文件");
            try(OutputStream out=getContentResolver().openOutputStream(uri);InputStream in=new BufferedInputStream(new FileInputStream(source))){copy(in,out);}catch(Exception e){getContentResolver().delete(uri,null,null);throw e;}
            ContentValues done=new ContentValues();done.put(MediaStore.MediaColumns.IS_PENDING,0);getContentResolver().update(uri,done,null,null);return uri;
        }
        File downloads=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);File folder=new File(downloads,"GradleApkBuilder");if(!folder.exists()&&!folder.mkdirs())throw new IOException("无法创建 Download/GradleApkBuilder");File target=new File(folder,name);try(InputStream in=new FileInputStream(source);OutputStream out=new FileOutputStream(target)){copy(in,out);}return Uri.fromFile(target);
    }

    private void pickSigningPackage(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/zip","application/octet-stream"});startActivityForResult(i,IMPORT_SIGNING);}
    private void exportSigningPackage(){if(!signingManager.isConfigured()){Toast.makeText(this,"尚未导入签名证书包",Toast.LENGTH_LONG).show();return;}Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");i.putExtra(Intent.EXTRA_TITLE,"GradleApkBuilder-signing-certificate.zip");startActivityForResult(i,EXPORT_SIGNING);}
    private void importSigningPackage(Uri uri){setBusy("正在导入签名证书包…");new Thread(()->{try(InputStream in=getContentResolver().openInputStream(uri)){signingManager.importPackage(in,runtime);runOnUiThread(()->{setIdle();refreshRuntime();new AlertDialog.Builder(this).setTitle("签名证书导入成功").setMessage(signingManager.status()+"\n\n后续本地构建和云端下载的 APK 会自动使用该证书签名。").setPositiveButton("立即编辑",(d,w)->showSigningConfigurationEditor("编辑刚导入的签名证书",null)).setNegativeButton("完成",null).show();});}catch(Exception e){runOnUiThread(()->{setIdle();error("签名证书导入失败",e);});}}).start();}
    private void writeSigningPackage(Uri uri){
        OperationProgressDialog pd=new OperationProgressDialog(this,"导出签名证书包",true);pd.show();setBusy("正在导出签名证书包…");
        new Thread(()->{try(OutputStream out=getContentResolver().openOutputStream(uri)){
            signingManager.exportPackage(out,new SigningCertificateManager.ExportProgress(){
                public void onProgress(String m,long d,long t){runOnUiThread(()->{pd.update(m,d,t);setProgressStatus(progress(m,d,t));});}
                public boolean isCancelled(){return pd.isCancelled();}
            });
            runOnUiThread(()->{pd.dismiss();setIdle();Toast.makeText(this,"签名证书包已导出，请严格保管私钥和密码",Toast.LENGTH_LONG).show();});
        }catch(Exception e){runOnUiThread(()->{pd.dismiss();setIdle();if(pd.isCancelled()){deleteDocumentQuietly(uri);Toast.makeText(this,"签名证书导出已取消",Toast.LENGTH_LONG).show();}else error("签名证书导出失败",e);});}}).start();
    }

    private void pickProject(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/zip","application/octet-stream"});startActivityForResult(i,PICK_PROJECT);}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();if(request==PICK_PROJECT)importProject(uri);else if(request==EXPORT_APK)writeExport(uri);else if(request==IMPORT_RUNTIME)importRuntime(uri);
        else if(request==EXPORT_RUNTIME)writeRuntimeExport(uri);
        else if(request==EXPORT_SYSTEM_BACKUP)writeSystemBackup(uri);
        else if(request==IMPORT_SYSTEM_BACKUP)importSystemBackup(uri);
        else if(request==EXPORT_BUG_LOG)writeBugLog(uri);
        else if(request==IMPORT_SIGNING)importSigningPackage(uri);
        else if(request==EXPORT_SIGNING)writeSigningPackage(uri);
        else if(request==EXTRACT_SIGNING_RESOURCE)inspectSigningResource(uri);
        else if(request==EXPORT_SETTINGS)writeSettingsBackup(uri);
        else if(request==IMPORT_SETTINGS)importSettingsBackup(uri);
        else if(request==PICK_APP_ICON)importCustomIcon(uri);
        else if(request==EXTRACT_APP_ICON)extractAppIcon(uri);
    }

    private void importProject(Uri uri){
        String name=displayName(uri);long total=contentLength(uri);OperationProgressDialog pd=new OperationProgressDialog(this,"正在导入工程",true);pd.show();setBusy("正在导入工程…");
        new Thread(()->{File target=new File(getCacheDir(),"imported-project.zip");try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(target)){byte[] b=new byte[65536];long done=0;int n;while((n=in.read(b))>=0){if(pd.isCancelled())throw new IOException("用户已取消导入");out.write(b,0,n);done+=n;long d=done;runOnUiThread(()->pd.update("正在复制工程 ZIP…",d,total));}runOnUiThread(()->pd.updatePercent("正在检查 Gradle 工程结构…",95,name));ProjectInspector.Result r=ProjectInspector.inspect(target);runOnUiThread(()->{pd.updatePercent("导入完成",100,name);pd.dismiss();projectZip=r.valid?target:null;projectText.setText("文件："+(name==null?"project.zip":name)+"\n大小："+human(target.length())+"\n\n"+r.summary());setStatus(r.valid?"工程检查通过，可选择本地或云端构建。":"工程检查未通过。 ");setIdle();updateBuildButtons();});}catch(Exception e){target.delete();runOnUiThread(()->{pd.dismiss();setIdle();error("导入失败",e);});}}).start();
    }
    private void importRuntime(Uri uri){long total=contentLength(uri);OperationProgressDialog pd=new OperationProgressDialog(this,"导入工具链程序包",false);pd.show();setBusy("正在导入 SDK 工具链…");new Thread(()->{try(InputStream in=getContentResolver().openInputStream(uri)){runtime.importBundle(in,(m,d,t)->runOnUiThread(()->{pd.update(m,d,t>0?t:total);setProgressStatus(progress(m,d,t));}));runOnUiThread(()->{pd.updatePercent("安装完成，环境自检通过",100,"");pd.dismiss();setIdle();refreshRuntime();setStatus("✓ 工具链程序包已安装，权限已恢复，环境自检通过");});}catch(Exception e){runOnUiThread(()->{pd.dismiss();setIdle();error("工具链导入失败",e);});}}).start();}
    private void writeRuntimeExport(Uri uri){
        OperationProgressDialog pd=new OperationProgressDialog(this,"导出全部工具链组件",true);pd.show();setBusy("正在导出 SDK 工具链…");
        new Thread(()->{try(OutputStream out=getContentResolver().openOutputStream(uri)){
            runtime.exportBundle(out,new RuntimeBundleManager.Progress(){
                public void onProgress(String m,long d,long t){runOnUiThread(()->{pd.update(m,d,t);setProgressStatus(progress(m,d,t));});}
                public boolean isCancelled(){return pd.isCancelled();}
            });
            runOnUiThread(()->{pd.dismiss();setIdle();setStatus("✓ 已下载的全部环境组件和程序已导出");});
        }catch(Exception e){runOnUiThread(()->{pd.dismiss();setIdle();if(pd.isCancelled()){deleteDocumentQuietly(uri);Toast.makeText(this,"工具链导出已取消",Toast.LENGTH_LONG).show();}else error("工具链导出失败",e);});}}).start();
    }

    private void startLocalBuild(){
        if(projectZip==null)return;
        saveCloudInputsSilently();builtApk=null;
        OperationProgressDialog pd=new OperationProgressDialog(this,"手机本地构建",true);
        setBusy("启动手机本地 Gradle 构建…");
        activeLocalBuild=new LocalBuildEngine(runtime,line->{bugLog.log("BUILD",line);runOnUiThread(()->{updateBuildProgress(pd,line);if(isTransientBuildStatus(line))setProgressStatus(line);else setStatus(line);if(pd.isCancelled()&&activeLocalBuild!=null)activeLocalBuild.cancel();});});
        pd.setOnCancelRequested(()->{LocalBuildEngine engine=activeLocalBuild;if(engine!=null)engine.cancel();});pd.show();pd.update("正在准备工程…",0,-1);
        new Thread(()->{try{
            if(pd.isCancelled())throw new InterruptedIOException("用户已取消本地构建");
            File buildZip=iconManager.prepareProjectZip(projectZip,new AppIconManager.Progress(){public void onProgress(String m,long d,long t){runOnUiThread(()->{pd.update(m,d,t);setProgressStatus(progress(m,d,t));});}public boolean isCancelled(){return pd.isCancelled();}});
            if(pd.isCancelled())throw new InterruptedIOException("用户已取消本地构建");
            File apk=activeLocalBuild.build(buildZip,new File(getFilesDir(),"local-builds"),taskInput.getText().toString());
            if(pd.isCancelled())throw new InterruptedIOException("用户已取消本地构建");
            File finalApk=signingManager.signIfConfigured(apk,runtime,line->{bugLog.log("SIGN",line);runOnUiThread(()->{pd.update(line,0,-1);setStatus(line);});});
            if(pd.isCancelled())throw new InterruptedIOException("用户已取消本地构建");
            builtApk=finalApk;
            runOnUiThread(()->{pd.updatePercent("本地构建完成",100,finalApk.getName());pd.dismiss();refreshRuntime();setStatus("✓ 本地构建成功："+finalApk.getName()+(signingManager.isConfigured()?"\n✓ 已使用导入证书签名":"")+"\n✓ Gradle/Maven 离线依赖："+runtime.gradleDependencyCacheSummary());setIdle();exportButton.setEnabled(true);});
        }catch(Exception e){runOnUiThread(()->{pd.dismiss();setIdle();if(pd.isCancelled()||e instanceof InterruptedIOException){setStatus("本地构建已取消");Toast.makeText(this,"本地构建已取消",Toast.LENGTH_LONG).show();}else{bugLog.log("ERROR","Local build failed: "+safe(e.getMessage()));error("本地构建失败",e);setStatus("构建失败："+safe(e.getMessage()));}});}finally{activeLocalBuild=null;}}).start();
    }

    private void startCloudBuild(){
        if(projectZip==null)return;
        String owner=ownerInput.getText().toString().trim(),repo=repoInput.getText().toString().trim(),branch=branchInput.getText().toString().trim(),token=tokenInput.getText().toString().trim();
        if(owner.isEmpty()||repo.isEmpty()||token.isEmpty()){Toast.makeText(this,"请填写 GitHub 用户名、仓库和令牌",Toast.LENGTH_LONG).show();return;}
        try{secureSettings.saveCloud(owner,repo,branch,taskInput.getText().toString().trim(),token);}catch(Exception saveError){error("云端配置保存失败",saveError);return;}
        setBusy("准备云端构建…");builtApk=null;
        OperationProgressDialog pd=new OperationProgressDialog(this,"GitHub Actions 云端构建",true);
        activeGitHubBuild=new GitHubBuilder(token,owner,repo,branch,s->{runOnUiThread(()->{updateBuildProgress(pd,s);setProgressStatus(s+"\n可锁屏或切换应用，任务会保持网络并自动重试。 ");});});
        pd.setOnCancelRequested(()->{GitHubBuilder builder=activeGitHubBuild;if(builder!=null)builder.cancel();});pd.show();pd.update("正在准备云端构建…",0,-1);
        final PowerManager.WakeLock wake=((PowerManager)getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"GradleApkBuilder:cloud");
        final WifiManager.WifiLock wifi=((WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE)).createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF,"GradleApkBuilder:cloudWifi");
        try{wake.acquire(60*60*1000L);wifi.acquire();}catch(Exception ignored){}
        new Thread(()->{try{
            File buildZip=iconManager.prepareProjectZip(projectZip,new AppIconManager.Progress(){public void onProgress(String m,long d,long t){runOnUiThread(()->{pd.update(m,d,t);setProgressStatus(progress(m,d,t));});}public boolean isCancelled(){return pd.isCancelled();}});
            if(pd.isCancelled())throw new InterruptedIOException("用户已取消云端构建");
            File apk=activeGitHubBuild.build(buildZip,new File(getFilesDir(),"outputs"));
            if(pd.isCancelled())throw new InterruptedIOException("用户已取消云端构建");
            File finalApk=signingManager.signIfConfigured(apk,runtime,line->{bugLog.log("SIGN",line);runOnUiThread(()->{pd.update(line,0,-1);setStatus("云端构建完成，正在本机签名…\n"+line);});});
            if(pd.isCancelled())throw new InterruptedIOException("用户已取消云端构建");
            builtApk=finalApk;runOnUiThread(()->{pd.updatePercent("云端构建完成",100,finalApk.getName());pd.dismiss();setStatus("✓ 云端构建成功\n"+finalApk.getName()+"\n"+human(finalApk.length())+(signingManager.isConfigured()?"\n✓ 已使用导入证书签名":""));setIdle();exportButton.setEnabled(true);});
        }catch(Exception e){runOnUiThread(()->{pd.dismiss();setIdle();if(pd.isCancelled()||e instanceof InterruptedIOException){setStatus("云端构建等待已取消；GitHub 上已经触发的任务可能仍会继续运行。 ");Toast.makeText(this,"已停止等待云端构建",Toast.LENGTH_LONG).show();}else{error("云端构建失败",e);setStatus("构建失败：\n"+safe(e.getMessage()));}});}finally{activeGitHubBuild=null;try{if(wifi.isHeld())wifi.release();}catch(Exception ignored){}try{if(wake.isHeld())wake.release();}catch(Exception ignored){}}}).start();
    }

    private void exportApk(){if(builtApk==null||!builtApk.exists())return;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/vnd.android.package-archive");i.putExtra(Intent.EXTRA_TITLE,builtApk.getName());startActivityForResult(i,EXPORT_APK);}
    private void writeExport(Uri uri){
        if(builtApk==null||!builtApk.isFile())return;
        OperationProgressDialog pd=new OperationProgressDialog(this,"导出 APK",true);pd.show();setBusy("正在导出 APK…");long total=builtApk.length();
        new Thread(()->{try(InputStream in=new BufferedInputStream(new FileInputStream(builtApk));OutputStream out=new BufferedOutputStream(getContentResolver().openOutputStream(uri))){
            byte[] buffer=new byte[65536];long done=0;int count;while((count=in.read(buffer))>=0){if(pd.isCancelled())throw new InterruptedIOException("用户已取消导出");out.write(buffer,0,count);done+=count;long current=done;runOnUiThread(()->{pd.update("正在导出 APK…",current,total);setProgressStatus(progress("正在导出 APK…",current,total));});}out.flush();
            runOnUiThread(()->{pd.dismiss();setIdle();Toast.makeText(this,"APK 已导出",Toast.LENGTH_LONG).show();});
        }catch(Exception e){runOnUiThread(()->{pd.dismiss();setIdle();if(pd.isCancelled()){deleteDocumentQuietly(uri);Toast.makeText(this,"APK 导出已取消",Toast.LENGTH_LONG).show();}else error("导出失败",e);});}}).start();
    }


    private void restoreSavedCloudSettings(){
        SecureSettings.Cloud c=secureSettings.loadCloud();
        ownerInput.setText(c.owner);repoInput.setText(c.repo);branchInput.setText(c.branch);taskInput.setText(c.task);tokenInput.setText(c.token);
    }

    private void attachCloudAutoSave(){
        TextWatcher watcher=new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){settingsHandler.removeCallbacks(saveCloudRunnable);settingsHandler.postDelayed(saveCloudRunnable,700);}public void afterTextChanged(Editable e){}};
        ownerInput.addTextChangedListener(watcher);repoInput.addTextChangedListener(watcher);branchInput.addTextChangedListener(watcher);taskInput.addTextChangedListener(watcher);tokenInput.addTextChangedListener(watcher);
    }

    private void saveCloudInputsSilently(){
        if(ownerInput==null||repoInput==null||branchInput==null||taskInput==null||tokenInput==null)return;
        try{secureSettings.saveCloud(ownerInput.getText().toString().trim(),repoInput.getText().toString().trim(),branchInput.getText().toString().trim(),taskInput.getText().toString().trim(),tokenInput.getText().toString().trim());}
        catch(Exception e){if(bugLog!=null)bugLog.log("ERROR","Cloud settings save failed: "+safe(e.getMessage()));}
    }

    @Override protected void onResume(){
        super.onResume();
        if(runtime!=null&&runtimeText!=null)refreshRuntime();
    }
    @Override protected void onPause(){saveCloudInputsSilently();super.onPause();}
    @Override protected void onStop(){saveCloudInputsSilently();super.onStop();}

    private void restoreCurrentProjectReference(){
        File saved=new File(getCacheDir(),"imported-project.zip");
        if(saved.isFile()){
            try{ProjectInspector.Result r=ProjectInspector.inspect(saved);if(r.valid){projectZip=saved;projectText.setText("已从上次会话恢复导入工程。\n大小："+human(saved.length())+"\n\n"+r.summary());setStatus("已恢复上次工程，可继续构建。 ");updateBuildButtons();}}catch(Exception ignored){}
        }
    }

    private void showBackupActions(){
        String[] items={"创建全量系统备份","从全量系统备份恢复","仅导出系统设置","仅导入系统设置","备份内容说明"};
        new AlertDialog.Builder(this).setTitle("系统备份与恢复").setItems(items,(d,w)->{
            if(w==0)askBackupPassword(false);
            else if(w==1)askBackupPassword(true);
            else if(w==2)askSettingsPassword(false);
            else if(w==3)askSettingsPassword(true);
            else showBackupHelp();
        }).show();
    }

    private void askBackupPassword(boolean restoring){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(8),dp(20),0);
        EditText first=input(restoring?"输入备份密码":"设置备份密码（至少 6 位）",true);box.addView(first);
        EditText second=null;if(!restoring){second=input("再次输入备份密码",true);box.addView(second);}final EditText confirm=second;
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(restoring?"恢复全量系统备份":"创建全量系统备份").setView(box).setPositiveButton(restoring?"选择备份文件":"选择保存位置",null).setNegativeButton("取消",null).create();
        dialog.setOnShowListener(x->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String p=first.getText().toString();if(p.length()<6){Toast.makeText(this,"备份密码至少需要 6 位",Toast.LENGTH_LONG).show();return;}if(confirm!=null&&!p.equals(confirm.getText().toString())){Toast.makeText(this,"两次输入的密码不一致",Toast.LENGTH_LONG).show();return;}pendingBackupPassword=p.toCharArray();dialog.dismiss();if(restoring)pickSystemBackup();else exportSystemBackup();}));dialog.show();
    }

    private void exportSystemBackup(){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_TITLE,"GradleApkBuilder-full-system-backup.gapbackup");startActivityForResult(i,EXPORT_SYSTEM_BACKUP);
    }
    private void pickSystemBackup(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,IMPORT_SYSTEM_BACKUP);}

    private void writeSystemBackup(Uri uri){
        char[] password=pendingBackupPassword;pendingBackupPassword=null;if(password==null)return;
        OperationProgressDialog pd=new OperationProgressDialog(this,"创建全量系统备份",true);pd.show();setBusy("正在创建全量系统备份…");bugLog.log("INFO","Full system backup started");
        new Thread(()->{try(OutputStream out=getContentResolver().openOutputStream(uri)){
            backupManager.exportAll(out,password,new SystemBackupManager.ExportProgress(){
                public void onProgress(String message,long done,long total){runOnUiThread(()->{pd.update(message,done,total);setProgressStatus(progress(message,done,total));});}
                public boolean isCancelled(){return pd.isCancelled();}
            });
            bugLog.log("INFO","Full system backup completed");
            runOnUiThread(()->{pd.updatePercent("备份完成",100,displayName(uri));pd.dismiss();setIdle();setStatus("✓ 全量系统备份已导出");});
        }catch(Throwable failure){Exception e=failure instanceof Exception?(Exception)failure:new IOException("系统备份被终止："+failure,failure);bugLog.log("ERROR","Full system backup failed: "+safe(e.getMessage()));runOnUiThread(()->{pd.dismiss();setIdle();if(pd.isCancelled()){deleteDocumentQuietly(uri);Toast.makeText(this,"系统备份已取消",Toast.LENGTH_LONG).show();}else error("系统备份失败",e);});}}).start();
    }

    private void importSystemBackup(Uri uri){
        char[] password=pendingBackupPassword;pendingBackupPassword=null;if(password==null)return;long total=contentLength(uri);
        OperationProgressDialog pd=new OperationProgressDialog(this,"恢复全量系统备份",true);pd.show();setBusy("正在流式恢复全量系统备份…");bugLog.log("INFO","Full system restore started");
        new Thread(()->{try(InputStream in=getContentResolver().openInputStream(uri)){
            backupManager.importAll(in,password,total,new SystemBackupManager.ExportProgress(){
                public void onProgress(String m,long d,long t){runOnUiThread(()->{pd.update(m,d,t);setProgressStatus(progress(m,d,t));});}
                public boolean isCancelled(){return pd.isCancelled();}
            });
            String test;try{test=runtime.selfTest();}catch(Exception e){test="恢复完成，但环境自检提示：\n"+safe(e.getMessage());}String result=test;
            bugLog.log("INFO","Full system restore completed");
            runOnUiThread(()->{pd.updatePercent("恢复完成",100,"");pd.dismiss();restoreSavedCloudSettings();restoreCurrentProjectReference();refreshRuntime();setIdle();setStatus("✓ 全量系统备份恢复完成");new AlertDialog.Builder(this).setTitle("系统恢复完成").setMessage(result+"\n\n已采用流式解密和逐目录覆盖。建议重新打开应用，使所有缓存完全生效。").setPositiveButton("确定",null).show();});
        }catch(Exception e){bugLog.log("ERROR","Full system restore failed: "+safe(e.getMessage()));runOnUiThread(()->{pd.dismiss();setIdle();if(pd.isCancelled())Toast.makeText(this,"全量恢复已取消",Toast.LENGTH_LONG).show();else error("系统恢复失败",e);});}}).start();
    }

    private void askSettingsPassword(boolean restoring){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(8),dp(20),0);
        EditText first=input(restoring?"输入系统设置备份密码":"设置导出密码（至少 6 位）",true);box.addView(first);
        EditText second=null;if(!restoring){second=input("再次输入密码",true);box.addView(second);}final EditText confirm=second;
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(restoring?"仅导入系统设置":"仅导出系统设置").setView(box).setPositiveButton(restoring?"选择设置文件":"选择保存位置",null).setNegativeButton("取消",null).create();
        dialog.setOnShowListener(x->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String value=first.getText().toString();if(value.length()<6){Toast.makeText(this,"密码至少需要 6 位",Toast.LENGTH_LONG).show();return;}if(confirm!=null&&!value.equals(confirm.getText().toString())){Toast.makeText(this,"两次输入的密码不一致",Toast.LENGTH_LONG).show();return;}pendingSettingsPassword=value.toCharArray();dialog.dismiss();if(restoring)pickSettingsBackup();else exportSettingsBackup();}));dialog.show();
    }
    private void exportSettingsBackup(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_TITLE,"GradleApkBuilder-system-settings.gapsettings");startActivityForResult(i,EXPORT_SETTINGS);}
    private void pickSettingsBackup(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,IMPORT_SETTINGS);}
    private void writeSettingsBackup(Uri uri){
        char[] password=pendingSettingsPassword;pendingSettingsPassword=null;if(password==null)return;
        OperationProgressDialog pd=new OperationProgressDialog(this,"仅导出系统设置",true);pd.show();setBusy("正在导出系统设置…");
        new Thread(()->{try(OutputStream out=getContentResolver().openOutputStream(uri)){
            backupManager.exportSettings(out,password,new SystemBackupManager.ExportProgress(){public void onProgress(String m,long d,long t){runOnUiThread(()->{pd.update(m,d,t);setProgressStatus(progress(m,d,t));});}public boolean isCancelled(){return pd.isCancelled();}});
            runOnUiThread(()->{pd.dismiss();setIdle();setStatus("✓ 系统设置已导出；现有工具链、工程和全量文件未改变");});
        }catch(Exception e){runOnUiThread(()->{pd.dismiss();setIdle();if(pd.isCancelled()){deleteDocumentQuietly(uri);Toast.makeText(this,"系统设置导出已取消",Toast.LENGTH_LONG).show();}else error("系统设置导出失败",e);});}}).start();
    }
    private void importSettingsBackup(Uri uri){
        char[] password=pendingSettingsPassword;pendingSettingsPassword=null;if(password==null)return;long total=contentLength(uri);
        OperationProgressDialog pd=new OperationProgressDialog(this,"仅导入系统设置",true);pd.show();setBusy("正在导入系统设置…");
        new Thread(()->{try(InputStream in=getContentResolver().openInputStream(uri)){
            backupManager.importSettings(in,password,total,new SystemBackupManager.ExportProgress(){public void onProgress(String m,long d,long t){runOnUiThread(()->{pd.update(m,d,t);setProgressStatus(progress(m,d,t));});}public boolean isCancelled(){return pd.isCancelled();}});
            runOnUiThread(()->{pd.dismiss();restoreSavedCloudSettings();refreshRuntime();setIdle();setStatus("✓ 系统设置已导入；重复设置已覆盖，其他组件和文件保持不变");});
        }catch(Exception e){runOnUiThread(()->{pd.dismiss();setIdle();if(pd.isCancelled())Toast.makeText(this,"系统设置导入已取消",Toast.LENGTH_LONG).show();else error("系统设置导入失败",e);});}}).start();
    }

    private void showBackupHelp(){
        new AlertDialog.Builder(this).setTitle("全量备份包含内容").setMessage(
                "备份包括：\n"+
                "• GitHub 用户名、仓库、分支、Gradle 任务和 Token\n"+
                "• Token 使用备份密码进行 AES-GCM 加密\n"+
                "• 已下载的 JDK 11/17/21、当前 JDK 选择、Android SDK、Build Tools、Platform Tools\n"+
                "• Gradle 缓存与本地构建输出\n"+
                "• PRoot、依赖库和 Linux rootfs\n"+
                "• 当前导入的工程 ZIP\n"+
                "• App 私有工作目录、签名证书包及组件元数据\n\n"+
                "全量恢复会校验格式和 ABI，采用流式解密并按顶层目录原子覆盖，以减少大文件恢复卡死和自动退出。\n\n"+
                "‘仅导入/导出系统设置’只处理 GitHub 配置、Token、Gradle 任务和活动 JDK 选择；重复设置覆盖，其他工具链、工程与全量文件保持不变。请妥善保存密码；密码遗失后无法恢复。")
                .setPositiveButton("知道了",null).show();
    }

    private void exportBugLog(){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");i.putExtra(Intent.EXTRA_TITLE,"GradleApkBuilder-bug-report-"+System.currentTimeMillis()+".zip");startActivityForResult(i,EXPORT_BUG_LOG);
    }
    private void writeBugLog(Uri uri){
        OperationProgressDialog pd=new OperationProgressDialog(this,"导出 Bug 日志",true);pd.show();setBusy("正在生成 Bug 日志包…");
        new Thread(()->{try(OutputStream out=getContentResolver().openOutputStream(uri)){bugLog.log("INFO","Exporting bug report");
            bugLog.exportReport(out,runtime,projectZip,builtApk,new BugLogManager.ExportProgress(){
                public void onProgress(String m,long d,long t){runOnUiThread(()->{pd.update(m,d,t);setProgressStatus(progress(m,d,t));});}
                public boolean isCancelled(){return pd.isCancelled();}
            });
            runOnUiThread(()->{pd.dismiss();setIdle();Toast.makeText(this,"Bug 日志已导出",Toast.LENGTH_LONG).show();});
        }catch(Exception e){runOnUiThread(()->{pd.dismiss();setIdle();if(pd.isCancelled()){deleteDocumentQuietly(uri);Toast.makeText(this,"Bug 日志导出已取消",Toast.LENGTH_LONG).show();}else error("Bug 日志导出失败",e);});}}).start();
    }

    private void showAbout(){
        String version;
        try{version=getPackageManager().getPackageInfo(getPackageName(),0).versionName;}catch(Exception e){version="未知";}
        long versionCode;
        try{android.content.pm.PackageInfo pi=getPackageManager().getPackageInfo(getPackageName(),0);versionCode=Build.VERSION.SDK_INT>=28?pi.getLongVersionCode():pi.versionCode;}catch(Exception e){versionCode=-1;}
        String qq="653902670",email="mail@pt20.cn";
        String content="产品：小魁安卓编译\n英文名：CoryKui APKbuild\n版本："+version+"\n版本代码："+versionCode+
                "\n\n本地引擎：Android 原生工具链 / 可选 PRoot Linux\n备用引擎：GitHub Actions"+
                "\n\n本程序由 小魁老师 制作\nQQ:"+qq+"\nE-mail: "+email+
                "\n\n更新安装必须使用与旧版相同的签名证书。\n支持随机签名证书、签名包导入导出和编译前应用图标替换。";
        SpannableString aboutContent=new SpannableString(content);
        int qqStart=content.indexOf(qq),mailStart=content.indexOf(email);
        aboutContent.setSpan(new ClickableSpan(){@Override public void onClick(View widget){openQqChat(qq);}},qqStart,qqStart+qq.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        aboutContent.setSpan(new ClickableSpan(){@Override public void onClick(View widget){composeEmail(email);}},mailStart,mailStart+email.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        TextView view=text("");view.setText(aboutContent);view.setTextIsSelectable(false);view.setMovementMethod(LinkMovementMethod.getInstance());view.setLinksClickable(true);view.setPadding(dp(22),dp(8),dp(22),dp(12));
        ScrollView scroll=new ScrollView(this);scroll.addView(view);
        new AlertDialog.Builder(this).setTitle("关于我们 / 版本信息").setView(scroll).setPositiveButton("确定",null).show();
    }

    private void openQqChat(String qq){
        Intent app=new Intent(Intent.ACTION_VIEW,Uri.parse("mqqwpa://im/chat?chat_type=wpa&uin="+qq+"&version=1&src_type=web"));
        try{startActivity(app);}catch(Exception noQq){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://wpa.qq.com/msgrd?v=3&uin="+qq+"&site=qq&menu=yes")));}catch(Exception e){Toast.makeText(this,"无法打开 QQ 临时会话",Toast.LENGTH_LONG).show();}}
    }

    private void composeEmail(String address){
        Intent mail=new Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:"+address));mail.putExtra(Intent.EXTRA_EMAIL,new String[]{address});mail.putExtra(Intent.EXTRA_SUBJECT,"关于 CoryKui APKbuild");
        try{startActivity(Intent.createChooser(mail,"选择邮件应用"));}catch(Exception e){Toast.makeText(this,"手机上没有可用的邮件应用",Toast.LENGTH_LONG).show();}
    }

    private void showHelp(){new AlertDialog.Builder(this).setTitle("使用说明").setMessage("本地编译：\n1. 在 SDK 管理器点击“自动下载安装”。应用会自动查询 AndroidIDE 工具清单，下载并解压 Android SDK、Build Tools、Platform Tools、Command-line Tools 和可用 JDK 组件。\n2. 如自动目录不可用，也可通过导入功能安装受信任的工具链 ZIP。\n2. 导入 Android Studio 工程 ZIP。\n3. 选择 Gradle 任务并开始构建。\n4. 构建成功后导出 APK。\n\n新版可迁移工具链包会包含：\ntoolchain-package.properties\nchecksums.sha256\ncomponents/（JDK 11/17/21、活动版本选择、SDK、Build Tools 等）\nruntime/（可选 PRoot/rootfs）\n\n导入后会自动校验、安装、恢复执行权限并运行环境自检。旧版完整 PRoot ZIP 仍兼容\n\n完整工具链通常占用 2–6 GB。建议接通电源并保留足够空间。 ").setPositiveButton("知道了",null).show();}

    private void deleteDocumentQuietly(Uri uri){try{getContentResolver().delete(uri,null,null);}catch(Exception ignored){}}

    private static boolean isTransientBuildStatus(String line){
        if(line==null)return false;String text=line.trim();
        return text.startsWith("正在")||text.startsWith("下载")||text.startsWith("解压")||text.contains("（")&&text.contains("%）");
    }
    private void setBusy(String msg){setStatus(msg);localButton.setEnabled(false);cloudButton.setEnabled(false);exportButton.setEnabled(false);}
    private void setIdle(){clearProgressStatus();updateBuildButtons();exportButton.setEnabled(builtApk!=null&&builtApk.exists());}
    private void setStatus(String message){
        if(message==null||statusText==null)return;String record=message.replace("\r","").trim();if(record.isEmpty())return;
        if(!statusHistory.isEmpty()&&statusHistory.peekFirst().equals(record))return;
        statusHistory.addFirst(record);while(statusHistory.size()>20)statusHistory.removeLast();renderStatus();
    }
    private void setProgressStatus(String message){statusProgressLines.clear();if(message!=null)for(String line:message.replace("\r","").split("\n")){line=line.trim();if(!line.isEmpty())statusProgressLines.add(line);}while(statusProgressLines.size()>6)statusProgressLines.remove(statusProgressLines.size()-1);renderStatus();}
    private void clearProgressStatus(){statusProgressLines.clear();renderStatus();}
    private void renderStatus(){
        if(statusText==null)return;StringBuilder out=new StringBuilder();
        if(!statusProgressLines.isEmpty()){for(String line:statusProgressLines){if(out.length()>0)out.append('\n');out.append(line);}out.append("\n\n");}
        int records=0;for(String record:statusHistory){if(records++>=20)break;if(out.length()>0&&out.charAt(out.length()-1)!='\n')out.append("\n\n");out.append(record);}
        statusText.setText(out.toString());
    }
    private void updateBuildProgress(OperationProgressDialog dialog,String line){
        if(dialog==null||line==null)return;String text=line.trim();if(text.isEmpty())return;
        java.util.regex.Matcher matcher=java.util.regex.Pattern.compile("(?:（|\\()\\s*(\\d{1,3})%\\s*(?:）|\\))").matcher(text);
        if(matcher.find()){int value;try{value=Integer.parseInt(matcher.group(1));}catch(Exception e){value=0;}dialog.updatePercent(text,value,"");}else dialog.update(text,0,-1);
    }
    private Button statusJumpButton(String symbol,String description){Button b=new Button(this);b.setText(symbol);b.setTextSize(20);b.setTextColor(Color.argb(175,35,45,80));b.setBackgroundColor(Color.TRANSPARENT);b.setAlpha(0.72f);b.setContentDescription(description);b.setPadding(0,0,0,0);return b;}
    private void scrollStatusTop(){if(statusScroll!=null)statusScroll.post(()->statusScroll.fullScroll(View.FOCUS_UP));}
    private void scrollStatusBottom(){if(statusScroll!=null)statusScroll.post(()->statusScroll.fullScroll(View.FOCUS_DOWN));}
    private void updateBuildButtons(){boolean has=projectZip!=null&&projectZip.exists();if(localButton!=null)localButton.setEnabled(has&&runtime.isBuildReady());if(cloudButton!=null)cloudButton.setEnabled(has);}
    private static String progress(String m,long d,long t){if(t>0)return m+"\n"+human(d)+" / "+human(t)+"（"+(d*100/Math.max(1,t))+"%）";return m+"\n"+human(d);}
    private void error(String title,Exception e){if(bugLog!=null)bugLog.log("ERROR",title+": "+safe(e==null?null:e.getMessage()));new AlertDialog.Builder(this).setTitle(title).setMessage(safe(e.getMessage())).setPositiveButton("确定",null).show();}
    private static String safe(String s){if(s==null)return"未知错误";return s.replaceAll("gh[pousr]_[A-Za-z0-9_]+","[令牌已隐藏]");}
    private long contentLength(Uri uri){try(android.database.Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.SIZE},null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.SIZE);if(i>=0&&!c.isNull(i))return c.getLong(i);}}catch(Exception ignored){}return -1;}
    private static int backupStagePercent(String m){if(m==null)return 0;if(m.contains("解密"))return 25;if(m.contains("恢复全部"))return 65;if(m.contains("环境自检"))return 92;if(m.contains("完成"))return 100;return 10;}
    private String displayName(Uri uri){try(android.database.Cursor c=getContentResolver().query(uri,null,null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}catch(Exception ignored){}return null;}
    private static void copy(InputStream in,OutputStream out)throws IOException{if(in==null||out==null)throw new IOException("无法打开文件");byte[]b=new byte[65536];int n;while((n=in.read(b))>=0)out.write(b,0,n);}
    private TextView section(String s){TextView v=text(s);v.setTextSize(19);v.setTextColor(Color.rgb(25,35,65));v.setPadding(0,dp(18),0,dp(8));return v;}
    private TextView text(String s){TextView v=new TextView(this);v.setText(s);v.setTextSize(15);v.setTextColor(Color.rgb(55,65,85));v.setPadding(dp(2),dp(8),dp(2),dp(12));return v;}
    private EditText input(String hint,boolean password){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setTextSize(15);e.setPadding(dp(12),dp(10),dp(12),dp(10));if(password)e.setInputType(0x81);return e;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(16);return b;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private static String human(long n){if(n<1024)return n+" B";if(n<1048576)return String.format(java.util.Locale.US,"%.1f KB",n/1024.0);if(n<1073741824)return String.format(java.util.Locale.US,"%.1f MB",n/1048576.0);return String.format(java.util.Locale.US,"%.2f GB",n/1073741824.0);}
}
